var redimensionador0 = document.documentElement.clientWidth - 20 ;
var redimensionador1 = document.documentElement.clientWidth - 50 ;
var redimensionador3 = document.documentElement.clientWidth - 45 ;
function redimensionado0() { 
document.write (redimensionador0);
}
function redimensionado1() {
document.write (redimensionador1);
}
function redimensionado3() { 
document.write (redimensionador3);
}
function text0() {
document.write ("<span class=\"GloboTrans GlbNavy\" style=\"position:absolute; top: -127px; left: -95px; height:35px; width: ");
}
function text0_1() {
document.write ("px; \">");
}
function text0_final() {
document.write (text0() + redimensionado0() + text0_1());
}

function text1() {
document.write ("<span class=\"GloboTrans GlbMSNTOP\" style=\"position:absolute; top: -85px; left:-80px; width: ");
}
function text1_1() {
document.write ("px; height: 30px;\">");
}
function text1_final() {
document.write (text1() + redimensionado1() + text1_1());
}

var GlbGrande = document.documentElement.clientWidth - ( 114 * 2 ) - 13 ;
function GlbSolucion() {
document.write (GlbGrande);
}

function GlbTotal0() {
document.write ("<div class=\"GloboTrans GlbTransparent\" id=\"content-3\" style=\"width: ");
}
function GlbTotal0_1() {
document.write ("px;\">");
}
function GlbTotal0_final() {
document.write (GlbTotal0() + GlbSolucion() + GlbTotal0_1());
}

function GlbFooterTotal0() {
document.write ("<div class=\"divXulo\" style=\"width: ");
}
function GlbFooterTotal0_1() {
document.write ("px;\">");
}
function GlbFooterTotal0_final() {
document.write (GlbFooterTotal0() + redimensionado3() + GlbFooterTotal0_1());
}

var redimensionador4 = document.documentElement.clientWidth - 264 ;

function redimensionado4() {
document.write (redimensionador4);
}

function GlbPieTotal1() { 
document.write ("<div class=\"divFuckinFooter\" id=\"content-4\" style=\"width: ");
}
function GlbPieTotal1_1() { 
document.write ("px;\">");
}
function GlbPieTotal1_final() { 
document.write (GlbPieTotal1() + redimensionado4() + GlbPieTotal1_1());
}

//------------------------------------------------------ Fin de redimensionadores, empiezan Tabs -------------------------------//

var tab1 = document.documentElement.clientWidth - 461 ;
var tab2 = document.documentElement.clientWidth - 415 ;
var search3 = document.documentElement.clientWidth - 159 ;
var addon0 = document.documentElement.clientWidth - 265 ;

function tab1_p() {
document.write (tab1);
}

function tab1_d() {
document.write ("<div style=\"position:absolute; top:239px; left: ");
}
function tab1_1d() {
document.write ("px; \">");
}
function tab1_finald() {
document.write (tab1_d() + tab1_p() + tab1_1d());
}

function tab2_p() {
document.write (tab2);
}

function tab2_d() {
document.write ("<div style=\"position:absolute; left:");
}
function tab2_1d() {
document.write ("px; \">");
}
function tab2_finald() {
document.write (tab2_d() + tab2_p() + tab2_1d());
}

function search3_p() {
document.write (search3);
}

function search3_d() {
document.write ("<div style=\"background-color: #D8D8D8; border: 1px solid #0B6138; height: 18px; width: 130px; position:absolute; top:80px; left: ");
}
function search3_1d() {
document.write ("px; z-index: 5000; -moz-border-radius: 5px; -khtml-border-radius: 5px; -webkit-border-radius: 5px;\">");
}
function search3_finald() {
document.write (search3_d() + search3_p() + search3_1d());
}

function addon0_p() {
document.write (addon0);
}

function addon0_d() {
document.write ("<span style=\"position:absolute; left: ");
}
function addon0_1d() {
document.write ("px; top:0px; color:Red; font-size:12px; font-weight:Bold;\">");
}
function addon0_finald() {
document.write (addon0_d() + addon0_p() + addon0_1d());
}

//-----------Div proprio------------//
//var resized = document.documentElement.clientWidth - 210 ;
//var resized_h = resized_h0() - resized_h1() - 15 ;
//function resized_h0() {document.write (document.getElementById('content-3').offsetTop);}
//function resized_h1() {document.write (document.getElementById('content-5').offsetTop);}

//function resized0() {document.write (resized);}
//function resized1() {document.write ("");}
//function resized1_1() {document.write ("");}
//function resized1_2() {document.write ("");}
//function resized1_2_1() {document.write ("");}
//function resized1() {document.write ();}
// BETA Activa

//-----------Fin Div Propio-------//

//---------------------------//

//function fix() {
//document.write ("0");
//}
