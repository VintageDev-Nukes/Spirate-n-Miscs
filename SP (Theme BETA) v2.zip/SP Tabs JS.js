function Code() {
document.write ( '<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd"><html xmlns="http://www.w3.org/1999/xhtml"><head><script language="Javascript"> function mostrar(nombreCapa){ document.getElementById(nombreCapa).style.visibility="visible"; } function ocultar(nombreCapa){ document.getElementById(nombreCapa).style.visibility="hidden"; } </script> <meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" /></head><body><div id="window1" style="position:absolute; z-index:10; left:1px; top:1px; width:1146px;background-color:#dde3eb; border:1px solid #464f5a; visibility:hidden"> <div style="padding-bottom:8px; width:1146px; height:20px; background-color:#718191; border-bottom:1px solid #464f5a;" onMouseDown="beginDrag(this.parentNode, event);"><div style="position:absolute; top:1px; left:5px; font-size:20px; font-weight:bold; color:#FFFFFF;"> <center>' )
}

function Code0() {
document.write ( '</center> </div><div style="position:absolute; top:3px; left:1132px; float:right;"> <div onclick="ocultar(\'window1\')"><img src="http://i.imgur.com/Fd6Q2.png" border="0" title="Cerrar" /></div></div> </div> <div style="margin-left:5px;">' )
}

function Code1() {
document.write ( '</div></div></body></html>' )
}

function Code2() {
document.write ( '<div id="capa1" onclick="mostrar(\'window1\')">' )
}

function Code3() {
document.write ( '</div>' )
}

function FirefoxDet() {
    document.write('<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd"><html xmlns="http://www.w3.org/1999/xhtml"><head><script language="Javascript"> function ocultar(nombreCapa){ document.getElementById(nombreCapa).style.visibility="hidden"; }</script></script><meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" /></head><body><div id="window2" style="position:absolute; z-index:10; left:350px; top:160px; width:400px;background-color:#dde3eb; border:1px solid #464f5a;"> <div style="padding-bottom:8px; width:400px; height:10px; background-color:#718191; border-bottom:1px solid #464f5a;" onMouseDown="beginDrag(this.parentNode, event);"><div style="position:absolute; top:1px; left:5px; font-size:16px; font-weight:bold; color:#FFFFFF;">Ventana flotante</div><div style="position:absolute; top:3px; left:377px; float:right;"><div onclick="ocultar(\'window2\')"><img src="img/cerrar.jpg" border="0" title="cerrar" /></div></div></div><br/><div  style="margin-left:20px;">está usando Firefox...</div><br/></div></body></html>');
}
