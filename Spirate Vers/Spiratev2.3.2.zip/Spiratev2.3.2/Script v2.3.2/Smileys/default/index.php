<script LANGUAGE="JavaScript">
var pagina="http://www.ga-mex-almacen.net"
function redireccionar()
{
location.href=pagina
}
setTimeout ("redireccionar()", 1000);
</script>
