<?php
if (!defined('SMF')) die('Error');
function CalendarMain(){}
function calendarBirthdayArray(){}
function calendarEventArray(){}
function calendarHolidayArray(){}
function calendarCanLink(){}
function CalendarPost(){}

?>