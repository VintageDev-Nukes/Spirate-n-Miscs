<?php
$shopVersion['develVersion'] = false;
$shopVersion['version'] = "1.0";
$shopVersion['build'] = "Por Admin";
$shopVersion['date'] = "10/8/08";
$shopVersion['SVNdate'] = '$Date: $'; 
$shopVersion['SVNid'] = '$Id: $';
?>