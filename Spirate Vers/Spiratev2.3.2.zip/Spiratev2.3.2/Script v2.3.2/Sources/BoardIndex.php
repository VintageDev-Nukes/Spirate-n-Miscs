<?php

if (!defined('SMF'))
	die('Error');
	
function BoardIndex(){}
function calendarDoIndex(){}


?>