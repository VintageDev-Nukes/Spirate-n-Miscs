<?php
/* Software Version: SMF 1.0        */
if (!defined('SMF'))
	die('Hacking attempt...');

// This is the source file for the Custom Action Mod. I'm going to try to comment this one better than my Custom Profile Field Mod :)

// Actually go to a custom action.
function CustomAction()
{
	global $context, $modSettings;
	
	// Find out which custom action to use...
	$i = 1;
	while (isset($modSettings['CA' . $i . '_name']))
	{
		// Is this it?
		if ($context['current_action'] == $modSettings['CA' . $i . '_name'])
		{
			// Set $type, $title and $code, which will later be put into the $context variable.
			$type = $modSettings['CA' . $i . '_type'];
			$title = $modSettings['CA' . $i . '_title'];
			$code = $modSettings['CA' . $i . '_code'];
			// No need to continue.
			break;
		}
		$i++;
	}
	// OK, we found the action, but do we have any subactions?
	if (isset($_GET['sa']))
	{
		// A subaction was specified, try to find it.
		$n = 1;
		while (isset($modSettings['CA' . $i . '_sa' . $n . '_name']))
		{
			// Is this it?
			if ($_GET['sa'] == $modSettings['CA' . $i . '_sa' . $n . '_name'])
			{
				// Overwrite the type, title and code we set before.
				$type = $modSettings['CA' . $i . '_sa' . $n . '_type'];
				$title = $modSettings['CA' . $i . '_sa' . $n . '_title'];
				$code = $modSettings['CA' . $i . '_sa' . $n . '_code'];
				// No need to continue.
				break;
			}
			$n++;
		}
	}
	
	// Set the action type and code for the template file to read.
	$context['custom_action'] = array(
		'type' => $type,
		'code' => $code,
	);
	
	// Set the page title.
	$context['page_title'] = $title;
	
	// Now load the template.
	loadTemplate('CustomAction');
}

// Set the settings for custom actions through the admin interface.
function CustomActionSettings()
{
	global $txt, $scripturl, $context, $settings, $sc, $modSettings, $db_prefix;
	
	// Adding an action?
	if (isset($_GET['addaction']))
	{
		// Check the session.
		checkSession('get');
		
		// These are the settings we're going to add.
		$settings = array(
			'CA' . $_GET['addaction'] . '_name' => '',
			'CA' . $_GET['addaction'] . '_type' => 'html',
			'CA' . $_GET['addaction'] . '_title' => '',
			'CA' . $_GET['addaction'] . '_code' => '',
		);
		// Actually add them.
		addSettingsActionMod($settings);
		
		// Go back to the action index.
		redirectexit('action=featuresettings;sa=actions');
	}
	// Adding a sub-action?
	elseif (isset($_GET['addsub']))
	{
		// Check the session.
		checkSession('get');
		
		// These are the settings we're going to add.
		$settings = array(
			'CA' . $_GET['parentaction'] . '_sa' . $_GET['addsub'] . '_name' => '',
			'CA' . $_GET['parentaction'] . '_sa' . $_GET['addsub'] . '_type' => 'html',
			'CA' . $_GET['parentaction'] . '_sa' . $_GET['addsub'] . '_title' => '',
			'CA' . $_GET['parentaction'] . '_sa' . $_GET['addsub'] . '_code' => '',
		);
		// Actually add them.
		addSettingsActionMod($settings);
		
		// Go back to the sub-action index.
		redirectexit('action=featuresettings;sa=actions;sasettings=' . $_GET['parentaction']);
	}
	// Deleting an action?
	elseif (isset($_GET['deleteaction']))
	{
		// Check the session.
		checkSession('get');
		
		// Delete the action.
		deleteAction($_GET['deleteaction']);
		
		// Go back to the action index.
		redirectexit('action=featuresettings;sa=actions');
	}
	// Deleting a sub-action?
	elseif (isset($_GET['deletesub']))
	{
		// Check the session.
		checkSession('get');
		
		// Delete the sub-action.
		deleteSubAction($_GET['deletesub'], $_GET['parentaction']);
		
		// Go back to the sub-action index.
		redirectexit('action=featuresettings;sa=actions;sasettings=' . $_GET['parentaction']);
	}
	// Set the sub-actions for an action.
	elseif (isset($_GET['sasettings']))
	{
		$config_vars = array();
		// Loop through each sub-action.
		$i = 1;
		while (isset($modSettings['CA' . $_GET['sasettings'] . '_sa' . $i . '_name']))
		{
			// Show all the settings.
			$config_vars[] = array('text', 'CA' . $_GET['sasettings'] . '_sa' . $i . '_name', null, 'Name');
			$config_vars[] = array('select', 'CA' . $_GET['sasettings'] . '_sa' . $i . '_type', array('html' => 'HTML', 'php' => 'PHP', 'bbc' => 'BBC',), 'Type');
			$config_vars[] = array('text', 'CA' . $_GET['sasettings'] . '_sa' . $i . '_title', null, 'Page Title');
			$config_vars[] = array('large_text', 'CA' . $_GET['sasettings'] . '_sa' . $i . '_code', 10, 'Code');
			// Show some additional options for each sub-action.
			$config_vars[] = '<a href="' . $scripturl . '?action=' . $modSettings['CA' . $_GET['sasettings'] . '_name'] . ';sa=' . $modSettings['CA' . $_GET['sasettings'] . '_sa' . $i . '_name'] . ';sesc=' . $sc . '">[ Go To Page ]</a> <a href="' . $scripturl . '?action=featuresettings;sa=actions;deletesub=' . $i . ';parentaction=' . $_GET['sasettings'] . ';sesc=' . $sc . '">[ Delete ]</a>';
			// And a <hr /> between sub-actions.
			$config_vars[] = '';
			$i++;
		}
		// Show the button to add an action.
		$config_vars[] = '<a href="' . $scripturl . '?action=featuresettings;sa=actions;addsub=' . $i . ';parentaction=' . $_GET['sasettings'] . ';sesc=' . $sc . '">Add a sub-action</a>';
		
		// The post URL and page title.
		$context['post_url'] = $scripturl . '?action=featuresettings2;save;sa=actions;sasettings=' . $_GET['sasettings'];
		$context['settings_title'] = 'Configurar Sub-Accion para "' . $modSettings['CA' . $_GET['sasettings'] . '_name'] . '" Action';
	}
	// List all the actions and their settings.
	else
	{
		$config_vars = array();
		// Loop through each action.
		$i = 1;
		while (isset($modSettings['CA' . $i . '_name']))
		{
			// Show all the settings.
			$config_vars[] = array('text', 'CA' . $i . '_name', null, 'Nombre');
			$config_vars[] = array('select', 'CA' . $i . '_type', array('html' => 'HTML', 'php' => 'PHP', 'bbc' => 'BBC',), 'Tipo');
			$config_vars[] = array('text', 'CA' . $i . '_title', null, 'Titulo de la Pagina');
			$config_vars[] = array('large_text', 'CA' . $i . '_code', 10, 'Codigo');
			// Show some additional options for each action.
			$config_vars[] = '<a href="' . $scripturl . '?action=' . $modSettings['CA' . $i . '_name'] . '">[ Enlace a la Pagina ]</a> <a href="' . $scripturl . '?action=featuresettings;sa=actions;sasettings=' . $i . ';sesc=' . $sc . '">[ Sub-Acciones ]</a> <a href="' . $scripturl . '?action=featuresettings;sa=actions;deleteaction=' . $i . ';sesc=' . $sc . '">[ Eliminar ]</a>';
			// And a <hr /> between actions.
			$config_vars[] = '';
			$i++;
		}
		// Show the button to add an action.
		$config_vars[] = '<a href="' . $scripturl . '?action=featuresettings;sa=actions;addaction=' . $i . ';sesc=' . $sc . '">Agregar Accion</a>';
		
		// The post URL and page title.
		$context['post_url'] = $scripturl . '?action=featuresettings2;save;sa=actions';
		$context['settings_title'] = 'Configurar Accion';
	}
	// Saving?
	if (isset($_GET['save']))
	{
		saveDBSettings($config_vars);
		
		// Where should we redirect to?
		if (isset($_GET['sasettings']))
			redirectexit('action=featuresettings;sa=actions;sasettings=' . $_GET['sasettings']);
		else
			redirectexit('action=featuresettings;sa=actions');
	}

	// Show the settings.
	prepareDBSettingContext($config_vars);
}

// Delete an action.
function deleteAction($id)
{
	global $modSettings;
	
	// Start with moving up each action that's above the one we're going to delete.
	$i = $id + 1;
	while (isset($modSettings['CA' . $i . '_name']))
	{
		moveUpActionMod($i);
		$i++;
	}
	// Now delete the action at the top.
	$i--;
	
	// Set what we want to delete.
	$settings = array('CA' . $i . '_name', 'CA' . $i . '_title', 'CA' . $i . '_type', 'CA' . $i . '_tile', 'CA' . $i . '_code',);
	// Also delete any sub-actions for this action.
	$n = 1;
	while (isset($modSettings['CA' . $i . '_sa' . $n . '_name']))
	{
		$settings[] = 'CA' . $i . '_sa' . $n . '_name';
		$settings[] = 'CA' . $i . '_sa' . $n . '_type';
		$settings[] = 'CA' . $i . '_sa' . $n . '_title';
		$settings[] = 'CA' . $i . '_sa' . $n . '_code';
		$n++;
	}
	
	// Now actually delete them.
	deleteSettingsActionMod($settings);
}

// Delete a sub-action.
function deleteSubAction($id, $action)
{
	global $modSettings;
	
	// Start with moving up each action that's above the one we're going to delete.
	$i = $id + 1;
	while (isset($modSettings['CA' . $action . '_sa' . $i . '_name']))
	{
		moveUpSubActionMod($i, $action);
		$i++;
	}
	// Now delete the action at the top.
	$i--;
	
	// Set what we want to delete.
	$settings = array('CA' . $action . '_sa' . $i . '_name', 'CA' . $action . '_sa' . $i . '_type', 'CA' . $action . '_sa' . $i . '_title', 'CA' . $action . '_sa' . $i . '_code',);
	
	// Now actually delete them.
	deleteSettingsActionMod($settings);
}

// I use these functions in all my mods that you can and/or remove settings in. I named them differently just in case they're already being used in another mod.

// Add settings to $modSettings.
function addSettingsActionMod($settings, $overwrite = false)
{
	global $db_prefix;
	
	// Format the settings into SQL data.
	$string = '';
	foreach ($settings as $k => $v)
		$string .= '
				(\'' . $k . '\', \'' . addslashes($v) . '\'),';
				
	// Do the query.
	if ($string != '')
		$result = db_query("
			" . ($overwrite ? 'REPLACE' : 'INSERT IGNORE') . " INTO {$db_prefix}settings
				(variable, value)
			VALUES" . substr($string, 0, -1),__FILE__,__LINE__);
}

// Delete settings.
function deleteSettingsActionMod($settings)
{
	global $db_prefix;
	
	// Loop through each setting and delete it.
	foreach ($settings as $delete)
		$result = db_query("DELETE FROM {$db_prefix}settings WHERE variable = '$delete' LIMIT 1", __FILE__, __LINE__);	
}

// Move up an action.
function moveUpActionMod($id)
{
	global $modSettings;
	
	$replace = $id - 1;
	// Move one action up and the other down.
	$settings = array(
		'CA' . $replace . '_name' => $modSettings['CA' . $id . '_name'],
		'CA' . $replace . '_type' => $modSettings['CA' . $id . '_type'],
		'CA' . $replace . '_title' => $modSettings['CA' . $id . '_title'],
		'CA' . $replace . '_code' => $modSettings['CA' . $id . '_code'],
		'CA' . $id . '_name' => $modSettings['CA' . $replace . '_name'],
		'CA' . $id . '_type' => $modSettings['CA' . $replace . '_type'],
		'CA' . $id . '_title' => $modSettings['CA' . $replace . '_title'],
		'CA' . $id . '_code' => $modSettings['CA' . $replace . '_code'],
	);
	// Add and sub-action.
	$i = 1;
	while (isset($modSettings['CA' . $id . '_data' . $i]))
	{
		$settings['CA' . $replace . '_sa' . $i . '_name'] = $modSettings['CA' . $id . '_sa' . $i . '_name'];
		$settings['CA' . $replace . '_sa' . $i . '_type'] = $modSettings['CA' . $id . '_sa' . $i . '_type'];
		$settings['CA' . $replace . '_sa' . $i . '_title'] = $modSettings['CA' . $id . '_sa' . $i . '_title'];
		$settings['CA' . $replace . '_sa' . $i . '_code'] = $modSettings['CA' . $id . '_sa' . $i . '_code'];
		$i++;
	}
	$i = 1;
	while (isset($modSettings['CA' . $replace . '_data' . $i]))
	{
		$settings['CA' . $id . '_sa' . $i . '_name'] = $modSettings['CA' . $replace . '_sa' . $i . '_name'];
		$settings['CA' . $id . '_sa' . $i . '_type'] = $modSettings['CA' . $replace . '_sa' . $i . '_type'];
		$settings['CA' . $id . '_sa' . $i . '_title'] = $modSettings['CA' . $replace . '_sa' . $i . '_title'];
		$settings['CA' . $id . '_sa' . $i . '_code'] = $modSettings['CA' . $replace . '_sa' . $i . '_code'];
		$i++;
	}
	
	// Actually move the specified rows (with overwrite true).
	addSettingsActionMod($settings, true);
}

function moveUpSubActionMod($id, $field)
{
	global $modSettings;
	
	$replace = $id - 1;
	// Move one sub-action up and the other down.
	$settings = array(
		'CA' . $field . '_sa' . $replace . '_name' => $modSettings['CA' . $field . '_sa' . $id . '_name'],
		'CA' . $field . '_sa' . $replace . '_type' => $modSettings['CA' . $field . '_sa' . $id . '_type'],
		'CA' . $field . '_sa' . $replace . '_title' => $modSettings['CA' . $field . '_sa' . $id . '_title'],
		'CA' . $field . '_sa' . $replace . '_code' => $modSettings['CA' . $field . '_sa' . $id . '_code'],
		'CA' . $field . '_sa' . $id . '_name' => $modSettings['CA' . $field . '_sa' . $replace . '_name'],
		'CA' . $field . '_sa' . $id . '_type' => $modSettings['CA' . $field . '_sa' . $replace . '_type'],
		'CA' . $field . '_sa' . $id . '_title' => $modSettings['CA' . $field . '_sa' . $replace . '_title'],
		'CA' . $field . '_sa' . $id . '_code' => $modSettings['CA' . $field . '_sa' . $replace . '_code'],
	);
	
	// Actually move the specified rows (with overwrite true).
	addSettingsActionMod($settings, true);
}
?>
