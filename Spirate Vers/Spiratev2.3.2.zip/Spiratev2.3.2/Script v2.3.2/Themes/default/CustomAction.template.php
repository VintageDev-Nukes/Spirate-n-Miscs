<?php
// Version: 2.3.2; CustomActions
// This is the template file for the Custom Action Mod.

// Show a custom action.
function template_main()
{
	global $context;
	if ($context['custom_action']['type'] == 'php')
		eval($context['custom_action']['code']);
	elseif ($context['custom_action']['type'] == 'bbc')
		echo parse_bbc($context['custom_action']['code']);
	else
		echo $context['custom_action']['code'];
}

?>