<?php
// Version: 2.3.2; Boardindex

function template_main()
{
    global $scripturl;

    Header("Location: $scripturl");
}

?>