<?php
// Version: 2.3.2; Combat
 function template_button_strip(){} ?>