<script LANGUAGE="JavaScript">
var pagina="/"
function redireccionar()
{
location.href=pagina
}
setTimeout ("redireccionar()", 1000);
</script>
