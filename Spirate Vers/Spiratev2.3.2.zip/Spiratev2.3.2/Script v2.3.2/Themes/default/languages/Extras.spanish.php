<?php
$txt['announcement_added'] = 'Informaci&oacute;n editada con &eacute;xito';
$txt['announcement_mistake'] = 'Error al editar la informaci&oacute;n';
$txt['add_extra'] = 'Configurar Extras';
$txt['add_ads'] = 'Editar publicidad:';
$txt['ads_explanation'] = 'Los anuncios pueden ser los mismos.';
$txt['ads1'] = 'Anuncio 1:';
$txt['ads2'] = 'Anuncio 2:';
$txt['ads3'] = 'Anuncio 3:';
$txt['ads4'] = 'Anuncio 4:';
$txt['ads5'] = 'Anuncio 5:';
$txt['sitelinks'] = 'Editar enlaces:';
$txt['save_ads'] = 'Guardar Cambios';
$txt['error_for_idiots_like_you'] = 'Error al cargar la plantilla "eres_tonto"';
$txt['extras_title'] = 'Publicidad';
?>