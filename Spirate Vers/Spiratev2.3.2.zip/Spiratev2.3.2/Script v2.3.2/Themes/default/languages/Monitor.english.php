﻿<?php
$txt['last_comments_post'] = 'Latest comments in your posts';
$txt['no_comments_go_home'] = 'Nothing in here,...';
$txt['last_comments_image'] = 'Latest comments in your images';
$txt['last_points_recieved'] = 'Latest points received';
$txt['last_favourites_added'] = 'Posts in favorites (Latest)';
$txt['last_comments_added'] = 'Latest comments in your posts';
$txt['last_comments_added_gallery'] = 'Latest comments in your images';
$txt['monitor_error_1'] = '&iexcl;Atention!';
$txt['private_function'] = 'This function is just for logged users.';
$txt['monitor_points'] = 'Points';
$txt['monitor_images'] = 'Images';
$txt['monitor_added_by'] = 'Added By;';
$txt['monitor_go_home'] = 'Go Home';
$txt['monitor_title']= 'User Monitor';
?>