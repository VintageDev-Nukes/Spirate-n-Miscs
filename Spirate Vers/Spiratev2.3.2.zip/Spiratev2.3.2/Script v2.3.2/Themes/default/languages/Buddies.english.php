<?php
$txt['Buddies_again'] = 'This Is Already Your Buddy.';
$txt['Buddies_added'] = '&iexcl;Added As Buddy!';
$txt['Buddies_youself'] = '&iexcl;You Can not Add You As Buddy!';
$txt['Buddies_center'] = 'Buddies Center';
$txt['Buddies_permission_short'] = '%s Wants To Be Your Buddy';
$txt['Buddies_permission_long'] = '%s Wants To Be Your Buddy. [url=%s]Click Here[/url] To Go To The Buddies Page.Then Accept Him Or Not';
$txt['Buddies_none'] = 'You Have Not Buddies In Your List';
$txt['Buddies_del'] = 'Delete Buddy';
$txt['Buddies_move_up'] = 'Move Up Buddy';
$txt['Buddies_move_down'] = 'Move Down Buddy';
$txt['Buddies_not_aproved'] = 'Buddies Not Aproved';
$txt['Buddies_aprove'] = 'Aprove Buddy';
$txt['Buddies_pend'] = 'Buddies Pend';
?>