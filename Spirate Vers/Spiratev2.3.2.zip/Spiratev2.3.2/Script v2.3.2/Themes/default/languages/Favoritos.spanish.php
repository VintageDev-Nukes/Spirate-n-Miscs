<?php
$txt['post_already_added_to_favorites'] = 'Ya tienes este post en tus favoritos!';
$txt['added_to_favorites'] = 'Agregado a favoritos';
$txt['my_favorites'] = 'Mis Favoritos';
$txt['no_favorites'] = 'No tienes ning&uacute;n post favorito';
$txt['selected_favorites'] = 'Favorito/s Seleccionado/s:';
$txt['favorites_ads'] = 'Publicidad';
?>