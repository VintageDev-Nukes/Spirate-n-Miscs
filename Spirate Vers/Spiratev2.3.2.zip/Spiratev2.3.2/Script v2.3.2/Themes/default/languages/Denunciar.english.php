<?php
//report!!
$txt['comment_denunciation'] = 'You have to writte the reason of your report.';
$txt['select_post'] = 'You have not selected which post';
$txt['denounce_post'] = 'Report post';
$txt['denounce_login'] = 'Excuse me, to  report a post you have to be logged.';
$txt['principal_page'] = 'Go home';
$txt['denounce_to_post'] = 'Report the post:';
$txt['created_by'] = 'Created by:';
$txt['denounce_reason'] = 'Reason:';
$txt['denounce_repost'] = 'Re-post';
$txt['denounce_spam'] = 'It�s spam';
$txt['denounce_links'] = 'Dead links';
$txt['denounce_disrespectful'] = 'Racist or rude';
$txt['denounce_personal_information'] = 'It has personal information';
$txt['denounce_mayus'] = 'The title is in caps';
$txt['denounce_porn'] = 'It has pornography';
$txt['denounce_gore'] = 'It is gore';
$txt['denounce_fount'] = 'Est&aacute; mal la fuente';
$txt['denounce_poor'] = 'Post too poor';
$txt['denounce_pass'] = 'No se encuentra el pass';
$txt['denounce_protocol'] = 'Out of the protocol';
$txt['denounce_other'] = 'Another reason (specify)';
$txt['denounce_explanation'] = 'Explanation:';
$txt['repost_link'] = 'If it�s re-post you have to put the original link.';
$txt['denounce_envoy'] = 'Report sent';
$txt['denounce_envoy2'] = 'Your report has been sent.';
$txt['denounce_titulo'] = "Report post";

?>