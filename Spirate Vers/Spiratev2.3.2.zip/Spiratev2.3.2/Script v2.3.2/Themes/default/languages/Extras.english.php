<?php
$txt['announcement_added'] = 'Announcement Added';
$txt['announcement_mistake'] = 'There Was An Error Adding The Announcement';
$txt['add_extra'] = "Extra�s Settings";
$txt['add_ads'] = 'Edit Ads:';
$txt['ads_explanation'] = 'The Ads Can Have The Same.';
$txt['ads1'] = 'Ad 1:';
$txt['ads2'] = 'Ad 2:';
$txt['ads3'] = 'Ad 3:';
$txt['ads4'] = 'Ad 4:';
$txt['ads5'] = 'Ad 5:';
$txt['sitelinks'] = 'Edit Links:';
$txt['save_ads'] = 'Save Changes';
$txt['error_for_idiots_like_you'] = 'There Was An Error While Opening The Template "You_Are_A_Fool"';
$txt['extras_title'] = 'Ads';
?>