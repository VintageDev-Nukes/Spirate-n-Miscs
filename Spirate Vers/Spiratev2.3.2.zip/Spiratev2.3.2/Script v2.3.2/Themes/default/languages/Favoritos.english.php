<?php
$txt['post_already_added_to_favorites'] = 'You have already this post as your favorite!';
$txt['added_to_favorites'] = 'Added to favorites';
$txt['my_favorites'] = 'My favorites';
$txt['no_favorites'] = 'You have not selected any favorite post';
$txt['selected_favorites'] = 'Favorite/s selected/s:';
$txt['favorites_ads'] = 'Ads';
?>