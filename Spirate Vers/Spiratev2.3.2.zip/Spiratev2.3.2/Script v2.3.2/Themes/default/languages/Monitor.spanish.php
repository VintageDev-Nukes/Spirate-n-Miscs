﻿<?php
$txt['last_comments_post'] = '&Uacute;ltimos comentarios de tus posts';
$txt['no_comments_go_home'] = 'Nada por aqu&iacute,...';
$txt['last_comments_image'] = '&Uacute;ltimos comentarios de tus im&aacute;nes';
$txt['last_points_recieved'] = '&Uacute;ltimos puntos obtenidos';
$txt['last_favourites_added'] = 'Posts en favoritos (&uacute;ltimos)';
$txt['last_comments_added'] = '&Uacute;ltimos comentarios de tus posts';
$txt['last_comments_added_gallery'] = '&Uacute;ltimos comentarios de tus im&aacute;genes';
$txt['monitor_error_1'] = '&iexcl;Atenci&oacute;n!';
$txt['private_function'] = 'Esta funci&oacute;n es solo para usuarios registrados.';
$txt['monitor_points'] = 'Puntos';
$txt['monitor_images'] = 'Imágenes';
$txt['monitor_added_by'] = 'Lo agreg&oacute;';
$txt['monitor_go_home'] = 'Ir a la P&aacute;gina principal';
$txt['monitor_title']= 'Monitor de usuario';
?>