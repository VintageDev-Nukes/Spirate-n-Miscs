<?php
$txt['Protocolo'] = 'Protocol';
$txt['Introduccion'] = 'Introduction';
$txt['Mensaje_1'] = 'this is an entertainment site for english users in which users share information about various topics (links, images, news, videos, etc..) through posts. <br> <br> this site was created with the idea to answer questions and discuss such topics as a web. <br> moderators are in charge of filtering, removing or editing the information shared in this way, we prevent the contents from becoming a large amount of "nothing" and always maintain the highest possible quality. there are rules which underpin the management philosophy called a protocol and is detailed below. ';
$txt['Caracteristicas'] = 'Features to post';
$txt['Mensaje_Protocolo'] = '<p>* Subject without caps (this indicates that you are shouting).</p>
<p>*That the font size is adequate (there may be exceptions in key words).</p>
<p>* Be as descriptive or as clear as possible, at the time of posting, to avoid misunderstandings , or comment or post being removed. </ p>
<p> * Posting on the right category. </p>
<p> * See if the links work properly. </p>
<p>* Do not reveal personal information about y rself or others such as e-mail, msn, full name, phones, etc ... This web does not take the trouble of publishing such content.) </p>
<br />
<p> <b> + Posts are removed: </b> </p>
<p> * If it is considered spam </p>
* If it  is repost <p>. </p>
<p> *  If it contains a vulgar vocabulary. </p>
<p> * If it refers to the violation of human rights. </ p>
<p>* If it has dead links.</p>
<p>* If you publish content without licence (demo).</p>
<p> * that contains pornographic material (images, videos, links, etc). </p>
<br/>
<p> <b> + are modified post containing: </b> </p>
<p> * that does not comply with the characteristics to post. </p>
<p> * title with opinions. </p>
<p> * containing spelling mistakes. </p>
<p> * post with more than 1000 comments (comments are closed). </p>
<br/>
<p> <b> + are removed comments containing: </b> </p>
<p> * all caps or abuse using caps. </ p>
<p> * that the user was the first to comment his post. </p>
<p> * name calling, insults, etc. (to another user or in general). </p>
<p> * comments racist. </p>
<p> * very large fonts or with the clear effect of attention. </p>
<p> * spam. </p>
<br/>
<p> <b> + are eliminated or suspended users: </b> </p>
<p> * users that are used to be the first to comment(in his gallery). </ p>
<p> * racist comments . </p>
* users who post <p> pornographic material or material morvan </p>
<br />
<p> <b> + are modified to the user: </b> </p>
<p> * when you have a firm with spam. </p>
<p> * when you have personal message spam. </p>
<p> * when you have an avatar with pornographic content. </p>
<p> * when the avatar url does not work. </p>
<br/>
<p> <b> + eliminate or modify the images in the gallery that contains: </b> </p>
<p> * spam (image with a site url) </p>
<p> * pictures with pornography. </p>
* images <p> morbid. </p>
<br/>
<p> <b> + comments are deleted in the gallery that contains: </b> </p>
<p> * spam </p>
<p> * name calling, insults, descrimination, etc. (to another user or in general). </p>
<p> * very large fonts or with the clear effect of attention. </p>
<p> * all caps or abuse of them. </p>
<p> * that the user is the first to discuss his image. </p>';

?>