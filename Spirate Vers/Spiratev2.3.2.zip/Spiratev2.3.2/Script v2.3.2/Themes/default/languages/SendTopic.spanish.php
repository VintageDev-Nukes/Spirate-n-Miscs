<?php
$txt['send_post'] = 'Enviar Post';
$txt['email_amigo'] = 'E-mail de tu amigo';
$txt['Asunto'] = 'Asunto';
$txt['Mensaje'] = 'Mensaje';
$txt['Mensaje_mail'] = 'Hola! Te recomiendo que veas este post! Saludos!';
$txt['Value_recomendar'] = 'Recomendar post';
$txt['send_no_friend'] = 'No has ingresado el e-mail de tu amigo.';
$txt['send_no_mess'] = 'No has ecrito ningun mensaje.';
$txt['send_from'] = 'Este mensaje ha sido enviado desde';
$txt['send_link'] = 'Enlace: ';
?>