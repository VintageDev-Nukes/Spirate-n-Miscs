<?php
//widget.english.php
$txt['should_be_integer'] = 'You have to write a number in the space to put how many posts';
$txt['should_input_something'] = 'You have to write a number in the list of posts';
$txt['maximun_listed_topics'] = 'The highest number can be';
$txt['title'] = 'Widget';
$txt['how_to_implement'] = 'It shows the latest post,so you can be aware.<br />

      In a few seconds you will have a lists of posts that will have the latest posts published.<br />
      You can customize it,and adapt it to the style of your site changing the size, color, number of posts and also select the category.<br /><br />

      <b>How to use it:</b><br />
      <b>1.</b> Customize it. Select a category, number of posts, size and color.<br />

      <b>2.</b> Copy the code that was generated and paste it in your web page.<br />
      <b>3.</b> Done. Now you can use our widget<br />';
$txt['customization'] = 'Customization';
$txt['code'] = 'Code';
$txt['example'] = 'Example';
$txt['category'] = 'Category';
$txt['all'] = 'All';
$txt['how_much'] = 'Quantity';
$txt['size'] = 'Size';
$txt['color'] = 'Color';
$txt['red'] = 'Red';
$txt['yellow'] = 'Yellow';
$txt['grey'] = 'Gray';
$txt['pink'] = 'Pink';
$txt['violet'] = 'Violete';
$txt['green'] = 'Green';
$txt['lightblue'] = 'Lightblue';
?>