<?php
  $path = getcwd();
  echo $path;
?>