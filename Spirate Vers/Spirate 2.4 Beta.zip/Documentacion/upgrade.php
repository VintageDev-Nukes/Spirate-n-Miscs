<?php
/**********************************************************************************
* upgrade.php                                                                     *
***********************************************************************************
* SP: Small Pirate                                                                *
* Open-Source Project Inspired by Cristian Viguri (rancitis@spirate.net)          *
* =============================================================================== *
* Software Version:           Small Pirate 2.3                                    *
* Software by:                Small Pirate (http://www.spirate.net)               *
* Copyright 2009-2010 by:     Small Pirate (http://www.spirate.net)               *
* Support, News, Updates at:  http://www.spirate.net                              *
***********************************************************************************
* This program is free software; you may redistribute it and/or modify it under   *
* the terms of the provided license as published by Simple Machines LLC.          *
*                                                                                 *
* This program is distributed in the hope that it is and will be useful, but      *
* WITHOUT ANY WARRANTIES; without even any implied warranty of MERCHANTABILITY    *
* or FITNESS FOR A PARTICULAR PURPOSE.                                            *
*                                                                                 *
* See the "license.txt" file for details of the Simple Machines license.          *
* The latest version can always be found at http://www.simplemachines.org.        *
**********************************************************************************/

echo '<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.net/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html>
	<head>
		<title>', $txt['smf_repair_settings'], '</title>
		<script language="JavaScript" type="text/javascript" src="Themes/default/script.js"></script>
		<style type="text/css">
			body
			{
				background-color: #BBDCE8;
				margin: 0px;
				padding: 0px;
			}
			body, td
			{
				color: #000000;
				font-size: small;
				font-family: verdana, sans-serif;
			}
			div#header
			{
				background-image: url(Themes/default/images/catbg.jpg);
				background-repeat: repeat-x;
				background-color: #E6EEF1;
				padding: 0px 4% 12px 4%;
				color: white;
				font-family: Georgia, serif;
				font-size: xx-large;
				border-bottom: 1px solid black;
				height: 60px;
				-moz-box-shadow: 0 0 5px #84A4CA;
                -webkit-box-shadow: 0 0 5px #84A4CA;
                -ms-filter: "progid:DXImageTransform.Microsoft.Shadow(color=#CDDAE9,direction=125,strength=5)";
			}
			div#content
			{
				padding: 20px 30px;
			}
			div.error_message
			{
				border: 2px dashed red;
				background-color: #E1E1E1;
				margin: 1ex 4ex;
				padding: 1.5ex;
			}
			div.panel
			{
				border: 1px solid gray;
				background-color: #F5F6CE;
				margin: 1ex 0;
				padding: 1.2ex;
				-moz-border-radius:5px;
				-webkit-border-radius:5px;
				-moz-box-shadow: 0 0 5px #84A4CA;
                -webkit-box-shadow: 0 0 5px #84A4CA;
                -ms-filter: "progid:DXImageTransform.Microsoft.Shadow(color=#CDDAE9,direction=125,strength=5)";

			}
			div.panel h2
			{
				margin: 0;
				margin-bottom: 0.5ex;
				padding-bottom: 3px;
				border-bottom: 1px dashed black;
				font-size: 14pt;
				font-weight: normal;
			}
			div.panel h3
			{
				margin: 0;
				margin-bottom: 2ex;
				font-size: 10pt;
				font-weight: normal;
			}
			form
			{
				margin: 0;
			}
			td.textbox
			{
				padding-top: 2px;
				font-weight: bold;
				white-space: nowrap;
				padding-', empty($txt['lang_rtl']) ? 'right' : 'left', ': 2ex;
			}
			
			textarea, input{background:#FFF;border: solid 1px #D1D1D1;padding:4px 2px;color:#333;font-size:12px;}
			
			input.login, .button{
            margin: 1px:
            padding:4px;
            background:#EFEFFB;
            font-weight: bold;
            color:#000000;
            margin:0px;
            cursor:pointer;
            border:1px solid #CCC;
            }

            input.login:hover, .button:hover{
            background:#D8D8D8;
            color:#000000;
            font-weight: bold;
            cursor:pointer;
            background:#E0E0F8;
            text-decoration: underline;
            border:1px solid #CCC;

            }

			
		</style>
	</head>
	<body>
		<div id="header">
			<a href="http://www.spirate.net/" target="_blank"><img src="Themes/default/images/logo.png" style="float: right;" alt="Spirate" border="0" /></a>
			<div title="Spirate!" style="padding-top:15px;"><font color="#000">Upgrade v2 a v2.3</font></div>
		</div>
		<div id="content">';
		
		
if(!file_exists('SSI.php')){
	echo'No existe SSI.php, o el directorio donde est&aacute; el upgrade.php es incorrecto.';
	exit;
	}
include('Settings.php');
$con = mysql_connect($db_server, $db_user, $db_passwd);
mysql_select_db($db_name, $con);

initialize_inputs();

if (function_exists('doStep' . $_GET['step']))
	call_user_func('doStep' . $_GET['step']);
	
function initialize_inputs(){
	if (isset($_GET['delete']))
	{
			@unlink(__FILE__);
			
		// Now just redirect to a blank.gif...
		header('Location: http://' . (isset($_SERVER['HTTP_HOST']) ? $_SERVER['HTTP_HOST'] : $_SERVER['SERVER_NAME'] . ':' . $_SERVER['SERVER_PORT']) . dirname($_SERVER['PHP_SELF']) . '/Themes/default/images/blank.gif');
		exit;
	}

	// Force an integer step, defaulting to 0.
	$_GET['step'] = (int) @$_GET['step'];
}

function doStep0(){

//Empezamos a crear las tablas y avisar de correcta inserci�n.
$request = mysql_query("CREATE TABLE IF NOT EXISTS `smf_buddies` (
  `ID_MEMBER` mediumint(8) NOT NULL DEFAULT '0',
  `BUDDY_ID` mediumint(8) NOT NULL DEFAULT '0',
  `approved` smallint(1) NOT NULL DEFAULT '0',
  `position` tinyint(4) NOT NULL DEFAULT '0',
  `time_updated` int(11) NOT NULL DEFAULT '0',
  `requested` mediumint(8) NOT NULL DEFAULT '0'
) ENGINE=MyISAM DEFAULT CHARSET=latin1;");

if($request){
echo 'Tabla <em>smf_buddies</em> <b>creada correctamente</b><hr>';
}else{
echo 'La tabla <em>smf_buddies</em> <b>existe</b> o hubo un <b>error</b> durante su creaci&oacute;n<hr>';
}


$request = mysql_query("CREATE TABLE IF NOT EXISTS `smf_points_per_day` (
  `ID_MEMBER` int(11) NOT NULL,
  `points` int(11) NOT NULL,
  PRIMARY KEY (`ID_MEMBER`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;");

if($request){
echo 'Tabla <em>smf_points_per_day</em> <b>creada correctamente</b><hr>';
}else{
echo 'La tabla <em>smf_points_per_day</em> <b>existe</b> o hubo un <b>error</b> durante su creaci&oacute;n<hr>';
}


$request = mysql_query("ALTER TABLE cw_comentarios RENAME AS smf_comentarios");

if($request){
echo 'Tabla <em>cw_comentarios</em> <b>renombrada correctamente a</b> <em>smf_comentarios</em><hr>';
}else{
echo 'La tabla <em>cw_comentarios</em> <b>ya fue renombrada</b> o hubo un <b>error</b> durante su renombramiento<hr>';
}


$request = mysql_query("ALTER TABLE cw_denuncias RENAME AS smf_denuncias");

if($request){
echo 'Tabla <em>cw_denuncias</em> <b>renombrada correctamente a</b> <em>smf_denuncias</em><hr>';
}else{
echo 'La tabla <em>cw_denuncias</em> <b>ya fue renombrada</b> o hubo un <b>error</b> durante su renombramiento<hr>';
}


$request = mysql_query("ALTER TABLE cw_puntos RENAME AS smf_puntos");

if($request){
echo 'Tabla <em>cw_puntos</em> <b>renombrada correctamente a</b> <em>smf_puntos</em><hr>';
}else{
echo 'La tabla <em>cw_puntos</em> <b>ya fue renombrada</b> o hubo un <b>error</b> durante su renombramiento<hr>';
}

$request = mysql_query("ALTER table smf_attachments
add column file_hash varchar(40) NOT NULL default 0");

if($request){
echo 'Agregado el campo<hr>';
}else{
echo '<b>El campo ya se encuentra en la base</b> o hubo un error<hr>';
}

$request = mysql_query("ALTER table smf_members
add column referrals_no mediumint(8) NOT NULL default 0");

if($request){
echo 'Agregado el campo<hr>';
}else{
echo '<b>El campo ya se encuentra en la base</b> o hubo un error<hr>';
}

$request = mysql_query("ALTER table smf_members
add column referrals_hits mediumint(10) NOT NULL default 0");

if($request){
echo 'Agregado el campo<hr>';
}else{
echo '<b>El campo ya se encuentra en la base</b> o hubo un error<hr>';
}

$request = mysql_query("ALTER table smf_members
add column referred_by mediumint(8) NOT NULL default 0");

if($request){
echo 'Agregado el campo<hr>';
}else{
echo '<b>El campo ya se encuentra en la base</b> o hubo un error<hr>';
}

$request = mysql_query("ALTER table smf_members
add column referred_on int(10) NOT NULL default 0");

if($request){
echo 'Agregado el campo<hr>';
}else{
echo '<b>El campo ya se encuentra en la base</b> o hubo un error<hr>';
}

$request = mysql_query("ALTER table smf_log_activity
add column referrals int(8) NOT NULL default 0");

if($request){
echo 'Agregado el campo<hr>';
}else{
echo '<b>El campo ya se encuentra en la base</b> o hubo un error<hr>';
}

$request = mysql_query("ALTER TABLE smf_puntos 
add column amount varchar(30) collate utf8_spanish_ci default NULL
");

if($request){
echo 'Agregado el campo<hr>';
}else{
echo '<b>El campo ya se encuentra en la base</b> o hubo un error<hr>';
}

mysql_query("INSERT INTO smf_settings(variable, value) VALUES ('date_points','000000')");

if($request){
echo 'Hecho<hr>';
}else{
echo '<b>Hecho<hr>';
}

mysql_query("INSERT INTO smf_points_per_day (ID_MEMBER, points)
			SELECT ID_MEMBER, 0
			FROM smf_members");

if($request){
echo 'SI<hr>';
}else{
echo '<b>no<hr>';
}
			
mysql_query("TRUNCATE smf_smileys");

if($request){
echo 'Hecho<hr>';
}else{
echo '<b>Hecho<hr>';
}

mysql_query("INSERT INTO smf_smileys (`ID_SMILEY`, `code`, `filename`, `description`, `smileyRow`, `smileyOrder`, `hidden`) VALUES
(54, ':smartass1:', 'smartass1.gif', '', 0, 31, 2),
(53, ':smartass:', 'smartass.gif', '', 0, 30, 2),
(59, ':offtopic:', 'offtopic.gif', '', 0, 32, 2),
(35, ':mrgreen:', 'icon_mrgreen.gif', '', 0, 15, 0),
(60, ':cerrado:', 'cerrado.gif', '', 0, 33, 2),
(62, ':google:', 'google.gif', '', 0, 34, 2),
(63, ':pirata:', 'pirata.gif', '', 0, 35, 2),
(21, ':cross:', 'cross.gif', '', 0, 1, 2),
(51, ':love1:', 'love1.gif', '', 0, 28, 2),
(52, ':nurse:', 'nurse.gif', '', 0, 29, 2),
(26, ':cool:', 'icon_cool.gif', '', 0, 6, 0),
(29, ':evil:', 'icon_evil.gif', '', 0, 9, 0),
(31, ':idea:', 'icon_idea.gif', '', 0, 11, 0),
(42, ':roll:', 'icon_rolleyes.gif', '', 0, 22, 0),
(49, ':lcop:', 'lcop.gif', '', 0, 4, 2),
(50, ':love:', 'love.gif', '', 0, 28, 2),
(22, ':doc:', 'doc.gif', '', 0, 2, 2),
(20, ':cop:', 'cop.gif', '', 0, 0, 2),
(25, ':???:', 'icon_confused.gif', '', 0, 5, 0),
(27, ':cry:', 'icon_cry.gif', '', 0, 7, 0),
(32, ':lol:', 'icon_lol.gif', '', 0, 12, 0),
(33, ':mad:', 'icon_mad.gif', '', 0, 13, 0),
(48, ':kid:', 'kid.gif', '', 0, 3, 2),
(39, ':?:', 'icon_question.gif', '', 0, 19, 0),
(55, ':v:', 'tick.gif', '', 0, 28, 2),
(24, ':D', 'icon_biggrin.gif', '', 0, 4, 0),
(41, ':$', 'icon_redface.gif', '', 0, 21, 0),
(40, ':P', 'icon_razz.gif', '', 0, 20, 0),
(28, '8|', 'icon_eek.gif', '', 0, 8, 0),
(38, ':|', 'icon_neutral.gif', '', 0, 18, 0),
(43, ':(', 'icon_sad.gif', '', 0, 23, 0),
(44, ':)', 'icon_smile.gif', '', 0, 24, 0),
(45, ':O', 'icon_surprised.gif', '', 0, 25, 0),
(47, ';)', 'icon_wink.gif', '', 0, 27, 0),
(66, ':banyg:', '002.gif', '', 0, 38, 2);
");

if($request){
echo 'Hecho<hr>';
}else{
echo '<b>Hecho<hr>';
}

$request = mysql_query("ALTER table smf_topics change puntos puntos int(15) default 0 NOT NULL");

if($request){
echo 'Campo actualizado<hr>';
}else{
echo '<b>El campo ya se ha actualizado<hr>';
}

mysql_query("INSERT INTO smf_settings(variable, value) VALUES ('meta_description', 'spirate, small, pirate, descargas, descarga, dvdrip, imagen, musica, juegos, espanol, pc, peliculas, msn, cookies, jdownloader'),
('meta_keywords', 'spirate, small, pirate, descargas, descarga, dvdrip, imagen, musica, juegos, espanol, pc, peliculas, msn, cookies, jdownloader'),
('meta_author', 'Small Pirate'),
('meta_copyright', '&copy; Copyright 2010'),
('hide_enableUnhiddenText', '0'),
('custom_avatar_enabled', '1'),
('custom_avatar_dir', ''),
('rand_seed', '1952581256'),
('0', 'smfVersion'),
('1', 'SMF 1.1.11')");

if($request){
echo 'Hecho<hr>';
}else{
echo '<b>Hecho<hr>';
}



		echo '
					<div style="margin: 1ex; font-weight: bold;">
						<label for="delete_self"><input type="checkbox" id="delete_self" onclick="doTheDelete();" />Deb&eacute;s borrar el upgrade.php YA!</label>
					</div>
					<script language="JavaScript" type="text/javascript"><!-- // --><![CDATA[
						function doTheDelete()
						{
							var theCheck = document.getElementById ? document.getElementById("delete_self") : document.all.delete_self;
							var tempImage = new Image();
							tempImage.src = "', $_SERVER['PHP_SELF'], '?delete=1&ts=" + (new Date().getTime());
							tempImage.width = 0;
							theCheck.disabled = true;
						}
					// ]]></script>
					<br />';
	echo '
					<a href="/">Ya puede ir a su FORO</a><br />
					<br />
					Buena suerte!
				</div>';
				
}

?>