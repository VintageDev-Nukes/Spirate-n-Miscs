<?php
			/* Spirate Script - Version 2.4
******   Settings - Configuraciones generales      ******/

//Colocar la web en mantenimiento
$maintenance = '0';
//Titulo mantenimiento
$mtitle = 'Mantenimiento';
//Mensaje de mantenimiento
$mmessage = 'Se esta Trabajando para mejorar el sitio';
//Activar Amigables
$amigables='0';
//Nombre de la web
$mbname = '';
//Lenguaje
$language = 'spanish';
//Ruta
$boardurl = '';
//Url de tu web
$url = '';
//Id del chat (chat de www.chatango.com. Coloca la id del subdominio, ej: misitioweb.chatango.com, escribes "misitioweb"
$chatid = 'forosp';
//Titulo del widget
$widget = 'Spirate.Net';
//Slogan de tu web
$slogan = 'Social Community Script';
//Url del no avatar
$no_avatar = '';
//Email del administrador
$webmaster_email = '';
//Nombre del cookie
$cookiename = 'SPCookies';

//Datos de la base de datos
$db_server = '';
$db_name = '';
$db_user = '';
$db_passwd = '';
$db_prefix = 'smf_';
$db_persist = '0';
$db_error_send = 1;
$cachedir = dirname(__FILE__) . '/cache';

//Ruta de los archivos
$boarddir = '';
//Ruta de los sources
$sourcedir = '';
$db_last_error = 1;
if (!file_exists($sourcedir) && file_exists($boarddir . '/Sources'))
   $sourcedir = $boarddir . '/Sources';
$db_character_set = 'utf8';
?>