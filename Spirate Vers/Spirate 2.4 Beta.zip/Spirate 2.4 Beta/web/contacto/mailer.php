<?php
// Contact System Creado por Phobos91
require('../../Settings.php');
// obtener las variables
$asunto = $_REQUEST["asunto"];
$mensaje = $_REQUEST["mensaje"];
$from = $_REQUEST["from"];
$verif_box = $_REQUEST["verif_box"];

$mensaje = stripslashes($mensaje); 
$asunto = stripslashes($asunto); 
$from = stripslashes($from); 

// Comprobar si el cÃƒÂ³digo de verificaciÃƒÂ³n era o no correcto
if(md5($verif_box).'a4xn' == $_COOKIE['tntcon']){
	mail("". $webmaster_email ."", 'Asunto: '.$asunto, $_SERVER['REMOTE_ADDR']."\n\n".$mensaje, "From: $from");
	setcookie('tntcon','');
} else {
	// mostrar error en caso de error
	header("Location:".$_SERVER['HTTP_REFERER']."?asunto=$asunto&from=$from&mensaje=$mensaje&wrong_code=true");
	exit;
}

Header("Location: ".$boardurl."/?action=contactenos;sa=enviado");

?>

