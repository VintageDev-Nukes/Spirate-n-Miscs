<?php
require('../../Settings.php');

/*******************************************
*                  Sp-widget               *
*------------------------------------------*
*                                          *
*         Widget doble opcion              *
*                                          *
********************************************
*  Version: 1.0                            *
*  Creado por: fivezone                    *
*  SP v: 2.4                               *
********************************************
*               Small Pirate               *
********************************************/

$con = mysql_connect($db_server, $db_user, $db_passwd);
mysql_select_db($db_name, $con);
global $txt, $context, $db_prefix,$boardurl, $ID_MEMBER, $settings, $modSettings;


// Metodo para mostrar la informacion del usuario



//Obtenemos datos
$ancho = (int) $_GET['an'] - 17;
$cant = (int) $_GET['cant'];
$color = $_GET['color'];
$id = $_GET['id'];
$imagen = $_GET['color'];
$tipo = $_GET['tipo'];

//colores
if($color == 'rojo')
$color = '#FF7777';
elseif($color == 'rosa')
$color = '#DD999A';
elseif($color == 'gris')
$color = '#BBBBBB';
elseif($color == 'amarillo')
$color = '#FEFE78';
elseif($color == 'turquesa')
$color = '#78F9FF';
elseif($color == 'verde')
$color = '#78FF75';
elseif($color == 'violeta')
$color = '#8C78FE';
elseif($color == 'negro')
$color = '#3B3B23';
else
$color = '#FF7777';



echo '<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" lang="es" xml:lang="es">
<head>
<meta http-equiv="Content-Type" content="text/html; charset= ISO-8859-1;" />
<title>',$widget,'</title>
<style type="text/css">
body
{
    font-family: Arial,Helvetica,sans-serif;
    font-size:12px;
    margin: 0px;
    padding:0px;
    background: ',$color,' url(',$boardurl,'/Themes/default/images/widget/bg_widget-'.$imagen.'.gif) repeat-x;
}
a{color: #000; text-decoration:none}
a:hover{color:#000000;}
*:focus{outline:0px;}
.nsfw{color: #FFbbBB}
.item
{
    width:'.$ancho.'px;
    overflow:hidden;
    height:16px;
    margin: 2px 0px 0px 0px;
    padding:0px;
    border-bottom: 1px solid #F4F4F4;
}
.exterior{width:'.$ancho.'px;}
</style>
</head>
<body>';

echo'
<div class="exterior">';

//Tipo de dise�o 1 = $tipo 0
if($tipo == '0'){

$request = mysql_query("
            SELECT *
            FROM ({$db_prefix}members)
            WHERE ID_MEMBER = $id
            ");

//Datos principal del usuario			
while($row = mysql_fetch_array($request))
{
    echo '<div  style="float:left;margin:0px 5px 0px 0px;">
   <img alt="" title="'.$row['realName'].'" src="'.$row['avatar'].'" width="50" heigth="50" style="margin-top:-0px;margin-left:5px;" /></div>
   <b>Nombre de usuario:</b> '.$row['realName'].'</a><br>
   <b>Sexo:</b> ', genero($row['gender']), '</a><br>
   <b>Ubicacion:</b> ', pais($row['usertitle']), ' - ', $row['location'], '<br></a>
   <b>E-mail:</b>:'.$row['emailAddress'].'<br>
   <b>Se registro:</b> '.hace($row['dateRegistered']),'<br></a></div>';}
   
}

//Tipo de dise�o 2 = $tipo 1
elseif ($tipo == '1'){
$request = mysql_query("
            SELECT *
            FROM ({$db_prefix}members)
            WHERE ID_MEMBER = $id
            ");
			
//Datos principal del usuario		
while($row = mysql_fetch_array($request))
{
    echo '<div  style="float:right;margin:0px 5px 0px 0px;">
   <img alt="" title="'.$row['realName'].'" src="'.$row['avatar'].'" width="80" heigth="60" style="margin-top:-0px;margin-left:5px;" /></div>
   <b>Nombre de usuario:</b>: '.$row['realName'].'</a><br>
   <b>Sexo:</b>: ', genero($row['gender']), '</a><br>
   <b>E-mail:</b>: '.$row['emailAddress'].'<br>
    <b><a target="_blank" href="'.$boardurl.'/index.php?action=registrarse">Registrate Ya!</a></b><br>
  </div>';}
  
}

	function pais($valor)
{
					
$valor = str_replace("ar", "Argentina", $valor);
$valor = str_replace("bo", "Bolivia", $valor);
$valor = str_replace("br", "Brasil", $valor);
$valor = str_replace("cl", "Chile", $valor);
$valor = str_replace("co", "Colombia", $valor);
$valor = str_replace("cr", "Costa Rica", $valor);
$valor = str_replace("cu", "Cuba", $valor);
$valor = str_replace("ec", "Ecuador", $valor);
$valor = str_replace("es", "Espa&ntilde;a", $valor);
$valor = str_replace("gt", "Guatemala", $valor);
$valor = str_replace("it", "Italia", $valor);
$valor = str_replace("mx", "Mexico", $valor);
$valor = str_replace("py", "Paraguay", $valor);
$valor = str_replace("pe", "Peru", $valor);
$valor = str_replace("pt", "Portugal", $valor);
$valor = str_replace("pr", "Puerto Rico", $valor);
$valor = str_replace("uy", "Uruguay", $valor);
$valor = str_replace("ve", "Venezuela", $valor);
$valor = str_replace("ot", "", $valor);

return $valor;}


function genero($valor)
{
			
$valor = str_replace("1", "Masculino", $valor);
$valor = str_replace("2", "Femenino", $valor);


return $valor;}

function hace($fecha){
    $fecha = $fecha; 
    $ahora = time();
    $tiempo = $ahora-$fecha; 
     if(round($tiempo / 31536000) <= 0){ 
        if(round($tiempo / 2678400) <= 0){ 
             if(round($tiempo / 86400) <= 0){ 
                if(round($tiempo / 3600) <= 0){ 
                    if(round($tiempo / 60) <= 0){ 
                if($tiempo <= 60){ $hace = "Hace instantes"; } 

                } else  
                { 
                    $can = round($tiempo / 60);
					$can2 = date("s",$tiempo);	//segundos		
                    if($can <= 1) {    $word = "minuto"; } else { $word = "minutos"; } 
                    $hace = "Hace " .$can. " ".$word." y " .$can2. " segundos";
                }
				
                } else  
                { 
                    $can = round($tiempo / 3600);
					$can2 = round(date("i",$tiempo)); //minutos
                    if($can <= 1) {    $word = "hora"; } else {    $word = "horas"; } 
                    $hace = "Hace " .$can. " ".$word." y " .$can2. " minutos"; 
                } 
                } else  
                { 
                    $can = round($tiempo / 86400);
					$can2 = round(date("H",$tiempo)); //horas
                    if($can <= 1) {    $word = "d&iacute;a"; } else {    $word = "d&iacute;as"; } 
                    $hace = "Hace " .$can. " ".$word." y " .$can2. " horas";
                } 
                } else  
                { 
                    $can = round($tiempo / 2678400);  
					$can2 = round(date("j",$tiempo)); //dias
                    if($can <= 1) {    $word = "mes"; } else { $word = "meses"; } 
                    $hace = "Hace " .$can. " ".$word." y " .$can2. " d&iacute;as";
                } 
                } else  
                { 
                    $can = round($tiempo / 31536000); 
                    if($can <= 1) {    $word = "a&ntilde;o";} else { $word = "a&ntilde;os"; } 
					$hace = "Hace " .$can. " ".$word."";
					
				}
    return $hace; 
}



?>