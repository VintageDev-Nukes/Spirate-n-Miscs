<?php
/*******************************************
*                  index                   *
*------------------------------------------*
*                                          *
*        Arrays de acciones y otros        *
*                                          *
********************************************
*  SP v: 2.4                               *
********************************************
*               Small Pirate               *
********************************************/
$forum_version = 'Spirate 2.4';

define('SPIRATE', 1);
@set_magic_quotes_runtime(0);
error_reporting(E_ALL);
$time_start = microtime();
// Make sure some things simply do not exist.
foreach (array('db_character_set') as $variable)
	if (isset($GLOBALS[$variable]))
		unset($GLOBALS[$variable]);

// Cargamos el settings...
require_once(dirname(__FILE__) . '/Settings.php');



//Verificacion de Instalacion de SP
if ((file_exists(dirname(__FILE__) . '/install.php')) && (($mbname == "")) && (($db_name == "")))
header('Location: ./install.php');


//Mas configuraciones
require_once($sourcedir . '/QueryString.php');
require_once($sourcedir . '/Subs.php');
require_once($sourcedir . '/Errors.php');
require_once($sourcedir . '/Load.php');
require_once($sourcedir . '/Security.php');
// cargamos el cache de archivos ( flat file )
require_once($sourcedir . '/classes/cache_class/cache.php');
// cargamos la clase para las notificaciones.
require_once($sourcedir . '/classes/notifications.class.php');

// Using an old version of PHP?
if (@version_compare(PHP_VERSION, '4.2.3') != 1)
	require_once($sourcedir . '/Subs-Compat.php');

// If $maintenance is set specifically to 2, then we're upgrading or something.
if (!empty($maintenance) && $maintenance == 2)
	db_fatal_error();

// Connect to the MySQL database.
if (empty($db_persist))
	$db_connection = @mysql_connect($db_server, $db_user, $db_passwd);
else
	$db_connection = @mysql_pconnect($db_server, $db_user, $db_passwd);

// Show an error if the connection couldn't be made.
if (!$db_connection || !@mysql_select_db($db_name, $db_connection))
	db_fatal_error();
// Load the settings from the settings table, and perform operations like optimizing.
reloadSettings();
// Clean the request variables, add slashes, etc.
cleanRequest();
$context = array();

// Seed the random generator?
if (empty($modSettings['rand_seed']) || mt_rand(1, 250) == 69)
	smf_seed_generator();

// Determine if this is using WAP, WAP2, or imode.  Technically, we should check that wap comes before application/xhtml or text/html, but this doesn't work in practice as much as it should.
if (isset($_SERVER['HTTP_ACCEPT']) && strpos($_SERVER['HTTP_ACCEPT'], 'application/vnd.wap.xhtml+xml') !== false)
	$_REQUEST['wap2'] = 1;
elseif (isset($_SERVER['HTTP_ACCEPT']) && strpos($_SERVER['HTTP_ACCEPT'], 'text/vnd.wap.wml') !== false)
{
	if (strpos($_SERVER['HTTP_USER_AGENT'], 'DoCoMo/') !== false || strpos($_SERVER['HTTP_USER_AGENT'], 'portalmmm/') !== false)
		$_REQUEST['imode'] = 1;
	else
		$_REQUEST['wap'] = 1;
}
if (!defined('WIRELESS'))
	define('WIRELESS', isset($_REQUEST['wap']) || isset($_REQUEST['wap2']) || isset($_REQUEST['imode']));
// Some settings and headers are different for wireless protocols.
if (WIRELESS)
{
	define('WIRELESS_PROTOCOL', isset($_REQUEST['wap']) ? 'wap' : (isset($_REQUEST['wap2']) ? 'wap2' : (isset($_REQUEST['imode']) ? 'imode' : '')));

	// Some cellphones can't handle output compression...
	$modSettings['enableCompressedOutput'] = '0';
	// !!! Do we want these hard coded?
	$modSettings['defaultMaxMessages'] = 5;
	$modSettings['defaultMaxTopics'] = 9;

	// Wireless protocol header.
	if (WIRELESS_PROTOCOL == 'wap')
		header('Content-Type: text/vnd.wap.wml');
}

// Check if compressed output is enabled, supported, and not already being done.
if (!empty($modSettings['enableCompressedOutput']) && !headers_sent() && ob_get_length() == 0)
{
	// If zlib is being used, turn off output compression.
	if (@ini_get('zlib.output_compression') == '1' || @ini_get('output_handler') == 'ob_gzhandler' || @version_compare(PHP_VERSION, '4.2.0') == -1)
		$modSettings['enableCompressedOutput'] = '0';
	else
		ob_start('ob_gzhandler');
}
// This makes it so headers can be sent!
if (empty($modSettings['enableCompressedOutput']))
	ob_start();

// Register an error handler.
set_error_handler('error_handler');

// Start the session. (assuming it hasn't already been.)
loadSession();

// What function shall we execute? (done like this for memory's sake.)
call_user_func(smf_main());

// Call obExit specially; we're coming from the main area ;).
obExit(null, null, true);

// The main controlling function.
function smf_main()
{
	global $modSettings, $settings, $user_info, $board, $topic, $maintenance, $sourcedir, $ID_MEMBER;
	
	// Special case: session keep-alive.
	if (isset($_GET['action']) && $_GET['action'] == 'keepalive')
		die;

	// Load the user's cookie (or set as guest) and load their settings.
	loadUserSettings();

	// Load the current board's information.
	loadBoard();

	// Load the current theme.  (note that ?theme=1 will also work, may be used for guest theming.)
	loadTheme();

	// Check if the user should be disallowed access.
	is_not_banned();

	// Load the current user's permissions.
	loadPermissions();
	
	
	
	// Do some logging, unless this is an attachment, avatar, theme option or XML feed.
	if (empty($_REQUEST['action']) || !in_array($_REQUEST['action'], array('dlattach', 'jsoption', '.xml')))
	{
		// Log this user as online.
		writeLog();

		// Track forum statistics and hits...?
		if (!empty($modSettings['hitStats']))
			trackStats(array('hits' => '+'));
	}

	// Is the forum in maintenance mode? (doesn't apply to administrators.)
	if (!empty($maintenance) && !allowedTo('admin_forum'))
	{
		// You can only login.... otherwise, you're getting the "maintenance mode" display.
		if (isset($_REQUEST['action']) && ($_REQUEST['action'] == 'login2' || $_REQUEST['action'] == 'logout'))
		{
			require_once($sourcedir . '/LogInOut.php');
			return $_REQUEST['action'] == 'login2' ? 'Login2' : 'Logout';
		}
		// Don't even try it, sonny.
		else
		{
			require_once($sourcedir . '/Subs-Auth.php');
			return 'InMaintenance';
		}
	}
	// If guest access is off, a guest can only do one of the very few following actions.
	elseif (empty($modSettings['allow_guestAccess']) && $user_info['is_guest'] && (!isset($_REQUEST['action']) || !in_array($_REQUEST['action'], array('coppa', 'login', 'login2', 'register', 'register2', 'reminder', 'activate', 'smstats', 'help', 'verificationcode'))))
	{
		require_once($sourcedir . '/Subs-Auth.php');
		return 'KickGuest';
	}
	elseif (empty($_REQUEST['action']))
	{
		// Action and board are both empty... BoardIndex!
		if (empty($board) && empty($topic))
		{
			if($modSettings['gestorbloques']==1)
		        require_once($sourcedir . '/Recent-Gestor.php');
                        else
		        require_once($sourcedir . '/Recent.php');

			return 'RecentPosts';
		}
		// Topic is empty, and action is empty.... MessageIndex!
		elseif (empty($topic))
		{
			require_once($sourcedir . '/MessageIndex.php');
			return 'MessageIndex';
		}
		// Board is not empty... topic is not empty... action is empty.. Display!
		else
		{
			require_once($sourcedir . '/Display.php');
			return 'Display';
		}
	}

	// Here's the monstrous $_REQUEST['action'] array - $_REQUEST['action'] => array($file, $function).
	$actionArray = array(
	    'thumb' => array('Thumbnail.php', 'Thumb'),	
		'galeria' => array('Galeria.php', 'GMain'),	
		'ajax' => array('ajax-requests.php', 'ajax'),
        'fast-register' => array('register.ajax.php', 'registro'),
        'borradores' => array('Drafts.php', 'drafts'),
		'buddies' => array('Buddies.php', 'BuddiesMain'),
		'activate' => array('Register.php', 'Activate'),
		'denuncias' => array('Denuncias.php', 'Denuncias'),
		'admin' => array('Admin.php', 'Admin'),
		'puntospr' => array('Rangos.php', 'PuntosPR'),
		'bloques' => array('MoveBloques.php', 'TMain'),
		'ban' => array('ManageBans.php', 'Ban'),
		'boardrecount' => array('Admin.php', 'AdminBoardRecount'),
		'favoritos' => array('Favoritos.php', 'Favoritos'),
		'cleanperms' => array('Admin.php', 'CleanupPermissions'),
		'convertentities' => array('Admin.php', 'ConvertEntities'),
		'convertutf8' => array('Admin.php', 'ConvertUtf8'),
		'comunidades' => array('Comunidades.php', 'Comunidades'),	 
		'coppa' => array('Register.php', 'CoppaForm'),
		'deletemsg' => array('RemoveTopic.php', 'DeleteMessage'),
		'detailedversion' => array('Admin.php', 'VersionDetail'),
		'display' => array('Display.php', 'Display'),
		'dumpdb' => array('DumpDatabase.php', 'DumpDatabase2'),
		'extras' => array('Extras.php', 'Extras'),
		'featuresettings' => array('ModSettings.php', 'ModifyFeatureSettings'),
		'featuresettings2' => array('ModSettings.php', 'ModifyFeatureSettings2'),
		'findmember' => array('Subs-Auth.php', 'JSMembers'),
		'help' => array('Help.php', 'ShowHelp'),	
		'helpadmin' => array('Help.php', 'ShowAdminHelp'),		
		'jsoption' => array('Themes.php', 'SetJavaScript'),
		'jsmodify' => array('Post.php', 'JavaScriptModify'),	
		'widget' => array('widget.php', 'ShowHelp'),
		'recomendar' => array('Recomendar.php', 'ShowHelp'),
		'denunciar' => array('Denunciar.php', 'ShowHelp'),
		'im' => array('PersonalMessage.php', 'MessageMain'),
		'jsoption' => array('Themes.php', 'SetJavaScript'),
                'jslang' => array('Themes.php', 'JsLang'),
		'jsmodify' => array('Post.php', 'JavaScriptModify'),
		'lock' => array('LockTopic.php', 'LockTopic'),
		'login' => array('LogInOut.php', 'Login'),
		'login2' => array('LogInOut.php', 'Login2'),
		'logout' => array('LogInOut.php', 'Logout'),
		'maintain' => array('Admin.php', 'Maintenance'),
		'manageattachments' => array('ManageAttachments.php', 'ManageAttachments'),
		'manageboards' => array('ManageBoards.php', 'ManageBoards'),
		'comment' => array('ProfileComments.php', 'CommentsMain'),
		'managesearch' => array('ManageSearch.php', 'ManageSearch'),
		'markasread' => array('Subs-Boards.php', 'MarkRead'),
		'membergroups' => array('ManageMembergroups.php', 'ModifyMembergroups'),
		'mergetopics' => array('SplitTopics.php', 'MergeTopics'),
		'mlist' => array('Memberlist.php', 'Memberlist'),
		'modifycat' => array('ManageBoards.php', 'ModifyCat'),
		'modifykarma' => array('Karma.php', 'ModifyKarma'),
		'hist-mod' => array('Modlog.php', 'ViewModlog'),
		'movetopic' => array('MoveTopic.php', 'MoveTopic'),
		'movetopic2' => array('MoveTopic.php', 'MoveTopic2'),
		'movetopic3' => array('MoveTopic.php', 'MoveTopic3'),
		'news' => array('ManageNews.php', 'ManageNews'),
		'monitor' => array('Monitor.php', 'Monitor'),
		'notify' => array('Notify.php', 'Notify'),
		'notifyboard' => array('Notify.php', 'BoardNotify'),
		'optimizetables' => array('Admin.php', 'OptimizeTables'),
		'packageget' => array('PackageGet.php', 'PackageGet'),
		'packages' => array('Packages.php', 'Packages'),
		'permissions' => array('ManagePermissions.php', 'ModifyPermissions'),
		'pgdownload' => array('PackageGet.php', 'PackageGet'),
		'pm' => array('PersonalMessage.php', 'MessageMain'),
		'post' => array('Post.php', 'Post'),
		'agregar' => array('Agregar.php', 'Agregar'),
		'agregar2' => array('Agregar.php', 'Agregar2'),
		'post2' => array('Post.php', 'Post2'),
		'postsettings' => array('ManagePosts.php', 'ManagePostSettings'),
		'printpage' => array('Printpage.php', 'PrintTopic'),
		'profile' => array('Profile.php', 'ModifyProfile'),
		'profile2' => array('Profile.php', 'ModifyProfile2'),
		'quotefast' => array('Post.php', 'QuoteFast'),
		'quickmod' => array('Subs-Boards.php', 'QuickModeration'),
		'quickmod2' => array('Subs-Boards.php', 'QuickModeration2'),
		'listen' => array('Admin.php', 'Listen'),
		'regcenter' => array('ManageRegistration.php', 'RegCenter'),
		'registrarse' => array('Register.php', 'Register'),
		'register2' => array('Register.php', 'Register2'),
		'reminder' => array('Reminder.php', 'RemindMe'),
		'removetopic2' => array('RemoveTopic.php', 'RemoveTopic2'),
		'removeoldtopics2' => array('RemoveTopic.php', 'RemoveOldTopics2'),
		'repairboards' => array('RepairBoards.php', 'RepairBoards'),
		'requestmembers' => array('Subs-Auth.php', 'RequestMembers'),
		'search' => array('Search.php', 'PlushSearch1'),
		'search2' => array('Search.php', 'PlushSearch2'),
		'serversettings' => array('ManageServer.php', 'ModifySettings'),
		'serversettings2' => array('ManageServer.php', 'ModifySettings2'),
		'sitemap' => array('Sitemap.php', 'ShowSiteMap'),
		'smileys' => array('ManageSmileys.php', 'ManageSmileys'),
		'splittopics' => array('SplitTopics.php', 'SplitTopics'),
                'stream' => array('stream.php', 'stream'),
		'TOPs' => array('Stats.php', 'DisplayStats'),
		'sticky' => array('LockTopic.php', 'Sticky'),
		'rz' => array('Acciones.php', 'Acciones'),
		'theme' => array('Themes.php', 'ThemesMain'),
		'trackip' => array('Profile.php', 'trackIP'),
		'viewErrorLog' => array('ManageErrors.php', 'ViewErrorLog'),
		'viewmembers' => array('ManageMembers.php', 'ViewMembers'),
		'viewprofile' => array('Profile.php', 'ModifyProfile'),
		'verificationcode' => array('Register.php', 'VerificationCode'),
		'who' => array('Who.php', 'Who'),
		'.xml' => array('News.php', 'ShowXmlFeed'),
		'enviar-puntos' => array('shop/Shop.php', 'Shop'),
		'shop_general' => array('shop/ShopAdmin.php', 'ShopGeneral'),
		'shop_inventory' => array('shop/ShopAdmin.php', 'ShopInventory'),
		'shop_usergroup' => array('shop/ShopAdmin.php', 'ShopUserGroup'),
        'terminos' => array('Varios.php', 'Terminos'),
        'contactenos' => array('Varios.php', 'Contactenos'),
        'enlazanos' => array('Varios.php', 'Enlazanos'),
        'enviar-a-amigo' => array('Varios.php', 'SendTopic'),
        'protocolo' => array('Varios.php', 'Protocolo'),
		'paises' => array('Varios.php', 'AdminPaises'),
		'404' => array('404.php', 'error404'),
	);

	// Get the function and file to include - if it's not there, do the board index.
	if (!isset($_REQUEST['action']) || !isset($actionArray[$_REQUEST['action']]))
	{
		// Catch the action with the theme?
		if (!empty($settings['catch_action']))
		{
			require_once($sourcedir . '/Themes.php');
			return 'WrapAction';
		}
                
                if($modSettings['gestorbloques']==1)
		require_once($sourcedir . '/Recent-Gestor.php');
                else
		require_once($sourcedir . '/Recent.php');

		return 'RecentPosts';
	}

	// Otherwise, it was set - so let's go to that action.
	require_once($sourcedir . '/' . $actionArray[$_REQUEST['action']][0]);
	return $actionArray[$_REQUEST['action']][1];
}

?>