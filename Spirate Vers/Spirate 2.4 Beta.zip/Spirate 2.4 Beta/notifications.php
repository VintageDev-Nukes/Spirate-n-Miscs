<?php
# El contenido de este archivo solo muestra html como ejemplo de lo que podria ser un sistema de notificaciones, no existe algoritmo alguno en este archivo.
# El siguiente formato estara en sp 2.4

sleep(2); // Damos un efecto para el loading.

echo '<div class="div-ul">
          <div class="item recent clearfix"><div class="context clearfix"><div class="avatar clearfix"><img src="photos/user-1.png"></div>
              <div class="information"><div><img src="images/balloon.png" style="margin-bottom:-3px"> &nbsp;<a href="profile.php?user=5">Paul</a>, <a href="profile.php?user=2">Silver</a> y <a>5 usuarios</a> m&aacute;s comentaron en tu post.</div>
              <span class="time">Hace 10 minutos.</span>
              </div></div></div>
              
          <div class="item recent clearfix"><div class="context clearfix"><div class="avatar"><img src="photos/user-4.jpg"></div>
              <div class="information"><div><img src="images/document-text.png" style="margin-bottom:-3px"> &nbsp;<a href="profile.php?user=2">Anonymous</a> creo un nuevo <a href="post.php?id=10">Post</a>.</div>
              <span class="time">Hace 1 hora.</span>
              </div></div></div>

            <div class="item clearfix"><div class="context clearfix"><div class="avatar clearfix"><img src="photos/user-5.jpg"></div>
              <div class="information"><div><img src="images/point.png" style="margin-bottom:-3px"> &nbsp;<a href="profile.php?user=5">The_pimp</a> dio 10 puntos a tu <a href="post.php?id=5">Post</a>.</div>
              <span class="time">Ayer.</span>
              </div></div></div>
          </div>
          <div align="right"><a href="monitor.php">Ver todas las notificaciones &raquo;&raquo;</a>';

?>