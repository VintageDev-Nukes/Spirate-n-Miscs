<?php
/* Spirate Script - Version 2.4
******   Acciones.php     ******/

if (!defined('SPIRATE'))
	die('Error');

function acciones(){
	global $settings, $user_info, $language, $context, $txt, $db_prefix;

$request = db_query("
SELECT m.ID_MEMBER, m.ID_POST_GROUP
FROM {$db_prefix}members AS m
WHERE '".$context['user']['id']."' = m.ID_MEMBER", __FILE__, __LINE__);
    
while ($grup = mysql_fetch_assoc($request)){	
	$context['idgrup'] = $grup['ID_POST_GROUP'];
	$context['leecher'] = $grup['ID_POST_GROUP'] == '4';
	$context['novato'] = $grup['ID_POST_GROUP'] == '5';
	$context['buenus'] = $grup['ID_POST_GROUP'] == '6';
}	
mysql_free_result($request);

        if(loadlanguage('Acciones') == false)
            loadLanguage('Acciones','spanish');
            
	loadTemplate('Acciones');
	
	$context['all_pages'] = array(
		'index' => 'intro',
		'enviarp' => 'enviarp',
		'enviari' => 'enviari',
		'editari' => 'editari',
		'editarp' => 'editarp',
		'editarcom' => 'editarcom',
		'eliminarp' => 'eliminarp',
		'post-agregado' => 'postagregado',
		'post-editado' => 'posteditado',
		'comentar' => 'comentar',
		'eliminarc' => 'eliminarc',
		'denuncias' => 'denuncias',
		'endenuncias' => 'endenuncias',
		'eldenuncias' => 'eldenuncias',
		'chat' => 'chat',
	);
	if (!isset($_GET['m']) || !isset($context['all_pages'][$_GET['m']]))
		$_GET['m'] = 'index';

        if($_GET['m'] == 'chat')
            $context['in_chat'] = true;

	$context['current_page'] = $_GET['m'];
	$context['sub_template'] = '' . $context['all_pages'][$context['current_page']];

	$context['page_title'] = $txt[18];
}

function denuncias(){
	adminIndex('denuncias');
}

?>