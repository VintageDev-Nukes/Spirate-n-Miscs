<?php
/* Spirate Script - Version 2.4
******   Rangos.php     ******/

if (!defined('SPIRATE'))
	die('Hacking attempt...');

function PuntosPR(){
	global $txt, $context, $db_prefix;

	// isAllowedTo('admin_forum') -> solo administradores -> :fuckyeah:
	isAllowedTo('admin_forum');

	// adminIndex() -> menu de administracion
	adminIndex('puntospr');

	// loadlanguage() -> Rangos.*.php
	loadlanguage('Rangos');

	// loadtemplate() -> Rangos.template.php
	loadtemplate('Rangos');

	// sub_template -> template_puntospr()
	$context['sub_template']  = 'puntospr';	

	// page_title -> titulo de pagina
	$context['page_title'] = 'Puntos Por Rangos';

	$context['admin_tabs'] = array(
		'title' => &$txt['puntospr'],
		'description' => $txt['puntospr_descripcion'],
		'tabs' => array(),
	);

	if(isset($_POST['edit'])){
		$rangos = db_query("SELECT *
		FROM {$db_prefix}membergroups
		", __FILE__, __LINE__);
		$context['puntospr'] = array();
		while ($row = mysql_fetch_assoc($rangos)){
			$id = $row['ID_GROUP'];
			$puntos = (int) $_POST['p'.$row['ID_GROUP']];
			db_query("UPDATE {$db_prefix}membergroups
			SET puntos = '$puntos'
			WHERE ID_GROUP = '$id'
			LIMIT 1", __FILE__, __LINE__);
		}
		mysql_free_result($rangos);
	}

	$rangos = db_query("SELECT *
	FROM {$db_prefix}membergroups
	ORDER BY minPosts ASC
	", __FILE__, __LINE__);
	$context['puntospr'] = array();
	while ($row = mysql_fetch_assoc($rangos)){
		$context['puntospr'][] = array(
			'ID_GROUP' => $row['ID_GROUP'],
			'groupName' => $row['groupName'],
			'onlineColor' => $row['onlineColor'],
			'minPosts' => $row['minPosts'],
			'stars' => $row['stars'],
			'puntos' => $row['puntos'],
		);
	}
	mysql_free_result($rangos);
}

?>