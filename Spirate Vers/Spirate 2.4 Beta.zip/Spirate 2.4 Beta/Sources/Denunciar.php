<?php
/* Spirate Script - Version 2.4
******   Denunciar.php     ******/

if (!defined('SPIRATE'))
	die('Error');

function ShowHelp()
{
	global $settings, $user_info, $language, $context, $txt;

        if(loadLanguage('Denunciar') == false)
            loadLanguage('Denunciar','spanish');
        if(loadLanguage('Manual') == false)
            loadLanguage('Manual','spanish');

	loadTemplate('Denunciar');

	$context['all_pages'] = array(
		'index' => 'intro',
		'enviada' => 'login',
	);

	if (!isset($_GET['page']) || !isset($context['all_pages'][$_GET['page']]))
		$_GET['page'] = 'index';

	$context['current_page'] = $_GET['page'];
	$context['sub_template'] = 'manual_' . $context['all_pages'][$context['current_page']];

	$context['template_layers'][] = 'manual';
	$context['page_title'] = $txt['denounce_titulo'];

}

function ShowAdminHelp()
{
	global $txt, $helptxt, $context, $scripturl;

	if (!isset($_GET['help']))
		fatal_lang_error('no_access');

        if(loadLanguage('Denunciar') == false)
            loadLanguage('Denunciar','spanish');

	if (isset($_GET['help']) && substr($_GET['help'], 0, 14) == 'permissionhelp'){
                if(loadLanguage('ManagePermissions') == false)
                    loadLanguage('ManagePermissions','spanish');}

	loadTemplate('Denunciar');

    
	$context['page_title'] = $txt['denounce_titulo'];

	$context['template_layers'] = array();
	$context['sub_template'] = 'popup';

	if (isset($helptxt[$_GET['help']]))
		$context['help_text'] = &$helptxt[$_GET['help']];
	elseif (isset($txt[$_GET['help']]))
		$context['help_text'] = &$txt[$_GET['help']];
	else
		$context['help_text'] = $_GET['help'];

	if (preg_match('~%([0-9]+\$)?s\?~', $context['help_text'], $match))
	{
		$context['help_text'] = sprintf($context['help_text'], $scripturl, $context['session_id']);
	}
}

?>