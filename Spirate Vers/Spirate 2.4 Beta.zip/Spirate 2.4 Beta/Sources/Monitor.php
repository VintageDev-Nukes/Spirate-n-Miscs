<?php
/* Spirate Script - Version 2.4
******   Monitor.php     ******/

if (!defined('SPIRATE'))
	die('Hacking attempt...');

function monitor(){
	global $context, $txt, $db_prefix, $tipo, $modSettings, $cantnot;
	
        // loadlenguage() -> Monitor.*.php
        loadlanguage('Monitor');
	// page_title -> titulo de la pagina
	$context['page_title'] = $txt['monitor_title'];

        $notifications = new notifications();
        $notifications->clean = true;
        $context['notifications'] = $notifications->getNotifications(false, $context['unread_notifications']);
        $last = reset($context['notifications']);
        
        $idmember = $context['user']['id'];
		if($idmember==''){
			fatal_error($txt['private_function']);
		}

        // maximo de notificaciones
	$cantlimit = $modSettings['monitorcant']<1 || empty($modSettings['monitorcant']) ? 1 : $modSettings['monitorcant'];
	
	// loadTemplate() -> Monitor.template.php
	loadTemplate('Monitor');
	// sub_template = template_main()
	$context['sub_template']  = 'main';
}

function verificar($cantmax){
	global $context, $txt, $db_prefix, $eliminados;
	
	$idmember = $context['user']['id'];
	
	$loquehay = 0;
	$request = db_query("SELECT *
	FROM {$db_prefix}monitor_new
	WHERE aquien = '$idmember'
	ORDER BY fecha ASC
	", __FILE__, __LINE__);
	while ($row = mysql_fetch_assoc($request)){
		$loquehay++;
	}
	mysql_free_result($request);
	
	if($loquehay>$cantmax){
		$dif = $loquehay - $cantmax;
		
        db_query("DELETE FROM {$db_prefix}monitor_new WHERE aquien = '$idmember' ORDER BY fecha ASC LIMIT {$dif}", __FILE__, __LINE__);
		
		$eliminados = 'Se han borrado '.$dif.' notificaciones antiguas';
	}
	else
		$eliminados='';
}

function vistos($op){
	global $context, $db_prefix;
	
	$idmember = $context['user']['id'];
	
	$result1 = db_query("UPDATE {$db_prefix}monitor_new
	SET visto = '$op'
	WHERE aquien = '$idmember' 
	", __FILE__, __LINE__);
}

function AdminMonitor(){
	global $settings, $user_info, $language, $context, $txt, $db_prefix,$tipo,$setting_mon;
	
	isAllowedTo('admin_forum');
	
	// loadlanguage() -> Monitor.*.php
	loadlanguage('Monitor');
	// page_title -> titulo de pagina
	$context['page_title'] = $txt['admin_monitor_title'];
	
	// loadTemplate() -> Monitor.template.php
	loadTemplate('Monitor');
	// sub_template -> template_adminmonitor()
	$context['sub_template']  = 'adminmonitor';
	
	// menu de administracion
	adminIndex('adminmonitor');
	
	$context['admin_tabs'] = array(
		'title' => &$txt['monitor_title'],
		'description' => $txt['admin_monitor_descripcion'],
		'tabs' => array(),
	);
	
	$request = db_query("SELECT *
	FROM {$db_prefix}settings
	", __FILE__, __LINE__);
	while ($row = mysql_fetch_assoc($request))
	$context['adminmonitor2'][] = array(
		'vr' => $row['variable'],
		'vl' => $row['value'],
	);
	mysql_free_result($request);
	
	$setting_mon = array(
		'monitorcant' => 'int',
		'monitorpubli' => 'textarea'
	);
	
	if(!empty($_POST['edit'])){
		foreach($context['adminmonitor2'] as $m){
			if(!empty($setting_mon[@$m['vr']])){

			   $result1 = db_query("
						UPDATE {$db_prefix}settings
						SET  value = '".$_POST[$m['vr']]."'
									WHERE variable = '".$m['vr']."' 
							", __FILE__, __LINE__);

			}
		}
	}
	
	$request = db_query("SELECT *
	FROM {$db_prefix}settings
	", __FILE__, __LINE__);
	while ($row = mysql_fetch_assoc($request))
	$context['adminmonitor'][] = array(
		'vr' => $row['variable'],
		'vl' => $row['value'],
	);
	mysql_free_result($request);
}

?>