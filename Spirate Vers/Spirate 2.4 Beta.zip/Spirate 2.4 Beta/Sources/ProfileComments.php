<?php
/* Spirate Script - Version 2.4
******   ProfileComments.php     ******/

if (!defined('SPIRATE'))
	die('Hacking attempt...');

function CommentsMain()
{

	loadtemplate('ProfileComments');
	loadlanguage('Post');
	
	// Load the language files
	if (loadlanguage('ProfileComments') == false)
		loadLanguage('ProfileComments','english');

	// Profile Comments actions
	$subActions = array(
		'view' => 'view',
		'admin' => 'CommentsAdmin',
		'edit' => 'Edit',
		'edit2' => 'Edit2',
		'delete' => 'Delete',
		'approve' => 'ApproveComment',
	);

	$sa = $_REQUEST['sa'];

	// Follow the sa or just go to administration.
	if (!empty($subActions[$sa]))
		$subActions[$sa]();
	else
		view();
}
function view()
{
	die(base64_decode('UG93ZXJlZCBieSBQcm9maWxlIENvbW1lbnRzIG1hZGUgYnkgdmJnYW1lcjQ1IGh0dHA6Ly93d3cuc21maGFja3MuY29t'));
}

function Edit()
{
	global $context, $mbname, $ID_MEMBER, $modSettings, $user_info, $db_prefix, $settings, $txt;
	// Guests can't do this stuff
	is_not_guest();
	// Check if spellchecking is both enabled and actually working. (for quick reply.)
	$context['show_spellchecking'] = !empty($modSettings['enableSpellChecking']) && function_exists('pspell_new');


	$context['sub_template']  = 'edit';

	//Set the page title
	$context['page_title'] = $mbname . $txt['pcomments_edit1'];

	// Initialize smiley array...
	$context['smileys'] = array(
		'postform' => array(),
		'popup' => array(),
	);

	
	if (function_exists('parse_bbc'))
		$esmile = 'embarrassed.gif';
	else
		$esmile = 'embarassed.gif';
	
	// Load smileys - don't bother to run a query if we're not using the database's ones anyhow.
	if (empty($modSettings['smiley_enable']) && $user_info['smiley_set'] != 'none')
		$context['smileys']['postform'][] = array(
			'smileys' => array(
				array('code' => ':)', 'filename' => 'smiley.gif', 'description' => $txt[287]),
				array('code' => ';)', 'filename' => 'wink.gif', 'description' => $txt[292]),
				array('code' => ':D', 'filename' => 'cheesy.gif', 'description' => $txt[289]),
				array('code' => ';D', 'filename' => 'grin.gif', 'description' => $txt[293]),
				array('code' => '>:(', 'filename' => 'angry.gif', 'description' => $txt[288]),
				array('code' => ':(', 'filename' => 'sad.gif', 'description' => $txt[291]),
				array('code' => ':o', 'filename' => 'shocked.gif', 'description' => $txt[294]),
				array('code' => '8)', 'filename' => 'cool.gif', 'description' => $txt[295]),
				array('code' => '???', 'filename' => 'huh.gif', 'description' => $txt[296]),
				array('code' => '::)', 'filename' => 'rolleyes.gif', 'description' => $txt[450]),
				array('code' => ':P', 'filename' => 'tongue.gif', 'description' => $txt[451]),
				array('code' => ':-[', 'filename' => $esmile, 'description' => $txt[526]),
				array('code' => ':-X', 'filename' => 'lipsrsealed.gif', 'description' => $txt[527]),
				array('code' => ':-\\', 'filename' => 'undecided.gif', 'description' => $txt[528]),
				array('code' => ':-*', 'filename' => 'kiss.gif', 'description' => $txt[529]),
				array('code' => ':\'(', 'filename' => 'cry.gif', 'description' => $txt[530])
			),
			'last' => true,
		);
	elseif ($user_info['smiley_set'] != 'none')
	{
		$request = db_query("
			SELECT code, filename, description, smileyRow, hidden
			FROM {$db_prefix}smileys
			WHERE hidden IN (0, 2)
			ORDER BY smileyRow, smileyOrder", __FILE__, __LINE__);
		while ($row = mysql_fetch_assoc($request))
			$context['smileys'][empty($row['hidden']) ? 'postform' : 'popup'][$row['smileyRow']]['smileys'][] = $row;
		mysql_free_result($request);
	}

	// Clean house... add slashes to the code for javascript.
	foreach (array_keys($context['smileys']) as $location)
	{
		foreach ($context['smileys'][$location] as $j => $row)
		{
			$n = count($context['smileys'][$location][$j]['smileys']);
			for ($i = 0; $i < $n; $i++)
			{
				$context['smileys'][$location][$j]['smileys'][$i]['code'] = addslashes($context['smileys'][$location][$j]['smileys'][$i]['code']);
				$context['smileys'][$location][$j]['smileys'][$i]['js_description'] = addslashes($context['smileys'][$location][$j]['smileys'][$i]['description']);
			}

			$context['smileys'][$location][$j]['smileys'][$n - 1]['last'] = true;
		}
		if (!empty($context['smileys'][$location]))
			$context['smileys'][$location][count($context['smileys'][$location]) - 1]['last'] = true;
	}
	$settings['smileys_url'] = $modSettings['smileys_url'] . '/' . $user_info['smiley_set'];

	// Allow for things to be overridden.
	if (!isset($context['post_box_columns']))
		$context['post_box_columns'] = 60;
	if (!isset($context['post_box_rows']))
		$context['post_box_rows'] = 12;
	if (!isset($context['post_box_name']))
		$context['post_box_name'] = 'comment';
	if (!isset($context['post_form']))
		$context['post_form'] = 'cprofile';


	// Set a flag so the sub template knows what to do...
	$context['show_bbc'] = !empty($modSettings['enableBBC']) && !empty($settings['show_bbc']);

	// Generate a list of buttons that shouldn't be shown - this should be the fastest way to do this.
	if (!empty($modSettings['disabledBBC']))
	{
		$disabled_tags = explode(',', $modSettings['disabledBBC']);
		foreach ($disabled_tags as $tag)
			$context['disabled_tags'][trim($tag)] = true;
	}
}
function Edit2()
{
	global $db_prefix, $ID_MEMBER, $txt,$context;
	// Guests can't do this stuff
	is_not_guest();
	
	@$subject = htmlspecialchars($_POST['subject'], ENT_QUOTES);
	@$comment = htmlspecialchars($_POST['comment'], ENT_QUOTES);
	@$id = (int) $_POST['commentid'];
	
	// Uncomment if you want the subject required
	//if ($subject == '')
	//	fatal_error($txt['pcomments_err_subject'],false);
	
	if ($comment == '')
		fatal_error($txt['pcomments_err_comment'],false);

	if (empty($id))
		fatal_error($txt['pcomments_err_nocom']);

	// Check if you are allowed to edit the comment
	$dbresult = db_query("
	SELECT p.ID_COMMENT, p.ID_MEMBER, p.COMMENT_MEMBER_ID 
	FROM {$db_prefix}profile_comments as p 
	WHERE p.ID_COMMENT = $id", __FILE__, __LINE__);
	$row = mysql_fetch_assoc($dbresult);
	mysql_free_result($dbresult);

        $yo = $context['user']['id'];

        if($row['ID_MEMBER']==$yo || $row['COMMENT_MEMBER_ID']==$yo)
        isAllowedTo('pcomments_edit_own');
        else
        isAllowedTo('pcomments_edit_any');

	
		/*
		// Get editing member name
		$dbresult = db_query("
		SELECT 
			m.ID_MEMBER, m.realName 
		FROM {$db_prefix}members AS m 
		WHERE m.ID_MEMBER = $ID_MEMBER LIMIT 1", __FILE__, __LINE__);
		$row2 = mysql_fetch_assoc($dbresult);
		mysql_free_result($dbresult);
		*/

//		$editname = $row2['realName'];
//		$commentdate = timeformat(time(),false);
		//$comment .= "<br />« " .  $txt['pcomments_lastedit'] . " $commentdate" . $txt['pcomments_by'] . "$editname »";

		
		// Check if you have automatic approval
		$approved = (allowedTo('pcomments_autocomment') ? 1 : 0);
		
		// Update the Comment
		db_query("UPDATE {$db_prefix}profile_comments
			SET subject = '$subject', comment = '$comment', approved = $approved 
		 WHERE ID_COMMENT = $id LIMIT 1", __FILE__, __LINE__);


		// Redirect back to profile
		redirectexit('action=profile;u=' . $row['COMMENT_MEMBER_ID']);


}
function Delete()
{
	global $db_prefix, $ID_MEMBER, $txt,$context;
	// Guests can't do this stuff
	is_not_guest();
	// Get the comment id
	$id = (int) @$_REQUEST['id'];

	if (empty($id))
		fatal_error($txt['pcomments_err_nocom']);

	// Check if you are allowed to delete the comment
	$dbresult = db_query("
	SELECT 
		p.ID_COMMENT, p.ID_MEMBER, p.COMMENT_MEMBER_ID 
	FROM {$db_prefix}profile_comments as p 
	WHERE p.ID_COMMENT = $id", __FILE__, __LINE__);
	$row = mysql_fetch_assoc($dbresult);
	mysql_free_result($dbresult);


        $yo = $context['user']['id'];

        if($row['ID_MEMBER']==$yo || $row['COMMENT_MEMBER_ID']==$yo)
        isAllowedTo('pcomments_delete_own');
        else
        isAllowedTo('pcomments_delete_any');


		db_query("DELETE FROM {$db_prefix}profile_comments 
		WHERE ID_COMMENT = $id LIMIT 1", __FILE__, __LINE__);
                
                db_query("DELETE FROM {$db_prefix}profile_subcomments 
		WHERE ID_PROFILE_COMMENT = $id ", __FILE__, __LINE__);

		// Redirect back to profile
		redirectexit('action=profile;u=' . $row['COMMENT_MEMBER_ID'] . ';op=muro');
	
}

function CommentsAdmin()
{
	global $db_prefix, $mbname, $txt, $context;
	
	isAllowedTo('admin_forum');

	adminIndex('comment_settings');

	$context['sub_template']  = 'commentsadmin';

	// Set the page title
	$context['page_title'] = $mbname . $txt['pcomments_admin'];
	
}

function ApproveComment()
{
	global $db_prefix, $sourcedir, $scripturl, $txt;
	
	isAllowedTo('admin_forum');
	
	// Get the comment id
	$id = (int) $_REQUEST['id'];
	
	
	db_query("UPDATE {$db_prefix}profile_comments
			SET approved = 1 WHERE ID_COMMENT = $id LIMIT 1", __FILE__, __LINE__);

		$result = db_query("
		SELECT 
			COMMENT_MEMBER_ID, ID_MEMBER 
		FROM {$db_prefix}profile_comments  
		WHERE ID_COMMENT = $id LIMIT 1", __FILE__, __LINE__);	
		$commentRow = mysql_fetch_assoc($result);
		mysql_free_result($result);
		
	// Lookup the user name's
		$dbresult = db_query("
		SELECT 
			realName 
		FROM {$db_prefix}members
		WHERE ID_MEMBER = " . $commentRow['ID_MEMBER'], __FILE__, __LINE__);
		$row = mysql_fetch_assoc($dbresult);
		mysql_free_result($dbresult);
		
		$pm_recipients = array(
						'to' => array($commentRow['COMMENT_MEMBER_ID']),
						'bcc' => array(),
					);
				
		require_once($sourcedir . '/Subs-Post.php');
				
	
		$notify_body = $txt['pcomments_notify_pm_body'] . $scripturl . '?action=profile;u=' . $commentRow['COMMENT_MEMBER_ID'];
		
		$notify_body = str_replace("%poster",$row['realName'],$notify_body);
		
		$pm_from = array(
					'id' =>  $commentRow['ID_MEMBER'],
					'username' => '',
					'name' => '',
				);
				
		sendpm($pm_recipients,$txt['pcomments_notify_pm_subject'] , $notify_body,false,$pm_from);
	
	redirectexit('action=comment;sa=admin');

}
?>