<?php
/* Spirate Script - Version 2.4
******   Help.php     ******/

if (!defined('SPIRATE'))
	die('Hacking attempt...');


// Redirect to the user help ;).
function ShowHelp()
{
	global $settings, $user_info, $language, $context, $txt;

	loadTemplate('Help');
	loadLanguage('Manual');

	// All the available pages.
	$context['all_pages'] = array(
		'index' => 'intro',
		'registering' => 'register',
		'loginout' => 'login',
		'profile' => 'profile',
		'post' => 'posting',
		'pm' => 'pm',
		'searching' => 'search',
	);

	if (!isset($_GET['page']) || !is_string($_GET['page']) || !isset($context['all_pages'][$_GET['page']]))
		$_GET['page'] = 'index';

	$context['current_page'] = $_GET['page'];
	$context['sub_template'] = 'manual_' . $context['all_pages'][$context['current_page']];

	$context['template_layers'][] = 'manual';
	$context['page_title'] = $txt['manual_smf_user_help'] . ': ' . $txt['manual_index_' . $context['all_pages'][$context['current_page']]];

	// We actually need a special style sheet for help ;)
	$context['html_headers'] .= '
		<link rel="stylesheet" type="text/css" href="' . (file_exists($settings['theme_dir'] . '/help.css') ? $settings['theme_url'] : $settings['default_theme_url']) . '/help.css" />';
}

// Show some of the more detailed help to give the admin an idea...
function ShowAdminHelp()
{
	global $txt, $helptxt, $context;

	// Load the admin help language file and template.
	loadLanguage('Help');

	// Permission specific help?
	if (isset($_GET['help']) && substr($_GET['help'], 0, 14) == 'permissionhelp')
		loadLanguage('ManagePermissions');

	loadTemplate('Help');

	// Set the page title to something relevant.
	$context['page_title'] = $context['forum_name'] . ' - ' . $txt[119];

	// Don't show any template layers, just the popup sub template.
	$context['template_layers'] = array();
	$context['sub_template'] = 'popup';

	// What help string should be used?
	if (isset($helptxt[$_GET['help']]))
		$context['help_text'] = &$helptxt[$_GET['help']];
	elseif (isset($txt[$_GET['help']]))
		$context['help_text'] = &$txt[$_GET['help']];
	else
		$context['help_text'] = $_GET['help'];
}

?>