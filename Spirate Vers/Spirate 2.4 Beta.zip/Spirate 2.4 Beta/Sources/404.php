<?php
/* Spirate Script - Version 2.4
******   Agregar.php     ******/

if (!defined('SPIRATE'))
	die('Error');

function error404()
{ 	
	$context['page_title'] = 'UPS!';
	loadTemplate('404');
	
}

?>