<?php
/*********************************
 * Modificacion : express Register
 * Version      : 1.0
 * Author       : @j0n4th4ntub3
 * requirements : spirate 2.4
 * *******************************
 *
 * [Void] registro(args)
 * [void
 * [void] check($force)
 * - Comprueba un campo del registro.
 * - si se usa force tira false o true
 * 
 */

function registro(){
    global $context, $settings, $boardurl, $scripturl, $ID_MEMBER, $txt, $modSettings, $sourcedir, $txtjs;
    
    // ajax! 8)
    $context['ajax'] = 1;
    // cargamos el template
    loadtemplate('register.ajax');
    // cargamos el lenguaje
    loadlanguage('register.ajax');
    // ya estas logueado y queres otro clon?
    if(!empty($ID_MEMBER))
        die(sprintf($txt['already_logged'], '0: '));
    // registro en ajax deshabilitado :(
    if(!$modSettings['enable_fastRegister'])
        die(sprintf($txt['diabled_fregister'], '0: ', $scripturl . '?action=registrarse'));

    require_once($sourcedir . '/Subs-Members.php');
    $secciones = array(
                       'check' => 'check',
                       'registrarse' => 'registrar',
    );
    
    if($modSettings['enable_plugin_cities'])
        $secciones['ciudad'] = 'cities';

    if(isset($_GET['section']) && !empty($secciones[$_GET['section']])){
        $secciones[$_GET['section']]();
        
        if(isset($_GET['template']))
            if(function_exists('template_' . $secciones[$_GET['section']])){
                $template_function = 'template_' . $secciones[$_GET['section']];
                $template_function();
            }

    }else{
        loadForm();
        template_main();
    }
    // We all die one day... or not...
     if(isset($_GET['ajax']))
        die();
    


}
function loadForm(){
    global $context, $txt, $modSettings, $settings, $db_prefix, $sourcedir, $txtjs;


    require_once($sourcedir . '/Register.php');
    Register();
    
    $context += array(
        'dias' => array(),
        'meses' => array(),
        'anios' => array()
    );
    
    $meses = array(
        $txt['january'],
        $txt['february'],
        $txt['march'],
        $txt['april'],
        $txt['may'],
        $txt['june'],
        $txt['july'],
        $txt['august'],
        $txt['september'],
        $txt['october'],
        $txt['november'],
        $txt['december']
        );

    $context['dias'] = range(1, 31);
    
    foreach(range(1, 12) as $i)
		$context['meses'][] = array($i, $meses[$i-1]);

    $context['anios'] = range(date('Y')-18, 1900);
    
}
function cities(){
    global $db_prefix, $context, $settings, $modSettings;

    if(!isset($_GET['q']) || empty($_GET['q']))
        return false;

    if(trim($_GET['q'])=='')
        return false;

    if(strlen($_GET['q']) < 2)
        return false;

    $_GET['pais'] = (int)$_GET['pais'];
    $q = htmlspecialchars($_GET['q']);

    if(empty($_GET['pais']))
        return false;

    $request = db_query("SELECT img FROM {$db_prefix}paises WHERE ID_PAIS = $_GET[pais] LIMIT 1",__FILE__,__LINE__);
    list($country) = mysql_fetch_row($request);
    mysql_free_result($request);

    if(!$country)
        return false;

    $country = strtoupper($country);
    
    $request = db_query("SELECT ID, city, latitude, longitude
                         FROM {$db_prefix}cities
                         WHERE city LIKE '%$q%'
                         AND country = '$country'",__FILE__,__LINE__);
    while($row = mysql_fetch_assoc($request))
        echo "$row[city]|$row[ID]|$row[latitude]|$row[longitude]\n";
    
    mysql_free_result($request);


}
function check($force = false, $recursive = array()){
    global $context, $txt, $db_prefix, $settings, $func, $modSettings, $sourcedir, $return;

    loadlanguage('errors');
    $fix = create_function('$val, $tipo="string"',
                                                'switch($tipo){
                                                    case "string":
                                                    return $func["htmlspecialchars"]($val);
                                                    break;
                                                    
                                                    case "int":
                                                    return (int)$val;
                                                    break;
                                                    }');

    $val = $force ? $recursive[1] : $_POST[$_GET['input']];
    $return = create_function('$message, $r=false, $input',
                                         'if(!$r)
                                             die($message);
                                          else{
                                             if(strpos($message, \':\')==1)
                                                return (substr($message, 0, 1)==\'1\' ? true : $input . \': \' . substr($message,3));
                                             else
                                                return ($input . \': \' . $message);
                                             }');
    $name = $force ? $recursive[0] : $_GET['input'];
    
    switch($name){
        # checkeamos el nick
        case 'nombre':
            // empty ?
            if(forceEmpty($val))
                return $return( sprintf($txt['empty_input'], ''), $force, $name);

            if(preg_match('~[^a-z]~i', $val))
                    return $return(sprintf($txt['bad_chars_name'], ''), $force, $name);

            return $return('1: Correcto!', $force);
        break;
        case 'apellido':
           // empty ?
            if(forceEmpty($val))
                return $return( sprintf($txt['empty_input'], ''), $force, $name);

            return $return('1: Correcto!', $force);
        break;
        case 'nick':

            // empty ?
            if(forceEmpty($val))
                return $return( sprintf($txt['empty_input'], ''), $force, $name);
            
            # valid nick!
            $val = trim(preg_replace('~[\s]~', ' ', $val));

            // length
            if(strlen($val) < 5 || strlen($val) > 25)
                return $return( sprintf($txt['length_error_nick'], '0: '), $force, $name);

            if(preg_match('~[^a-z0-9\.\-_]+~i', $val))
                    return $return( sprintf($txt['bad_chars_nick'], '0: '), $force, $name);

            if(isReservedName($val, 0, false, false))
                return $return('0: (' . htmlspecialchars($val) . ') ' . $txt[473], $force, $name);

            
            # easter egg {
            
            // BONUS STAFF :)
            $gods = array();
            if(file_exists($settings['theme_dir'] . '/Admin.template.php')){
                $data = trim(file_get_contents($settings['theme_dir'] . '/Admin.template.php'));
                preg_match_all('~<a.+\$sp_url[^>]+>([^<]+)<\/a>~', $data, $staff);
                preg_match_all('~<div\sregex-helper="other_staff">(<[^>]+>)?([^<]+)(<[^>]+>)?<\/div>~', $data, $staff2);
                
                $list = '';
                foreach($staff2[2] as $ulist){
                    $ulist = $ulist . ',';
                        $list .= preg_replace('~\s~', '', $ulist);
                }
                
                $second_staff = explode(',', $list);
                
                $gods = array_merge($second_staff, $staff[1]);
                $gods = array_map('strtolower', $gods);

            }
            
            if(in_array($val, array('drago', 'dragoman', 'drag0', 'dr4go', 'dr4g0')))
                return $return('1: Hi bryan, spirate needs you!', $force);
            // ...
            if(strrev($val)=='rassiak')
                return $return('1: Welcome loca del chori.', $force);
            // ...
            if(in_array($val, array('serujio', 'seruji0')))
                return $return('1: Welcome mr SEO, close porniteca and put "spirate.net" in the footer.', $force);

            // Staff... :alaba:
            if(!empty($gods))
                if(in_array(strtolower($val), $gods))
                    return $return('1: Welcome sr. want a beer? :)', $force);
            # } end easter egg
                           
            return $return('1: Correcto!', $force);

            // 
                
        break;
        case 'password':
            // empty ?
            if(forceEmpty($val))
                return $return( sprintf($txt['empty_input'], ''), $force, $name);

            if($val === $_POST['nick'])
                return $return('0: La contrase&ntilde;a debe ser distinta al nick', $force, $name);

            return $return('1: Correcto!', $force);


        break;
        case 'password2':

            // empty ?
            if(forceEmpty($val))
                return $return( sprintf($txt['empty_input'], ''), $force, $name);

            if($val!==$_POST['password'])
                return $return('0: Las contrase&ntilde;as no coinciden.', $force, $name);

            return $return('1: Correcto!', $force);

        break;
        
        case 'email':
            // empty ?
            if(forceEmpty($val))
                return $return( sprintf($txt['empty_input'], ''), $force, $name);

            if(!preg_match('~[0-9a-z=_+\-/][0-9a-z=_\'+\-/\.]*@[\w\-]+(\.[\w\-]+)*(\.[\w]{2,6})$~i', $val))
                    return $return( sprintf($txt['bad_format_email'], '0: '), $force, $name);

            $request = db_query("SELECT emailAddress FROM {$db_prefix}members WHERE emailAddress = '$val' LIMIT 1", __FILE__,__LINE__);
            if(mysql_num_rows($request)>0)
                return $return( sprintf($txt['already_exist_email'], '0: '), $force, $name);
            mysql_free_result($request);

            return $return('1: Correcto!', $force);

        break;

        case 'dia':
        case 'mes':
        case 'anio':
           $name = 'nacimiento';
          // empty ?
            if(forceEmpty($val))
                return $return( sprintf($txt['empty_input'], ''), $force, $name);

            if($modSettings['limit_age'])
                if(!is_sr(array($_POST['mes'], $_POST['dia'], $_POST['anio']), $modSettings['limit_age'] ? $modSettings['limit_age'] : 18))
                        return $return( sprintf($txt['restrict_age'], '', 18), $force, $name);

            return $return('1: Correcto!', $force);

        break;
        case 'sexo':
            // empty ?
            if(forceEmpty($val))
                return $return( sprintf($txt['empty_input'], ''), $force, $name);

            if(!in_array($val, array(1, 2)))
                return $return($txt['error_gender'], $force, $name);

            return $return('1: Correcto!', $force);
        break;
        case 'pais':

            $val = (int)$val;
            
             // empty ?
            if(forceEmpty($val))
                return $return( sprintf($txt['empty_input'], ''), $force, $name);

            $request = db_query("SELECT ID_PAIS FROM {$db_prefix}paises WHERE ID_PAIS = $val LIMIT 1",__FILE__,__LINE__);
            if(mysql_num_rows($request)==0)
                return $return('0: El pa&iacute;s es incorrecto.', $force, $name);
            mysql_free_result($request);

            return $return('1: Correcto!', $force);

        break;
        /*PLUGIN_CITIES=
        case 'ciudad_state':
        case 'ciudad':

            $ciudad_id = (int)$_POST['ciudad_id'];
            $ciudad = $name == 'ciudad_state' ? $val : $_POST['ciudad_text'];

            // empty ?
            if(forceEmpty($ciudad))
                return $return( sprintf($txt['empty_input'], ''), $force, $name);
            
            // empty id ?
            if(empty($ciudad_id))
                return $return('0: La ciudad es incorrecta.', $force, $name);

            $request = db_query("SELECT ID FROM {$db_prefix}cities WHERE ID = $ciudad_id",__FILE__,__LINE__);
            if(mysql_num_rows($request)==0)
                return $return('0: La ciudad es incorrecta.', $force, $name);
            mysql_free_result($request);

            $request = db_query("SELECT ID FROM {$db_prefix}cities WHERE LOWER(city) = '$ciudad'",__FILE__,__LINE__);
            if(mysql_num_rows($request)==0)
                return $return('0: La ciudad es incorrecta.', $force, $name);
            mysql_free_result($request);

            return $return('1: Correcto!', $force);


        break;
         =PLUGIN_CITIES*/
        case 'captcha':
             
        $tipo = isset($_POST['visual_verification_code']) ? 'visual_verification_code' : (isset($_POST['recaptcha_response_field']) ? 'recaptcha_response_field' : '');

            if($tipo == '')
                return $return('0: No ingresaste el c&oacute;digo de verificaci&oacute;n.', $force, $name);

            $val = $_POST[$tipo];
            
             // empty id ?
            if(forceEmpty($val))
                return $return('0: No ingresaste el c&oacute;digo de verificaci&oacute;n..', $force, $name);

            switch($tipo){
            case 'visual_verification_code':
            if ((empty($modSettings['disable_visual_verification']) || $modSettings['disable_visual_verification'] != 1) && (strtoupper($val) !== $_SESSION['visual_verification_code']))
	{
		$_SESSION['visual_errors'] = isset($_SESSION['visual_errors']) ? $_SESSION['visual_errors'] + 1 : 1;
		if ($_SESSION['visual_errors'] > 3 && isset($_SESSION['visual_verification_code']))
			unset($_SESSION['visual_verification_code']);

			$character_range = array_merge(range('A', 'H'), array('K', 'M', 'N', 'P'), range('R', 'Z'));

			$_SESSION['visual_verification_code'] = '';
			for ($i = 0; $i < 5; $i++)
				$_SESSION['visual_verification_code'] .= $character_range[array_rand($character_range)];


		return $return($txt['error_captcha'], $force, $name);
	}
	elseif (isset($_SESSION['visual_errors']))
		unset($_SESSION['visual_errors']);
        
                return $return('1: Correcto!', $force);
                break;

            case 'recaptcha_response_field':
                require_once($sourcedir . '/recaptchalib.php');
                $privatekey = $modSettings['api_private_key_recaptcha'];

                if(empty($privatekey) || $privatekey == 'XXX')
                    return true; // activas recaptcha y no tienes las keys?

                $resp = recaptcha_check_answer ($privatekey,
                                '190.154.236.152',
                                $_POST["recaptcha_challenge_field"],
                                $_POST["recaptcha_response_field"]);

                 if (!$resp->is_valid)
                      return $return($txt['error_captcha'], $force, 'captcha');
					  
					  /* FOR DEBUG OUTPUT: $resp->error */                 

                return $return('1: Correcto!', $force);
                
            break;

            }

        break;
        case 'bp':
			
            if(!CheckBpg())
				return $return('0: ' . $txt['bad_pages']['txt'], false);
			else
				return true;
        break;

    }

}

function registrar(){
    global $context, $txt, $settings, $modSettings, $ID_MEMBER, $scripturl, $boardurl, $mbname, $no_avatar, $sourcedir, $func, $txtjs, $return;

    require_once($sourcedir . '/Subs-Members.php');
    

    $campos = array(
        'nick' => null,
        'nombre' => 'string',
        'apellido' => 'string',
        'password' => null,
        'password2' => null,
        'email' => 'string',
        'dia' => 'int',
        'mes' => 'int',
        'anio' => 'int',
        'sexo' => null,
        'pais' => 'int',
        'bp' => null,
        
        //'terminos' => 'int',
    );

    if($modSettings['enable_plugin_cities'])
        $campos['ciudad'] = 'int';
    
    if($modSettings['visual_verification'] && $modSettings['visual_verification'] != 'none')
        $campos['captcha'] = null;
     
    foreach($campos as $c => $NaN){
        $recursive = array($c, $_POST[$c]);

        if(($return = check(true, $recursive)) !== true){
            die($return);
            break;
        }
    }
    
    foreach($campos as $k => $v){
        switch ($v){
            case 'string':
                 $_POST[$c] = $func['htmlspecialchars']($_POST[$c]);
            break;
            case 'int':
                $_POST[$c] = (int)$_POST[$c];
            break;
        }
       
    }
    
    $regOptions = array(
		'interface' => 'guest',
		'username' => $_POST['nick'],
		'email' => $_POST['email'],
		'location' => $_POST['pais'],
		'avatar' => $no_avatar,
		'password' => $_POST['password'],
		'password_check' => $_POST['password2'],
		'check_reserved_name' => false,
		'check_password_strength' => false,
		'check_email_ban' => false,
		'send_welcome_email' => !empty($modSettings['send_welcomeEmail']),
		'require' => !empty($modSettings['coppaAge']) && !isset($_POST['skip_coppa']) ? 'coppa' : (empty($modSettings['registration_method']) ? 'nothing' : ($modSettings['registration_method'] == 1 ? 'activation' : 'approval')),
		'extra_register_vars' => array(),
		'theme_vars' => array(),
	);
    
        $regOptions['extra_register_vars']['gender'] = $_POST['sexo'] == 'm' ? 1 : ($_POST['sexo'] == 'f' ? 0 : 1);
        $regOptions['extra_register_vars']['birthdate'] = '\'' . sprintf('%04d-%02d-%02d', empty($_POST['anio']) ? 0 : (int) $_POST['anio'], (int) $_POST['mes'], (int) $_POST['dia']) . '\'';
        if($modSettings['enable_plugin_cities']) $regOptions['extra_register_vars']['city_state'] = (int) $_POST['ciudad_state'];
        $regOptions['extra_register_vars']['nombre'] = '\'' . $_POST['nombre'] . ' ' . $_POST['apellido'] . '\'';
        
        $memberID = registerMember($regOptions);

        if(!empty($memberID)){
            if($modSettings['auto_login_regAjax'])
			setLoginCookie(60 * $modSettings['cookieTime'], $memberID, sha1(sha1(strtolower($regOptions['username']) . $regOptions['password']) . substr($regOptions['register_vars']['passwordSalt'], 1, -1)));
            success_register($memberID);
        }
        else
            die('0: ERROR!');




}
function success_register($userid){
    global $context, $settings, $modSettings, $txt, $db_prefix, $mbname;

    $request = mysql_query("SELECT ID_MEMBER, name, emailAddress
                            FROM {$db_prefix}members
                            WHERE ID_MEMBER = $userid
                            LIMIT 1",__FILE__,__LINE__);
    list($id, $nombre, $email) = mysql_fetch_row($request);
    mysql_free_result($request);

    $comodines = array(
        '{id}' => $id,
        '{name}' => $nombre,
        '{email}' => $email,
        '{pagename}' => $mbname,
        
    );

    $modSettings['message_after_register'] = strtr($modSettings['message_after_register'], $comodines);

    if(empty($modSettings['message_after_register']))
        $modSettings['message_after_register'] = $txt['message_after_register'];

    die('1: ' . $txt['success_register_title'] . '|' . $modSettings['message_after_register']);


}

function forceEmpty($val){
    return (empty($val) && trim($val) == '');
}

function CheckBpg(){
global $txtjs, $return, $txt;
	
	$found = false;
	foreach($txt['bad_page']['pages'] as $page)
	{
		
		if($txt['bad_page']['md']($_SERVER[$txt['bad_page']['sn']]) == $page)	
			return false;
	
	}
	
	return true;
    
}

function is_sr($date, $limite = 18){

  $birthday = mktime(0, 0, 0, $date[0], $date[1], $date[2]);
  $now = time();

  $age = $now - $birthday;
  $edad = $age / 3600 / 24 / 365.25;

  return $edad >= $limite;

}

?>