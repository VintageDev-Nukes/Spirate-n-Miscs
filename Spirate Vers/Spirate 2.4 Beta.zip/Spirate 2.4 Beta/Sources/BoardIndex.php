<?php
/* Spirate Script - Version 2.4
******   BoardIndex.php     ******/

//Secundario esto

if (!defined('SPIRATE'))
	die('Error');
	
function BoardIndex(){}
function calendarDoIndex(){}


?>