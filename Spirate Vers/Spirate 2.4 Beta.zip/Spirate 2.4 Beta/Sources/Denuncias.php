<?php
/* Spirate Script - Version 2.4
******   Denuncias.php     ******/

if (!defined('SPIRATE'))
	die('Hacking attempt...');

function Denuncias(){
	// language -> Denuncias.*.php
	loadlanguage('Denuncias');
	
	// template -> Denuncias.template.php
	loadtemplate('Denuncias');

	// sub acciones -> funciones
	$subActions = array(
		'denunciar' => 'denunciar',
		'denunciar2' => 'denunciar2',
		'ver' => 'ver'
	);
	
	$sa = $_GET['sa'];
	if (!empty($subActions[$sa]))
		$subActions[$sa]();
	// default
	else
		ver();
}

// ver denuncias
function ver(){
	global $context;
	$context['page_title'] = 'Moderaci&oacute;n de Denuncias';

	$context['sub_template']  = 'denuncias';
	
	// adminIndex() -> menu de administracion
	adminIndex('denuncias');
}

// denunciar form
function denunciar(){
	global $context;
	
	is_not_guest();
	
	$context['page_title'] = 'Denunciar';

	$context['sub_template']  = 'denunciar';
}

// denuncia enviar
function denunciar2(){
	global $db_prefix, $context, $ID_MEMBER;
	
	is_not_guest();
	
	$context['page_title'] = 'Denuncias';
	
	$context['sub_template']  = 'denunciar2';
	
	$comentario = htmlspecialchars($_POST['comentario'], ENT_QUOTES);
	$tipo = (int) $_POST['tipo'];
	$razon = (int) $_POST['razon'];
	$id = (int) $_POST['id'];
	
	/*die("Tipo: ".$tipo.", Razon:".$razon.", id: ".$id."");*/

	if($razon < 0 or $razon > 15){
		die(json_encode(array('msg' => 'Deb&eacute;s especificar la raz&oacute;n de tu denuncia.')));
	}
	
	if($id < 0){
		die(json_encode(array('msg' => 'Me t&eacute;nes que indicar lo que quer&eacute;s denunciar.')));
	}
	
	//Denuncias a posts
	if($tipo == 1){
		$r = db_query("SELECT p.ID_TOPIC
		FROM {$db_prefix}messages as p
		WHERE p.ID_TOPIC = '$id'",__FILE__,__LINE__);
		$n = mysql_num_rows($r);
		mysql_free_result($r);

		$result = db_query("SELECT p.ID_MEMBER, p.ID_TOPIC
		FROM {$db_prefix}messages as p
		WHERE p.ID_TOPIC = '$id'",__FILE__,__LINE__);
		$f = mysql_fetch_array($result);
		mysql_free_result($result);
		if(!$f){

			die(json_encode(array('msg' => 'Error al procesar la denuncia.')));
		}

		if($ID_MEMBER == $f['ID_MEMBER']){

			die(json_encode(array('msg' => 'No puedes denunciar tus publicaciones.')));
		}

		$j = db_query("SELECT d.id_denuncia
		FROM {$db_prefix}denuncias as d
		WHERE d.id = '$id' AND d.id_user = '$ID_MEMBER' AND d.tipo = 1",__FILE__,__LINE__);
		$h = mysql_num_rows($j);
		mysql_free_result($j);

		if($h){
			die(json_encode(array('msg' => 'Ya denunciaste este post.')));
		}
		if($n){
			$fecha = time();
			db_query("INSERT INTO {$db_prefix}denuncias
			(id,id_user,tipo,razon,comentario,fecha)
			VALUES ('$id','$ID_MEMBER',$tipo,'$razon','$comentario','$fecha')", __FILE__, __LINE__);
			die(json_encode(array('msg' => 'Denuncia enviada con exito.')));
		}
		else {
			die(json_encode(array('msg' => 'El post fue eliminado.')));
		}
	}
	//Denuncias a usuarios
	else if($tipo == 2){

		if(empty($comentario)){
			die(json_encode(array('status' => 'error', 'msg' => 'Debes especificar la raz&oacute;n de tu denuncia.')));
		}
		$r = db_query("SELECT mem.ID_MEMBER
		FROM {$db_prefix}members as mem
		WHERE mem.ID_MEMBER = '$id'",__FILE__,__LINE__);
		$n = mysql_num_rows($r);
		mysql_free_result($r);
		if($n){
			$fecha = time();
			db_query("INSERT INTO {$db_prefix}denuncias
			(id,id_user,tipo,razon,comentario,fecha)
			VALUES ('$id','$ID_MEMBER',$tipo,'$razon','$comentario','$fecha')", __FILE__, __LINE__);
			die(json_encode(array('msg' => 'Denuncia enviada con exito.')));
		}
		else {
			die(json_encode(array('status' => 'error', 'msg' => 'El usuario no existe.')));
		}
	}
	//Denuncias a imagenes
	elseif($tipo == 3){

		$r = db_query("SELECT i.IDI
		FROM {$db_prefix}imagenes as i
		WHERE i.IDI = '$id'",__FILE__,__LINE__);
		$n = mysql_num_rows($r);
		mysql_free_result($r);

		$j = db_query("SELECT d.id_denuncia
		FROM {$db_prefix}denuncias as d
		WHERE d.id = '$id' AND d.id_user = $ID_MEMBER AND tipo = 3",__FILE__,__LINE__);
		$h = mysql_num_rows($j);
		mysql_free_result($j);

		if($h){
			die(json_encode(array('msg' => 'Ya denunciaste esta imagen.')));
		}
		if($n){
			$fecha = time();
			db_query("INSERT INTO {$db_prefix}denuncias
			(id,id_user,tipo,razon,comentario,fecha)
			VALUES ('$id','$ID_MEMBER',$tipo,'$razon','$comentario','$fecha')", __FILE__, __LINE__);
			die(json_encode(array('msg' => 'Denuncia enviada con exito.')));
		}
		else {
			fdie(json_encode(array('msg' => 'La imagen fue eliminada.')));
		}
	}
	//Denuncias a streams
	if($tipo == 4){

		

		$r = db_query("SELECT id
		FROM {$db_prefix}activity
		WHERE id = '$id'",__FILE__,__LINE__);
		$n = mysql_num_rows($r);
		mysql_free_result($r);

		$result = db_query("SELECT subject, type, object
		FROM {$db_prefix}activity
		WHERE id = '$id'",__FILE__,__LINE__);
		$f = mysql_fetch_array($result);
		mysql_free_result($result);
		if(!$f){

				die(json_encode(array('status' => 'error', 'msg' => 'Publicaci&oacute;n no encontrada.')));
		}
		elseif($f['type'] == "re-stream"){

					$result2 = db_query("SELECT s.activity_id
					FROM {$db_prefix}activity_stream as s, {$db_prefix}activity as a
					WHERE a.id = '$id' AND a.object = s.activity_id",__FILE__,__LINE__);
					$y = mysql_fetch_array($result2);
					mysql_free_result($result2);

					if(!$y){

						die(json_encode(array('status' => 'error', 'msg' => 'No se encuentra la publicaci&oacute;n original.')));
					}


		}
		
		if($ID_MEMBER == $f['subject']){

			die(json_encode(array('status' => 'exito', 'msg' => 'No puedes denunciar tus publicaciones.')));
		}

		$j = db_query("SELECT d.id_denuncia
		FROM {$db_prefix}denuncias as d
		WHERE d.id = '$id' AND d.id_user = '$ID_MEMBER' AND d.tipo = 1",__FILE__,__LINE__);
		$h = mysql_num_rows($j);
		mysql_free_result($j);

		if($h){
			die(json_encode(array('status' => 'exito', 'msg' => 'Ya denunciaste esta publicacion.')));
		}
		if($n){

			$fecha = time();
			db_query("INSERT INTO {$db_prefix}denuncias
			(id,id_user,tipo,razon,comentario,fecha)
			VALUES ('$id','$ID_MEMBER',$tipo,'$razon','$comentario','$fecha')", __FILE__, __LINE__);
			die(json_encode(array('msg' => 'Denuncia enviada con exito.')));
		}
		else {
			die(json_encode(array('status' => 'exito', 'msg' => 'La publicaci&oacute;n fue eliminada.')));
		}
	}

	else {
		die(json_encode(array('status' => 'error', 'msg' => 'La denuncia no es v&aacute; v&aacute;lida.')));
	}
	
}

?>