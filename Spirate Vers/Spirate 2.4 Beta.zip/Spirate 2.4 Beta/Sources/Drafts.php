<?php
/* Spirate Script - Version 2.4
******   Acciones.php     ******/

if (!defined('SPIRATE'))
	die('Error');

function drafts(){
	global $settings, $user_info, $language, $context, $txt, $db_prefix;

        if(loadlanguage('Drafts') == false)
            loadLanguage('Drafts','spanish');
            
	loadTemplate('Drafts');

	$context['page_title'] = "Borradores";
}


?>