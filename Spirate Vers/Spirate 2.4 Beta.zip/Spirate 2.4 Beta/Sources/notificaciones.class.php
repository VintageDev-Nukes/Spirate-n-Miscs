<?php

if (!defined('SPIRATE'))
    die('hacking attempt...');

require_once($sourcedir . '/classes/parser.class.php');

class notificaciones extends parser {

    private $activities = array(
        'comment',
        'bookmark',
        'points'
    );
   
    // constructor
    public function __construct() {
        // nothing to make here...
    }
        
    public function notificar($type, $data) {
        global $context, $db_prefix, $scripturl, $text, $modSettings, $settings, $func, $ID_MEMBER;

        if(!in_array($type, $this->activities))
                return false;
        
        $ID = $this->constructNotify($type, $data);

        return $ID;
    }
    public function getNotifications($method = 'minimal'){
        global $ID_MEMBER, $db_prefix;

        if($method == 'minimal'){

        $result = db_query("SELECT ID_NOTIFY FROM {$db_prefix}notifications WHERE ID_MEMBER = $ID_MEMBER AND is_read = 0 ORDER BY ID_NOTIFY DESC",__FILE__,__LINE__);
        $total_no_reads = mysql_num_rows($result);
        mysql_free_result($result);

        $limit = $total_no_reads < 5 ? (5 - $total_no_reads) + $total_no_reads : $total_no_reads;

        $result = db_query("SELECT n.ID_NOTIFY, n.ID_MEMBER, n.type, n.template, n.data, n.is_read, n.time
                            FROM {$db_prefix}notifications as n
                            WHERE n.ID_MEMBER = $ID_MEMBER
                            ORDER BY n.ID_NOTIFY DESC
                            LIMIT $limit",__FILE__,__LINE__);
        $output = array();
        while($row = mysql_fetch_assoc($result)){
            $unserialized = unserialize($row['data']);

            $output[] = array(
                'id' => $row['ID_NOTIFY'],
                'senders' => array(
                    'id' => $unserialized['author']['ID_MEMBER'],
                    'name' => $unserialized['author']['memberName'],
                    'avatar' => $unserialized['author']['avatar'],
                ),
                'template' => $row['template'],
                'time' => $row['time'],
                'date' => hace($row['time']),
                'type' => $row['type'],
                'data' => $unserialized,
                'is_read' => $row['is_read'],
            );
        }

        return $output;
        
        }

    }
    public function markAsRead($ids){
        global $scripturl, $db_prefix, $ID_MEMBER;
        
        $ids = (array) $ids;
        
        // clean bad ids
        $notifications = array();
        foreach($ids as $id)
            $notifications[] = (int) $id;

        db_query("UPDATE {$db_prefix}notifications SET is_read = 1 WHERE ID_NOTIFY IN (" . implode(', ', $notifications) . ") AND ID_MEMBER = $ID_MEMBER",__FILE__,__LINE__);
        $updates = mysql_affected_rows();

        return $updates;

    }
    /*
     * internal functions
     */
    private function getDataFetch($type, $data){
        global $ID_MEMBER, $db_prefix, $context, $modSettings, $scripturl, $db_prefix;
        
        $output = array();

        $rows = array(
            'table[members]' => array(
                'comment' => array('ID_MEMBER', 'realName', 'memberName', 'avatar', 'notifications'),
                'bookmark' => array('ID_MEMBER', 'realName', 'memberName', 'avatar', 'notifications'),
            ),
            'table[topics]' => array(
                'comment' => array('m.ID_TOPIC', 'm.subject', 't.ID_MEMBER_STARTED'),
                'bookmark' => array('m.ID_TOPIC', 'm.subject', 't.ID_MEMBER_STARTED'),
            )
        );

        $idTopic = $data['topic']; $idAuthor = $data['author'];
		
		        
                // bad data?
                if(empty($idAuthor) || empty($idTopic))
                        return $output;

                $dataFromDB = array();

                // extract info...
                $result = db_query("SELECT " . implode(', ', $rows['table[members]'][$type]) . "
                                    FROM {$db_prefix}members
                                    WHERE ID_MEMBER = $idAuthor
                                    LIMIT 1", __FILE__, __LINE__);
                if(mysql_num_rows($result) == 0)
                    return $output;
                $fetch = mysql_fetch_assoc($result);
                mysql_free_result($result);

                foreach($fetch as $k => $v)
                    $dataFromDB['author'][$k] = $v;
                

                $result = db_query("SELECT " . implode(', ', $rows['table[topics]'][$type]) . ", mem.notifications as MEMBER_STARTED_NOTIFICATIONS
                                    FROM {$db_prefix}messages as m
                                    LEFT JOIN {$db_prefix}topics as t ON m.ID_TOPIC = t.ID_TOPIC
                                    LEFT JOIN {$db_prefix}members AS mem ON mem.ID_MEMBER = t.ID_MEMBER_STARTED
                                    WHERE m.ID_TOPIC = $idTopic
                                    LIMIT 1",__FILE__,__LINE__);
                if(mysql_num_rows($result) == 0)
                    return $output;
                $fetch = mysql_fetch_assoc($result);
                mysql_free_result($result);

                foreach($fetch as $k => $v)
                    $dataFromDB['topic'][$k] = $v;
                
                if($dataFromDB['topic']['ID_MEMBER_STARTED'] == $idAuthor)
                    return array('no_insert_notify' => true);
                

    switch($type){
        case 'comment':

            $output = $dataFromDB;

                $output['template'] = array(
                'user_profile' => $scripturl . '?action=profile&u=' . $dataFromDB['author']['ID_MEMBER'],
                'user_nick' => $dataFromDB['author']['realName'],
                'topic_url' => $scripturl . '?topic=' . $dataFromDB['topic']['ID_TOPIC'],
                'topic_name' => $dataFromDB['topic']['subject'],
            );

            $output['dataTodb'] =  array();
            $output['dataTodb']['topic'] = $dataFromDB['topic'];
            $output['dataTodb']['author'] = $dataFromDB['author'];
            $output['template_type'] = 'single';

            $request = db_query("SELECT ID_NOTIFY, time, data
                                FROM {$db_prefix}notifications
                                WHERE ID_MEMBER = " . $dataFromDB['topic']['ID_MEMBER_STARTED'] . "
                                AND is_read = 0
                                AND type = 'comment'
                                AND time + 86400 > ". time() ."
                                ORDER BY ID_NOTIFY DESC
                                LIMIT 1" ,__FILE__,__LINE__); 
            if(mysql_num_rows($request) != 0){
                    $r = mysql_fetch_assoc($request);
                    mysql_free_result($request);
                    $data_unserialize = unserialize($r['data']);
                    $last_sender = $data_unserialize['author'] ? $data_unserialize['author']['ID_MEMBER'] : false;
                    $last_senders = $data_unserialize['authors'] ? $data_unserialize['authors'] : array();
                    $last_topic = $data_unserialize['topic']['ID_TOPIC'];
                    if($last_sender == $idAuthor && $last_topic == $idTopic){
                            $output['no_insert_notify'] = true;
                            return $output;
                    }else if($data_unserialize['topic']['ID_TOPIC'] == $idTopic){
                        
                            unset($output['dataTodb']['author']);
                            $output['template_type'] = 'plural';
                            
                            $data_unserialize['count'] = (int) $data_unserialize['count'];
                            $count = $data_unserialize['count'];

                            if($data_unserialize['count'] < 1)
                                    $commentators = array($last_sender, $idAuthor);
                            else{
                                    $commentators = array();
                                    foreach($last_senders['IDS'] as $commentator)
                                            $commentators[] = $commentator;

                                    if(!in_array($idAuthor, $commentators))
                                            $commentators[] = $idAuthor;
                                    else{
                                            $output['no_insert_notify'] = true;
                                            return $output;
                                    }
                            }
                            $output['updateRow'] = 1;
                            $count = $count + 1;

                            if($count > 3){
                                $output['dataTodb'] = $data_unserialize;
                                $output['dataTodb']['count'] = $count;
                                $output['dataTodb']['authors']['IDS'] = $commentators;
                                $output['dataTodb']['authors']['data'] = $data_unserialize['authors']['data'];
                                
                                $output['template'] = array(
                                    'topic_url' => $scripturl . '?topic=' . $dataFromDB['topic']['ID_TOPIC'],
                                    'topic_name' => $dataFromDB['topic']['subject'],
                                    'remaining_users' => ' y <a name="remaining_members">'.($count-3).'</a> usuarios m&aacute;s comentaron'
                                );
                                
                                foreach($data_unserialize['authors']['data'] as $member)
                                    $output['template']['users_profile'][] = array(
                                            'template' => '<a href="{profile_url}" title="{nick}">{nick}</a>' . (end($data_unserialize['authors']['data']) == $member ? '' : ', '),
                                            'profile_url' => $scripturl . '?action=profile&u=' . $member['ID_MEMBER'],
                                            'nick' => $member['memberName']
                                    );                                
                                
                                $output['update_query'] = array(
                                    'template' => "SET template='%s', ",
                                    'data' => "data='" . serialize($output['dataTodb']) . "', ",
                                    'time' => "time = " . time(),
                                    'WHERE' => 'WHERE ID_NOTIFY = ' . $r['ID_NOTIFY']
                                );
                                
                                return $output;
                            }


                            $commentators_result = array(); $commentatorsLog = array();

                            $result = db_query("SELECT ID_MEMBER, memberName, avatar FROM {$db_prefix}members WHERE ID_MEMBER IN(".implode(', ', $commentators).")",__FILE__,__LINE__);
                            while($row = mysql_fetch_assoc($result)){
                                    $commentators_result[] = array(
                                            'ID_MEMBER' => $row['ID_MEMBER'],
                                            'memberName' => $row['memberName'],
                                            'avatar' => $row['avatar']
                                    );
                                    $commentatorsLog['IDS'][] = $row['ID_MEMBER'];
                            }
                            mysql_free_result($result);
                            
                            $output['dataTodb']['authors'] = array();
                            $output['dataTodb']['authors']['data'] = $commentators_result;
                            $output['dataTodb']['authors']['IDS'] = $commentatorsLog['IDS'];
                            $output['dataTodb']['count'] = $count;
                            
                            $output['template'] = array(
                                    'topic_url' => $scripturl . '?topic=' . $dataFromDB['topic']['ID_TOPIC'],
                                    'topic_name' => $dataFromDB['topic']['subject'],

                            );

                            foreach($commentators_result as $member){
                                    $separator = $commentators_result[0] == $member ? '' : (end($commentators_result) == $member ? ' y ' : ', ');

                                    $output['template']['users_profile'][] = array(
                                            'template' => $separator . '<a href="{profile_url}" title="{nick}">{nick}</a>',
                                            'profile_url' => $scripturl . '?action=profile&u=' . $member['ID_MEMBER'],
                                            'nick' => $member['memberName']
                                    );						
                            }
                            
                            
                            $output['update_query'] = array(
                                    'template' => "SET template='%s', ",
                                    'data' => "data='" . serialize($output['dataTodb']) . "', ",
                                    'time' => "time = " . time(),
                                    'WHERE' => 'WHERE ID_NOTIFY = ' . $r['ID_NOTIFY']
                            );
                            return $output;

                    }

            }
            mysql_free_result($request);
            return $output;
                    

        break;
        case 'bookmark':
            //..
        break;

    }

    return $output;
    }
    private function constructNotify($type, $data){
        global $scripturl, $db_prefix, $context, $modSettings;


        switch($type){
            case 'comment':
            $dataFetch = $this->getDataFetch($type, $data);
            $dataToParse = array();
            foreach($dataFetch['template'] as $k => $v)
                $dataToParse[$k] = $v;

            $template = $this->getTemplate(array($type, 'minimal', $dataFetch['template_type']));
            $parsedTemplate = $this->parse($template, $dataToParse);


            if(!$dataFetch['no_insert_notify']){

            $makeNotifyQuery = array(
                    'ID_MEMBER' => $dataFetch['topic']['ID_MEMBER_STARTED'],
                    'type' => "'" . $type . "'",
                    'template' => "'" . $parsedTemplate . "'",
                    'data' => "'" . serialize($dataFetch['dataTodb']) . "'",
                    'is_read' => 0,
                    'time' => time()
                );
			
			if(isset($dataFetch['updateRow']))
				$dataFetch['update_query']['template'] = sprintf($dataFetch['update_query']['template'], $parsedTemplate);

             $last_id = $this->addNotification(isset($dataFetch['updateRow']) ? $dataFetch['update_query'] : $makeNotifyQuery, isset($dataFetch['updateRow']) ? true : false);

            if($last_id != 'no_count' && !empty($last_id))
                updateMemberData($dataFetch['topic']['ID_MEMBER_STARTED'], array('notifications' => '+'));
			
            return $last_id;
            }

            return false;

            break;
        }


    }
    private function addNotification($data, $update = false){
        global $db_prefix;
        
        if($update)
            $makeQuery = "UPDATE {$db_prefix}notifications " . implode(' ', array_values($data));
        else
            $makeQuery = "INSERT INTO {$db_prefix}notifications (" . implode(', ', array_keys($data)) . ")
                          VALUES(" . implode(', ', array_values($data)) . ")";
						  
            db_query($makeQuery,__FILE__,__LINE__);

        if(!$update)
            return mysql_insert_id();
        else
            return 'no_count';
        
    }
    private function parse($template, $data){
        return self::_parse($template, $data);
    }/**
     *
     * Obtenemos el template para la notificacion.
     * @access private
     * @param array $filter
     * @return string|array
     */
    private function getTemplate($filter){

        // I know... I know...
        $templates = array(
            'comment' => array(
                'minimal' => array(
                    'single' => '<a href="{user_profile}">{user_nick}</a> coment&oacute; en tu <a class="tt-element" href="{topic_url}" title="{topic_name}">post</a>.',
                    'plural' => '{array:users_profile} {remaining_users} comentaron en tu <a class="tt-element" href="{topic_url}" title="{topic_name}">post</a>.'
                ),
                'extended' => array(
                    'single' => '<a href="{user_profile}">{user_nick}</a> coment&oacute; en tu post <a class="tt-element" href="{topic_url}" title="{topic_name}">{topic_name}</a>. {short_comment}',
                    'plural' => '{array:users_profile} {remaining_users html:<a href="#"></a>} comentaron en tu post <a class="tt-element" href="{topic_url}" title="{topic_name}">{topic_name}</a>.'
                )
            ),
            'bookmark' => array(
                'minimal' => array(
                    'single' => '<a href="{user_profile}">{user_nick}</a> agreg&oacute; a favoritos tu post <a class="tt-element" href="{topic_url}" title="{topic_name}">post</a>.',
                    'plural' => '{array:users_profile} {remaining_users} agregaron a favoritos tu <a class="tt-element" href="{topic_url}" title="{topic_name}">post</a>.'
                ),
                'extended' => array(
                    'single' => '',
                    'plural' => ''
                )
            )
        );

        $template = '';
        foreach($filter as $find){
            $template = $templates[$find];
            $templates = $template;
        }

        return $template;
    }

}



?>