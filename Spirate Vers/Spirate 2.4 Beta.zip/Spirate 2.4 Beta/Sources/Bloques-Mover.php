<?php
/* Spirate Script - Version 2.4
******   Bloques-Mover.php     ******/

require("../Settings.php");

$conexion = mysql_connect($db_server, $db_user, $db_passwd) OR die("Error al procesar lo solicitado");
require("../SSI.php");
mysql_select_db($db_name, $conexion) OR die("Error al procesar lo solicitado");

global $context;


/*Seguridad SOLO ADMINS ENTRAN ACA*/
$autor = $context['user']['id'];
$isadmin = mysql_query("SELECT ID_GROUP
                        FROM smf_members
                        WHERE ID_MEMBER = '$autor' LIMIT 1");
	while ($row = mysql_fetch_assoc($isadmin))
              if($row['ID_GROUP']!=1){die('No tienes permisos para ingresar aqui');}                                
	mysql_free_result($isadmin);
/**********************************/


$filabloque = $_POST['filabloque'];

if($filabloque==1){
//bloque a mover
$idmover = $_POST['idmover'];
$cual = $_POST['cual'];

//bloque
$donde = $_POST['donde'];

$result1 = mysql_query("
			UPDATE {$db_prefix}bloques
			SET  columna = '$cual'
			WHERE columna = '$donde' 
		LIMIT 1");

$result1 = mysql_query("
			UPDATE {$db_prefix}bloques
			SET  columna = '$donde'
			WHERE ID = '$idmover' 
		LIMIT 1");

if($result1)
{echo'<center><font color="#24B011"><b>Movido Correctamente!!!</b></font><br></center>';}
else{
echo'<center><font color="red"><b>Un error ha ocurrido...</b></font><br></center>';}
}
elseif($filabloque==2){

//bloque a mover
$idmover = $_POST['idmover'];
$cual = $_POST['cual'];

//bloque
$donde = $_POST['donde'];

$result1 = mysql_query("
			UPDATE {$db_prefix}bloquesf
			SET  filabloque = '$cual'
			WHERE filabloque = '$donde' 
		LIMIT 1");

$result1 = mysql_query("
			UPDATE {$db_prefix}bloquesf
			SET  filabloque = '$donde'
			WHERE ID_BLOQUE = '$idmover' 
		LIMIT 1");

if($result1)
{echo'<center><font color="#24B011"><b>Movido Correctamente!!!</b></font><br></center>';}
else{
echo'<center><font color="red"><b>Un error ha ocurrido...</b></font><br></center>';}

}

?>