<?php
/* Spirate Script - Version 2.4
******   ManageRegistration.php     ******/

if (!defined('SPIRATE'))
	die('Hacking attempt...');

// Main handling function for the admin approval center
function RegCenter()
{
	global $modSettings, $context, $txt, $db_prefix, $scripturl;

	// Old templates might still request this.
	if (isset($_REQUEST['sa']) && $_REQUEST['sa'] == 'browse')
		redirectexit('action=viewmembers;sa=browse' . (isset($_REQUEST['type']) ? ';type=' . $_REQUEST['type'] : ''));

	$subActions = array(
                'register' => array('AdminRegister', 'moderate_forum'),
                'reservednames' => array('SetReserve', 'admin_forum'),
		'settings' => array('AdminSettings', 'admin_forum'),
                'fast-register' => array('FastRegister', 'registro'),
	);

	// Work out which to call...
	$context['sub_action'] = isset($_REQUEST['sa']) && isset($subActions[$_REQUEST['sa']]) ? $_REQUEST['sa'] : (allowedTo('moderate_forum') ? 'register' : 'settings');

	// Must have sufficient permissions.
	isAllowedTo($subActions[$context['sub_action']][1]);

	// Set the admin area...
	adminIndex('registration_center');

	// Loading, always loading.
	loadLanguage('Login');
	loadTemplate('Register');

	// Next create the tabs for the template.
	$context['admin_tabs'] = array(
		'title' => &$txt['registration_center'],
		'help' => 'registrations',
		'description' => $txt['admin_settings_desc'],
		'tabs' => array(
			'register' => array(
				'title' => $txt['admin_browse_register_new'],
				'description' => $txt['admin_register_desc'],
				'href' => $scripturl . '?action=regcenter;sa=register',
				'is_selected' => $context['sub_action'] == 'register',
				'is_last' => !allowedTo('admin_forum'),
			)
		)
	);
	if (allowedTo('admin_forum'))
	{

		

		$context['admin_tabs']['tabs']['reservednames'] = array(
			'title' => $txt[341],
			'description' => $txt[699],
			'href' => $scripturl . '?action=regcenter;sa=reservednames',
			'is_selected' => $context['sub_action'] == 'reservednames',
		);
		$context['admin_tabs']['tabs']['settings'] = array(
			'title' => $txt['settings'],
			'description' => $txt['admin_settings_desc'],
			'href' => $scripturl . '?action=regcenter;sa=settings',
			'is_last' => true,
			'is_selected' => $context['sub_action'] == 'settings',
		);
                $context['admin_tabs']['tabs']['fast-register'] = array(

			'title' => $txt['title_fregister'],

			'description' => $txt['admin_fregister_desc'],

			'href' => $scripturl . '?action=regcenter;sa=fast-register',

			'is_last' => true,

			'is_selected' => $context['sub_action'] == 'fast-register',

		);
	}

	// Finally, get around to calling the function...
	$subActions[$context['sub_action']][0]();
}

// This function allows the admin to register a new member by hand.
function AdminRegister()
{
	global $txt, $context, $db_prefix, $sourcedir, $scripturl;

	// Setup the "tab", just incase an error occurs.
	$context['admin_tabs']['tabs']['register']['is_selected'] = true;

	if (!empty($_POST['regSubmit']))
	{
		checkSession();

		foreach ($_POST as $key => $value)
			if (!is_array($_POST[$key]))
				$_POST[$key] = htmltrim__recursive(str_replace(array("\n", "\r"), '', $_POST[$key]));

		$regOptions = array(
			'interface' => 'admin',
			'username' => $_POST['user'],
			'email' => $_POST['email'],
			'password' => $_POST['password'],
			'password_check' => $_POST['password'],
			'check_reserved_name' => true,
			'check_password_strength' => false,
			'check_email_ban' => false,
			'send_welcome_email' => isset($_POST['emailPassword']) || empty($_POST['password']),
			'require' => isset($_POST['emailActivate']) ? 'activation' : 'nothing',
			'memberGroup' => empty($_POST['group']) ? 0 : (int) $_POST['group'],
		);

		require_once($sourcedir . '/Subs-Members.php');
		$memberID = registerMember($regOptions);
		if (!empty($memberID))
		{
			$context['new_member'] = array(
				'id' => $memberID,
				'name' => $_POST['user'],
				'href' => $scripturl . '?action=profile;u=' . $memberID,
				'link' => '<a href="' . $scripturl . '?action=profile;u=' . $memberID . '">' . $_POST['user'] . '</a>',
			);
			$context['registration_done'] = sprintf($txt['admin_register_done'], $context['new_member']['link']);
		}
	}

	// Basic stuff.
	$context['sub_template'] = 'admin_register';
	$context['page_title'] = $txt['registration_center'];

	// Load the assignable member groups.
	$request = db_query("
		SELECT groupName, ID_GROUP
		FROM {$db_prefix}membergroups
		WHERE ID_GROUP != 3
			AND minPosts = -1" . (allowedTo('admin_forum') ? '' : "
			AND ID_GROUP != 1") . "
		ORDER BY minPosts, IF(ID_GROUP < 4, ID_GROUP, 4), groupName", __FILE__, __LINE__);
	$context['member_groups'] = array(0 => &$txt['admin_register_group_none']);
	while ($row = mysql_fetch_assoc($request))
		$context['member_groups'][$row['ID_GROUP']] = $row['groupName'];
	mysql_free_result($request);
}

// I hereby agree not to be a lazy bum.
function EditAgreement()
{
	global $txt, $boarddir, $context, $modSettings;

	if (isset($_POST['agreement']))
	{
		checkSession();

		// Off it goes to the agreement file.
		$fp = fopen($boarddir . '/agreement.txt', 'w');
		fwrite($fp, str_replace("\r", '', stripslashes($_POST['agreement'])));
		fclose($fp);

		updateSettings(array('requireAgreement' => !empty($_POST['requireAgreement'])));

		redirectexit('action=regcenter;sa=agreement');
	}

	// Get the current agreement.
	$context['agreement'] = file_exists($boarddir . '/agreement.txt') ? htmlspecialchars(file_get_contents($boarddir . '/agreement.txt')) : '';
	$context['warning'] = is_writable($boarddir . '/agreement.txt') ? '' : $txt['smf320'];
	$context['require_agreement'] = !empty($modSettings['requireAgreement']);

	$context['sub_template'] = 'edit_agreement';
	$context['page_title'] = $txt['smf11'];
}

// Set reserved names/words....
function SetReserve()
{
	global $txt, $db_prefix, $context, $modSettings;

	// Submitting new reserved words.
	if (!empty($_POST['save_reserved_names']))
	{
		checkSession();

		// Set all the options....
		updateSettings(array(
			'reserveWord' => (isset($_POST['matchword']) ? '1' : '0'),
			'reserveCase' => (isset($_POST['matchcase']) ? '1' : '0'),
			'reserveUser' => (isset($_POST['matchuser']) ? '1' : '0'),
			'reserveName' => (isset($_POST['matchname']) ? '1' : '0'),
			'reserveNames' => str_replace("\r", '', $_POST['reserved'])
		));
	}

	// Get the reserved word options and words.
	$context['reserved_words'] = explode("\n", $modSettings['reserveNames']);
	$context['reserved_word_options'] = array();
	$context['reserved_word_options']['match_word'] = $modSettings['reserveWord'] == '1';
	$context['reserved_word_options']['match_case'] = $modSettings['reserveCase'] == '1';
	$context['reserved_word_options']['match_user'] = $modSettings['reserveUser'] == '1';
	$context['reserved_word_options']['match_name'] = $modSettings['reserveName'] == '1';

	// Ready the template......
	$context['sub_template'] = 'edit_reserved_words';
	$context['page_title'] = $txt[341];
}

// This function handles registration settings, and provides a few pretty stats too while it's at it.
function AdminSettings()
{
	global $txt, $context, $db_prefix, $scripturl, $modSettings;

	global $sourcedir;
	// Setup the template
	$context['sub_template'] = 'admin_settings';
	$context['page_title'] = $txt['registration_center'];

	// Saving?
	if (isset($_POST['save']))
	{
		checkSession();

		// Are there some contacts missing?
		if (!empty($_POST['coppaAge']) && !empty($_POST['coppaType']) && empty($_POST['coppaPost']) && empty($_POST['coppaFax']))
			fatal_error($txt['admin_setting_coppa_require_contact']);

		// Post needs to take into account line breaks.
		$_POST['coppaPost'] = str_replace("\n", '<br />', empty($_POST['coppaPost']) ? '' : $_POST['coppaPost']);





		// PM Register User cleaning

		$_POST['pm_register_from'] = strtr(htmlspecialchars($_POST['pm_register_from'], ENT_QUOTES), array("\r" => '', "\n" => '', "\t" => ''));

		$_POST['pm_register_subject'] = strtr(htmlspecialchars($_POST['pm_register_subject'], ENT_QUOTES), array("\r" => '', "\n" => '', "\t" => ''));

		$_POST['pm_register_body'] = htmlspecialchars($_POST['pm_register_body'], ENT_QUOTES);



		// Load Subs-Post.php for this instance.

		require_once($sourcedir . '/Subs-Post.php');



		// Preparse the body for PM Register.

		preparsecode($_POST['pm_register_body']);
		// Update the actual settings.
		updateSettings(array(
			'registration_method' => (int) $_POST['registration_method'],
			'notify_new_registration' => isset($_POST['notify_new_registration']) ? 1 : 0,
			'send_welcomeEmail' => isset($_POST['send_welcomeEmail']) ? 1 : 0,
			'password_strength' => (int) $_POST['password_strength'],
			'disable_visual_verification' => isset($_POST['visual_verification_type']) ? (int) $_POST['visual_verification_type'] : 0,
			'coppaAge' => (int) $_POST['coppaAge'],
			'coppaType' => empty($_POST['coppaType']) ? 0 : (int) $_POST['coppaType'],
			'coppaPost' => $_POST['coppaPost'],
			'coppaFax' => !empty($_POST['coppaFax']) ? $_POST['coppaFax'] : '',
			'coppaPhone' => !empty($_POST['coppaPhone']) ? $_POST['coppaPhone'] : '',
			'ajaxregEnabled' => isset($_POST['ajaxregEnabled']) ? 1 : 0,
			'ajaxregFailureCSS' => !empty($_POST['ajaxregFailureCSS']) ? $_POST['ajaxregFailureCSS'] : '',
			'ajaxregSuccessCSS' => !empty($_POST['ajaxregSuccessCSS']) ? $_POST['ajaxregSuccessCSS'] : '',
		));

		// Reload the page, so the tabs are accurate.
		redirectexit('action=regcenter;sa=settings');
	}

	// Turn the postal address into something suitable for a textbox.
	$context['coppaPost'] = !empty($modSettings['coppaPost']) ? preg_replace('~<br(?: /)?' . '>~', "\n", $modSettings['coppaPost']) : '';


$mod_settings = array(

		'ajaxregEnabled' => true,

		'ajaxregFailureCSS' => 'color: white; background-color: green; width: 197px; border: thin black outset; text-align: center;',

		'ajaxregSuccessCSS' => 'color: white; background-color: red; width: 197px; border: thin black outset; text-align: center;',

);
	// Generate a sample registration image.
	$context['use_graphic_library'] = in_array('gd', get_loaded_extensions());
	$context['verificiation_image_href'] = $scripturl . '?action=verificationcode;rand=' . md5(mt_rand());

	$character_range = array_merge(range('A', 'H'), array('K', 'M', 'N', 'P'), range('R', 'Z'));
	$_SESSION['visual_verification_code'] = '';
	for ($i = 0; $i < 5; $i++)
		$_SESSION['visual_verification_code'] .= $character_range[array_rand($character_range)];
}

function FastRegister(){
    global $txt, $context, $db_prefix, $sourcedir, $scripturl;

    $context['admin_tabs']['tabs']['fast-register']['is_selected'] = true;

    $context['page_title'] = $txt['ajaxRegister_center'];

    require_once($sourcedir . '/ManageServer.php');
    loadLanguage('ModSettings');

    $context['sub_template'] = 'show_settings';

    $config_vars = array(
			$txt['admin_fregister_desc'],
                        array('check', 'enable_fastRegister'),
                        array('large_text', 'banned_passwords'),
                        array('int', 'limit_age'),
                        array('select', 'visual_verification', array('captcha' => 'default', 'recaptcha' => 'recaptcha', 'none' => 'ninguno')),
                        'need a key? For more information visit: &nbsp;<a target="_blank" href="http://www.google.com/recaptcha/whyrecaptcha">http://www.google.com/recaptcha/whyrecaptcha</a>',
                        array('text', 'api_public_key_recaptcha'),
                        array('text', 'api_private_key_recaptcha'),
                        array('check', 'enable_plugin_cities'),
                        array('large_text', 'message_after_register'),
                        array('check', 'auto_login_regAjax')

                    );

    if (isset($_GET['save']))
	{

		saveDBSettings($config_vars);

		writeLog();
		redirectexit('action=regcenter;sa=fast-register&saved=1');
	}

    
    prepareDBSettingContext($config_vars);
    
    // plugin cities is enabled ?
    $context['config_vars']['enable_plugin_cities']['disabled'] = true;

    $context['post_url'] = $scripturl . '?action=regcenter;sa=fast-register;save';
    $context['settings_title'] = $txt['ajaxRegister_center'];

}

?>