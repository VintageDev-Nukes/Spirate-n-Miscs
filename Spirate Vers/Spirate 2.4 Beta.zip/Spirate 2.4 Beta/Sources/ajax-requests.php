<?php
/* Spirate Script - Version 2.4
******   Ajax-sp.php     ******/

if (!defined('SPIRATE'))
die('Hacking attempt...');

function ajax(){
	global $txt, $context, $scripturl, $db_prefix, $settings, $modSettings;
	
	// languages -> Ajax-sp.*.php
	loadlanguage('Ajax-sp');
    loadlanguage('Denuncias');

	//Lista de acciones ajax
	$acciones = array(
            'comentar' => 'comentar',
            'add_bookmark' => 'add_bookmark',
            'send_points' => 'send_points',
            'notificaciones' => array('getNotifications', 'template' => 'notifications'),
            'add_cperfil' => 'add_cperfil',
            'comentarios' => 'comentarios',
            'vprevia' => 'vprevia',
			'borrarcom' => 'borrarcom',
            'den_form' => 'den_form',
            'eraseden' => 'eraseden',
            'previacom' => 'previacom',
            'add_imgcomment' => 'add_imgcomment',
            'puntosimg' => 'puntosimg',
            'videotube' => 'videotube',
            'filmonitor' => 'filmonitor',
            'vaciarmonitor' => 'vaciarmonitor',
            'html2bbc' => 'html2bbc',
            'bbc2html' => 'bbc2html',
			'follow_u' => 'follow_u',
			'unfollow_u' => 'unfollow_u',
            'editbox' => 'editbox',
			'topsday' => 'topsday',
			'topscat' => 'topscat',
            'statusform' => 'statusform',
            'statuschange' => 'statuschange',
            'preview'=> 'preview',
	);

        // Ajax off? ok, die now (:
        if(!$context['ajax_request'])
            die();

        // make sure is ajax
        $_REQUEST['ajax'] = 1;
	
	if (isset($_REQUEST['do']) && !empty($acciones[$_REQUEST['do']])){
            if(is_array($acciones[$_REQUEST['do']])){
                // funcion principal
                $acciones[$_REQUEST['do']][0]();
                // template
                if(!empty($acciones[$_REQUEST['do']]['template'])){
                    $template = 'template_' . $acciones[$_REQUEST['do']]['template'];
                    loadtemplate('ajax');
                    $template();
                }
            }
            else
                $acciones[$_REQUEST['do']]();
        }
	
	die();
}

function borrarcom(){

    global $txt, $context, $scripturl, $db_prefix, $settings, $modSettings, $ID_MEMBER, $no_avatar, $func, $boarddir, $sourcedir;

       $comid = (int) $_POST['comid'];
       $topic = (int) $_POST['postid'];


       $allow_admin = allowedTo('moderate_forum');


         // existe el post realmente?
        $request = db_query("SELECT ID_BOARD, ID_MEMBER_STARTED, locked FROM {$db_prefix}topics WHERE ID_TOPIC = $topic",__FILE__,__LINE__);
        
        list($board, $TopicAutor, $locked) = mysql_fetch_row($request);

        if(mysql_num_rows($request) == 0)
            die(json_encode(array('status' => 'error', 'msg' => 'El post no se encuentra o ha sido eliminado.')));

        mysql_free_result($request);


        
        // usuario inexistente?
        $request = db_query("SELECT memberName, realName, avatar FROM {$db_prefix}members WHERE ID_MEMBER = $ID_MEMBER LIMIT 1",__FILE__,__LINE__);
        list($memberName, $realName, $avatar) = mysql_fetch_row($request);

        if(mysql_num_rows($request)==0)
            die(json_encode(array('status' => 'error', 'msg' => 'Usuario inexistente.')));

        mysql_free_result($request);
                
        list($ID_BOARD) = mysql_fetch_row($request);
        mysql_free_result($request);


        // Existe el comentario?
        
        $request = db_query("SELECT comentario
                                FROM ({$db_prefix}comentarios)
                                WHERE id_coment = $comid", __FILE__, __LINE__);
            list($existec) = mysql_fetch_row($request);

         if(is_real_empty($existec))
            die(json_encode(array('status' => 'error', 'msg' => 'El comentario no existe.')));

        mysql_free_result($request);

            

       //Fijemonos que sea mayor a 0
            $request = db_query("SELECT comments
                                FROM ({$db_prefix}topics)
                                WHERE ID_TOPIC = $topic", __FILE__, __LINE__);
            list($totalComments) = mysql_fetch_row($request);
            mysql_free_result($request);


            $cant_com = $totalComments;


        //Nos fijamos si es admin o mod

                  $allow_erase = allowedTo('moderate_forum') || $ID_MEMBER == $TopicAutor;

        if(!$allow_erase){

            die(json_encode(array('status' => 'error', 'msg' => 'No tienes los permisos suficientes para borrar comentarios.')));
        }
            

        //Si no es 0 le resta 1 comentario    
        if($cant_com != 0){


         db_query("UPDATE {$db_prefix}topics
                               SET comments = comments - 1
                          WHERE ID_TOPIC = $topic",__FILE__,__LINE__);   

		//Actualizamos cantidad total de comentarios		  
		updateStats('comment',false);
        }

        db_query("DELETE FROM {$db_prefix}comentarios WHERE id_coment = $comid", __FILE__, __LINE__);

        die(json_encode(array('msg' => 'Comentario eliminado.', 'nohay' => '$cant_com' )));


}

function den_form(){

 global $txt, $context, $scripturl, $db_prefix, $settings, $modSettings, $ID_MEMBER, $no_avatar, $func, $boarddir, $sourcedir;

$tipo = $_POST['tipo'];
$id = $_POST['id'];

  if(empty($ID_MEMBER))
            die("Debes estar registrado para denunciar posts.");


             

     switch($tipo){

        case 1:

        $j = db_query("SELECT d.id_denuncia
                    FROM {$db_prefix}denuncias as d
                    WHERE d.id = '$id' AND d.id_user = '$ID_MEMBER' AND d.tipo = 1",__FILE__,__LINE__);
                    $h = mysql_num_rows($j);
                    mysql_free_result($j);

                    if($h){
                        die("Ya denunciaste este post.");
                    }

        $r = db_query("SELECT p.subject, mem.realName               
                                FROM {$db_prefix}messages as p, {$db_prefix}members as mem              
                                WHERE p.ID_TOPIC = '$id' AND mem.ID_MEMBER = p.ID_MEMBER",__FILE__,__LINE__);
                                $n = mysql_num_rows($r);                
                                if($n){ $data = mysql_fetch_assoc($r);
                                    echo'<div class="denunciar-form-div">
                                    <form id="denunciar-formul" action="'.$scripturl.'?action=denuncias&sa=denunciar2" method="post" accept-charset="', $context['character_set'], '">   
                                    <ul class="denunciar-form"><li><strong>Post:</strong> 
                                    <a href="'.$scripturl.'?topic='.$id.'" title="'.censorText($data['subject']).'" target="_blank">'.censorText($data['subject']).'</a></li>';                           
                                    /*echo'<li><strong>ID:</strong> '.$id.'</li>';*/
                                    echo'<li><strong>Autor:</strong> <a href="'.$scripturl.'?action=profile&user='.$data['realName'].'" title="'.$data['realName'].'" target="_blank">'.$data['realName'].'</a></li>
                                    <li><strong>Raz&oacute;n:</strong></li>
                                    <li><select name="razon"><option value="0">',$txt['denounce_repost'],'</option>
                                    <option value="0">',$txt['denounce_spam'],'</option>
                                    <option value="1">',$txt['denounce_links'],'</option>
                                    <option value="2">',$txt['denounce_disrespectful'],'</option>
                                    <option value="3">',$txt['denounce_personal_information'],'</option>
                                    <option value="4">',$txt['denounce_mayus'],'</option>
                                    <option value="5">',$txt['denounce_porn'],'</option>
                                    <option value="6">',$txt['denounce_gore'],'</option>
                                    <option value="7">',$txt['denounce_fount'],'</option>
                                    <option value="8">',$txt['denounce_poor'],'</option>
                                    <option value="9">',$txt['denounce_pass'],'</option>
                                    <option value="10">',$txt['denounce_protocol'],'</option>
                                    <option value="11">',$txt['denounce_other'],'</option></select></li>
                                    <li><strong>Comentario:</strong></li>
                                    <li><textarea style="width:310px" cols="50" rows="5" name="comentario" placeholder="Para ser m&aacute;s espec&iacute;fico en tu denuncia, agrega un comentario."></textarea></li>                           
                                    <li>',$txt['repost_link'],'</li>
                            <input type="hidden" name="tipo" value="1" />
                            <input type="hidden" name="id" value="'.$id.'" /></ul></form></div>';}               
                            else { echo'El post fue eliminado.';
                                    die();}    
                                    mysql_free_result($r);

        break;

        case 2:

        if($ID_MEMBER == $id){
            echo'No puedes denunciarte a ti mismo.';
            die();
        }

        $j = db_query("SELECT d.id_denuncia
                    FROM {$db_prefix}denuncias as d
                    WHERE d.id = '$id' AND d.id_user = '$ID_MEMBER' AND d.tipo = 3",__FILE__,__LINE__);
                    $h = mysql_num_rows($j);
                    mysql_free_result($j);

                    if($h){
                        echo'Ya denunciaste a este usuario.';
                        die();
                    }
        $r = db_query("SELECT mem.realName                
                                FROM {$db_prefix}members as mem             
                                WHERE mem.ID_member = '$id'",__FILE__,__LINE__);
                                $n = mysql_num_rows($r);                
                                if($n){ $data = mysql_fetch_assoc($r);
                                    echo'<div class="denunciar-form-div"><form id="denunciar-formul" action="'.$scripturl.'?action=denuncias&sa=denunciar2" method="post" accept-charset="', $context['character_set'], '">     
                                    <ul class="denunciar-form">';
                                    echo'<li><strong>Usuario:</strong> <a href="'.$scripturl.'?action=profile&user='.$data['realName'].'" title="'.$data['realName'].'" target="_blank">'.$data['realName'].'</a></li>
                                    <li><textarea style="width:310px" cols="50" rows="5" name="comentario" placeholder="Explica detalladamente la raz&oacute;n de tu denuncia."></textarea></li>                           
                            <input type="hidden" name="tipo" value="2" />
                            <input type="hidden" name="razon" value="0" />
                            <input type="hidden" name="id" value="'.$id.'" /></ul></form></div>';}               
                            else {echo'El usuario no existe.';}    
                                    mysql_free_result($r);
        break;

        case 3:

        $j = db_query("SELECT d.id_denuncia
                    FROM {$db_prefix}denuncias as d
                    WHERE d.id = '$id' AND d.id_user = '$ID_MEMBER' AND d.tipo = 3",__FILE__,__LINE__);
                    $h = mysql_num_rows($j);
                    mysql_free_result($j);

                    if($h){
                        echo'Ya denunciaste esta imagen.';
                        die();
                    }
        $r = db_query("SELECT i.titulo, mem.realName                
                                FROM {$db_prefix}imagenes as i, {$db_prefix}members as mem              
                                WHERE i.IDI = '$id' AND mem.ID_MEMBER = i.ID_MEMBER",__FILE__,__LINE__);
                                $n = mysql_num_rows($r);                
                                if($n){ $data = mysql_fetch_assoc($r);
                                    echo'<div class="denunciar-form-div"><form id="denunciar-formul" action="'.$scripturl.'?action=denuncias&sa=denunciar2" method="post" accept-charset="', $context['character_set'], '">     
                                    <ul class="denunciar-form"><li><strong>Imagen:</strong> 
                                    <a href="'.$scripturl.'?topic='.$id.'" title="'.censorText($data['subject']).'" target="_blank">'.censorText($data['titulo']).'</a></li>';                           
                                    /*echo'<li><strong>ID:</strong> '.$id.'</li>';*/
                                    echo'<li><strong>Autor:</strong> <a href="'.$scripturl.'?action=profile&user='.$data['realName'].'" title="'.$data['realName'].'" target="_blank">'.$data['realName'].'</a></li>
                                    <li><strong>Raz&oacute;n:</strong></li>
                                    <li><select name="razon">
                                    <option value="0">',$txt['denounce_spam'],'</option>
                                    <option value="2">',$txt['denounce_disrespectful'],'</option>
                                    <option value="3">',$txt['denounce_personal_information'],'</option>
                                    <option value="4">',$txt['denounce_mayus'],'</option>
                                    <option value="5">',$txt['denounce_porn'],'</option>
                                    <option value="6">',$txt['denounce_gore'],'</option>
                                    <option value="10">',$txt['denounce_protocol'],'</option>
                                    <option value="11">',$txt['denounce_other'],'</option></select></li>
                                    <li><strong>Comentario:</strong></li>
                                    <li><textarea style="width:310px" cols="50" rows="5" name="comentario" placeholder="Para ser m&aacute;s espec&iacute;fico en tu denuncia, agrega un comentario."></textarea></li>                           
                                    <li>',$txt['repost_link'],'</li>
                            <input type="hidden" name="tipo" value="3" />
                            <input type="hidden" name="id" value="'.$id.'" /></ul></form></div>';}               
                            else {echo'La imagen fue eliminada.';}    
                                    mysql_free_result($r);
        break;
        case 4 :

                            $j = db_query("SELECT d.id_denuncia
                                        FROM {$db_prefix}denuncias as d
                                        WHERE d.id = '$id' AND d.id_user = '$ID_MEMBER' AND d.tipo = 4",__FILE__,__LINE__);
                                        $h = mysql_num_rows($j);
                                        mysql_free_result($j);

                                        if($h){
                                            die("Ya denunciaste esta publicaci&oacute;n.");
                                        }

                            $result = db_query("SELECT s.msg, a.id, s.ID_ATTACH, s.msg, s.thumbnail, s.coords_thumbnail,
                                            m.memberName, m.avatar, m.avatar_coords, att.params
                                            FROM {$db_prefix}activity as a
                                            LEFT JOIN {$db_prefix}activity_stream as s ON (s.activity_id = a.id )
                                            LEFT JOIN {$db_prefix}members AS m ON( m.ID_MEMBER = a.subject)
                                            LEFT JOIN {$db_prefix}activity_attachments AS att ON( att.ID_ATTACH = s.ID_ATTACH)
                                            WHERE a.id = $id",__FILE__,__LINE__);
                        
                                    $data = mysql_fetch_assoc($result);
                                    mysql_free_result($result);

                                    $msg = cortar($data['msg'],100);

                                    echo'<div class="denunciar-form-div">
                                    <form id="denunciar-formul" action="'.$scripturl.'?action=denuncias&sa=denunciar2" method="post" accept-charset="', $context['character_set'], '">';
                                    echo'<ul class="denunciar-form">';
                                    
                                    if(!empty($msg)){
                                        echo'<br><center style="font-size:16px;color:#BDBDBD"> '.$msg.' </center>
                                        <br><hr>';
                                    }                         
                                    /*echo'<li><strong>ID:</strong> '.$id.'</li>';*/
                                    echo'<li><strong>Usuario:</strong> <a href="'.$scripturl.'?action=profile&user='.$data['memberName'].'" title="'.$data['memberName'].'" target="_blank">'.$data['memberName'].'</a></li>
                                    <li><strong>Raz&oacute;n:</strong></li>
                                    <li><select name="razon">
                                    <option value="3">',$txt['denounce_personal_information'],'</option>
                                    <option value="5">',$txt['denounce_porn'],'</option>
                                    <option value="6">',$txt['denounce_gore'],'</option>
                                    <option value="10">',$txt['denounce_protocol'],'</option>
                                    <option value="11">',$txt['denounce_other'],'</option></select></li>
                                    <li><strong>Comentario:</strong></li>
                                    <li><textarea style="width:310px" cols="50" rows="5" name="comentario" placeholder="Para ser m&aacute;s espec&iacute;fico en tu denuncia, agrega un comentario."></textarea></li>                           
                            <input type="hidden" name="tipo" value="4" />
                            <input type="hidden" name="id" value="'.$id.'" /></ul></form></div>';               
                                    mysql_free_result($r);

        break;

    }                  
}



function eraseden(){

    global $txt, $context, $scripturl, $db_prefix, $settings, $modSettings, $ID_MEMBER, $no_avatar, $func, $boarddir, $sourcedir;

    $id = $_POST['id'];
    $tipo = $_POST['tipo'];
       
    
    switch ($tipo){
    case  1:

        $r = db_query("SELECT p.ID_TOPIC
        FROM {$db_prefix}messages as p
        WHERE p.ID_TOPIC = '$id'",__FILE__,__LINE__);
        $sipost = mysql_num_rows($r);
        mysql_free_result($r);

        if($sipost){
        }
        else{
            die(json_encode(array('status' => 'error', 'msg' => 'El post no existe.')));
        }

        $j = db_query("SELECT d.id_denuncia
        FROM {$db_prefix}denuncias as d
        WHERE d.id = '$id' AND d.tipo = '$tipo'",__FILE__,__LINE__);
        $siden = mysql_num_rows($j);
        mysql_free_result($j);


        if($siden){

            db_query("DELETE FROM {$db_prefix}denuncias WHERE id = $id AND tipo = $tipo", __FILE__, __LINE__);

            die(json_encode(array('msg' => 'Denuncias del post eliminadas.')));
        }
        else{
            die(json_encode(array('status' => 'error', 'msg' => 'La denuncia al post no existe.')));
        }
        

    break;

    case  2:

        $r = db_query("SELECT mem.realName                
        FROM {$db_prefix}members as mem             
        WHERE mem.ID_member = '$id'",__FILE__,__LINE__);
        $siuser = mysql_num_rows($r);       

        if($siuser){
        }
        else{
            die(json_encode(array('status' => 'error', 'msg' => 'El usuario no existe.')));
        }

        $j = db_query("SELECT d.id_denuncia
        FROM {$db_prefix}denuncias as d
        WHERE d.id = '$id' AND d.tipo = '$tipo'",__FILE__,__LINE__);
        $siden = mysql_num_rows($j);
        mysql_free_result($j);


        if($siden){

            db_query("DELETE FROM {$db_prefix}denuncias WHERE id = $id AND tipo = $tipo", __FILE__, __LINE__);

            die(json_encode(array('msg' => 'Denuncias hacia el usuario eliminadas.')));
        }
        else{
            die(json_encode(array('status' => 'error', 'msg' => 'El usuario no tiene denuncias.')));
        }
        

    break;

    case 3:

        $r = db_query("SELECT i.IDI
        FROM {$db_prefix}imagenes as i
        WHERE i.IDI = '$id'",__FILE__,__LINE__);
        $simg = mysql_num_rows($r);
        mysql_free_result($r);
        
        if($simg){
        }
        else{
            die(json_encode(array('status' => 'error', 'msg' => 'La imagen no existe.')));
        }

         $j = db_query("SELECT d.id_denuncia
        FROM {$db_prefix}denuncias as d
        WHERE d.id = '$id' AND d.tipo = '$tipo'",__FILE__,__LINE__);
        $siden = mysql_num_rows($j);
        mysql_free_result($j);


        if($siden){

            db_query("DELETE FROM {$db_prefix}denuncias WHERE id = $id AND tipo = $tipo", __FILE__, __LINE__);

            die(json_encode(array('msg' => 'Denuncias de la imagen eliminadas.')));
        }
        else{
            die(json_encode(array('status' => 'error', 'msg' => 'La denuncia no existe.')));
        }
    break;

    case 4:

        $r = db_query("SELECT id
        FROM {$db_prefix}activity
        WHERE id = '$id'",__FILE__,__LINE__);
        $sstr = mysql_num_rows($r);
        mysql_free_result($r);
        
        if(!$sstr){
            die(json_encode(array('status' => 'error', 'msg' => 'La publicaci&oacute;n no existe.')));
        }

         $j = db_query("SELECT d.id_denuncia
        FROM {$db_prefix}denuncias as d
        WHERE d.id = '$id' AND d.tipo = '$tipo'",__FILE__,__LINE__);
        $siden = mysql_num_rows($j);
        mysql_free_result($j);


        if($siden){

            db_query("DELETE FROM {$db_prefix}denuncias WHERE id = $id AND tipo = $tipo", __FILE__, __LINE__);

            die(json_encode(array('msg' => 'Denuncias de la publicaci&oacute;n eliminadas.')));
        }
        else{
            die(json_encode(array('status' => 'error', 'msg' => 'La denuncia no existe.')));
        }
    break;

}

}


//Funcion para previsualizar - Ventana Modal
/*function preview(){
global $txt, $context, $scripturl, $db_prefix, $settings, $modSettings, $ID_MEMBER, $no_avatar, $func, $boarddir, $sourcedir;

    $message = $_POST['msg'];
    	
    if(empty($message)){

    die(json_encode(array('status' => 'error', 'msg' => 'Hubo un error al previsualizar.')));

    }

    die(json_encode(array('status' => 'correcto', 'msg' => $message)));
}*/


function statusform(){
global $txt, $context, $scripturl, $db_prefix, $settings, $modSettings, $ID_MEMBER, $no_avatar, $func, $boarddir, $sourcedir;

    $iduser = (int) $_POST['id'];
    $msg = $_POST['msg'];
    

    $allow_erase = allowedTo('moderate_forum') || $ID_MEMBER == $iduser;

    if(!$allow_erase){

    die(json_encode(array('status' => 'error', 'msg' => 'No tienes los permisos suficientes para realizar esta acci&oacute;n.')));

    }

    echo'<textarea id="new_status" style="width:310px;height:90px;">'.$msg.'</textarea><br><div id="new_statusCallBack"></div>';



}


function statuschange(){
global $txt, $context, $scripturl, $db_prefix, $settings, $modSettings, $ID_MEMBER, $no_avatar, $func, $boarddir, $sourcedir;

    $data = $_POST['status'];
    $iduser = (int) $_POST['id'];


    $data = htmlspecialchars($data);
    $data = trim($data);
    $data = stripslashes($data);
    $data = mysql_real_escape_string($data); 

    $allow_erase = allowedTo('moderate_forum') || $ID_MEMBER == $iduser;

    if(!$allow_erase){

    die(json_encode(array('status' => 'error', 'msg' => 'No tienes los permisos suficientes para realizar esta acci&oacute;n.')));

    }

    db_query("UPDATE {$db_prefix}members_info SET estado = '$data' WHERE ID_MEMBER = '$iduser' LIMIT 1", __FILE__, __LINE__);

     die(json_encode(array('status' => 'correcto', 'msg' => 'Tu estado ha sido actualizado.')));

}


function editbox(){
    global $txt, $context, $scripturl, $db_prefix, $settings, $modSettings, $ID_MEMBER, $no_avatar, $func, $boarddir, $sourcedir;

    $data = $_POST['data'];
    $iduser = (int) $_POST['iduser'];
    $tipo = (int) $_POST['tipo'];

    

    $allow_erase = allowedTo('moderate_forum') || $ID_MEMBER == $iduser;

    if(!$allow_erase){

    die(json_encode(array('status' => 'error', 'msg' => 'No tienes los permisos suficientes para realizar esta acci&oacute;n.')));

    }

    switch($tipo){

        case 1:
        db_query("UPDATE {$db_prefix}members_info SET biografia = '$data' WHERE ID_MEMBER = '$iduser' LIMIT 1", __FILE__, __LINE__);
        break;
        case 2:
        db_query("UPDATE {$db_prefix}members_info SET busca = '$data' WHERE ID_MEMBER = '$iduser' LIMIT 1", __FILE__, __LINE__);
        break;
        case 3:
        db_query("UPDATE {$db_prefix}members_info SET hobbies = '$data' WHERE ID_MEMBER = '$iduser' LIMIT 1", __FILE__, __LINE__);
        break;
        case 4:
        db_query("UPDATE {$db_prefix}members_info SET idiomas = '$data' WHERE ID_MEMBER = '$iduser' LIMIT 1", __FILE__, __LINE__);
        break;
        case 5:
        db_query("UPDATE {$db_prefix}members_info SET estudios = '$data' WHERE ID_MEMBER = '$iduser' LIMIT 1", __FILE__, __LINE__);
        break;
        case 6:
        db_query("UPDATE {$db_prefix}members_info SET trabajo = '$data' WHERE ID_MEMBER = '$iduser' LIMIT 1", __FILE__, __LINE__);
        break;
        case 7:
        db_query("UPDATE {$db_prefix}members_info SET habilidades = '$data' WHERE ID_MEMBER = '$iduser' LIMIT 1", __FILE__, __LINE__);
        break;
        case 8:
        db_query("UPDATE {$db_prefix}members_info SET intereses = '$data' WHERE ID_MEMBER = '$iduser' LIMIT 1", __FILE__, __LINE__);
        break;
        case 9:
        db_query("UPDATE {$db_prefix}members_info SET situacion = '$data' WHERE ID_MEMBER = '$iduser' LIMIT 1", __FILE__, __LINE__);
        break;
        case 10:
        db_query("UPDATE {$db_prefix}members_info SET vivecon = '$data' WHERE ID_MEMBER = '$iduser' LIMIT 1", __FILE__, __LINE__);
        break;
        case 11:
        db_query("UPDATE {$db_prefix}members_info SET estado = '$data' WHERE ID_MEMBER = '$iduser' LIMIT 1", __FILE__, __LINE__);
        break;
    }

    die(json_encode(array('status' => 'correcto', 'msg' => 'Datos cambiados correctamente.')));

}


function comentar(){
    global $txt, $context, $scripturl, $db_prefix, $settings, $modSettings, $ID_MEMBER, $no_avatar, $func, $boarddir, $sourcedir;


        if(empty($ID_MEMBER))
            die(json_encode(array('status' => 'error', 'message' => 'Solo usuarios registrados pueden comentar.')));

        if($_SESSION['stop_flood:comments'] > time() - 15){
            $timeout = $_SESSION['stop_flood:comments'] - time() + 15;
            die(json_encode(array('status' => 'error', 'type' => 'timeout', 'timeout' => $timeout, 'message' => 'Debes esperar unos segundos antes de comentar de nuevo')));
        }
        $_SESSION['stop_flood:comments'] = time();

	$ID_TOPIC = (int) $_POST['post'];
	$comentario = $func['htmlspecialchars']($_POST['comentario'], ENT_QUOTES, 'UTF-8');

        if(is_real_empty($comentario) || $comentario == 'undefined')
            die(json_encode(array('status' => 'error', 'message' => 'Dejaste el campo vacio.')));
		
	$fecha = time();

        // existe el post realmente?
        $request = db_query("SELECT ID_BOARD, ID_MEMBER_STARTED, locked FROM {$db_prefix}topics WHERE ID_TOPIC = $ID_TOPIC",__FILE__,__LINE__);
        
        list($board, $TopicAutor, $locked) = mysql_fetch_row($request);

        if(mysql_num_rows($request) == 0)
            die(json_encode(array('status' => 'error', 'message' => 'El post no se encuentra o ha sido eliminado.')));

        mysql_free_result($request);

        // usuario inexistente?
        $request = db_query("SELECT memberName, realName, avatar, avatar_coords FROM {$db_prefix}members WHERE ID_MEMBER = $ID_MEMBER LIMIT 1",__FILE__,__LINE__);
        list($memberName, $realName, $avatar, $avatar_coords) = mysql_fetch_row($request);

        if(mysql_num_rows($request)==0)
            die(json_encode(array('status' => 'error', 'message' => 'Usuario inexistente.')));

        mysql_free_result($request);
                
        list($ID_BOARD) = mysql_fetch_row($request);
        mysql_free_result($request);

        $allow_comments = allowedTo('moderate_forum') || !$locked || $ID_MEMBER == $TopicAutor;

        if(!$allow_comments)
            die(json_encode(array('status' => 'error', 'type' => 'locked', 'message' => 'El post se encuentra cerrado. No puedes comentar')));

	db_query("INSERT INTO {$db_prefix}comentarios (id_post,id_cat,id_user,comentario,fecha)
                    VALUES ('$ID_TOPIC', '$ID_BOARD', '$ID_MEMBER','$comentario','$fecha')",__FILE__,__LINE__);
        
        $last_id = mysql_insert_id();
        
        if(empty($last_id))
            die(json_encode(array('status' => 'error', 'message' => 'Ocurrio un error al solicitar lo procesado')));

        $r = db_query("SELECT comentario, id_user FROM {$db_prefix}comentarios WHERE id_coment = $last_id",__FILE__,__LINE__);
        list($Tempcomentario, $tempAutorCom) = mysql_fetch_row($r);
        mysql_free_result($r);

        // eh! agregame uno mas a la lista :)
        db_query("UPDATE {$db_prefix}topics
                  SET comments = comments + 1
                  WHERE ID_TOPIC = $ID_TOPIC",__FILE__,__LINE__);
        
        db_query("UPDATE {$db_prefix}members
                  SET comments = comments + 1
                  WHERE ID_MEMBER = $ID_MEMBER",__FILE__,__LINE__);

		//Actualizamos cantidad total de comentarios		  
		updateStats('comment',true);
			
        // el cache debe actualizarse!
        if(!empty($modSettings['cache_enable'])){
            
            $request = db_query("SELECT subject FROM {$db_prefix}messages WHERE ID_TOPIC = $ID_TOPIC",__FILE__,__LINE__);
            list($subject) = mysql_fetch_row($request);
            mysql_free_result($request);

			cache_update_data('recent:comments', array(
				'id_comment' => $last_id,
				'titulo' => $subject,
				'ID_TOPIC' => $ID_TOPIC,
				'memberName' => $memberName,
				'realName' => $realName,
			), 15);
		
        }
        
        // notifiquemos!
        $notifications = new notifications();
        $notifications->add('comment', array(
            'author' => $ID_MEMBER,
            'topic' => $ID_TOPIC
        ));

        $avatar_coords = makeAvatarCoords($avatar_coords);
        $avatar_coords = $avatar_coords[48]['style'];

        $templateData = array(
            'avatar' => !empty($avatar) ? $avatar : $no_avatar,
            'avatar_coords' => $avatar_coords,
            'nick' => $context['user']['name'],
            'comment' => parse_bbc($Tempcomentario),
            'id_member' => $ID_MEMBER,
            'time' => hace($fecha),
            'id_comment' => $last_id,
            'type_comment' => ' ' . ($tempAutorCom == $TopicAutor ? ' author' : ' own')
        );

        if($_POST['show_comment'])
            die(json_encode(array(
                'gotolast' => true,
                'message' => 'Tu comentario fue agregado exitosamente. Ir a la ',
                'txt_gotolast' => '&Uacute;ltima p&aacute;gina.'
                )));

        die(json_encode($templateData));
}

function getNotifications(){
    global $context, $sourcedir, $ID_MEMBER, $db_prefix;
	
	$notifications = new notifications();
        $notifications->clean = true;
        $context['notifications'] = $notifications->getNotifications();
        
}

function html2bbc(){
    global $context, $sourcedir, $boardir, $txt, $settings, $func, $ID_MEMBER;

    if(empty($ID_MEMBER))
        die();

    require_once($sourcedir . '/Subs-Editor.php');
    $_POST['body'] = html_to_bbc($_POST['body']);

    die(json_encode(array('status' => 'ok', 'data' => $_POST['body'])));


}
function bbc2html(){
     global $context, $sourcedir, $boardir, $txt, $settings, $func, $ID_MEMBER;

    if(empty($ID_MEMBER))
        die();

    require_once($sourcedir . '/Subs-Editor.php');
	$context['bbc_no_auto_link'] = true;
	$context['parse_from_ajax'] = true;
    die(json_encode(array('status' => 'ok', 'data' => parse_bbc($_POST['body']))));

}

function add_bookmark(){
    global $txt, $context, $scripturl, $db_prefix, $settings, $modSettings, $ID_MEMBER, $sourcedir;
    
    require_once($sourcedir . '/Favoritos.php');

    if(!$ID_MEMBER)
         die(json_encode(array('status' => 'error', 'message' => 'Debes loguearte para realizar esta accion.')));

    $data = array((int)$_POST['topic'], $ID_MEMBER);

    $result = addFavoritos($data[0], $data[1]);
    
    $notifications = new notifications();
    
    if($result['error'])
        die(json_encode(array('status' => 'error', 'message' => $result['error'])));
    else
        $notifications->add('bookmark', array(
            'author' => $data[1],
            'topic' => $data[0]
        ));

    die(json_encode(array('status' => 'success', 'message' => $result['message'], 'button_text' => 'Agregado!')));
    
}

function send_points(){
    global $txt, $context, $scripturl, $db_prefix, $settings, $modSettings, $ID_MEMBER, $sourcedir;

    if(!$ID_MEMBER)
         die(json_encode(array('status' => 'error', 'message' => 'Debes loguearte para realizar esta accion.')));

    require_once($sourcedir . '/shop/Shop-Send.php');

    $_POST['puntos'] = (int)$_POST['puntos'];
    $_POST['post'] = (int)$_POST['post'];

    if(empty($_POST['puntos']))
        die( json_encode( array('status' => 'error', 'message' => 'Olvidaste enviar puntos.') ) );

    if(empty($_POST['post']))
        die( json_encode( array('status' => 'error', 'message' => 'No seleccionaste el post.') ) );
    
    $request = db_query("SELECT ID_TOPIC FROM {$db_prefix}topics WHERE ID_TOPIC = $_POST[post]",__FILE__,__LINE__);
    
    if(mysql_num_rows($request) == 0)
        die(json_encode(array('status' => 'error', 'message' => 'El post no existe o fue eliminado.')));
    mysql_free_result($request);   

    $_GET['amount'] = $_POST['puntos'];
    $_GET['topic'] = $_POST['post'];

    $sended = sendMoney();

    $notifications = new notifications();

    if($sended['error'])
        die(json_encode(array('status' => 'error', 'message' => $sended['error'])));
    else
        $notifications->add('points', array(
            'author' => $ID_MEMBER,
            'topic' => $_POST['post'],
            'points' => $_POST['puntos']
        ));

    die(json_encode(array('status' => 'success', 'points' => $_POST['puntos'], 'message' => 'Puntos agregado exitosamente.')));

}

// comentar perfil
function add_cperfil(){
	global $txt, $context, $scripturl, $db_prefix, $settings, $modSettings, $ID_MEMBER;
	
	loadLanguage('muro');
	
	if($context['user']['id']==''){
		echo $txt['pcomments_only_logued'];
	}
else{
$comment = htmlspecialchars($_POST['comment'],ENT_QUOTES,'UTF-8');
$userid = (int) $_POST['userid'];
$idc = (int) $_POST['idc'];
$avatar = $_POST['avatar'];

if($_POST['comment']==''){
	echo'<center><span style="color: red;" class="size11"><b>';
	die("Mmmm no...");
}

if($_POST['comment']=='Deja tu comentario...'){
echo'<center><span style="color: red;" class="size11"><b>';
die("No has escrito ningun Comentario");}

if($_POST['idc']==''){
echo'<center><span style="color: red;" class="size11"><b>';
die("Mmmm no...");}

$commentdate = time();

if($_POST['tipo']==1){
	//Comentarios del perfil
	$dbresult = db_query("SELECT ID_MEMBER, date
	FROM {$db_prefix}profile_comments
	WHERE ID_MEMBER = '$ID_MEMBER'
	ORDER BY date DESC 
	LIMIT 1", __FILE__, __LINE__);
	$l = mysql_fetch_assoc($dbresult);
	mysql_free_result($dbresult);
	
	$tiempomax = $commentdate - $l['date'];
	if($tiempomax<30)
		die('<center>No puedes realizar tantos comentarios en tan poco tiempo</center>');
	
	$subject = htmlspecialchars($_POST['subject'],ENT_QUOTES);
	
	// Auto aprobamos el comentario :P
	$approved = 1;

	db_query("INSERT INTO {$db_prefix}profile_comments
			(ID_MEMBER, comment, subject, date, COMMENT_MEMBER_ID,approved)
		VALUES ('$ID_MEMBER','$comment','$subject', '$commentdate','$userid','$approved')", __FILE__, __LINE__);

	
	
    
        //Agregamos al Monitor de Usuario
        notificar($userid,$ID_MEMBER,6,0,0,0);

echo'<table>
		 <tr>
		 <td align="left" valign="top">	
		 <img class="muro_avatar" src="',$avatar,'" align="top" border="0" width="50" height="50" /></a>
		</td>
		<td align="left" valign="top" style="width:700px;"><br>
                <div class="muro_coment">',parse_bbc(parse_video($comment,0)),'</div>
                </td>
                </tr>
     </table><hr style="background:#EFEFEF;">';
	
}
elseif($_POST['tipo']==2){
	//subcomentarios
	$dbresult = db_query("SELECT ID_MEMBER, DATE
	FROM {$db_prefix}profile_subcomments
	WHERE ID_MEMBER = '$ID_MEMBER'
	ORDER BY DATE DESC 
	LIMIT 1", __FILE__, __LINE__);
	$l = mysql_fetch_assoc($dbresult);
	mysql_free_result($dbresult);
	
	$tiempomax = $commentdate - $l['DATE'];
	if($tiempomax<30)
		die('No puedes realizar tantos comentarios en tan poco tiempo');
	
	db_query("INSERT INTO {$db_prefix}profile_subcomments
	(ID_PROFILE_COMMENT, ID_MEMBER, COMMENT, DATE)
	VALUES ('$idc','$ID_MEMBER','$comment','$commentdate')", __FILE__, __LINE__);
	
	$dbresult = db_query("SELECT p.COMMENT_MEMBER_ID, p.ID_COMMENT, p.ID_MEMBER, m.realName 
	FROM {$db_prefix}profile_comments as p, {$db_prefix}members as m
	WHERE p.ID_COMMENT = '$idc'
	AND m.ID_MEMBER = p.ID_MEMBER", __FILE__, __LINE__);
	$row2 = mysql_fetch_assoc($dbresult);
	mysql_free_result($dbresult);
	
	$duenocoment = $row2['ID_MEMBER'];   
	$perfil = $row2['COMMENT_MEMBER_ID'];             
	
	// notifico
	notificar($duenocoment,$ID_MEMBER,7,$perfil,0,0);
	
	echo'
	<div style="background:#D0ECFF;padding:5px;width:95%;">
		<table width="70%">
			<tr>
				<td width="30px" valign="top">
					<img src="',$avatar,'" width="30px" height="30px;" />
				</td>
				<td valign="top">
					',parse_bbc(parse_video($comment,0)),'
				</td>
			</tr>
		</table>
	</div>';
}

elseif($_POST['tipo']==3){
	// es moderador?
	$dbresult = db_query("SELECT realName, ID_GROUP 
	FROM {$db_prefix}members
	WHERE ID_MEMBER = '$ID_MEMBER'", __FILE__, __LINE__);
	$row = mysql_fetch_assoc($dbresult);
	mysql_free_result($dbresult);
	
	// es autor del comentario?
	$dbresult = db_query("SELECT ID_MEMBER, ID_PROFILE_COMMENT 
	FROM {$db_prefix}profile_subcomments
	WHERE ID_SC = '$idc'", __FILE__, __LINE__);
	$row2 = mysql_fetch_assoc($dbresult);
	mysql_free_result($dbresult);
	
	// es mi muro?
	$dbresult = db_query("SELECT ID_MEMBER, ID_COMMENT, COMMENT_MEMBER_ID
	FROM {$db_prefix}profile_comments
	WHERE ID_COMMENT = '".$row2['ID_PROFILE_COMMENT']."'", __FILE__, __LINE__);
	$row3 = mysql_fetch_assoc($dbresult);
	mysql_free_result($dbresult);

	if($row['ID_GROUP']==1 || $row['ID_GROUP']==2 || $row2['ID_MEMBER']==$ID_MEMBER || $row3['COMMENT_MEMBER_ID']==$ID_MEMBER){
		//borrar subcomentarios
		db_query("DELETE FROM {$db_prefix}profile_subcomments WHERE ID_SC = '$idc' LIMIT 1", __FILE__, __LINE__);
		echo'<center><span style="color:red;margin:2px;font-weight:bold;">',$txt['pcomments_delete'],'</span></center>';
	}
	else{
		echo'<center><span style="color:red;margin:2px;font-weight:bold;">No tienes los permisos para borrar</span></center>';
	}
}

}

}

// actualizar comentarios del home
function comentarios(){
	global $context, $scripturl, $db_prefix;
	
	$rs = db_query("SELECT c.id_post, c.id_coment, m.subject, m.ID_TOPIC, c.id_user, mem.ID_MEMBER, mem.RealName, mem.memberName
	FROM ({$db_prefix}comentarios AS c, {$db_prefix}messages AS m, {$db_prefix}members AS mem)
	WHERE id_post = m.ID_TOPIC AND c.id_user = mem.ID_MEMBER
	ORDER BY c.id_coment DESC
	LIMIT 15", __FILE__, __LINE__);
	$context['comentarios25'] = array();
	while ($row = mysql_fetch_assoc($rs)){
		censorText($row['subject']);
		$context['comentarios25'][] = array(
			'id_coment' => $row['id_coment'],
			'titulo' => $row['subject'],
			'ID_TOPIC' => $row['ID_TOPIC'],
			'memberName' => $row['memberName'],
			'RealName' => $row['RealName'],
		);
	}
	mysql_free_result($rs);
	
	foreach ($context['comentarios25'] as $coment25){
		$tamano = 35; // tamano maximo en caracteres, los espacios tambien cuentan
		
		if (strlen($coment25['titulo'])>$tamano)	{$coment25['titulo']=substr($coment25['titulo'],0,$tamano-1)."...";}
		echo '<font class="size11" title="'. $coment25['titulo'] .'" ><b><a href="'. $scripturl .'?action=profile;user='. $coment25['RealName'] .'">'. $coment25['RealName'] .'</a></b> - <a href="'. $scripturl .'?topic='. $coment25['ID_TOPIC'] .'#cmt_'. $coment25['id_coment'] .'">'. ucfirst (strtolower($coment25['titulo'])) .'</a><br>';
	}
}

// vista previa de posts
function vprevia(){
	global $txt, $context;
	
	$contenido = htmlentities($_POST['message'], ENT_QUOTES, 'UTF-8');
	$contenido = parse_bbc($contenido); 
	$iduser = $context['user']['id'];
	
	echo'
	
		 <div class="box-border-striped green">
        <div class="stripes"></div>
        <div class="content"><div class="header"><h3>As&iacute; se ver&aacute; tu post...</h3></div>
        <div class="html-content clearfix preview-post">
			'.censorText($contenido).'
		<div align="right" style="margin-top:5px;">
			<input onclick="javascript:preview.cerrar();" class="sp-button green" value="Cerrar la previsualizaci&oacute;n" title="Cerrar la previsualizaci&oacute;n" type="button"> <input onclick="return oblig(this.form.subject.value, this.form.message.value, this.form.tags.value, this.form,this.form.causa.value);" class="preview sp-button bluesky" value="Postear" title="Postear" type="submit">
		</div>
	<br />
	
	';
}

// vista previa de comentarios
function previacom(){
	global $scripturl, $txt, $context;

	if($context['user']['id']==''){
		die('Solo usuarios registrados pueden previsualizar comentarios.');
	}
	else{
		$comentario = htmlspecialchars($_POST['cuerpo_comment']);
		$autor = htmlspecialchars($_POST['autor']);
		$comentarios = parse_bbc($comentario);
		$fecha_actual = date('d-m-Y | g:i:s A');
		
		echo'
		<div class="box_title">
			Vista Previa
		</div>
		<div class="box_cuerpo">
			<b id="autor_cmnt_'.$ultimo_id_coment.'" user_comment="'.$autor.'" text_comment="'.$comentario.'"><a href="'.$scripturl.'?action=profile;user='.$autor.'">'.$autor.'</a></b> | &nbsp;dijo:
			<br />'. $comentarios .'
			<hr />
		</div>
		<div class="alignC" style="margin-bottom:8px;">
			<input onclick="cerrarprevia();" class="login" value="Cerrar" type="button" />
		</div>';
	}
}

// comentar imagen
function add_imgcomment(){
	global $context, $scripturl, $db_prefix, $ID_MEMBER, $txt, $modSettings;
	
	if($context['user']['id']==''){
		die('Solo usuarios registrados pueden comentar im&aacute;genes.');
	}
	
	$comment = htmlspecialchars($_POST['comentario']);
	$id = (int) $_REQUEST['imagen'];
	
	if($id == '')
		die('Mmm no no');
	
	$dbresult = db_query("SELECT p.allowcomments FROM {$db_prefix}gallery_pic as p WHERE ID_PICTURE = '$id' LIMIT 1", __FILE__, __LINE__);
	$row = mysql_fetch_assoc($dbresult);
	mysql_free_result($dbresult);

	if($comment == '')
		die('No has ingresado un comentario');
	$commentdate = time();
	
	if($_SESSION['last_add_gallery'] > time() - 60)
		die('No puedes realizar tantas acciones en tan poco tiempo.');
	
	db_query("INSERT INTO {$db_prefix}gallery_comment
	(ID_MEMBER, comment, date, ID_PICTURE)
	VALUES ('$ID_MEMBER','$comment','$commentdate','$id')", __FILE__, __LINE__);
	
	$last = db_insert_id();
	$inserted = !empty($last) ? true : false;
	
	if(!$inserted)
		die('Hubo un error al agregar el comentario, intentalo mas tarde');
	else
		$_SESSION['last_add_gallery'] = time();
	
	if (isset($modSettings['shopVersion']))
		db_query("UPDATE {$db_prefix}gallery_pic
		SET commenttotal = commenttotal + 1
		WHERE ID_PICTURE = '$id'
		LIMIT 1", __FILE__, __LINE__);
	
	$dbresult = db_query("SELECT *
	FROM {$db_prefix}gallery_pic
	WHERE ID_PICTURE = '$id'
	LIMIT 1", __FILE__, __LINE__);
	$notif = mysql_fetch_assoc($dbresult);
		$aquien = $notif['ID_MEMBER'];
		$dato = $notif['title']; 
	mysql_free_result($dbresult);
	
	// notifico
	notificar($aquien,$ID_MEMBER,4,$id,$dato,0);
	
	echo'
	<div id="cmt_'.$id.'">
		<span class="size12">
			<b id="autor_cmnt_'.$id.'" user_comment="'.$context['user']['name'].'" text_comment="'.$comment.'">
				<a href="', $scripturl ,'?action=profile;u='.$ID_MEMBER.'">
					'.$context['user']['name'].'
				</a>
			</b> |
			<span class="size10">',fechaGeneral($commentdate),'</span> 
			<a class="iconso emp" href="'.$scripturl.'?action=pm&sa=send&u='.$ID_MEMBER.'">
				<img src="', $settings['images_url'] ,'/espacio.gif" align="top" />
			</a>
			<a class="iconso citar" onclick="citar_comment('.$id.')" href="javascript:void(0)">
				<img src="', $settings['images_url'] ,'/espacio.gif" align="top" />
			</a> dijo:
			<br />',parse_bbc($comment),'
		</span>
	</div>
	<hr class="divider" />';
}

// votar imagen
function puntosimg(){
	global $context, $db_prefix, $txt, $modSettings, $ID_MEMBER;
	
	// languages -> Gallery.*.php
	loadLanguage('Gallery');
	
	$cantidad = (float) $_POST['puntos'];
	$id = (int) $_POST['imagen'];
	$user = (int) $_POST['user'];
	$userincr = $context['user']['id'];
	
    if($cantidad < 0)
		die($txt['gallery_point_positive']);
	elseif ($cantidad == 0)
		die($txt['gallery_quantity_validated']);
	
	if($id == '')
		die($txt['gallery_error_no_pic_selected']);
	if($cantidad == '')
		die($txt['gallery_quantity_specify']);
	if($user == '')
		die($txt['gallery_specify_user']);
	if($user == $context['user']['id'])
		die($txt['gallery_no_point_images']);
	
	$request = mysql_query("SELECT *
	FROM {$db_prefix}members AS m
	WHERE ".$context['user']['id']." = m.ID_MEMBER");
	while($grup = mysql_fetch_assoc($request)){
		if($grup['ID_GROUP']!=0)
			$migrupo = $grup['ID_GROUP'];
		else
			$migrupo = $grup['ID_POST_GROUP'];
	}
	mysql_free_result($request);
	
	$nodebosuperar = 0;
	$maxpuntos = 0;
	$maxpuntos_puedo = 0;
	
	$rangos = db_query("SELECT puntos
	FROM {$db_prefix}membergroups
	ORDER BY puntos DESC
	LIMIT 1", __FILE__, __LINE__);
	while($row3 = mysql_fetch_assoc($rangos))
		$maxpuntos = $row3['puntos'];
	mysql_free_result($rangos);
	
	$rangos = db_query("SELECT *
	FROM {$db_prefix}membergroups
	WHERE ID_GROUP = $migrupo", __FILE__, __LINE__);
	while ($row2 = mysql_fetch_assoc($rangos))
		$maxpuntos_puedo = $row2['puntos'];
	mysql_free_result($rangos);
	
	$nodebosuperar = $maxpuntos - $maxpuntos_puedo;
	
	if($cantidad > $maxpuntos_puedo){
		$text = '<div class="alignC"><span class="color_red">No puedes dar m&aacute;s de '.$maxpuntos.' puntos.</span></div>';
		if(!isset($_REQUEST['ajax'])){
			fatal_error($text, false);
		}
		else{
			die($text);
		}
	}
	
	$errorr = mysql_query("SELECT *
	FROM {$db_prefix}gallery_cat
	WHERE id_user = $userincr AND id_img = {$id}
	LIMIT 1");
	$yadio = mysql_num_rows($errorr) != 0 ? true : false;
	mysql_free_result($errorr);
	
	if($yadio)
		die($txt['gallery_no_point_retry']);
	if($cantidad > 10)
		die($txt['gallery_no_point_ten']);
	
	//Cuantos puntos me quedan
	$request1 = db_query("SELECT points
	FROM {$db_prefix}points_per_day
	WHERE ID_MEMBER = {$ID_MEMBER}", __FILE__, __LINE__);
	$row1 = mysql_fetch_assoc($request1);
	mysql_free_result($request1);
	if($cantidad > $row1['points'])
		die('No tienes puntos suficientes. Debes esperar hasta ma&ntilde;ana.');
	
	//Quita los puntos del dia
	db_query("UPDATE {$db_prefix}points_per_day
	SET points = points - {$cantidad}
	WHERE ID_MEMBER = '$userincr'
	LIMIT 1", __FILE__, __LINE__);
	
	//Filtramos Por Puntos/Por posts by Mr.Freack
	if($modSettings['por_posts']){
		$rankeding = "";
	}
	elseif($modSettings['por_puntos']){
		$rankeding = ", moneyrankpp = moneyrankpp + {$cantidad}";
	}
    else{
		$rankeding = "";
	}
	
	// Dar los puntos al usuario
	db_query("UPDATE {$db_prefix}members
	SET money = money + '$cantidad' ".$rankeding."
	WHERE ID_MEMBER = '$user'
	LIMIT 1", __FILE__, __LINE__);
	
	db_query("UPDATE {$db_prefix}gallery_pic
	SET puntos = puntos + '$cantidad'
	WHERE ID_PICTURE = '$id'
	LIMIT 1", __FILE__, __LINE__);
	
	db_query("INSERT INTO {$db_prefix}gallery_cat 
	(id_img,id_user)
	values
	('$id', '$userincr')", __FILE__, __LINE__);
	
	$dbresult = db_query("SELECT *
	FROM {$db_prefix}gallery_pic
	WHERE ID_PICTURE = '$id'
	LIMIT 1", __FILE__, __LINE__);
	$notif = mysql_fetch_assoc($dbresult);
	$aquien = $notif['ID_MEMBER'];
	$dato = $notif['title']; 
	mysql_free_result($dbresult);
	
	// notifico
	notificar($aquien,$userincr,5,$id,$dato,$cantidad);
	echo'<div class="alignC"><span class="color_green"><b>',$cantidad,' Puntos A&ntilde;adidos Correctamente</b></span></div>';
}

function follow_u(){
	global $txt, $context, $scripturl, $db_prefix, $settings, $modSettings, $ID_MEMBER, $no_avatar, $func, $boarddir, $sourcedir;
	
	$target = $_POST['uid'];
	
	require_once( $sourcedir . '/classes/followers.class.php' );
	
	$followers = new followers;
	
	$followers->follow( $target, true );	

}
function unfollow_u(){
	global $txt, $context, $scripturl, $db_prefix, $settings, $modSettings, $ID_MEMBER, $no_avatar, $func, $boarddir, $sourcedir;
	
	$target = $_POST['uid'];
	
	require_once( $sourcedir . '/classes/followers.class.php' );
	
	$followers = new followers;
	
	$followers->unfollow( $target, true );

}

function topsday(){
	global $txt, $scripturl, $db_prefix, $modSettings, $user_info, $context,$settings;

	$parametro = (INT) $_POST['parametro'];
	$cat = $_POST['cat'];
	
/* SWITCH DE LA VARIABLE PASADA POR $_POST QUE CREA LA VARIABLE CON LA CONDICION*/	
	switch ($parametro) {
/*daily*/ case '1': $periodo = 'AND m.posterTime > '.mktime(0, 0, 0, date('n'), date('j'), date('Y')); 
			break;								

/*weekly*/ case '2': $periodo =  'AND m.posterTime > '.forum_time(false, mktime(0, 0, 0, date("n"), date("j"), date("Y")) - (date("N")*3600*24));
			break;
/*monthly*/	case '3': $periodo =  'AND m.posterTime > '.forum_time(false, mktime(0, 0, 0, date("n"), date("j")-30, date("Y"))); 
			break;
/*yearly*/	case '4': $periodo =  'AND m.posterTime > '.mktime(0, 0, 0, 1, 1, date('Y')); 
			break;
/*default*/	case '5': $periodo =  ''; 
			break;			
		
}

	switch ($parametro) {
/*daily*/ case '1': $seccion = 1; 
			break;								

/*weekly*/ case '2': $seccion =  2; 
			break;
/*monthly*/	case '3': $seccion =  3; 
			break;
/*yearly*/	case '4': $seccion =  4; 
			break;
/*default*/	case '5': $seccion = 5; 
			break;			
		
}	

$category = '';
if(!empty($cat) && $cat != 0)
{
$category = 'AND t.ID_BOARD = '.$cat.'';

}

		
	/* PRIMER QUERY DE LOS TOPICS CON MAS PUNTOS*/
        $request = db_query("SELECT m.subject, m.posterTime, t.puntos, t.ID_BOARD, t.ID_TOPIC, b.name
                        FROM ({$db_prefix}topics AS t, {$db_prefix}messages AS m, {$db_prefix}boards AS b)
                        WHERE m.ID_MSG = t.ID_FIRST_MSG
                        AND $user_info[query_see_board]" . (!empty($modSettings['recycle_enable']) && $modSettings['recycle_board'] > 0 ? "
                        AND b.ID_BOARD != $modSettings[recycle_board]" : '') . "
                        AND t.ID_BOARD = b.ID_BOARD" . (!empty($topic_ids) ? "
                        AND t.ID_TOPIC IN (" . implode(', ', $topic_ids) . ")" : '') . "
                        AND t.puntos > 0
						$periodo
						$category
                        ORDER BY t.puntos DESC
                        LIMIT 10", __FILE__, __LINE__);

        $context['tops-topicPoints'] = array();
        while ($row = mysql_fetch_assoc($request))
        $context['tops-topicPoints'][] = array(
            'subject' => censorText(_substr($row['subject'], 0, 35, 25, true)),
            'count' => $row['puntos'],
            'id' => $row['ID_TOPIC'],
             'board' => array(
                'id' => $row['ID_BOARD'],
                'name' => $row['bname']
                )
            );
        
        mysql_free_result($request);
/*SEGUNDA QUERY CON LOS TOPICS CON MAS COMENTARIOS*/
    $requestq = db_query("SELECT m.subject, m.posterTime, t.comments, t.ID_BOARD, t.ID_TOPIC, b.name
                        FROM ({$db_prefix}topics AS t, {$db_prefix}messages AS m, {$db_prefix}boards AS b)
                        WHERE m.ID_MSG = t.ID_FIRST_MSG
                        AND $user_info[query_see_board]" . (!empty($modSettings['recycle_enable']) && $modSettings['recycle_board'] > 0 ? "
                        AND b.ID_BOARD != $modSettings[recycle_board]" : '') . "
                        AND t.ID_BOARD = b.ID_BOARD" . (!empty($topic_ids) ? "
                        AND t.ID_TOPIC IN (" . implode(', ', $topic_ids) . ")" : '') . "
                        AND t.comments > 0
						$periodo
						$category
                        ORDER BY t.comments DESC
                        LIMIT 10", __FILE__, __LINE__);
        $context['tops-topicComments'] = array();
        while ($row = mysql_fetch_assoc($requestq))
        $context['tops-topicComments'][] = array(
            'subject' => censorText(_substr($row['subject'], 0, 35, 25, true)),
            'count' => $row['comments'],
            'id' => $row['ID_TOPIC'],
            'board' => array(
                'id' => $row['ID_BOARD'],
                'name' => $row['bname']
                )
            );
        mysql_free_result($requestq);
	/* QUERY CON LOS TOPICS CON MAS FAVORITOS*/
     $requestq = db_query("SELECT COUNT(*) as cant, m.subject, m.posterTime, t.ID_BOARD, t.ID_TOPIC, b.name
                        FROM ({$db_prefix}bookmarks AS bk, {$db_prefix}topics AS t, {$db_prefix}messages AS m, {$db_prefix}boards AS b)
                        WHERE t.ID_TOPIC = bk.ID_TOPIC
						AND m.ID_MSG = t.ID_FIRST_MSG
                        AND $user_info[query_see_board]" . (!empty($modSettings['recycle_enable']) && $modSettings['recycle_board'] > 0 ? "
                        AND b.ID_BOARD != $modSettings[recycle_board]" : '') . "
                        AND t.ID_BOARD = b.ID_BOARD" . (!empty($topic_ids) ? "
                        AND t.ID_TOPIC IN (" . implode(', ', $topic_ids) . ")" : '') . "
						$periodo
						$category
                        GROUP BY m.subject, t.ID_TOPIC
                        ORDER BY cant DESC
                        LIMIT 10", __FILE__, __LINE__);
        $context['tops-favoritos'] = array();
        while ($row = mysql_fetch_assoc($requestq))
        $context['tops-favoritos'][] = array(
            'subject' => censorText(_substr($row['subject'], 0, 35, 25, true)),
            'count' => $row['cant'],
            'id' => $row['ID_TOPIC'],
            'board' => array(
                'id' => $row['ID_BOARD'],
                'name' => $row['bname']
                )
            );
        mysql_free_result($requestq);





echo'1: 

<table>
<tr>
        <td style="vertical-align:top; padding: 0"><div class="arrow-box" style="width:335px; float:left">
		<div class="title"><span><i></i></span> <strong>Top post m&aacute;s comentado</strong></div>
			<div class="count-list data list">';

                        if(empty($context['tops-topicComments']))
                            echo '<div class="error" style="margin:5px">No se encontro ningun post.</div>';
                        
            foreach($context['tops-topicComments'] as $top)
			echo '<div class="list-element clearfix"><span class="list-number"></span> <img src="'.$settings['images_url'].'/post/icono_'.$top['board']['id'].'.gif" style="float: left; margin-top: 2px;"> <a href="'.$scripturl.'?topic='.$top['id'].'">'.$top['subject'].'</a> <span class="points">'.$top['count'].'</span></div>';
			echo '</div>
		</div>
        <div class="arrow-box yellow" style="width:335px; float:left">
		<div class="title"><span><i></i></span> <strong>Top post con m&aacute;s favoritos</strong></div>
			<div class="count-list data list">';

                        if(empty($context['tops-favoritos']))
                            echo '<div class="error" style="margin:5px">No se encontro ningun post.</div>';
                        
            foreach ($context['tops-favoritos'] as $top)
			echo '<div class="list-element clearfix"><span class="list-number"></span> <img src="'.$settings['images_url'].'/post/icono_'.$top['board']['id'].'.gif" style="float: left; margin-top: 2px;"> <a href="'.$scripturl.'?topic='.$top['id'].'">'.$top['subject'].'</a> <span class="points">', $top['count'], '</span></div>';

			echo '</div>
		</div>
        </td>
                
        <td style="vertical-align:top; padding: 0"><div class="arrow-box green" style="width:335px; float:left">
		<div class="title"><span><i></i></span> <strong>Top post con m&aacute;s puntos</strong></div>
			<div class="count-list data list">';

                        if(empty($context['tops-topicPoints']))
                            echo '<div class="error" style="margin:5px">No se encontro ningun post.</div>';
                        
            foreach ($context['tops-topicPoints'] as $top)
			echo '<div class="list-element clearfix"><span class="list-number"></span> <img src="'.$settings['images_url'].'/post/icono_'.$top['board']['id'].'.gif" style="float: left; margin-top: 2px;"> <a href="'.$scripturl.'?topic='.$top['id'].'">', $top['subject'], '</a> <span class="points">', $top['count'], '</span></div>';

			echo '</div>
		</div>
        </td></tr>
        </table><input type="text" name="seccion" id="seid" class="hideObj" value="'.$seccion.'" ><script type="text/javascript">
$(document).ready(function(){
    count_list();
    });
</script>
		
';		
	
}
function topscat(){
	global $txt, $scripturl, $db_prefix, $modSettings, $user_info, $context,$settings;

$cat = $_POST['cat'];
$section = $_POST['seccion'];



/* SWITCH DE LA VARIABLE PASADA POR $_POST QUE CREA LA VARIABLE CON LA CONDICION*/	
	switch ($section) {
/*daily*/ case '1': $periodo = 'AND m.posterTime > '.mktime(0, 0, 0, date('n'), date('j'), date('Y')); 
			break;								

/*weekly*/ case '2': $periodo =  'AND m.posterTime > '.forum_time(false, mktime(0, 0, 0, date("n"), date("j"), date("Y")) - (date("N")*3600*24));
			break;
/*monthly*/	case '3': $periodo =  'AND m.posterTime > '.forum_time(false, mktime(0, 0, 0, date("n"), date("j")-30, date("Y"))); 
			break;
/*yearly*/	case '4': $periodo =  'AND m.posterTime > '.mktime(0, 0, 0, 1, 1, date('Y')); 
			break;
/*default*/	case '5': $periodo =  ''; 
			break;			
		
}


$category = '';
if(!empty($cat) && $cat != 0)
{
$category = 'AND t.ID_BOARD = '.$cat.'';

}

		
	/* PRIMER QUERY DE LOS TOPICS CON MAS PUNTOS*/
        $request = db_query("SELECT m.subject, m.posterTime, t.puntos, t.ID_BOARD, t.ID_TOPIC, b.name
                        FROM ({$db_prefix}topics AS t, {$db_prefix}messages AS m, {$db_prefix}boards AS b)
                        WHERE m.ID_MSG = t.ID_FIRST_MSG
                        AND $user_info[query_see_board]" . (!empty($modSettings['recycle_enable']) && $modSettings['recycle_board'] > 0 ? "
                        AND b.ID_BOARD != $modSettings[recycle_board]" : '') . "
                        AND t.ID_BOARD = b.ID_BOARD" . (!empty($topic_ids) ? "
                        AND t.ID_TOPIC IN (" . implode(', ', $topic_ids) . ")" : '') . "
                        AND t.puntos > 0
						$periodo
						$category
                        ORDER BY t.puntos DESC
                        LIMIT 10", __FILE__, __LINE__);

        $context['tops-topicPoints'] = array();
        while ($row = mysql_fetch_assoc($request))
        $context['tops-topicPoints'][] = array(
            'subject' => censorText(_substr($row['subject'], 0, 35, 25, true)),
            'count' => $row['puntos'],
            'id' => $row['ID_TOPIC'],
             'board' => array(
                'id' => $row['ID_BOARD'],
                'name' => $row['bname']
                )
            );
        
        mysql_free_result($request);
/*SEGUNDA QUERY CON LOS TOPICS CON MAS COMENTARIOS*/
    $requestq = db_query("SELECT m.subject, m.posterTime, t.comments, t.ID_BOARD, t.ID_TOPIC, b.name
                        FROM ({$db_prefix}topics AS t, {$db_prefix}messages AS m, {$db_prefix}boards AS b)
                        WHERE m.ID_MSG = t.ID_FIRST_MSG
                        AND $user_info[query_see_board]" . (!empty($modSettings['recycle_enable']) && $modSettings['recycle_board'] > 0 ? "
                        AND b.ID_BOARD != $modSettings[recycle_board]" : '') . "
                        AND t.ID_BOARD = b.ID_BOARD" . (!empty($topic_ids) ? "
                        AND t.ID_TOPIC IN (" . implode(', ', $topic_ids) . ")" : '') . "
                        AND t.comments > 0
						$periodo
						$category
                        ORDER BY t.comments DESC
                        LIMIT 10", __FILE__, __LINE__);
        $context['tops-topicComments'] = array();
        while ($row = mysql_fetch_assoc($requestq))
        $context['tops-topicComments'][] = array(
            'subject' => censorText(_substr($row['subject'], 0, 35, 25, true)),
            'count' => $row['comments'],
            'id' => $row['ID_TOPIC'],
            'board' => array(
                'id' => $row['ID_BOARD'],
                'name' => $row['bname']
                )
            );
        mysql_free_result($requestq);
	/* QUERY CON LOS TOPICS CON MAS FAVORITOS*/
     $requestq = db_query("SELECT COUNT(*) as cant, m.subject, m.posterTime, t.ID_BOARD, t.ID_TOPIC, b.name
                        FROM ({$db_prefix}bookmarks AS bk, {$db_prefix}topics AS t, {$db_prefix}messages AS m, {$db_prefix}boards AS b)
                        WHERE t.ID_TOPIC = bk.ID_TOPIC
						AND m.ID_MSG = t.ID_FIRST_MSG
                        AND $user_info[query_see_board]" . (!empty($modSettings['recycle_enable']) && $modSettings['recycle_board'] > 0 ? "
                        AND b.ID_BOARD != $modSettings[recycle_board]" : '') . "
                        AND t.ID_BOARD = b.ID_BOARD" . (!empty($topic_ids) ? "
                        AND t.ID_TOPIC IN (" . implode(', ', $topic_ids) . ")" : '') . "
						$periodo
						$category
						GROUP BY m.subject, t.ID_TOPIC
                        ORDER BY cant DESC
                        LIMIT 10", __FILE__, __LINE__);
        $context['tops-favoritos'] = array();
        while ($row = mysql_fetch_assoc($requestq))
        $context['tops-favoritos'][] = array(
            'subject' => censorText(_substr($row['subject'], 0, 35, 25, true)),
            'count' => $row['cant'],
            'id' => $row['ID_TOPIC'],
            'board' => array(
                'id' => $row['ID_BOARD'],
                'name' => $row['bname']
                )
            );
        mysql_free_result($requestq);





echo'1: 

<table>
<tr>
        <td style="vertical-align:top; padding: 0"><div class="arrow-box" style="width:335px; float:left">
		<div class="title"><span><i></i></span> <strong>Top post m&aacute;s comentado</strong></div>
			<div class="count-list data list">';

                        if(empty($context['tops-topicComments']))
                            echo '<div class="error" style="margin:5px">No se encontro ningun post.</div>';
                        
            foreach($context['tops-topicComments'] as $top)
			echo '<div class="list-element clearfix"><span class="list-number"></span> <img src="'.$settings['images_url'].'/post/icono_'.$top['board']['id'].'.gif" style="float: left; margin-top: 2px;"> <a href="'.$scripturl.'?topic='.$top['id'].'">'.$top['subject'].'</a> <span class="points">'.$top['count'].'</span></div>';
			echo '</div>
		</div>
        <div class="arrow-box yellow" style="width:335px; float:left">
		<div class="title"><span><i></i></span> <strong>Top post con m&aacute;s favoritos</strong></div>
			<div class="count-list data list">';

                        if(empty($context['tops-favoritos']))
                            echo '<div class="error" style="margin:5px">No se encontro ningun post.</div>';
                        
            foreach ($context['tops-favoritos'] as $top)
			echo '<div class="list-element clearfix"><span class="list-number"></span> <img src="'.$settings['images_url'].'/post/icono_'.$top['board']['id'].'.gif" style="float: left; margin-top: 2px;"> <a href="'.$scripturl.'?topic='.$top['id'].'">'.$top['subject'].'</a> <span class="points">', $top['count'], '</span></div>';

			echo '</div>
		</div>
        </td>
                
        <td style="vertical-align:top; padding: 0"><div class="arrow-box green" style="width:335px; float:left">
		<div class="title"><span><i></i></span> <strong>Top post con m&aacute;s puntos</strong></div>
			<div class="count-list data list">';

                        if(empty($context['tops-topicPoints']))
                            echo '<div class="error" style="margin:5px">No se encontro ningun post.</div>';
                        
            foreach ($context['tops-topicPoints'] as $top)
			echo '<div class="list-element clearfix"><span class="list-number"></span> <img src="'.$settings['images_url'].'/post/icono_'.$top['board']['id'].'.gif" style="float: left; margin-top: 2px;"> <a href="'.$scripturl.'?topic='.$top['id'].'">', $top['subject'], '</a> <span class="points">', $top['count'], '</span></div>';

			echo '</div>
		</div>
        </td></tr>
        </table><input type="text" name="seccion" id="seid" class="hideObj" value="'.$section.'" ><script type="text/javascript">
$(document).ready(function(){
    count_list();
    });
</script>
		
';		
}

?>