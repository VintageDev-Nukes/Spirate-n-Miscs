<?php
/******************************
*       Comunidades.php       *
*=============================*
*        Spirate v2.4         *
*******************************
* Version 1.6.1               *
* Por Mr.Freack (c) 2012      *
******************************/

if (!defined('SPIRATE'))
die('Hacking attempt...');

/***** INDEX COMUNIDADES *****/

function Comunidades(){
	global $context, $txt, $db_prefix, $tipo, $modSettings, $settings, $sourcedir, $boarddir;
	global $txt, $scripturl, $db_prefix, $user_info, $context, $ID_MEMBER, $modSettings, $sourcedir, $board;
	global $settings, $limit_posts, $mbname, $boarddir, $comunidades;
	
 // agregamos los archivos al index
   $context['html_headers'][] = '
        <!-- COMUNIDADES -->
        <script src="'.$settings['theme_url'].'/Comunidades.js?upds='.rand(1,99999).'"></script>
        <link rel="stylesheet" type="text/css" href="'.$settings['theme_url'].'/Comunidades.css?time='.time().'"/>
        <link rel="canonical" href="'.$scripturl.'?action=comunidades'.(!empty($_REQUEST['sa']) ? ';sa='.$_REQUEST['sa']:'').''.(!empty($_REQUEST['idco']) ? ';idco='.$_REQUEST['idco']:'').''.(!empty($_REQUEST['idtema']) ? ';idtema='.$_REQUEST['idtema']:'').'">
        '.($_GET['action']=='comunidades' ?
        '<script type="text/javascript">
	         global.comunidad = {
		          '.(isset($_REQUEST['idco'])? 'id_comunidad : \''.$_REQUEST['idco'].'\',':'').''.(isset($_REQUEST['idtema'])? 'id_tema : \''.$_REQUEST['idtema'].'\',':'').'
		          images_comunidad : \''.$settings['images_url'].'/comunidades/\',
		          user_comunidad : \''.$ID_MEMBER.'\'
	         };
	      </script>':'').'
	      ';
     
  // loadlenguage() -> Comunidades.*.php
     if(loadLanguage('Comunidades') == false)
	      loadLanguage('Comunidades','spanish');

  // loadTemplate() -> Comunity.template.php
	   loadTemplate('Comunidades');

	
  // Si esta en mantenimiento y sos admin podes verlas
   if(!$modSettings['comunidades_activas'] && !$context['user']['is_admin'])
      fatal_error($txt['comunidades_enable']);	
   
  //SubActions
   $context['sub_action'] = isset($_REQUEST['sa']) ? $_REQUEST['sa'] : '';
  
 // subaction ? yes : not
   if(!empty($context['sub_action'])){
   
  // filtramos las subacciones  
      switch ($context['sub_action']){
	       case 'ajax'              : ajax();              break;
	       case 'protocolo'         : protocolo();         break;
               //Mis Comunidades by Virus
	       case 'miscomunidades'    : miscomunidades();    break;
               case 'adminComunidades'  : adminComunidades();  break;
               case 'adminPublicidad'   : adminPublicidad();   break;
               case 'adminCategorias'   : adminCategorias();   break;
	       case 'subcategorias'     : subcategorias();     break;
	       case 'crearcomunidad'    : nuevaComunidad();    break;
	       case 'nuevacomunidad'    : creandoComunidad();  break;
	       case 'comunidad-agregada': comunidad_agregada();break;
	       case 'comunidad'         : comunidadesDisplay();break;
	       case 'editar-comunidad'  : comunidadesEditar(); break;
	       case 'updatecomunidad'   : creandoComunidad();  break;
	       case 'comunidad-editada' : comunidad_editada(); break;
	       case 'creartema'         : creartema();         break;
	       case 'previaTema'        : previaTema();        break;
	       case 'creandotema'       : creandoTema();       break;
	       case 'tema-agregado'     : tema_agregado();     break;
	       case 'tema'              : temaDisplay();       break;
	       case 'miembros'          : miembros();          break;
	       case 'suspender_causa'   : suspender_causa();   break;
	       case 'suspender'         : miembros_suspender();break;
	       case 'unirse'            : unirse();            break;
	       case 'abandonar'         : abandonar();         break;
	       case 'cancelar_solicitud': cancelar_solicitud();break;
                //Directorio by Virus
	       case 'dir'      		: directorio();	       break;
	       case 'borradores-agregar': borradores_agregar();break;
	       case 'borradores-guardar': borradores_guardar();break;
	       
	       case 'follows'           : follows();           break;
	       case 'nofollows'         : nofollows();         break;
	       
	       case 'votos'             : votos();             break;
	       case 'bookmark'          : favoritos();         break;
	       case 'comentar'          : comentar();          break;
	       case 'edite_answer'      : edite_answer();      break;
	       case 'save_answer'       : save_answer();       break;
	       case 'reload_answer'     : reload_answer();     break;
	       
         /*
	       case 'newcomunity'     : createcomunity();  break;
	       case 'updatecomunity'  : updatecomunity();  break;
	       case 'comunidadcreada' : comunidadcreada(); break;
	       case 'comunidadeditada': comunidadeditada();break;
	       case 'admincomunidad'  : admincomunidad();  break;
	       case 'creartema'       : newthem();         break;
	       case 'creandotema'     : creandotema();     break;
	       case 'temacreado'      : temacreado();      break;
	       case 'temaeditado'     : temaeditado();     break;
	       case 'tprevia'         : previatema();      break;
	       case 'temas'           : temas();           break;
	       case 'miscomunidades'  : mycomunity();      break;
	       case 'formoparte'      : formoparte();      break;
	       case 'all'             : all();             break;
	       */
	    }
   }
   else{
  // sub_template = template_main()
   $context['sub_template']  = 'comunidades';
	      
	// titulo de la seccion
	 $context['page_title'] = $txt['comunidades'];
	 
	// obtenemos las categorias
   getCategorias('0');
	 
	//obtenemos lista de comunidades recientes 
	getComunidad('recientes');
	
	//obtenemos lista de comunidades populares
	getComunidad('populares');
	
	//obtenemo la comunidad destacada
   getComunidad('destacada');
   
  //Determinar las paginas
    
   $LimTemas = !empty($modSettings['temas_index']) ? $modSettings['temas_index'] : 0;
   $_REQUEST['page'] = (int)$_REQUEST['page'];
   $categoria = !empty($_GET['categoria'])?(int)$_GET['categoria']:'';
   $categoriaf = !empty($categoria)?"AND ID_BOARD = {$categoria}":'';
   
    if(!empty($categoria)){
    $request = db_query("SELECT COUNT(*) FROM {$db_prefix}comunidades_temas WHERE borrador = 0 $categoriaf",__FILE__,__LINE__);
    list($totalTemas) = mysql_fetch_row($request);
    mysql_free_result($request);
       $context['total_temas'] = !empty($totalTemas) ? $totalTemas:0;
    }
    else{
       $context['total_temas'] = !empty($modSettings['TotalTemas']) ? $modSettings['TotalTemas']:0;
    }

    require_once($sourcedir . '/classes/Pagination.php');
    $paginator = new Pagination(array(
        'base_url' => $scripturl . '?action=comunidades;'.(!empty($categoria)?'categoria='.$categoria.';':'').'page=',
        'total_rows' => $context['total_temas'],
        'per_page' => $LimTemas,
        'first_link' => '',
        'last_link' => '',
        'query_string_segment' => 'page',
        'full_tag_open' => '<ul class="paginator smallfont clearfix">',
        'full_tag_close' => '</ul>'
    ));

    $context['paginacion'] = $paginator->create_links($getData);
    $context['total_pages'] = $getData['num_pages'];

  //obtenemos la lista de temas
   getTemas('lista',0,0,$_REQUEST['page'],$LimTemas,$categoria);
   
   if($modSettings['SetTimeTopSettings']<(time()-($modSettings['SetTimeTop']*60))){
      actualizar_populares();
   }
   //obtenemos el top de comunidades populares
   getTopPopulares();
   }
   
   getAnswer('recent');
   
}

  // GET COMUNIDADES POPULARES
   function getTopPopulares(){
      global $db_prefix, $context;

	    $request = db_query("SELECT tp.id_top, tp.posicion, tp.codigo, ct.ID_COMUNIDAD, ct.titulo, ct.popularidad
	                         FROM ({$db_prefix}comunidades_tops as tp, {$db_prefix}comunidades as ct)
	                         WHERE codigo IN (1,2,3)
	                         AND tp.id_top = ct.ID_COMUNIDAD
	                         ORDER BY tp.posicion ASC, tp.codigo ASC
	                         ", __FILE__, __LINE__);
	                         
	    $context['comunidades_week'] = array();
	    $context['comunidades_month'] = array();
	    $context['comunidades_all'] = array();
	    
	    while ($row = mysql_fetch_assoc($request)){
         $codname = "";
         switch($row['codigo']){
            case 1: $codname = "week";break; 
            case 2: $codname = "month";break; 
            case 3: $codname = "all";
         }
         
		     $context['comunidades_'.$codname][] = array(
			      'titulo' => $row['titulo'],
			      'puntos' => $row['popularidad'],
			      'id' => $row['id_top']
		     );
      }
	    mysql_free_result($request);
   }

  // UPDATE COMUNIDADES POPULARES
   function actualizar_populares(){
      global $db_prefix, $context;

        /* Borramos antiguo Log*/
         db_query("DELETE FROM {$db_prefix}comunidades_tops WHERE codigo IN (1,2,3)", __FILE__, __LINE__);

        /* comunidades populares de la semana */
	       $semana = mktime(0, 0, 0, date("n"), date("j")-date('w'), date("Y"));
	       $semana = forum_time(false, $semana);


	       //OBTENEMOS COMUNIDADES CON EL SETTIME DE LA SEMANA
	        getComunidad('SetTime',0,$semana);
	           $c=0;
	        foreach($context['comunidad']['SetTime'] as $cs){
	           $c++;
	         db_query("INSERT INTO {$db_prefix}comunidades_tops
                     (dato, id_top, posicion, codigo)
              VALUES ('".$cs['idmember']."','".$cs['id']."','$c',1)", __FILE__, __LINE__);
	        }

        /* comunidades populares del mes */
	       $mes = mktime(0, 0, 0, date("n"), date("j")-(date('t')-date('w')), date("Y"));
	       $mes = forum_time(false, $mes);

	       //OBTENEMOS COMUNIDADES CON EL SETTIME DEL MES
	        getComunidad('SetTime2',0,$mes);
	           $c=0;
	        foreach($context['comunidad']['SetTime2'] as $cs2){
	           $c++;
	         db_query("INSERT INTO {$db_prefix}comunidades_tops
                     (dato, id_top, posicion, codigo)
              VALUES ('".$cs2['idmember']."','".$cs2['id']."','$c',2)", __FILE__, __LINE__);
	        }
         
	       //OBTENEMOS COMUNIDADES CON EL SETTIME DE SIEMPRE
	        getComunidad('SetTime3');
	           $c=0;
	        foreach($context['comunidad']['SetTime3'] as $cs3){
	           $c++;
	         db_query("INSERT INTO {$db_prefix}comunidades_tops
                     (dato, id_top, posicion, codigo)
                      VALUES ('".$cs3['idmember']."','".$cs3['id']."','$c',3)", __FILE__, __LINE__);
	        }
	        
     db_query("UPDATE {$db_prefix}settings SET value = '".time()."' WHERE variable = 'SetTimeTopSettings'", __FILE__, __LINE__);
   }
   
  // SUBACCIONES FUNCTIONS
  
  // FUNCIONES AJAX
   function ajax(){
	    global $txt, $context, $scripturl, $db_prefix, $settings, $modSettings;

	//Lista de acciones ajax
	   $acciones = array(
	          'none' => 'none',
	   );
	   if(isset($_POST['op']) && !empty($acciones[$_POST['op']])){
        $acciones[$_POST['op']]();
     }
     else{
     	  redirectexit('action=comunidades');
     }
	   die();
  }
   
   
  // ADMINISTRAR COMUNIDADES
   function adminComunidades(){
	   global $context, $txt, $db_prefix, $tipo, $modSettings, $cantnot, $ID_MEMBER;
	      
	      isAllowedTo('admin_forum');

       // loadTemplate() -> Comunidades.template.php
	         loadTemplate('Comunidades');
       
       // Funcion de Admins
        if(empty($context['user']['id']) or isAllowedTo('admin_forum'))
           fatal_error($txt['comunidades_private_function']);
       
       // sub_template = template_main()
        $context['sub_template']  = 'AdminComunidades';
       
       // menu de administracion
	      adminIndex('admincomunidades');
	      
	     // titulo de la seccion
	      $context['page_title'] = $txt['comunidades_admin'];
	      
	     // Wanna save this page?
	      if(isset($_POST['save_settings'])){
		     checkSession();

		   // Update the actual settings.
		     updateSettings(array(
		  //activar Comunidad ?? si - no
			     'comunidades_activas' => empty($_POST['comunidades_activas']) ? '0' : '1',
			
			//sticky en comunidades
			     'enableStickyComunidades' => empty($_POST['enableStickyComunidades']) ? '0' : '1',
			     
			//sticky en temas importantes en comunidades
			     'enableStickyTemas' => empty($_POST['enableStickyTemas']) ? '0' : '1',
			     
			//subcaterias en comunidades
			     'subcategoriasTemas' => empty($_POST['subcategoriasTemas']) ? '0' : '1',
			     
		  //activar puntos en temas ?? si - no
			     'comunidades_puntos_activos' => empty($_POST['comunidades_puntos_activos']) ? '0' : '1',
			     
		  //activar publicidad ?? si - no
			     'publicidad_activa' => empty($_POST['publicidad_activa']) ? '0' : '1',
			     
		  //activar boton next && prev ?? si - no
			     'btn_nextprev' => empty($_POST['btn_nextprev']) ? '0' : '1',
			     
			//cantidad de Comunidades en index
			     'comunidades_index' => empty($_POST['comunidades_index']) ? '10' : (int)$_POST['comunidades_index'],
			     
			//cantidad de Comunidades en mis comunidades
			     'comunidades_mycommunitys' => empty($_POST['comunidades_mycommunitys']) ? '10' : (int)$_POST['comunidades_mycommunitys'],
				 
			//cantidad de publicaciones en index
			     'temas_index' => empty($_POST['temas_index']) ? '10' : (int) $_POST['temas_index'],
			     
			//cantidad de comentarios por paginacion en el index
			     'comentarios_index' => empty($_POST['comentarios_index']) ? '20' : (int)$_POST['comentarios_index'],
			     
			//cantidad de comentarios por paginacion en comunidad
			     'comentarios_comunidades' => empty($_POST['comentarios_comunidades']) ? '20' : (int) $_POST['comentarios_comunidades'],
			     
			//cantidad de comentarios por paginacion en temas
			     'comentarios_temas' => empty($_POST['comentarios_temas']) ? '20' : (int)$_POST['comentarios_temas'],
			     
			//cantidad de subcomentarios por comentarios en temas
			     'subcomentarios_temas' => empty($_POST['subcomentarios_temas']) ? '20' : (int)$_POST['subcomentarios_temas'],
			     
			//cantidad de caracteres en descripcion
			     'max_descripcionLength' => empty($_POST['max_descripcionLength']) ? '700' : (int)$_POST['max_descripcionLength'],
			     
			//cantidad de caracteres en el cuerpo de un tema
			     'max_bodyLength' => empty($_POST['max_bodyLength']) ? '63206' : (int)$_POST['max_bodyLength'],
			     
			//Tiempo de recarga de Comunidades Populares
			     'SetTimeTop' => empty($_POST['SetTimeTop']) ? '10' : (int)$_POST['SetTimeTop'],
			     
			//Tiempo de recarga de Top Temas
			     'SetTimeTopTemas' => empty($_POST['SetTimeTopTemas']) ? '10' : (int)$_POST['SetTimeTopTemas'],
			     
			// default settings setTime
			     'SetTimeTopSettings' => empty($_POST['SetTimeTop']) ? time() : time(),
			     'SetTimeTopTemasSettings' => empty($_POST['SetTimeTopTemas']) ? time() : time(),
			     
			//tiempo antiflood
			     'comunidades_anti_flood' => empty($_POST['comunidades_anti_flood']) ? '0' : (int)$_POST['comunidades_anti_flood'],
			     
			// user  Twitter';
			     'user_twitter' => empty($_POST['user_twitter']) ? '' : $_POST['user_twitter'],
			     
			// aplication ID facebook
			     'appID_FB' => empty($_POST['appID_FB']) ? '' : $_POST['appID_FB'],
			     
			     
		     ));
	      }
   }
   
  // ADMINISTRAR PUBLICIDAD EN COMUNIDADES
   function adminPublicidad(){
	   global $context, $txt, $db_prefix, $tipo, $modSettings, $cantnot, $ID_MEMBER;
	      
	      isAllowedTo('admin_forum');

       // loadTemplate() -> Comunity.template.php
	         loadTemplate('Comunidades');
       
       // Funcion de Admins
        if(empty($context['user']['id']) or isAllowedTo('admin_forum'))
           fatal_error($txt['private_function']);
       
       // sub_template = template_main()
        $context['sub_template']  = 'adminPublicidad';
       
       // menu de administracion
	      adminIndex('admincomunidades');
	      
	     // titulo de la seccion
	      $context['page_title'] = $txt['comunidades_publicidad'];
	      
	       
	    // Wanna save this page?
	      if(isset($_POST['save_settings'])){
		     checkSession();

		  // Update the actual settings.
		     updateSettings(array(
			     
			// bloque de publicidad uno
			     'publicidad_one' => empty($_POST['publicidad_one']) ? '' : $_POST['publicidad_one'],
			     
			// bloque de publicidad dos
			     'publicidad_two' => empty($_POST['publicidad_two']) ? '' : $_POST['publicidad_two'],
		     ));
	      }
   }
   
  // ADMINISTRAR CATEGORIAS EN COMUNIDADES
   function adminCategorias(){
	   global $context, $txt, $db_prefix, $tipo, $modSettings, $cantnot, $ID_MEMBER;
	      
	      isAllowedTo('admin_forum');

       // loadTemplate() -> Comunity.template.php
	         loadTemplate('Comunidades');
       
       // Funcion de Admins
        if(empty($context['user']['id']) or isAllowedTo('admin_forum'))
           fatal_error($txt['private_function']);
       
       // menu de administracion
	      adminIndex('admincomunidades');
	      
	     // titulo de la seccion
	      $context['page_title'] = $txt['comunidades_categorias_'];
       
	     // Format: 'sub-action' => array('function', 'permission')
	      $subActions = array(
		       'main' => array('CategoriasMain', 'admin_forum'),
		       'board' => array('CategoriasEdite', 'admin_forum'),
		       'board2' => array('CategoriasEdite2', 'admin_forum'),
		       
		       'settings' => array('CategoriasSettings', 'admin_forum'),
	       );

	     // Default to sub action 'main' or 'settings' depending on permissions.
	      $_REQUEST['op'] = isset($_REQUEST['op']) && isset($subActions[$_REQUEST['op']]) ? $_REQUEST['op'] : (allowedTo('admin_forum') ? 'main' : 'settings');
	      
	      $subActions[$_REQUEST['op']][0]();
   }
   
   
  // CATEGORIAS GENERALES
   function CategoriasMain(){
   	  global $txt, $context, $cat_tree, $boards, $boardList, $scripturl, $sourcedir, $txt;
          
       // sub_template = template_main()
        $context['sub_template']  = 'adminCategorias';
        
       // Load Categories
       getCategorias('0');
   }
   
   
  // EDITAR CATEGORIA
   function CategoriasEdite(){
   	  global $txt, $context, $cat_tree, $boards, $boardList, $scripturl, $sourcedir, $txt, $db_prefix;
   	  
       // sub_template = template_main()
        $context['sub_template']  = 'EditeCategorias';
        
       // Load Categories
       getCategorias('0');
       
   	  // ID_BOARD must be a number....
	     $_REQUEST['boardid'] = isset($_REQUEST['boardid']) ? (int)$_REQUEST['boardid'] : 0;
	     
	     if(!isset($boards[$_REQUEST['boardid']])){
		      $_REQUEST['boardid'] = 0;
		      $_REQUEST['sa'] = 'newboard';
	     }
	     
	     if ($_REQUEST['sa'] == 'newboard'){
		  // Some things that need to be setup for a new board.
		   $curBoard = array(
			    'memberGroups' => array(0, -1),
			    'category' => (int) $_REQUEST['cat']
		   );
		   
		   $context['board_order'] = array();
		   
		   $context['board'] = array(
			    'is_new' => true,
			    'id' => 0,
			    'name' => $txt['mboards_new_board_name'],
		   );
	     }
	     else{
		  // Just some easy shortcuts.
		   $curBoard = &$boards[$_REQUEST['boardid']];
		   $context['board'] = $boards[$_REQUEST['boardid']];
		   $context['board']['name'] = htmlspecialchars($context['board']['name']);
	    }
		   
		  // Default membergroups.
	     $context['groups'] = array(
		                         -1 => array(
			                              'id' => '-1',
			                            'name' => $txt['comunidades_only_guests'],
			                         'checked' => in_array('-1', $curBoard['memberGroups']),
			                   'is_post_group' => false,
		                         ),
		                        0 => array(
			                              'id' => '0',
			                            'name' => $txt['comunidades_members_only'],
			                         'checked' => in_array('0', $curBoard['memberGroups']),
			                   'is_post_group' => false,
		                        )
	      );
	      
	    // Load membergroups.
	     $request = db_query("
		      SELECT groupName, ID_GROUP, minPosts
		      FROM {$db_prefix}membergroups
		      WHERE ID_GROUP > 3 OR ID_GROUP = 2
		      ORDER BY minPosts, ID_GROUP != 2, groupName", __FILE__, __LINE__);
	      while ($row = mysql_fetch_assoc($request)){
		      if($_REQUEST['op'] == 'newboard' && $row['minPosts'] == -1)
			         $curBoard['memberGroups'][] = $row['ID_GROUP'];

		      $context['groups'][(int) $row['ID_GROUP']] = array(
			         'id' => $row['ID_GROUP'],
			         'name' => trim($row['groupName']),
			         'checked' => in_array($row['ID_GROUP'], $curBoard['memberGroups']),
			         'is_post_group' => $row['minPosts'] != -1,
		      );
	      }
	      mysql_free_result($request);
	      
   }
   
  // Make changes to/delete a board.
   function CategoriasEdite2(){
	   global $txt, $db_prefix, $sourcedir, $modSettings;
     
      checkSession();
      $_POST['boardid'] = (int)$_POST['boardid'];
     	
     // Mode: modify aka. don't delete.
	    if(isset($_POST['edit']) || isset($_POST['add'])){
		    $boardOptions = array();

		// Change '1 & 2' to '1 &amp; 2', but not '&amp;' to '&amp;amp;'...
		 $boardOptions['board_name'] = preg_replace('~[&]([^;]{8}|[^;]{0,8}$)~', '&amp;$1', $_POST['board_name']);

		
		 modifyCategorias($_POST['boardid'], $boardOptions);
	    }
     elseif (isset($_POST['delete'])){  
			deleteCategorias(array($_POST['boardid']), 0);
	   } 
  
	   redirectexit('action=comunidades;sa=adminCategorias');
   }
   
  // CATEGORIAS SETTINGS
   function CategoriasSettings(){
   	  global $txt, $context, $cat_tree, $boards, $boardList, $scripturl, $sourcedir, $txt;
          
       // sub_template = template_main()
        $context['sub_template']  = 'adminCategorias2';
   }
  // NUEVA COMUNIDAD

   function protocolo(){
	    global $context, $txt, $db_prefix, $tipo, $modSettings, $ID_MEMBER, $func, $comunidades;
	
	     is_not_guest();
	     
       // sub_template = template_main()
        $context['sub_template']  = 'protocolo';	
        
	     // titulo de la seccion
	      $context['page_title'] = $txt['comunidades_protocolo'];

       // es nueva comunidad ???
        $context['nueva_comunidad'] = !isset($_REQUEST['idco']);

        $id_comunidad = (int)$_REQUEST['idcom'];
        
        	// Previewing, modifying, or posting?
	     if (isset($id_comunidad) || !empty($context['comunidad_error'])){		
	        // No check is needed, since nothing is really posted.
		       checkSubmitOnce('free');
		   }
       
       // get categories
        getCategorias('0');
        
       // se puede destacar ??
       $context['is_sticky'] = !empty($modSettings['enableStickyComunidades']) ? true: false;
       
       // se pueden usar las subcaterias ??
       $context['is_subcategorias'] = !empty($modSettings['subcategoriasTemas']) ? true: false;
      
      // Register this form in the session variables.
	       checkSubmitOnce('register');
   }
   
  // NUEVA COMUNIDAD

   function nuevaComunidad(){
	    global $context, $txt, $db_prefix, $tipo, $modSettings, $ID_MEMBER, $func, $comunidades;
	
	     is_not_guest();
	     
       // sub_template = template_main()
        $context['sub_template']  = 'nuevacomunidad';	
        
	     // titulo de la seccion
	      $context['page_title'] = $txt['comunidades_nueva_comunidad'];

       // es nueva comunidad ???
        $context['nueva_comunidad'] = !isset($_REQUEST['idco']);

        $id_comunidad = (int)$_REQUEST['idcom'];
        
        	// Previewing, modifying, or posting?
	     if (isset($id_comunidad) || !empty($context['comunidad_error'])){		
	        // No check is needed, since nothing is really posted.
		       checkSubmitOnce('free');
		   }
       
       // get categories
        getCategorias('0');
        
       // se puede destacar ??
       $context['is_sticky'] = !empty($modSettings['enableStickyComunidades']) ? true: false;
       
       // se pueden usar las subcaterias ??
       $context['is_subcategorias'] = !empty($modSettings['subcategoriasTemas']) ? true: false;
      
      // Register this form in the session variables.
	       checkSubmitOnce('register');
   }
  
  
  // EDITAR COMUNIDAD
  function comunidadesEditar(){
  	 global $txt, $db_prefix, $scripturl, $context, $comunidades, $miembros, $temas, $ID_MEMBER, $boards, $modSettings;
     
     is_not_guest();

     // es nueva comunidad ???
     $context['nueva_comunidad'] = !isset($_REQUEST['idco']);
     
     $id_comunidad = (int)$_GET['idco'];
     
     // Previewing, modifying, or posting?
	    if(isset($id_comunidad) || !empty($context['comunidad_error'])){		
	      // No check is needed, since nothing is really posted.
		     checkSubmitOnce('free');
		  }
        
     //query of comunity
      getComunidad('query');
        
     // Just some easy shortcuts.
		  $context['comunidad'] = &$comunidades[$id_comunidad];
		  
		  if(empty($context['user']['is_admin']) && empty($context['comunidad']['soyadmin'])){
		     fatal_error($txt['comunidades_no_be_admin'],false);
		  }

		 // get categories
      getCategorias('0');
		   
     // se pueden usar las subcaterias ??
     $context['is_subcategorias'] = !empty($modSettings['subcategoriasTemas']) ? true: false;
        
       // se puede destacar ??
       $context['is_sticky'] = !empty($modSettings['enableStickyComunidades']) ? true: false;
		   
     // sub_template = template_main()
      $context['sub_template']  = 'nuevacomunidad';	
        
	   // titulo de la seccion
	    $context['page_title'] = $txt['comunidades_edite_community'].' "'.$context['comunidad']['titulo'].'"';
	    
	   // Register this form in the session variables.
	    checkSubmitOnce('register');
  }
   
  // SUBCATEGORIAS EN NUEVA COMUNIDAD
  function subcategorias(){
	    global $context, $txt, $db_prefix, $tipo, $modSettings, $ID_MEMBER, $func, $comunidades, $boardurl;
       
       //categoria
       $categoria = $_POST['id'];
       $subcategoria = isset($_POST['cat'])?$_POST['cat']:0;
       
       if(empty($modSettings['subcategoriasTemas'])){
       echo '<span class="tema-errormsg fleft error" style="display:block;width:220px;text-align:center">'.$txt['comunidades_enabled_subcategorias'].'</span><br>';
       }
       else
       if(!empty($categoria) && !empty($modSettings['subcategoriasTemas'])){
       
       // get categories
        getCategorias($categoria);
        
        echo'
        <div class="box-categories rounded" style="margin-top:10px;overflow: hidden; width: auto; height: 300px;">
           <ul id="form-sub-categorias" class="slimScroll2">
              <li></li>
              <li '.(empty($subcategoria)?'class="selected"':'').'><a val="0" style="padding:0"><i class="iconos_ subcategorias"></i>'.$txt['comunidades_select_sub_categories'].'</a></li>';
	            foreach($context['categorias'] as $board){
		     echo'<li id="'.$board['id'].'" '.($subcategoria == $board['id'] ? ' class="selected"' : '').'><i class="iconos_ cat_'.$board['tipo'].'"></i><a val="'.$board['id'].'">'.$board['name'].'</a></li>';}
	       echo'<li></li>
	         </ul>
	      </div>
	      <script>
	      $(\'.slimScroll2\').slimScroll({
           width: \'auto\',
           height: \'300px\',
           size: \'10px\',
           position: \'right\',
           color: \'#333\',
           alwaysVisible: false,
           distance: \'5px\',
           start: \'top\'
        });
        var li = $(\'li.push\').remove();
                 $(\'ul#form-sub-categorias li:eq(2)\').before(li);
                 $(\'#form-sub-categorias li:last-child\').addClass(\'rounded-bottom\');
        $.Comunidades.select_category(\'sub-\');
        </script>
	      ';
	    }
	    else{
	    redirectexit($boardurl);
	    }
	    exit;
  
  }
  
  // CREANDO COMUNIDAD
  function 	creandoComunidad(){
	    global $context, $txt, $db_prefix, $tipo, $modSettings, $ID_MEMBER, $func, $idco, $user_info;
	    
	    // Prevent double submission of this form.
	     checkSubmitOnce('check');
       
       is_not_guest();
       
       // No errors as yet.
	      $comunidad_errors = array();
	     
	     $context['comunidad']['id_comunidad'] = !empty($_POST['id_comunidad'])?$_POST['id_comunidad']:0;
	     $context['comunidad']['titulo'] = $_POST['titulo'];
	     $context['comunidad']['portada'] = $_POST['portada'];
	     $context['comunidad']['descripcion'] = $func['htmlspecialchars']($_POST['descripcion'], ENT_QUOTES);
	     $context['comunidad']['categoria'] = $_POST['categoria'];
	     $context['comunidad']['sub-categoria'] = isset($_POST['sub-categoria']) && !empty($modSettings['subcategoriasTemas']) ? $_POST['sub-categoria'] : 0;
	     $context['comunidad']['background'] = $_POST['background'];
	     $context['comunidad']['miembros'] = (int)$_POST['miembros'];
	     $context['comunidad']['rangos'] = (int)$_POST['rangos'];
	     $context['comunidad']['sticky'] = isset($_POST['sticky']) && !empty($modSettings['enableStickyComunidades']) ? $_POST['sticky'] : null;
	     $context['comunidad']['privacidad'] = (int)$_POST['privacidad'];
	     $context['comunidad']['admin'] = (int)$_POST['admin'];
	     $context['comunidad']['permiso'] = $context['comunidad']['admin'] == $ID_MEMBER || !empty($context['user']['is_admin']) ? true:false;
	     
	     //dimensiones para img
	      $imagen = getimagesize($context['comunidad']['portada']);
	      $imagenf = getimagesize($context['comunidad']['background']);
	     
	     // sin titulo ? :O
	     if(!isset($context['comunidad']['titulo']) || $func['htmltrim']($context['comunidad']['titulo']) === '')
		    $comunidad_errors[] = 'no_title';
		    
	     // sin portada ? :O
	     if(!isset($context['comunidad']['portada']) || $func['htmltrim']($context['comunidad']['portada']) === ''){
		    $comunidad_errors[] = 'no_portada';}
		   else if(empty($imagen[0]) && empty($imagen[1])){
		    $comunidad_errors[] = 'no_portada_valida';}
		   
		   // sind escripcion
			 if(!isset($context['comunidad']['descripcion']) || $func['htmltrim']($context['comunidad']['descripcion']) === '')
		    $comunidad_errors[] = 'no_descripcion';

	    // You are not!
	     if (isset($context['comunidad']['descripcion']) && strtolower($context['comunidad']['descripcion']) == 'i am the administrator.' && !$user_info['is_admin'])
		     fatal_error('Knave! Masquerader! Charlatan!', false);
        
        // are you serius?
        $enemy = array('phpost', 'php0st');
        $uncensured_enemy = (censorText($enemy[0]) == 'phpost' && censorText($enemy[1]) == 'php0st');
        if($uncensured_enemy)
            if (isset($context['comunidad']['descripcion']) && preg_match('~(php(0|o)st)(\.net|)?~i', trim($context['comunidad']['descripcion'])) === 1)
                    $context['comunidad']['descripcion'] = str_replace($enemy, 'spirate', $context['comunidad']['descripcion']);
       
	     // sin portada ? :O
	     if(!empty($context['comunidad']['background'])){
	        if(empty($imagenf[0]) && empty($imagenf[1])){
		         $comunidad_errors[] = 'no_portada_valida_f';
		      }
		   }
		    
       // sin categoria
       if(empty($context['comunidad']['categoria'])){
        $comunidad_errors[] = 'empty_category';
       }
       else{
        // really exists that category?
        $request = db_query("SELECT ID_BOARD
                             FROM {$db_prefix}comunidades_categorias
                             WHERE ID_BOARD = '".$context['comunidad']['categoria']."'", __FILE__, __LINE__);
        if(mysql_num_rows($request) == 0)
            $comunidad_errors[] = 'bad_category';
        mysql_free_result($request);
       }
       
        //no se selecciono la validacion
         if(!isset($context['comunidad']['miembros']) || $func['htmltrim']($context['comunidad']['miembros']) === '')
		        $comunidad_errors[] = 'no_validation';
		        
        //no se selecciono un rango
         if(!isset($context['comunidad']['rangos']) || $func['htmltrim']($context['comunidad']['rangos']) === '')
		        $comunidad_errors[] = 'no_rangos';
        
       // Creating a new topic?
	      $nuevacomunidad = empty($_REQUEST['idco']);
	      
	      // parametros
	      $ComunidadOptions = array(
	         'comunidad' => $context['comunidad']['id_comunidad'],
	         'titulo' => $context['comunidad']['titulo'],
	         'portada' => $context['comunidad']['portada'],
	         'descripcion' => $context['comunidad']['descripcion'],
	         'categoria' => $context['comunidad']['categoria'],
	         'subcategoria' => $context['comunidad']['sub-categoria'],
	         'background' => $context['comunidad']['background'],
	         'miembros' => $context['comunidad']['miembros'],
	         'rangos' => $context['comunidad']['rangos'],
	         'sticky' => $context['comunidad']['sticky'],
	         'privacidad' => $context['comunidad']['privacidad'],
	         'fecha' => time(),
	      );

	      $posterOptions = array(
		       'id' => $ID_MEMBER,
		       'admin' => $context['comunidad']['admin'],
		       'permiso' => $context['comunidad']['permiso'],
	      );
      
  	  // Any mistakes?
	     if (!empty($comunidad_errors)){
		    // Previewing.
		     $_REQUEST['submit'] = true;

		     $context['comunidad_error'] = array('messages' => array());
		     
		     foreach ($comunidad_errors as $comunidad_error){
			     $context['comunidad_error'][$comunidad_error] = true;
			     $context['comunidad_error']['messages'][] = $txt['comunidades_error_'.$comunidad_error];
		     }
		    if(empty($context['comunidad']['id_comunidad'])){      
		       return nuevaComunidad();
		    }
		    else{      
		       return comunidadesEditar();
		    }
	     }
	     else if(!empty($context['comunidad']['id_comunidad'])){
	        updateComunidad($ComunidadOptions, $posterOptions);
	     }
	     else{
	        createComunidad($ComunidadOptions, $posterOptions);
	     }
	     
	     // END FILTERS
	     
	     if(!empty($context['comunidad']['id_comunidad']))	
	        redirectexit('action=comunidades;sa=comunidad-editada;idco='.$context['comunidad']['id_comunidad']); 
	     else{
		      redirectexit('action=comunidades;sa=comunidad-agregada;idco='.$idco);
		   }
  }
  
    // COMUNIDAD AGREGADA
  
  function comunidad_editada(){
  	 global $txt, $db_prefix, $scripturl, $context, $comunidades;
	   
	   	 is_not_guest();
	     
       // sub_template = template_main()
        $context['sub_template']  = 'comunidad_editada';	
        
	     // titulo de la seccion
	      $context['page_title'] = $txt['comunidades_comunidad_editada'];
 
       //query of comunity
        getComunidad('query');

        $id_comunidad = (int)$_GET['idco'];
        
       // Just some easy shortcuts.
		   $context['comunidad_editada'] = &$comunidades[$id_comunidad];
  }

  // COMUNIDAD AGREGADA
  function comunidad_agregada(){
  	 global $txt, $db_prefix, $scripturl, $context, $comunidades;
	   
	   	 is_not_guest();
	     
       // sub_template = template_main()
        $context['sub_template']  = 'comunidad_agregada';	
        
	     // titulo de la seccion
	      $context['page_title'] = $txt['comunidades_comunidad_agregada'];
 
       //query of comunity
        getComunidad('query');

        $id_comunidad = (int)$_GET['idco'];
        
       // Just some easy shortcuts.
		   $context['comunidad_nueva'] = &$comunidades[$id_comunidad];
  }
  
  // COMUNIDAD DISPLAY
  function comunidadesDisplay(){
  	 global $txt, $db_prefix, $scripturl, $context, $comunidades, $miembros, $temas, $ID_MEMBER, $boards, $modSettings;
     global $pagAnterior, $pagActual, $pagTotal, $pagSiguiente, $solicitudes;
 
        $id_comunidad = (int)$_GET['idco'];
        
       //query of comunity
        getComunidad('query');
        
       // Just some easy shortcuts.
		   $context['comunidad'] = &$comunidades[$id_comunidad];
		   
		   if(!isset($id_comunidad) || empty($id_comunidad)){
		      redirectexit('action=comunidades');
		   }
		   else if(empty($context['comunidad'])){
		      fatal_error($txt['comunidades_no_exist'],false);
		   }
       
       getComunidadMembers('unlimited',$id_comunidad);
       
		   $context['miembro'] = &$miembros[$ID_MEMBER];
		   
		   getComunidadSolicitud($id_comunidad);
       
		   $context['solicituds'] = &$solicitudes[$ID_MEMBER];
		   
		   // si el miembro no lo has bloqueado vera todo
		   if(/*empty($context['miembro']['is_member']) ||*/ empty($context['miembro']['bloqueado']) && empty($context['solicituds']['bloqueado'])){
		   
		   if($context['comunidad']['privacity']['tipo']==1 && $context['user']['is_guest']){
		      fatal_error($txt['comunidades_register_c'],false);
		   }
		   
		   //filtro de vistas
		   switch($context['comunidad']['privacity']['tipo']){
		      case 0: 
		         $context['puedeverla'] = true;
		         $context['puedeverla_txt'] = '';
		      break;
		      case 1: 
		         $context['puedeverla'] = $context['user']['is_logged'] ? true:false;
		         $context['puedeverla_txt'] = 'dd';
		      break;
		      case 2:
		         $context['puedeverla'] = !empty($context['miembro']['is_member']) ? true:false;
		         $context['puedeverla_txt'] = '<div class="fleft info infofix">
		                                          '.$txt['comunidades_register_one'].'
		                                          <a onclick="$.Comunidades.unirse("", '.$context['comunidad']['id'].','.$context['comunidad']['rango'].')">
		                                             '.$txt['comunidades_registre_two'].'
		                                          </a>
		                                          '.$txt['comunidades_register_three'].'
		                                       </div>';
		      break;
		   }
		   
		   //obtenemos la subcategoria si existe sino pues ahorremos recurso :D
		   if(!empty($context['comunidad']['id_subcategoria']) && !empty($modSettings['subcategoriasTemas'])){
        getCategorias($context['comunidad']['id_categoria']);
		    $context['subcategoria'] = &$boards[$context['comunidad']['id_subcategoria']];
       }
       $context['temas_index'] = empty($modSettings['temas_index'])?20:$modSettings['temas_index'];
       
       //paginamos resultados en temas
       $pagTotal = ceil($context['comunidad']['temas']/$context['temas_index']);
       
       if(!isset($_GET['pag'])){
       $pagActual=1;
       } 
       else{
       $pagActual=$_GET['pag'];
       }
       $pagAnterior = $pagActual-1;
       $pagSiguiente = $pagActual+1;
       $ini = ($pagActual-1)*$context['temas_index']; 

       //nos ahorramos querys si es visitante y el user no permite ver a visitantes
       if($context['puedeverla']){
          //query of comunity temas importants
           getTemas('importantes',$id_comunidad,0,$ini,$context['temas_index']);
        
          //query of comunity temas normales
           getTemas('normales',$id_comunidad,0,$ini,$context['temas_index']);
       }
		   
		   }
		   else{
		      $context['user']['bloqueado'] = '<div class="fleft error infofix">
		                                          '.$txt['comunidades_bloked_user'].': '.$context['miembro']['razon'].'
		                                       </div>';
		   }
       //obtenemos el staff de la ocmunidad
       getStaff($id_comunidad);

       // sub_template = template_main()
        $context['sub_template']  = 'Comunidad_Display';	
        
	     // titulo de la seccion
	      $context['page_title'] = $context['comunidad']['titulo'].' - '.$context['forum_name'];

        if($modSettings['SetTimeTopTemasSettings']<(time()-($modSettings['SetTimeTopTemas']*60))){
           actualizar_TopTemas($context['comunidad']['id']);
        }
       //obtenemos el top de temas
        getTopTemas($context['comunidad']['id']);
        
       //visitas!
	     if(empty($_SESSION['visita']['comunidad'][$context['comunidad']['id']]) || $_SESSION['visita']['comunidad'][$context['comunidad']['id']] != $context['comunidad']['id']){
	        updateVisitas($context['comunidad']['id'], $context['comunidad']['idmember'],1);
	     }
	     
       //seguidores
       im_follow($context['comunidad']['id'], $ID_MEMBER, 2);
       
       getAnswer('list',0,0,$context['comunidad']['id']);

  }

    // GET TOP TEMAS

   function getTopTemas($id){
      global $db_prefix, $context;

	    $request = db_query("SELECT tp.id_top, tp.posicion, tp.codigo, ct.ID_TEMA, ct.titulo, ct.popularidad
	                         FROM ({$db_prefix}comunidades_tops as tp, {$db_prefix}comunidades_temas as ct)
	                         WHERE codigo IN (4,5,6)
	                         AND tp.dato = $id
	                         AND tp.id_top = ct.ID_TEMA
	                         ORDER BY tp.posicion ASC, tp.codigo ASC
	                         ", __FILE__, __LINE__);
	                         
	    $context['temas_week'] = array();
	    $context['temas_month'] = array();
	    $context['temas_all'] = array();
	    
	    while ($row = mysql_fetch_assoc($request)){
         $codname = "";
         switch($row['codigo']){
            case 4: $codname = "week";break; 
            case 5: $codname = "month";break; 
            case 6: $codname = "all";
         }
         
		     $context['temas_'.$codname][] = array(
			      'titulo' => recortart(censorText($row['titulo']),28),
			      'puntos' => $row['popularidad'],
			      'id' => $row['ID_TEMA']
		     );
      }
	    mysql_free_result($request);
	 }
	 
  // UPDATE TOP TEMAS
  
   function actualizar_TopTemas($id_comunidad){
      global $db_prefix, $context;

        /* Borramos antiguo Log*/
         db_query("DELETE FROM {$db_prefix}comunidades_tops WHERE codigo IN (4,5,6) AND dato = $id_comunidad", __FILE__, __LINE__);

        /* comunidades populares de la semana */
	       $semana = mktime(0, 0, 0, date("n"), date("j")-date('w'), date("Y"));
	       $semana = forum_time(false, $semana);
	       
	       //OBTENEMOS TOP TEMAS CON EL SETTIME DE LA SEMANA
	        getTemas('SetTime',$id_comunidad,0,0,0,0, $semana);
	           $c=0;
	        foreach($context['temas']['SetTime'] as $cs){
	           $c++;
	         db_query("INSERT INTO {$db_prefix}comunidades_tops
                     (dato, id_top, posicion, codigo)
              VALUES ('".$cs['id_comunidad']."','".$cs['id']."','$c',4)", __FILE__, __LINE__);
	        }

        /* comunidades populares del mes */
	       $mes = mktime(0, 0, 0, date("n"), date("j")-(date('t')-date('w')), date("Y"));
	       $mes = forum_time(false, $mes);

	       //OBTENEMOS TOP TEMAS CON EL SETTIME DEL MES
	        getTemas('SetTime2',$id_comunidad,0,0,0,0, $mes);
	           $c=0;
	        foreach($context['temas']['SetTime2'] as $cs2){
	           $c++;
	         db_query("INSERT INTO {$db_prefix}comunidades_tops
                     (dato, id_top, posicion, codigo)
              VALUES ('".$cs2['id_comunidad']."','".$cs2['id']."','$c',5)", __FILE__, __LINE__);
	        }
         
	       //OBTENEMOS TOP TEMAS CON EL SETTIME DE SIEMPRE
	        getTemas('SetTime3',$id_comunidad);
	           $c=0;
	        foreach($context['temas']['SetTime3'] as $cs3){
	           $c++;
	         db_query("INSERT INTO {$db_prefix}comunidades_tops
                     (dato, id_top, posicion, codigo)
              VALUES ('".$cs3['id_comunidad']."','".$cs3['id']."','$c',6)", __FILE__, __LINE__);
	        }
	        
     db_query("UPDATE {$db_prefix}settings SET value = '".time()."' WHERE variable = 'SetTimeTopTemasSettings'", __FILE__, __LINE__);
   }
  
  // CREAR TEMA NUEVO
  function creartema(){
  	 global $txt, $db_prefix, $scripturl, $context, $comunidades, $miembros, $staff, $ID_MEMBER, $user_info, $modSettings;
 
	   	  is_not_guest();
	   	 
        $id_comunidad = (int)$_GET['idco'];
  
       // sub_template = template_main()
        $context['sub_template']  = 'nuevoTema';	
        
	     // titulo de la seccion
	      $context['page_title'] = $context['forum_name'];

        // es nuevo tema ???
        $context['nuevo_tema'] = !isset($_REQUEST['idtema']);

        $id_tema = (int)$_GET['idtema'];
        
        // Previewing, modifying, or posting?
	       if (isset($id_tema)){		
	          // No check is needed, since nothing is really posted.
		        checkSubmitOnce('free');
		     }
        
        //hay stickys ??
        $context['enable_stickys'] = !empty($modSettings['enableStickyTemas']) ? true:false;
	       
       //obtenemos los miembros de la comunidad
       getComunidadMembers('last', $id_comunidad);
       
       //obtenemos info de la comunidad
       getComunidad('query');
       
       //obtenemos el staff de la ocmunidad
       getStaff($id_comunidad);
       
		   $context['comunidad'] = &$comunidades[$id_comunidad];
       
		   $context['miembro'] = &$miembros[$ID_MEMBER];
		   
		   $context['staff'] = &$staff[$ID_MEMBER];
		   
		   // es admin o moderador
		   $context['is_admin_comunidad'] = !empty($context['staff']['admin']) ? true:false;
		   
       if(empty($context['miembro']['publicador'])){
          fatal_error($txt['comunidades_you_are_guest'],false);
       }
       else if(empty($context['comunidad']['tipo']) && empty($context['miembro']['admin'])){
          fatal_error($txt['comunidades_no_nuevos_temas'],false);
       }
       else
       if(empty($context['miembro']['is_member']) && empty($context['miembro']['admin'])){
          fatal_error($txt['comunidades_no_members_sorry'],false);
       }
       
      // Register this form in the session variables.
	       checkSubmitOnce('register');
       
  }
  
  // vista previa del tema
  function previaTema(){
    global $context, $settings, $boardurl, $scripturl, $ID_MEMBER, $txt, $modSettings, $sourcedir, $func;
    
    $cuerpo = parse_html_entities($_POST['cuerpo'], ENT_QUOTES);
    
    if(!empty($cuerpo)){
       echo'1: <div class="content_body_tema">'.parse_bbc(censorText($cuerpo)).'</div>
               <script>
                  sp_dialog.center();
                  sp_dialog.endload(false, true);  
               </script>';
   }
   else{
       redirectexit($boardurl);
   }
    exit();
  }
  
  // CREANDO NUEVO TEMA
  function 	creandoTema(){
	    global $context, $txt, $db_prefix, $tipo, $modSettings, $ID_MEMBER, $func, $idtema, $user_info, $miembros, $temas;
	    
	   	  is_not_guest();
	   	  
	    // Prevent double submission of this form.
	     checkSubmitOnce('check');
	     
	     $context['t_comunidad'] = $_POST['comid'];
	     $context['t_borrador'] = (int)$_POST['borrador'];
	     
	     //obtenemos los miembros de la comunidad
       getComunidadMembers('last',$context['t_comunidad']);
       
		   $context['miembro'] = &$miembros[$ID_MEMBER];
		   
	     if(empty($context['miembro']['publicador']) && empty($context['user']['is_admin'])){
          fatal_error($txt['comunidades_you_are_guest'],false);
       }
       else if(empty($context['miembro']['is_member']) && empty($context['user']['is_admin'])){
          fatal_error($txt['comunidades_no_members_sorry'],false);
       }
       else if(!empty($context['miembro']['bloqueado']) && empty($context['user']['is_admin'])){
          fatal_error($txt['comunidades_acces_restringido'],false);
       }
	     
	     $context['t_titulo'] = $_POST['titulo'];
	     $context['t_cuerpo'] = $func['htmlspecialchars']($_POST['cuerpo'], ENT_QUOTES);
	     $context['t_categoria'] = (int)$_POST['categoria'];
	     $context['t_categoria2'] = (int)$_POST['subcategoria'];
	     $context['t_siguiendo'] = !empty($_POST['follow']) ? 1:0;
	     $context['t_cerrado'] = (int)$_POST['cerrado'];
	     $context['t_sticky'] = isset($_POST['sticky']) && !empty($modSettings['enableStickyTemas']) ? (int)$_POST['sticky'] : null;

	    // You are not!
	     if (isset($context['t_cuerpo']) && strtolower($context['t_cuerpo']) == 'i am the administrator.' && !$user_info['is_admin'])
		     fatal_error('Knave! Masquerader! Charlatan!', false);
        
        // are you serius?
        $enemy = array('phpost', 'php0st');
        $uncensured_enemy = (censorText($enemy[0]) == 'phpost' && censorText($enemy[1]) == 'php0st');
        if($uncensured_enemy)
            if (isset($context['t_cuerpo']) && preg_match('~(php(0|o)st)(\.net|)?~i', trim($context['t_cuerpo'])) === 1)
                    $context['t_cuerpo'] = str_replace($enemy, 'spirate', $context['t_cuerpo']);
        
       // Creating a new them?
	      $nuevotema = empty($_REQUEST['idtema']);
	       
        
        if(!empty($context['t_borrador'])){
		     //query of comunity temas
           getTemas('lista',$context['t_comunidad'],1);
        
         // Just some easy shortcuts.
		      $context['tema'] = &$temas[$context['t_borrador']];
		    }
		   
	      // parametros
	      $TemaOptions = array(
	         'titulo' => $context['t_titulo'],
	         'comunidad' => $context['t_comunidad'],
	         'categoria' => $context['t_categoria'],
	         'categoria2' => $context['t_categoria2'],
	         'cuerpo' => $context['t_cuerpo'],
	         'siguiendo' => $context['t_siguiendo'],
	         'cerrado' => $context['t_cerrado'],
	         'sticky' => $context['t_sticky'],
	         'tema' => (int)$context['t_borrador'],
	      );
	      
	      $posterOptions = array(
		       'id' => $ID_MEMBER,
		       'permiso' => $context['tema']['id_admin'] == $ID_MEMBER || !empty($context['user']['is_admin']) ? true:false,
	      );   

		   if(isset($_REQUEST['idtema']) || !empty($context['tema']['id']) && !empty($context['tema']['borrador'])){
	        updateTema($TemaOptions, $posterOptions);
       }   
	     else{
	        createComunidadTema($TemaOptions, $posterOptions);
	     }
	     
	     // END FILTERS
	     
	     if(isset($_REQUEST['idtema'])){
	        redirectexit('action=comunidades;sa=tema-editado;idtema='.$idtema); // esto falta
	     }
	     else if(!empty($context['tema']['id']) && !empty($context['tema']['borrador'])){
		      redirectexit('action=comunidades;sa=tema-agregado;idtema='.$context['tema']['id']);
	     }
	     else{
		      redirectexit('action=comunidades;sa=tema-agregado;idtema='.$idtema);
		   }
  }

  // TEMA CREADO

  function tema_agregado(){
  	 global $txt, $db_prefix, $scripturl, $context, $temas;
	   
	   	 is_not_guest();
 
       //query of comunity temas
        getTemas('lista');

        $id_tema = (int)$_GET['idtema'];
        
       // Just some easy shortcuts.
		   $context['tema_nuevo'] = &$temas[$id_tema];

		   if(empty($context['tema_nuevo']['is_admin'])){
		      redirectexit('action=comunidades;sa=tema;idtema='.$context['tema_nuevo']['id']);
		   }
	     
       // sub_template = template_main()
        $context['sub_template']  = 'tema_agregado';	
        
	     // titulo de la seccion
	      $context['page_title'] = $txt['comunidades_tema_agregado'];
  }

  // DISPLAY TEMA
  
  function temaDisplay(){
  	 global $txt, $db_prefix, $scripturl, $context, $temas, $comunidades, $modSettings;
  	 global $txt, $db_prefix, $scripturl, $context, $comunidades, $miembros, $temas, $ID_MEMBER, $boards, $modSettings;
     global $pagAnterior, $pagActual, $pagTotal, $pagSiguiente, $solicitudes;

        $id_tema = (int)$_GET['idtema'];
  	 
       //query of comunity temas
        getTemas('lista');  

       // Just some easy shortcuts.
		   $context['tema'] = &$temas[$id_tema];
		           
       //query of comunity
        getComunidad('query');
                
       // Just some easy shortcuts.
		   $context['comunidad'] = &$comunidades[$context['tema']['id_comunidad']];
        
       if(!isset($context['tema']['id_comunidad']) || empty($context['tema']['id_comunidad'])){
		      redirectexit('action=comunidades');
		   }
		   else if(empty($context['comunidad'])){
		      fatal_error($txt['comunidades_no_exist'],false);
		   }
		   else if(!isset($id_tema) || empty($id_tema)){
		      redirectexit('action=comunidades');
		   }
		   else if(empty($context['tema'])){
		      fatal_error($txt['comunidades_fatal_error_idt'],false);
		   }
        
       // +1 twitter
       $context['user_twitter'] = $modSettings['user_twitter'];
       
       // ID APLICATION FACEBOOK
       $context['appID_FB'] = $modSettings['appID_FB'];
        
       getComunidadMembers('unlimited',$context['tema']['id_comunidad']);
       
		   $context['miembro'] = &$miembros[$ID_MEMBER];
		   
		   getComunidadSolicitud($context['tema']['id_comunidad']);
       
		   $context['solicituds'] = &$solicitudes[$ID_MEMBER];
		   
		   // si el miembro no lo has bloqueado vera todo
		   if(/*empty($context['miembro']['is_member']) ||*/ empty($context['miembro']['bloqueado']) && empty($context['solicituds']['bloqueado'])){
		   
		   if($context['comunidad']['privacity']['tipo']==1 && $context['user']['is_guest']){
		      fatal_error($txt['comunidades_register_c'],false);
		   }
		   
		   //filtro de vistas
		   switch($context['comunidad']['privacity']['tipo']){
		      case 0: 
		         $context['puedeverla'] = true;
		         $context['puedeverla_txt'] = '';
		      break;
		      case 1: 
		         $context['puedeverla'] = $context['user']['is_logged'] ? true:false;
		         $context['puedeverla_txt'] = 'dd';
		      break;
		      case 2:
		         $context['puedeverla'] = !empty($context['miembro']['is_member']) ? true:false;
		         $context['puedeverla_txt'] = '<div class="fleft info infofix">
		                                          '.$txt['comunidades_register_one'].'
		                                          <a onclick="$.Comunidades.unirse("", '.$context['comunidad']['id'].','.$context['comunidad']['rango'].')">
		                                             '.$txt['comunidades_registre_two'].'
		                                          </a>
		                                          '.$txt['comunidades_register_three'].'
		                                       </div>';
		      break;
		   }
		   
		   //obtenemos la subcategoria si existe sino pues ahorremos recurso :D
		   if(!empty($context['comunidad']['id_subcategoria']) && !empty($modSettings['subcategoriasTemas'])){
        getCategorias($context['comunidad']['id_categoria']);
		    $context['subcategoria'] = &$boards[$context['comunidad']['id_subcategoria']];
       }
		   
		   }
		   else{
		      $context['user']['bloqueado'] = '<div class="fleft error infofix">
		                                          '.$txt['comunidades_bloked_user'].': '.$context['miembro']['razon'].'
		                                       </div>';
		   }
       //visitas!
	     if(empty($_SESSION['visita']['tema'][$context['tema']['id']]) || $_SESSION['visita']['tema'][$context['tema']['id']] != $context['tema']['id']){
	        updateVisitas($context['tema']['id'], $context['tema']['id_admin'],2);
	     }
       // sub_template = template_main()
        $context['sub_template']  = 'Tema_Display';	
        
	     // titulo de la seccion
	      $context['page_title'] = $context['tema']['titulo'];
	     
       //seguidores
       im_follow($context['comunidad']['id'], $ID_MEMBER, 2);
       
       // votos
       ya_vote($context['tema']['id'], $ID_MEMBER);
       
       // comentarios
          
          $pages_for_comments = $modSettings['comentarios_temas'];
          
          if(empty($pages_for_comments))
             $pages_for_comments = 10;

          $_GET['start'] = (int)$_GET['start'];
          $context['paginacion'] = constructPageIndex($scripturl . '?action=comunidades;sa=tema;idtema='.$context['tema']['id'], $_GET['start'], $context['tema']['respuestas'], $pages_for_comments, false, array(
             'type' => 'advanced',
             'paginatorClass' => 'paginator moz-stack',
             'anchor' => 'all-comments',
             'varPage' => 'pagina',
             'contiguous_pages' => 10
          ), $getDataPaginator);

          $context['is_last_page'] = $getDataPaginator['is_last_page'];
          $context['last_page_href'] = $getDataPaginator['last_page_href'];
          $context['show_paginator'] = $getDataPaginator['counter'] > 1;
          
       if(!empty($context['tema']['respuestas'])){
          getAnswer('list',$context['tema']['id'],0,0,$_GET['start'],$pages_for_comments);
       }
       
  }

  
  // MIEMBROS DE LA COMUNIDAD
  
  function miembros(){
  	 global $txt, $db_prefix, $scripturl, $context, $miembros, $comunidades, $ID_MEMBER;
  	 
	     //Si no esta registrado
	   	 is_not_guest();

		   $id_comunidad = (int)$_GET['idco'];
		   $tipo = $_GET['tipo'];
		   
       //obtenemos info de la comunidad
       getComunidad('query');
       
       // Just some easy shortcuts.
		   $context['comunidad'] = &$comunidades[$id_comunidad];
		   
		   if(!isset($id_comunidad) || empty($id_comunidad)){
		      redirectexit('action=comunidades');
		   }
		   else if(empty($context['comunidad']['id'])){
		      fatal_error($txt['comunidades_no_exist'],false);
		   }
		   
        //obtenemos los miembros de la comunidad
       getComunidadMembers('todos', $id_comunidad);
		  
       //obtenemos los miembros de la comunidad
       getComunidadMembers($tipo,$id_comunidad);
       
		   $context['miembro'] = &$miembros[$ID_MEMBER];
	     
       // sub_template = template_main()
        $context['sub_template']  = 'miembros';	
        
	     // titulo de la seccion
	      $context['page_title'] = $txt['comunidades_members'];
  }
  
  //SUSPENSION DE MIEMBROS
  
  function suspender_causa(){
    global $context, $settings, $boardurl, $scripturl, $ID_MEMBER, $txt, $modSettings, $sourcedir, $func;
    global $context, $settings, $ID_MEMBER, $db_prefix, $scripturl, $boardurl, $modSettings, $miembros;
    	 
	     //Si no esta registrado
	   	 is_not_guest();
	   	 
   $id = !empty($_POST['id']) ? (int)$_POST['id']:0;
   
   if(!empty($id)){
   
   $body = '
     <div><textarea maxlength="200" id="causa_suspension" onkeyup="changed_val(this.value);" style="max-width:270px!important;min-width:270px!important;height:100px"></textarea></div>
     <script>
        sp_dialog.center();
        sp_dialog.endload(false, true);
        function changed_val(th){
           $(\'input[name=suspension_'.$id.']\').val(th);
        }
        
     </script>';
     
     die(json_encode(array('status' => 1, 'data' => $body, 'title' => $txt['comunidades_desc_causa'])));
     
      exit();
   }
   else{
	    redirectexit('action=comunidades');
   }
  }
  
  function miembros_suspender(){
    global $context, $settings, $boardurl, $scripturl, $ID_MEMBER, $txt, $modSettings, $sourcedir, $func;
    global $context, $settings, $ID_MEMBER, $db_prefix, $scripturl, $boardurl, $modSettings, $miembros;
     	 
	     //Si no esta registrado
	   	 is_not_guest();
	   	 
   $tipo = !empty($_POST['tipo']) ? (int)$_POST['tipo']:0;
   $user = !empty($_POST['id']) ? (int)$_POST['id']:0;
   $cmd = !empty($_POST['cmd']) ? (int)$_POST['cmd']:0;
   $admin = !empty($_POST['adm']) ? (int)$_POST['adm']:0;
   $causa = !empty($_POST['causa']) ? $_POST['causa']:' ';
   
   if(!empty($tipo) || !empty($user) || !empty($cmd) || !empty($admin) || !empty($causa)){
      switch($tipo){
         case '1': // para suspender
            $title = $txt['comunidades_suspend2'];
            $onc = '$.Comunidades.suspender('.$user.','.$cmd.',2);';
            $ban = '1';
         break;
         case '2': // para quitar suspension
            $title = $txt['comunidades_suspend'];
            $onc = '$.Comunidades.suspender_show('.$user.','.$cmd.',1);';
            $ban = '0';
         break;
      }
	 
   //empezamos a verificar el rango :D
       getComunidadMembers('todos',$cmd);
       
		   $context['miembro'] = &$miembros[$ID_MEMBER];
		   
		   // si es posteador o visitante
		   if(!empty($context['miembro']['posteador']) && !empty($context['miembro']['visitante'])){
          die(json_encode(array('status' => 0, 'data' => $txt['comunidades_error_range_admin'], 'title' => $txt['comunidades_error'])));
		   }
		   if($user == $admin){
          die(json_encode(array('status' => 0, 'data' => $txt['comunidades_error_no_blocked_is_admin'], 'title' => $txt['comunidades_error'])));
		   }
		   else{
		      // si es admin o moderador o el creador
		       if(allowedTo('moderate_forum') || !empty($context['miembro']['admin']) || !empty($context['miembro']['moderador']) or $context['miembro']['idmember'] == $admin){
  
		             if($_SESSION['stop_flood:suspension'] > time() - 15){
                    $timeout = $_SESSION['stop_flood:suspension'] - time() + 15;
                       die(json_encode(array('status' => 0, 'data' => $txt['comunidades_error_wait_minuts_suspend'])));
                 }
                 else{

		                    $der = db_query("UPDATE {$db_prefix}comunidades_miembros
                                     SET BAN = '$ban', Razon = '$causa'
                                     WHERE ID_COMUNIDAD = '$cmd'
                                     AND ID_MIEMBRO = '$user'
                                     ", __FILE__, __LINE__);
      
                    if(!empty($der)){
                      //creamos el antiflood
                       $_SESSION['stop_flood:suspension'] = time();
                       die(json_encode(array('status' => 1, 'data' => $txt['comunidades_change_exit'], 'title' => $txt['comunidades_change_congratulations'], 'titulo' => $title, 'id' => $onc)));
                    }
                    else{
                       die(json_encode(array('status' => 0, 'data' => $txt['comunidades_error_error_proccess'])));                 
                    }
                 }

		       }
		       else{
              die(json_encode(array('status' => 0, 'data' => $txt['comunidades_error_range_admin'], 'title' => $txt['comunidades_error'])));
		       }
		   }

      exit();
   }
   else{
	    redirectexit('action=comunidades');
   }

  }
   
   // UNIRSE A UNA COMUNIDAD
  function unirse(){
    global $context, $settings, $boardurl, $scripturl, $ID_MEMBER, $txt, $modSettings, $sourcedir, $func;
    global $context, $settings, $ID_MEMBER, $db_prefix, $scripturl, $boardurl, $modSettings, $miembros, $comunidades, $solicitudes;
     	 
	     //Si no esta registrado
	   	 is_not_guest();
	   	 
   $id_comunidad = !empty($_POST['id']) ? (int)$_POST['id']:0;
   $rango = !empty($_POST['rg']) ? (int)$_POST['rg']:0; // rango para el user
   $admin = !empty($_POST['adm']) ? (int)$_POST['adm']:0;
   
   if(!empty($id_comunidad) || !empty($rango) || !empty($admin)){

   // comprobamos si la comunidad existe
    getComunidad('query');
       
   // Just some easy shortcuts.
		$context['comunidad'] = &$comunidades[$id_comunidad];
		
		switch($context['comunidad']['validation']['tipo']){
		   case 1:
		      $aproved = '1';
		   break;
		   case 2:
		      $aproved = '0';
		   break;
		   case 3:
		      $aproved = '';
		   break;
		}
		
		if($context['comunidad']['id'] == $id_comunidad && !empty($context['comunidad']['id'])){
		
		   getComunidadSolicitud($id_comunidad);
		   getComunidadMembers('todos',$id_comunidad);
          
		   $context['miembro'] = &$miembros[$ID_MEMBER];
       
		   $context['solicitud'] = &$solicitudes[$ID_MEMBER];
		   
		   // si esta bloqueado: en solicitud y siendo miembro
		   if(!empty($context['solicitud']['bloqueado']) || !empty($context['miembro']['bloqueado'])){
		      die(json_encode(array('status' => 0, 'data' => $txt['comunidades_acces_restringido'], 'title' => $txt['comunidades_error'])));
		   } 
		   // si tiene solicitud
		   else if(!empty($context['solicitud']['idmember'])){
		      die(json_encode(array('status' => 0, 'data' => $txt['comunidades_solicitud_send2'], 'title' => $txt['comunidades_error'])));
		   }
		   // si es miembro
		   else if(!empty($context['miembro']['is_member'])){
		      die(json_encode(array('status' => 0, 'data' => $txt['comunidades_is_member'], 'title' => $txt['comunidades_error'])));
		   }
		   else if(!empty($context['comunidad']['validation']['tipo']) && $context['comunidad']['validation']['tipo'] ==3){
		      die(json_encode(array('status' => 0, 'data' => $txt['comunidades_validate_no'], 'title' => $txt['comunidades_error'])));
		   }
		   else{
		   
		      if($_SESSION['stop_flood:union'] > time() - 15){
             $timeout = $_SESSION['stop_flood:union'] - time() + 15;
             die(json_encode(array('status' => 0, 'data' => $txt['comunidades_error_wait_minuts_community'])));
          }
          else{
		      // agregamos al user
            updateMemberComunidad($id_comunidad,$ID_MEMBER,$rango,$aproved); // insert into member

          //creamos el antiflood
          $_SESSION['stop_flood:union'] = time();
          
          $notif = $aproved == 0 ? 'comunidad_userpendiente':'comunidad_usernuevo';
          // notifiquemos!
           $notifications = new notifications();
           $notifications->add($notif, array(
              'author' => $ID_MEMBER,
              'id' => $id_comunidad
           ));
          
           if($aproved == 0){
               
		           die(json_encode(array('status' => 1, 'tipo' => '2', 'title' => $txt['comunidades_solicitud_send'], 'data' => $txt['comunidades_solicitud_send_desc'], 'set' => true)));
		        }
		        else{
		           die(json_encode(array('status' => 1, 'tipo' => '1', 'set' => true)));
		        }
          }
		   }
		}
		else{
		   die(json_encode(array('status' => 0, 'data' => $txt['comunidades_no_exist'], 'title' => $txt['comunidades_error'])));
		}
    
    exit();
   }
   else{
	    redirectexit('action=comunidades');
   }

  }
 
   // UNIRSE A UNA COMUNIDAD
  function abandonar(){
    global $context, $settings, $boardurl, $scripturl, $ID_MEMBER, $txt, $modSettings, $sourcedir, $func;
    global $context, $settings, $ID_MEMBER, $db_prefix, $scripturl, $boardurl, $modSettings, $miembros, $comunidades, $solicitudes;
     	 
	     //Si no esta registrado
	   	 is_not_guest();
	   	 
   $id_comunidad = !empty($_POST['id']) ? (int)$_POST['id']:0;
   $rango = !empty($_POST['rg']) ? (int)$_POST['rg']:0; // rango que tiene el user
   $admin = !empty($_POST['adm']) ? (int)$_POST['adm']:0;
   
   if(!empty($id_comunidad) || !empty($rango) || !empty($admin)){

   // comprobamos si la comunidad existe
    getComunidad('query');
       
   // Just some easy shortcuts.
		$context['comunidad'] = &$comunidades[$id_comunidad];
		
		if($context['comunidad']['id'] == $id_comunidad && !empty($context['comunidad']['id'])){
		   
		   getComunidadMembers('unlimited',$id_comunidad);
          
		   $context['miembro'] = &$miembros[$ID_MEMBER];
		   
		   //sino e smiembro sale error
		   if(empty($context['miembro']['is_member'])){
		      die(json_encode(array('status' => 0, 'data' => $txt['comunidades_no_be_member'], 'title' => $txt['comunidades_error'], 'tipo' => '1', 'set' => true)));
		   }
		   // si es miembro se elimina bajo su peticion u.u
		   else if(!empty($context['miembro']['is_member'])){
		   		
		   		if($_SESSION['stop_flood:abandonar'] > time() - 15){
             $timeout = $_SESSION['stop_flood:abandonar'] - time() + 15;
             die(json_encode(array('status' => 0, 'data' => $txt['comunidades_error_wait_minuts_aband'])));
          }
          else{
		         deleteMemberComunidad($id_comunidad,$ID_MEMBER,$rango,$context['comunidad']['popularidad'],$context['comunidad']['miembros'], 1);
          
             //creamos el antiflood
             $_SESSION['stop_flood:abandonar'] = time();
          
		         die(json_encode(array('status' => 1, 'tipo' => '1', 'set' => true)));
          }
		   }
		   else{
		      die(json_encode(array('status' => 0, 'data' => $txt['comunidades_error_undefined'], 'title' => $txt['comunidades_error'])));
		   }
		}
		else{
		   die(json_encode(array('status' => 0, 'data' => $txt['comunidades_no_exist'], 'title' => $txt['comunidades_error'])));
		}
    
    exit();
   }
   else{
	    redirectexit('action=comunidades');
   }

  }
  
   //CANCELAR SOLICITUD
   
   function cancelar_solicitud(){
    global $context, $settings, $boardurl, $scripturl, $ID_MEMBER, $txt, $modSettings, $sourcedir, $func;
    global $context, $settings, $ID_MEMBER, $db_prefix, $scripturl, $boardurl, $modSettings, $miembros, $comunidades, $solicitudes;
     	 
	     //Si no esta registrado
	   	 is_not_guest();
	   	 
   $id_comunidad = !empty($_POST['id']) ? (int)$_POST['id']:0;
   $rango = !empty($_POST['rg']) ? (int)$_POST['rg']:0; // rango que tiene el user
   $admin = !empty($_POST['adm']) ? (int)$_POST['adm']:0;
   
   if(!empty($id_comunidad) || !empty($rango) || !empty($admin) || !empty($ID_MEMBER)){

   // comprobamos si la comunidad existe
    getComunidad('query');
       
   // Just some easy shortcuts.
		$context['comunidad'] = &$comunidades[$id_comunidad];
		
		if($context['comunidad']['id'] == $id_comunidad && !empty($context['comunidad']['id'])){

		   getComunidadSolicitud($id_comunidad);
		   
		   getComunidadMembers('unlimited',$id_comunidad);
          
		   $context['miembro'] = &$miembros[$ID_MEMBER];
       
		   $context['solicitud'] = &$solicitudes[$ID_MEMBER];

		   // si no es miembro te sale error
		   if(empty($context['miembro']['is_member']) && !empty($context['miembro']['insolicitud'])){
		      die(json_encode(array('status' => 0, 'data' => $txt['comunidades_no_be_member'], 'title' => $txt['comunidades_error'], 'tipo' => '1', 'set' => true)));
		   }
		   // si es miembro te sale error
		   if(!empty($context['miembro']['is_member'])){
		      die(json_encode(array('status' => 0, 'data' => $txt['comunidades_solicitud_acept_for_admin'], 'title' => $txt['comunidades_error'])));
		   }
		   // si tiene solicitud se le mostrara que sera eliminada
		   else if(!empty($context['solicitud']['idmember'])){
		   		
		   		if($_SESSION['stop_flood:cancel_solicitud'] > time() - 15){
             $timeout = $_SESSION['stop_flood:cancel_solicitud'] - time() + 15;
             die(json_encode(array('status' => 0, 'data' => $txt['comunidades_error_wait_minuts_cancel_solicitud'])));
          }
          else{
		         deleteMemberComunidad($id_comunidad,$ID_MEMBER,$rango,$context['comunidad']['popularidad'],$context['comunidad']['miembros'], 0);
          
             //creamos el antiflood
             $_SESSION['stop_flood:cancel_solicitud'] = time();
          
		         die(json_encode(array('status' => 1, 'tipo' => '1', 'set' => true)));
          }
		   }
		   else{
		      die(json_encode(array('status' => 0, 'data' => $txt['comunidades_error_undefined'], 'title' => $txt['comunidades_error'])));
		   } 
		}
		else{
		   die(json_encode(array('status' => 0, 'data' => $txt['comunidades_no_exist'], 'title' => $txt['comunidades_error'])));
		}
    
    exit();
   }
   else{
	    redirectexit('action=comunidades');
   }

  }

   // AGREGAR BORRADOR
   
   function borradores_agregar(){
    global $context, $settings, $boardurl, $scripturl, $ID_MEMBER, $txt, $modSettings, $sourcedir, $func, $db_prefix, $boardurl, $user_info, $idtema, $temas;
    
       // presets
       $TemaOptions = array(
	         'titulo' => $_POST['titulo'],
	         'cuerpo' => $_POST['cuerpo'],
	         'comunidad' => (int)$_POST['comunidad'],
	         'siguiendo' => !empty($_POST['follow']) ? 1:0,
	         'cerrado' => $_POST['sin_comentarios'],
	         'sticky' => $_POST['sticky'],
	         'categoria' => $_POST['categoria'],
	         'categoria2' => $_POST['subcategoria'],
	         'borrador' => $_POST['borrador_id'],
	     );	  
	         
	     $posterOptions = array(
		       'id' => $ID_MEMBER
	      );
           
       if(!empty($TemaOptions['comunidad']) || !empty($ID_MEMBER)){

		      if(!empty($TemaOptions['borrador'])){
		         //query of comunity temas
              getTemas('lista',$TemaOptions['comunidad'],1);
           
             // Just some easy shortcuts.
		          $context['tema'] = &$temas[$TemaOptions['borrador']];
		      }
		      
		      if($_SESSION['stop_flood:save_eraser'] > time() - 15){
             $timeout = $_SESSION['stop_flood:save_eraser'] - time() + 15;
             die(json_encode(array('status' => 0, 'data' => $txt['comunidades_error_wait_minuts_eraser'])));
          }
          else if(!empty($context['tema']['id']) && empty($context['tema']['borrador'])){
		         die(json_encode(array('status' => 0, 'data' => '<b style="color:red">'.$txt['comunidades_error_them_post'].'</b>')));
          }   
          else if(empty($TemaOptions['comunidad'])){
		         die(json_encode(array('status' => 0, 'data' => '<b style="color:red">'.$txt['comunidades_is_required_name'].'</b>')));
          }
          else if(empty($TemaOptions['titulo']) || $TemaOptions['titulo'] == '' || $func['htmltrim']($TemaOptions['titulo']) === ''){
		         die(json_encode(array('status' => 0, 'data' => '<b style="color:red">'.$txt['comunidades_is_required_title'].'</b>')));
          }
          else if(empty($TemaOptions['cuerpo']) || $TemaOptions['cuerpo'] == '' || $func['htmltrim']($TemaOptions['cuerpo']) === ''){
		         die(json_encode(array('status' => 0, 'data' => '<b style="color:red">'.$txt['comunidades_is_required_body'].'</b>')));
          }// You are not!
          else if (isset($TemaOptions['cuerpo']) && strtolower($TemaOptions['cuerpo']) == 'i am the administrator.' && !$user_info['is_admin']){
		         die(json_encode(array('status' => 0, 'data' => '<b>Knave! Masquerader! Charlatan!</b>')));
          }
          
          // are you serius?
          $enemy = array('phpost', 'php0st');
          $uncensured_enemy = (censorText($enemy[0]) == 'phpost' && censorText($enemy[1]) == 'php0st');
          if($uncensured_enemy){
             if(isset($TemaOptions['cuerpo']) && preg_match('~(php(0|o)st)(\.net|)?~i', trim($TemaOptions['cuerpo'])) === 1){
                $TemaOptions['cuerpo'] = str_replace($enemy, 'spirate', $TemaOptions['cuerpo']);
             }
          }
          
          if(!empty($follow)){
          // falta crear seguidores
          }
          //empezamos a crear
	        save_borrador($TemaOptions, $posterOptions);
	        
	        if(!empty($idtema)){
	           $_SESSION['stop_flood:save_eraser'] = time();
		         die(json_encode(array('status' => 1, 'data' => $idtema)));
	        }
	        else{
		         die(json_encode(array('status' => 0, 'data' => '<b style="color:red">'.$txt['comunidades_error_undefined'])));
	        }
       }
       else{
	        redirectexit('action=comunidades');
       } 
       
       exit();
   }

   // GUARDAR BORRADOR
   
   function borradores_guardar(){
    global $context, $settings, $boardurl, $scripturl, $temas, $ID_MEMBER, $txt, $idtema, $modSettings, $sourcedir, $func, $db_prefix, $boardurl;

       // presets
       $TemaOptions = array(
	         'titulo' => $_POST['titulo'],
	         'cuerpo' => $_POST['cuerpo'],
	         'comunidad' => (int)$_POST['comunidad'],
	         'siguiendo' => !empty($_POST['follow']) ? 1:0,
	         'cerrado' => $_POST['sin_comentarios'],
	         'sticky' => $_POST['sticky'],
	         'categoria' => $_POST['categoria'],
	         'categoria2' => $_POST['subcategoria'],
	         'borrador' => $_POST['borrador_id'],
	     );	  
	         
	     $posterOptions = array(
		       'id' => $ID_MEMBER
	      );
	     
	     if(!empty($TemaOptions['comunidad']) || !empty($ID_MEMBER)){
	     
	        //verificamos si ya fue publicado
	      		      
		      if(!empty($TemaOptions['borrador'])){
		         //query of comunity temas
              getTemas('lista',$TemaOptions['comunidad'],1);
           
             // Just some easy shortcuts.
		          $context['tema'] = &$temas[$TemaOptions['borrador']];
		      }
          
	      	if($_SESSION['stop_flood:save_eraser2'] > time() - 15){
             $timeout = $_SESSION['stop_flood:save_eraser2'] - time() + 15;
             die(json_encode(array('status' => 0, 'data' => $txt['comunidades_error_wait_minuts_eraser'])));
          }
	        else if(empty($TemaOptions['comunidad'])){
		         die(json_encode(array('status' => 0, 'data' => '<b style="color:red">'.$txt['comunidades_no_exist'].'</b>')));
          }
	        if(empty($TemaOptions['borrador'])){
		         die(json_encode(array('status' => 0, 'data' => '<b style="color:red">'.$txt['comunidades_fatal_error_idt'].'</b>')));
          }
          else if($context['tema']['eraser'] == 0){
		           die(json_encode(array('status' => 0, 'data' => '<b style="color:red">'.$txt['comunidades_error_them_post'].'</b>')));
          }   
          else{

	           updateTemaBorrador($TemaOptions, $posterOptions);
       	  
       	     if(!empty($idtema)){
                $_SESSION['stop_flood:save_eraser2'] = time();
		            die(json_encode(array('status' => 1, 'data' => $idtema)));
	           }
	           else{
		            die(json_encode(array('status' => 0, 'data' => '<b style="color:red">'.$txt['comunidades_error_undefined'])));
	           }
          }
       }
       else{
	        redirectexit('action=comunidades');
       } 
       
       exit();
   }

   // SEGUIR COMUNIDAD TEMA
   
   function follows(){
    global $context, $settings, $boardurl, $scripturl, $temas, $ID_MEMBER, $txt, $idtema, $modSettings, $sourcedir, $func, $db_prefix, $boardurl, $comunidades;

       // presets
	      $Options = array(
	         'id' => $_POST['id'],
	         'type' => empty($_POST['type']) ? '': ($_POST['type']== 1 ?'comunidad_follow':'tema_follow'),
	         'time' => time(),
	         'me' => $ID_MEMBER,
	      );
	      
	      if(!empty($Options['id']) || !empty($Options['type'])){
	      	     
	         // tema o comunidad
	         switch($Options['type']){
	            case 'comunidad_follow':
	               // verificamos si existe la comunidad
                  getComunidad('query');
                 // Just some easy shortcuts.
		              $context['verify'] = &$comunidades[$Options['id']];
		              $type = '2';
	            break;
	            case 'tema_follow':
		              $type = '3';
	               // verificamos si existe el tema
	            break;
	         }
		       im_follow($Options['id'], $Options['me'], $type);
          
		      if($_SESSION['stop_flood:follows_comunidad'] > time() - 15){
             $timeout = $_SESSION['stop_flood:follows_comunidad'] - time() + 15;
             die(json_encode(array('status' => 0, 'data' => $txt['comunidades_error_wait_minuts_follow_comunidad'])));
          }
          
	         if(empty($Options['me'])){
	            die(json_encode(array('status' => 0, 'data' => $txt['comunidades_require_logged'])));
		       }
		       
		       if(empty($context['verify'])){
	            die(json_encode(array('status' => 0, 'data' => $txt['comunidades_error_no_id_valid'].' '.$Options['id'].' : '.$context['verify'])));
			     }
		
		       if(!empty($context['siguiendo'])){
	            die(json_encode(array('status' => 0, 'data' => $txt['comunidades_error_already_follow_comunidad'])));
	         }
		       insert_followers($Options['id'], $Options['me'], $type, $Options['time']);
		       
		       updateFollowsCount($Options['id'], $type, '+');
		       
           $_SESSION['stop_flood:follows_comunidad'] = time(); 
           
          // notifiquemos!
           $notifications = new notifications();
           $notifications->add($Options['type'], array(
              'author' => $Options['me'],
              'id' => $Options['id']
           ));
            
	         die(json_encode(array('status' => 1)));
       }
       else{
	        redirectexit('action=comunidades');
       } 
       exit();
   }

   // NO SEGUIR COMUNIDAD TEMA
   
   function nofollows(){
    global $context, $settings, $boardurl, $scripturl, $temas, $ID_MEMBER, $txt, $idtema, $modSettings, $sourcedir, $func, $db_prefix, $boardurl, $comunidades;

      // presets
	      $Options = array(
	         'id' => $_POST['id'],
	         'type' => empty($_POST['type']) ? '': ($_POST['type']== 1 ?'comunidad':'tema'),
	         'time' => time(),
	         'me' => $ID_MEMBER,
	      );
	      
	      if(!empty($Options['id']) || !empty($Options['type'])){
	      	     
	         // tema o comunidad
	         switch($Options['type']){
	            case 'comunidad':
	               // verificamos si existe la comunidad
                  getComunidad('query');
                 // Just some easy shortcuts.
		              $context['verify'] = &$comunidades[$Options['id']];
		              $type = '2';
	            break;
	            case 'tema':
		              $type = '3';
	               // verificamos si existe el tema
	            break;
	         }
	         
		       im_follow($Options['id'], $Options['me'], $type);
          
		       if($_SESSION['stop_flood:nofollows_comunidad'] > time() - 15){
              $timeout = $_SESSION['stop_flood:nofollows_comunidad'] - time() + 15;
              die(json_encode(array('status' => 0, 'data' => $txt['comunidades_error_wait_minuts_nofollow_comunidad'])));
           }	
             
	         if(empty($Options['me'])){
	            die(json_encode(array('status' => 0, 'data' => $txt['comunidades_require_logged'])));
		       }
		       
		       if(empty($context['verify'])){
	            die(json_encode(array('status' => 0, 'data' => $txt['comunidades_error_no_id_valid'])));
			     }
		
		       if(empty($context['siguiendo'])){
	            die(json_encode(array('status' => 0, 'data' => $txt['comunidades_error_not_follow_comunidad'])));
	         }
		       
		       delete_followers($Options['id'], $Options['me'], $type);
		       
           $_SESSION['stop_flood:nofollows_comunidad'] = time(); 
           
		       updateFollowsCount($Options['id'], $type, '-');
                  
	         die(json_encode(array('status' => 1)));
       }
       else{
	        redirectexit('action=comunidades');
       }
       
       exit();
   }

   // VOTAR EN UN TEMA
   
   function votos(){
    global $context, $settings, $boardurl, $scripturl, $temas, $ID_MEMBER, $txt, $idtema, $modSettings, $sourcedir, $func, $db_prefix, $boardurl, $comunidades;

      // presets
	      $OptionsV = array(
	         'voto' => $_POST['voto'],
	         'voto_type' => $_POST['voto']== 1 ? '1':'2',
	         'idtema' => (int)$_POST['idtema'],
	         'user' => $_POST['user'],
	         'comunidad' => $_POST['comunidad'],
	      );
	      
	      
	      if(!empty($OptionsV['voto']) && $OptionsV['voto'] != '' && !empty($OptionsV['idtema']) && $OptionsV['user'] == $ID_MEMBER && !empty($OptionsV['user'])){
	         // verificamos que el tema exista
	          getTemas('all',$OptionsV['comunidad']);
	          
	          $context['tema'] = &$temas[$OptionsV['idtema']];
	          
	          im_follow($OptionsV['idtema'], $context['tema']['id_admin'], 2); // verificar si lo sigue el admin
	          
		        ya_vote($context['tema']['id'], $OptionsV['user']/*, $OptionsV['voto_type']*/);
	          	          
		        if($_SESSION['stop_flood:votos_tema'] > time() - 15){
               $timeout = $_SESSION['stop_flood:votos_tema'] - time() + 15;
               die(json_encode(array('status' => 0, 'data' => $txt['comunidades_error_wait_minuts_votar_tema'])));
            }
           
	          if($context['tema']['id_admin'] == $ID_MEMBER){
	             die(json_encode(array('status' => 0, 'data' => $txt['comunidades_error_no_votos_me'])));
	          }		       		       

	          if(empty($context['tema'])){
	             die(json_encode(array('status' => 0, 'data' => $txt['comunidades_error_no_id_valid'])));
			      }
			      			      
			      if(!empty($context['voto_id']) && $OptionsV['voto_type'] == $context['voto_type']){ // el voto existe del mismo tipo
	             die(json_encode(array('status' => 0, 'data' => $txt['comunidades_error_dont_cant_votos'])));
			      }
			      if(!empty($context['voto_id']) && $OptionsV['voto_type'] != $context['voto_type']){ // el voto existe pero no es igual se updatea :D
	            update_votos($OptionsV['idtema'], $OptionsV['user'], $OptionsV['voto_type']);

              $_SESSION['stop_flood:votos_tema'] = time();
	             die(json_encode(array('status' => 1)));
			      }
			      if(empty($context['voto_id'])){ // el voto no existe pero se crea ^^
	            insert_votos($OptionsV['idtema'], $OptionsV['user'], $OptionsV['voto_type']);
              $_SESSION['stop_flood:votos_tema'] = time();
              
              if(!empty($context['siguiendo'])){ // aun no sirve u.u
              // notificamos al admin si esta siguiendolo
              $name_tipe = $OptionsV['voto_type'] == 1 ? 'tema_like':'tema_nolike';
              
              $notifications->add($name_tipe, array(
                  'author' => $Options['user'],
                  'id' => $Options['tema']
               ));
              }
	             die(json_encode(array('status' => 1)));
			      }
			      
       }
       else{
	        redirectexit('action=comunidades');
       }
       
       exit();
   }

   // agregar tema a favoritos
   function favoritos(){
      global $txt, $context, $scripturl, $db_prefix, $settings, $modSettings, $ID_MEMBER, $sourcedir;
         
          // presets
	      $Options = array(
	         'tema' => $_POST['idtema'],
	         'autor' => $_POST['autor'],
	         'comunidad' => $_POST['id'],
	      );
   
      if(!empty($Options['comunidad']) && !empty($Options['tema']) && !empty($Options['autor']) && !empty($ID_MEMBER)){
      
         $notifications = new notifications();
         
         //verificar si ya esta en los favoritos
         im_add_bookmark($Options['tema'], $ID_MEMBER);

         if($_SESSION['stop_flood:favorito_tema'] > time() - 15){
            $timeout = $_SESSION['stop_flood:favorito_tema'] - time() + 15;
            die(json_encode(array('status' => 0, 'data' => $txt['comunidades_error_wait_minuts_bookmark'])));
         }
         if(!empty($context['agregado_bookmark'])){
	          die(json_encode(array('status' => 0, 'data' => $txt['comunidades_error_already_bookmark'])));
         }
         
         if($Options['autor'] == $ID_MEMBER){
	          die(json_encode(array('status' => 0, 'data' => $txt['comunidades_error_dont_cant_bookmark'])));
         }
         
         //empezamos el insert
            $result = db_query("INSERT INTO {$db_prefix}bookmarks (ID_MEMBER, ID_TOPIC, type, time)
                        VALUES ('$ID_MEMBER', '$Options[tema]', '3', '".time()."')", __FILE__, __LINE__);
         
         	  $id_last_insert = mysql_insert_id();
            
            if(!empty($id_last_insert)){
              $_SESSION['stop_flood:favorito_tema'] = time();
               
               // update count in temas
                updateComunidadTemas($Options['comunidad'], 'tema', $Options['tema'], 1);
	             
	             $notifications->add('tema_bookmark', array(
                  'author' => $ID_MEMBER,
                  'id' => $Options['tema']
               ));
               
	             die(json_encode(array('status' => 1, 'data' => $txt['comunidades_add_ok'])));
            
            }else{
	             die(json_encode(array('status' => 0, 'data' => $txt['comunidades_error_undefined'])));
            }
      }
      else{
	       redirectexit('action=comunidades');
      }
       
      exit();
   }

   // comentar un tema :F
   function comentar(){
    global $txt, $context, $scripturl, $db_prefix, $settings, $modSettings, $ID_MEMBER, $no_avatar, $func, $boarddir, $sourcedir, $temas, $user_info;
         
          // presets
	      $Options = array(
	         'tema' => (int)$_POST['idtema'],
	         'comunidad' => (int)$_POST['idcomunidad'],
	         'autor' => $ID_MEMBER,
	         'comentario' => $func['htmlspecialchars']($_POST['comentario'], ENT_QUOTES, 'UTF-8'),
	         'show_answer' => $_POST['show_answer'],
	      );
	      
	      
      if(!empty($Options['tema']) && !empty($Options['autor']) && !empty($ID_MEMBER)){

        if(is_real_empty($Options['comentario']) || $Options['comentario'] == 'undefined'){
            die(json_encode(array('status' => 0, 'data' => $txt['comunidades_error_textaerea_empty'])));
        }
        
        if($_SESSION['stop_flood:answer'] > time() - 15){
            $timeout = $_SESSION['stop_flood:answer'] - time() + 15;
            die(json_encode(array('status' => 0, 'type' => 'timeout', 'timeout' => $timeout, 'data' => $txt['comunidades_error_wait_minuts'])));
        }
		
	      $fecha = time();
	      
	      //verificamos la existencia del tema
	      getTemas('lista', $Options['comunidad']);
	      
	      $context['tema'] = &$temas[$Options['tema']];
	      
	      if(empty($context['tema']['id'])){
	         die(json_encode(array('status' => 0, 'data' => $txt['comunidades_error_no_id_valid'])));
			  }
			  
        // usuario inexistente?
        $request = db_query("SELECT memberName, realName, avatar, avatar_coords FROM {$db_prefix}members WHERE ID_MEMBER = $ID_MEMBER LIMIT 1",__FILE__,__LINE__);
        list($memberName, $realName, $avatar, $avatar_coords) = mysql_fetch_row($request);

        if(mysql_num_rows($request)==0)
	         die(json_encode(array('status' => 0, 'data' => $txt['comunidades_error_invalid_user'])));

        mysql_free_result($request);
                
        list($ID_BOARD) = mysql_fetch_row($request);
        mysql_free_result($request);
        

        $allow_comments = allowedTo('moderate_forum') || empty($context['tema']['cerrado']) || $ID_MEMBER == $context['tema']['id_admin'];

        if(!$allow_comments){
	          die(json_encode(array('status' => 0, 'type' => 'locked', 'data' => $txt['comunidades_error_no_comment_in_them'])));
        }
        
        // You are not!
	      if (isset($Options['comentario']) && strtolower($Options['comentario']) == 'i am the administrator.' && !$user_info['is_admin'])
		       fatal_error('Knave! Masquerader! Charlatan!', false);
        
        // are you serius?
        $enemy = array('phpost', 'php0st');
        $uncensured_enemy = (censorText($enemy[0]) == 'phpost' && censorText($enemy[1]) == 'php0st');
        if($uncensured_enemy)
            if (isset($Options['comentario']) && preg_match('~(php(0|o)st)(\.net|)?~i', trim($Options['comentario'])) === 1)
                    $Options['comentario'] = str_replace($enemy, 'spirate', $Options['comentario']);
                    
       
	      db_query("INSERT INTO {$db_prefix}comunidades_comentarios (ID_COMUNIDAD, ID_TEMA, cuerpo, ID_MEMBER_STARTED, fecha)
           VALUES ('$Options[comunidad]', '$Options[tema]', '$Options[comentario]', '$Options[autor]','$fecha')",__FILE__,__LINE__);
        
        $last_id = mysql_insert_id();
        
        if(empty($last_id)){  
	          die(json_encode(array('status' => 0, 'data' => $txt['comunidades_error_error_proccess'])));
	      }else{
            $_SESSION['stop_flood:answer'] = time();
        }
        
        $r = db_query("SELECT cuerpo, ID_MEMBER_STARTED FROM {$db_prefix}comunidades_comentarios WHERE ID_C = $last_id AND ID_TEMA = $Options[tema]",__FILE__,__LINE__);
        list($Tempcomentario, $tempAutorCom) = mysql_fetch_row($r);
        mysql_free_result($r);

        // eh! agregame uno mas a la lista :)
        db_query("UPDATE {$db_prefix}comunidades_temas
                  SET respuestas = respuestas + 1
                  WHERE ID_TEMA = $Options[tema]",__FILE__,__LINE__);
                  
        updateStats('respuestas');
        /*
        db_query("UPDATE {$db_prefix}members
                  SET comments = comments + 1
                  WHERE ID_MEMBER = $ID_MEMBER",__FILE__,__LINE__);*/

        // el cache debe actualizarse!
        require_once($sourcedir . '/classes/cache_class/cache.php');
        $cache = Cache::load('file', array('dir' => $boarddir . '/cache/'));
        
        if(($getCacheComments = $cache->get('recent::lastAnswer', $expire, true)) !== cache::NOT_FOUND){

                if(count($getCacheComments) >= 15)
                    array_pop($getCacheComments);
                
                array_unshift($getCacheComments, array(
                    'id_comment' => $last_id,
                    'titulo' => $context['tema']['titulo'],
                    'ID_TEMA' => $Options['tema'],
                    'memberName' => $memberName,
                    'realName' => $realName,
                ));
                
                $cache->set('recent::lastAnswer', $getCacheComments, 60*30);
        }
        
        // notifiquemos!
        $notifications = new notifications();
        $notifications->add('answer', array(
            'author' => $ID_MEMBER,
            'id' => $Options['tema']
        ));
        
        $avatar_coords = makeAvatarCoords($avatar_coords);
        $avatar_coords = $avatar_coords[48]['style'];

        $templateData = array(
            'avatar' => !empty($avatar) ? $avatar : $no_avatar,
            'avatar_coords' => $avatar_coords,
            'nick' => $context['user']['name'],
            'comment' => parse_bbc($Tempcomentario),
            'comment2' => $Tempcomentario,
            'id_member' => $ID_MEMBER,
            'time' => hace($fecha),
            'id_comment' => $last_id,
            'type_comment' => ' ' . ($tempAutorCom == $context['tema']['id_admin'] ? ' author' : ' own')
        );

        if($Options['show_answer']){
            die(json_encode(array('gotolast' => true, 'templ' => $txt['comunidades_comment_add_ok'], 'txt_gotolast' => $txt['comunidades_last_page'])));
        }
        
        die(json_encode($templateData));
        }
      else{
	       redirectexit('action=comunidades');
      }
       
      exit();
   }
   
   function edite_answer(){
    global $context, $settings, $boardurl, $scripturl, $ID_MEMBER, $txt, $modSettings, $sourcedir, $func;
    global $context, $settings, $ID_MEMBER, $db_prefix, $scripturl, $boardurl, $modSettings, $miembros, $temas, $answers;
    	 
	     // presets
	      $Options = array(
	         'tema' => (int)$_POST['idtema'],
	         'comunidad' => (int)$_POST['idcomunidad'],
	         'autor' => $_POST['mid'],
	         'idcomentario' => $_POST['cid'],
	      );
   
   if(!empty($Options['tema']) || !empty($ID_MEMBER)){
      
      if(!allowedTo('moderate_forum')){
	          die(json_encode(array('status' => 0, 'data' => $txt['comunidades_error_range_admin'])));
      }
      
      if(empty($Options['comunidad'])){
	          die(json_encode(array('status' => 0, 'data' => $txt['comunidades_error_error_proccess'])));
      }
      
      // VERIFICAR QUE TODO EXISTA!
       getTemas('lista', $Options['comunidad']);
       
       $context['tema'] = &$temas[$Options['tema']];
      
      if(empty($context['tema']['id'])){
	          die(json_encode(array('status' => 0, 'data' => $txt['comunidades_fatal_error_idt'])));
      }
      
      if(empty($context['tema']['id_comunidad'])){
	          die(json_encode(array('status' => 0, 'data' => $txt['comunidades_fatal_error_id'])));
      }
      // obtenemos el comentario
       getAnswer('user', $context['tema']['id'], $Options['autor']);
       
       $context['answer'] = &$answers[$Options['idcomentario']];
       
      $body = '<div>
                  <textarea id="edite_answer" onkeyup="$.Comunidades.changed_val_edicion(this.value, '.$Options['autor'].');" style="max-width:400px!important;min-width:400px!important;height:100px">'.$context['answer']['comentario']['source'].'</textarea>
               </div>';
     
     die(json_encode(array('status' => 1, 'data' => $body, 'title' => $txt['comunidades_edite_comment'])));
     
      exit();
   }
   else{
	    redirectexit('action=comunidades');
   }
  }

  function save_answer(){
    global $context, $settings, $boardurl, $scripturl, $ID_MEMBER, $txt, $modSettings, $sourcedir, $func;
    global $context, $settings, $ID_MEMBER, $db_prefix, $scripturl, $boardurl, $modSettings, $miembros, $temas, $answers;
       	 
	     // presets
	      $Options = array(
	         'tema' => (int)$_POST['idtema'],
	         'comunidad' => (int)$_POST['idcomunidad'],
	         'autor' => $_POST['mid'],
	         'idcomentario' => $_POST['cid'],
	         'comentario' => $_POST['answer'],
	      );
   
   if(!empty($Options['tema']) || !empty($ID_MEMBER)){
      
      if($_SESSION['stop_flood:save_answer'] > time() - 15){
         die(json_encode(array('status' => 0, 'data' => $txt['comunidades_error_wait_minuts_suspend'], 'title' => $txt['comunidades_error'])));
      }
      
      if(!allowedTo('moderate_forum')){
	          die(json_encode(array('status' => 0, 'data' => $txt['comunidades_error_range_admin'], 'title' => $txt['comunidades_error'])));
      }
      
      if(empty($Options['comunidad'])){
	          die(json_encode(array('status' => 0, 'data' => $txt['comunidades_error_error_proccess'], 'title' => $txt['comunidades_error'])));
      }
      
      // VERIFICAR QUE TODO EXISTA!
       getTemas('lista', $Options['comunidad']);
       
       $context['tema'] = &$temas[$Options['tema']];
      
      if(empty($context['tema']['id'])){
	          die(json_encode(array('status' => 0, 'data' => $txt['comunidades_fatal_error_idt'], 'title' => $txt['comunidades_error'])));
      }
      
      if(empty($context['tema']['id_comunidad'])){
	          die(json_encode(array('status' => 0, 'data' => $txt['comunidades_fatal_error_id'], 'title' => $txt['comunidades_error'])));
      }
      // obtenemos el comentario
       getAnswer('user', $context['tema']['id'], $Options['autor']);
       
       $context['answer'] = &$answers[$Options['idcomentario']];
       
       if($context['answer']['comentario']['bbc'] != $Options['comentario']){
              
		   $der = db_query("UPDATE {$db_prefix}comunidades_comentarios
                                     SET cuerpo = '$Options[comentario]', ID_MEMBER_UPDATED = '$ID_MEMBER'
                                     WHERE ID_TEMA = '$Options[tema]'
                                     AND ID_MEMBER_STARTED = '$Options[autor]'
                                     AND ID_C = '$Options[idcomentario]'
                                     ", __FILE__, __LINE__);
      
          if(!empty($der)){
             //creamos el antiflood
              $_SESSION['stop_flood:save_answer'] = time();
                  die(json_encode(array('status' => 1, 'data' => parse_bbc($Options['comentario']), 'source' => $Options['comentario'])));
          }
          else{
              die(json_encode(array('status' => 0, 'data' => $txt['comunidades_error_error_proccess'], 'title' => $txt['comunidades_error'])));                 
          }
       }else{
       
       }

     
      exit();
   }
   else{
	    redirectexit('action=comunidades');
   }
  }

  function reload_answer(){
    global $context, $settings, $boardurl, $scripturl, $ID_MEMBER, $txt, $modSettings, $sourcedir, $func;
    global $context, $settings, $ID_MEMBER, $db_prefix, $scripturl, $boardurl, $modSettings, $miembros, $temas, $answers;
       	 
   $type = $_POST['type'];
   $id_comunidad = $_POST['idcomunidad'];
       	 
   if(!empty($type)){
   
      if(!empty($id_comunidad) && $type == 2){
         getAnswer('list',0,0,$id_comunidad);
         $name = 'list';
      }else if($type == 1){
         getAnswer('recent');
         $name = 'recent';
      }
      
      echo'1: ';
          if(empty($context[$name]['count'])){
             echo'<div class="error">'.$txt['comunidades_empty_answers'].'</div>';
          }else{
             foreach($context['respuestas'][$name] as $comments){
             if($type == 1){
             echo'<li>
                     <span class="subinfo">
                        <a href="'.$scripturl.'?action=profile;u='.$comments['autor'].'">'.$comments['username'].'</a>
                     </span> 
                     <a href="'.$scriptur.'?action=comunidades;sa=tema;idtema='.$comments['id'] .'#all-comments" title="',$comments['titulo'],'">
                        '. _substr($comments['titulo'], 0, 35, 30).'
                     </a>
                  </li>';
              }else{
             echo'<div class="list-element">
			               <a href="'.$scriptur.'?action=comunidades;sa=tema;idtema='.$comments['id'] .'#all-comments">',$comments['titulo'],'</a>
		              </div>';
              }
             }
          }
      
      exit();
   }
   else{
	    redirectexit('action=comunidades');
   }
  }


//OBTENEMOS MIS COMUNIDADES	
function getMyComunidades($name, $idmember, $ord, $inicio, $fin){
  	 global $txt, $db_prefix, $scripturl, $context, $modSettings, $ID_MEMBER;
		
		$doing = $modSettings['comunidades_mycommunitys'];
     
     //Limites
	    $Lim = !empty($inicio) || !empty($fin) ? "{$inicio},{$fin}":"{$doing}";
		
		$limite = "LIMIT {$Lim}";
		
		   switch($ord){
		      default:
		      case 'name':
		         $order = 'ORDER BY c.titulo ASC';
		      break;
		      case 'range':
		         $order = 'ORDER BY cm.ID_RANGO DESC';
		      break;
		      case 'members':
		         $order = 'ORDER BY c.miembros DESC';
		      break;
		      case 'thems':
		         $order = 'ORDER BY c.temas DESC';
		      break;
		      case 'id':
		         $order = 'ORDER BY cm.ID_COMUNIDAD DESC';
		         $limite = "LIMIT {$doing}";
		      break;
		   }
     
     $comunidades = db_query("SELECT cm.ID, cm.ID_COMUNIDAD, cm.ID_MIEMBRO, cm.ID_RANGO, cm.APROVED, cm.BAN,
                                     c.ID_COMUNIDAD, c.portada, c.titulo, c.ID_BOARD, c.descripcion, c.miembros, c.temas,
                                     cc.ID_BOARD, cc.name
                              FROM ({$db_prefix}comunidades_miembros as cm, {$db_prefix}comunidades as c, {$db_prefix}comunidades_categorias as cc)
                              WHERE cm.APROVED = 1
                              AND cm.ID_MIEMBRO = $ID_MEMBER
                              AND cm.BAN = 0
                              AND cm.ID_COMUNIDAD = c.ID_COMUNIDAD
                              AND cc.ID_BOARD = c.ID_BOARD
                              $order
                              {$limite}", __FILE__, __LINE__);
                              
     $context['comunidades'][$name] = array();
	  $context['count::comunidades'] = mysql_num_rows($comunidades);
	  
	  while ($row = mysql_fetch_assoc($comunidades)){

		 $context['comunidades'][$name][] = array(
        'id' => $row['ID_COMUNIDAD'],
        'id_member' => $row['ID_MIEMBRO'],
        'id_rango' => $row['ID_RANGO'],
        'portada' => $row['portada'],
        'titulo' => $row['titulo'],
        'descripcion' => $row['descripcion'],
        'id_categoria' => $row['ID_BOARD'],
        'categoria' => $row['name'],
        'miembros' => $row['miembros'],
        'temas' => $row['temas'],
		);
	}
	mysql_free_result($comunidades);
}
  // MIS COMUNIDADES

  function miscomunidades(){
  	 global $txt, $db_prefix, $scripturl, $context, $temas, $sourcedir, $ID_MEMBER, $modSettings;
		   
	// No guests!
	is_not_guest();
	
	
    $context['page_actual'] =  empty($_GET['page']) ? 1: $_GET['page'];
    
	$doing = $modSettings['comunidades_mycommunitys'];

    require_once($sourcedir . '/classes/Pagination.php');
    $paginator = new Pagination(array(
        'base_url' => $scripturl . '?action=comunidades;sa=miscomunidades;tipo='.$_GET['tipo'].';page=',
        'total_rows' => $context['user']['count::comunidades'],
        'per_page' => $doing,
        'first_link' => '',
        'last_link' => '',
        'query_string_segment' => 'page',
        'full_tag_open' => '<ul class="paginator smallfont clearfix">',
        'full_tag_close' => '</ul>'
    ));

    $context['paginacion'] = $paginator->create_links($getData);
    $context['total_pages'] = $getData['num_pages'];


      $order = isset($_GET['tipo']) ? $_GET['tipo']:'id';

       getMyComunidades('my',$ID_MEMBER, $order,$context['page_actual'],$doing);

       //paginamos

       $context['pages'] = round($context['count::comunidades']/$doing) == 0 ? 1 : round($context['count::comunidades']/$doing);


       // sub_template = template_main()
        $context['sub_template']  = 'miscomunidades';


	     // titulo de la seccion
	      $context['page_title'] = $txt['comunidades_my_communitys'];


  }


// DIRECTORIO DE COMUNIDADES

function directorio(){

global $txt, $context, $scripturl, $db_prefix;


	$context['sub_template']  = 'directorio';
	$context['page_title'] = $txt['comunidades_directory'];
	$context['linktree'][] = array(
		'url' => $scripturl,
		'name' => 'Comunidad',
		);
	$context['linktree'][] = array(
		'url' => '#',
		'name' => $txt['comunidades_directory'],
		);

$id = $_GET['id'];

if($id!='')
{
$dbresult = db_query("

        SELECT  c.ID_BOARD, c.ID_BOARD2, c.titulo, c.portada, c.descripcion, c.ID_COMUNIDAD, c.miembros, c.temas, cc.ID_BOARD, cc.name
		FROM {$db_prefix}comunidades AS c, {$db_prefix}comunidades_categorias AS cc
		WHERE c.ID_BOARD = '".$cat."'
                AND c.ID_BOARD = cc.ID_BOARD
                AND c.ID_BOARD2 = cc.ID_BOARD
                ORDER BY cc.name ASC

	        ", __FILE__, __LINE__);

	while ($row = mysql_fetch_assoc($dbresult))
	{
		$context['comunidad'][] = array(
		'id_comunidad' => $row['ID_COMUNIDAD'],
		'miembros' => $row['miembros'],
		'titulo' => $row['titulo'],
		'portada' => $row['portada'],
                'temas' => $row['temas'],
                'name' => $row['name'],
                'descripcion' => $row['descripcion'],
                'id_board' => $row['ID_BOARD'],
                'id_board2' => $row['ID_BOARD2'],


	);
  }
  mysql_free_result($dbresult);

}

$dbresult = db_query("

        SELECT  type, ID_BOARD, name
		FROM  {$db_prefix}comunidades_categorias
		WHERE type = 0
                ORDER BY name ASC

	        ", __FILE__, __LINE__);

	while ($row = mysql_fetch_assoc($dbresult))
	{
		$context['categoria'][] = array(
		'id_comunidad' => $row['ID_COMUNIDAD'],
                'name' => $row['name'],
                'ID_BOARD' => $row['ID_BOARD'],
                'ID_BOARD2' => $row['ID_BOARD'],


	);
  }
  mysql_free_result($dbresult);


/*CREAR TEMPLATE O LO QUE SEA PARA LAS SUBCATEGORIAS
DE LAS COMUNIDADES TIPO T!

ACA UN LINK DE SUBCATEGORIA --> http://www.taringa.net/comunidades/dir/Internacional/diversion-esparcimiento

ACA OTRO LINK DE LAS COMUNIDADES POR CATEGORIA --> http://www.taringa.net/comunidades/dir/Internacional/diversion-esparcimiento/vida-noctura


*/

}




























// OBTENER COMENTARIOS/RESPUESTAS

function getAnswer($name, $id_tema, $id_member, $id_comunidad, $inicio, $fin){
  	 global $db_prefix, $txt, $modSettings, $context, $temas, $ID_MEMBER, $respuestas, $no_avatar, $answers;
	                 
	//Limites
	$LimIndex = !empty($modSettings['comentarios_index']) ? $modSettings['comentarios_index'] : 0;
	$LimAnswer = !empty($modSettings['comentarios_temas']) ? $modSettings['comentarios_temas'] : 0;
	$LimAnswer2 = !empty($inicio) && !empty($fin) ? "{$inicio},{$fin}":"{$LimAnswer}";
	
	// FILTRAMOS LAS QUERYS
	switch($name){
	   case 'all':
	      $limit = "";
	      $and = '';
	      $oder = 'cc.ID_TEMA DESC';
	   break;
	   case 'recent':
	      $limit = "LIMIT {$LimIndex}";
	      $and = '';
	      $oder = 'cc.ID_C DESC';
	   break;
	   case 'list':
	      $limit = "LIMIT {$LimAnswer2}";
	      $and = '';
	      $oder = 'cc.ID_TEMA DESC';
	   break;
	   case 'user':
	      $limit = "LIMIT {$LimAnswer2}";
	      $and = '';
	      $oder = 'cc.ID_TEMA DESC';
	   break;
	}

	$id_tema = !empty($id_tema) ? "AND cc.ID_TEMA = {$id_tema}":'';
	$id_member = !empty($id_member) ? "AND cc.ID_MEMBER_STARTED = {$id_member}":'';
	$id_comunidad = !empty($id_comunidad) ? "AND cc.ID_COMUNIDAD = {$id_comunidad}":'';

	// query llena de filtros
	  $request = db_query("SELECT cc.ID_C, cc.ID_COMUNIDAD, cc.ID_TEMA, cc.cuerpo, cc.ID_MEMBER_STARTED, cc.fecha,
	                              m.ID_MEMBER, m.realName, m.avatar, m.avatar_coords,
	                              ct.ID_TEMA, ct.titulo
		                    FROM ({$db_prefix}comunidades_comentarios as cc, {$db_prefix}members as m, {$db_prefix}comunidades_temas as ct)
		                    WHERE cc.ID_MEMBER_STARTED = m.ID_MEMBER
		                    AND ct.ID_TEMA = cc.ID_TEMA
		                    $id_tema
		                    $id_member
		                    $id_comunidad
	                      ORDER BY $oder
	                      $limit", __FILE__, __LINE__);
	                      
	  $context['respuestas'][$name] = array();
	  
	  $context[$name]['count'] = mysql_num_rows($request);
	  
	  while ($row = mysql_fetch_assoc($request)){

		 $context['respuestas'][$name][] = array(
		    'id2' => $row['ID_C'],
		    'titulo' => $row['titulo'],
		    'id' => $row['ID_TEMA'],
		    'comentario' => array(
		                    'bbc' => parse_bbc($row['cuerpo']),
		                    'source' => $row['cuerpo']
		                    ),
		    'autor' => $row['ID_MEMBER_STARTED'],
		    'hace' => hace($row['fecha']),
		    'fecha' => $row['fecha'],
		    'fecha_title' => fechaGeneralComunidades($row['fecha']), 
		    'username' => $row['realName'],
		    'avatar' => (empty($row['avatar']) ? $no_avatar : $row['avatar']),
		    'avatar_coords' => makeAvatarCoords($row['avatar_coords']),
		);
		
		if ($name == 'user' || !empty($row['ID_C'])){ // para colocar en el perfil
			$answers[$row['ID_C']] = array(
		    'id2' => $row['ID_C'],
		    'titulo' => $row['titulo'],
		    'id' => $row['ID_TEMA'],
		    'comentario' => array(
		                    'bbc' => parse_bbc($row['cuerpo']),
		                    'source' => $row['cuerpo']
		                    ),
		    'autor' => $row['ID_MEMBER_STARTED'],
		    'hace' => hace($row['fecha']),
		    'fecha' => $row['fecha'],
		    'fecha_title' => fechaGeneralComunidades($row['fecha']), 
		    'username' => $row['realName'],
		    'avatar' => (empty($row['avatar']) ? $no_avatar : $row['avatar']),
		    'avatar_coords' => makeAvatarCoords($row['avatar_coords']),
			);
		}
		
	}
	mysql_free_result($request);
	    
}

// YA LO AGREGUE A FAVORITO ???

function im_add_bookmark($id, $idm){
      global $db_prefix, $context, $ID_MEMBER;
         
	     	$bookmark = db_query("SELECT ID_MEMBER, ID_TOPIC, type
			                          FROM {$db_prefix}bookmarks
			                          WHERE ID_MEMBER = '$idm'
			                          AND ID_TOPIC = '$id'
			                          AND type = 3
			                          LIMIT 1",__FILE__,__LINE__);
		
	            $context['agregado_bookmark'] = false;
	            
	         $row = mysql_fetch_assoc($bookmark);
	         
	         $context['bookmark_id'] = $row['ID_TOPIC'];
	            
		       if(mysql_num_rows($bookmark) > 0 ){
	            $context['agregado_bookmark'] = true;
	         }     
	            
		       mysql_free_result($bookmark);    
}

// UPDATE FOLLOWS
function update_votos($id, $me, $type){
   global $db_prefix, $context;
   
  switch($type){
     case 1:
        $leg = "positivos = positivos + 1, negativos = negativos - 1, popularidad = popularidad + 1";
     break;
     case 2:
        $leg = "positivos = positivos - 1, negativos = negativos + 1, popularidad = popularidad - 1";
     break;
  }
    
		// eh! agregame uno mas a la lista :)
  $up = db_query("UPDATE {$db_prefix}comunidades_likes
             SET TYPE = {$type}
             WHERE id_like = $id
             AND ID_MEMBER = $me
             ",__FILE__,__LINE__);
             
  $up2 = db_query("UPDATE {$db_prefix}comunidades_temas
             SET {$leg}
             WHERE ID_TEMA = $id
             ",__FILE__,__LINE__);
  
  if($up){
	// Success.
	return true;
  }
  else{
	// Error.
	return false;
  }
}

// YA VOTE ???

function ya_vote($id, $idm, $type){
      global $db_prefix, $context, $ID_MEMBER;
         
         $type = !empty($type) ? "AND TYPE = {$type}":'';
  	     // soy seguidor???
	     	$follow = db_query("SELECT id_like, ID_MEMBER, TYPE
			                          FROM {$db_prefix}comunidades_likes
			                          WHERE ID_MEMBER = '$idm'
			                          AND id_like = '$id'
			                          $type
			                          LIMIT 1",__FILE__,__LINE__);
		
	            $context['ya_vote'] = false;
	            
	         $row = mysql_fetch_assoc($follow);
	         
	         $context['voto_id'] = $row['id_like'];
	         $context['voto_type'] = $row['TYPE'];
	            
		       if(mysql_num_rows($follow) > 0 ){
	            $context['ya_vote'] = true;
	         }     
	            
		       mysql_free_result($follow);    
}

// INSERT VOTOS
function insert_votos($id, $me, $type){
   global $db_prefix, $context;
   
  switch($type){
     case 1:
        $leg = "positivos = positivos + 1, popularidad = popularidad + 1";
     break;
     case 2:
        $leg = "negativos = negativos + 1, popularidad = popularidad - 1";
     break;
  }
  
	 db_query("INSERT IGNORE INTO {$db_prefix}comunidades_likes (id_like, ID_MEMBER, TYPE, fecha)
			       VALUES('$id', '$me', '$type', '".time()."')",__FILE__,__LINE__);
			       
	 $idvoto = mysql_insert_id();
	 
	  $up2 = db_query("UPDATE {$db_prefix}comunidades_temas
             SET {$leg}
             WHERE ID_TEMA = $id
             ",__FILE__,__LINE__);
             
   if(!empty($idvoto)){
      return true;
   }
   else{
      return false;
   }
}

// DELETE FOLLOWSFOLLOWS
function delete_followers($id, $me, $type){
   global $db_prefix, $context;
		       
 $delete = db_query("DELETE FROM {$db_prefix}followers 
		                 WHERE uid = '".$id."' 
		                 AND uif = '".$me."' 
		                 AND type = '".$type."'
		                 LIMIT 1 ",__FILE__,__LINE__);
	
   if(!empty($delete)){
      return true;
   }
   else{
      return false;
   }
}
// INSERT FOLLOWS
function insert_followers($id, $me, $type, $time){
   global $db_prefix, $context;

	 db_query("INSERT IGNORE INTO {$db_prefix}followers (uid, uif, type, time)
			       VALUES('$id', '$me', '$type', '$time')",__FILE__,__LINE__);
			       
	 $idtema = mysql_insert_id();
	
   if(!empty($idtema)){
      return true;
   }
   else{
      return false;
   }
}
			       
// PARSE HTML ENTIDADES

function parse_html_entities($data){

$data_parse = str_replace(array('"', '<', '>', '  '), array('&quot;', '&lt;', '&gt;', ' &nbsp;'), $data);
    
return $data_parse;
}


// SEGUIDORES

function im_follow($id, $idm, $type){
      global $db_prefix, $context, $ID_MEMBER;

  	     // soy seguidor???
	     	$follow = db_query("SELECT uif, uid, type
			                          FROM {$db_prefix}followers 
			                          WHERE uif = '$idm'
			                          AND uid = '$id'
			                          AND type = '$type'
			                          LIMIT 1",__FILE__,__LINE__);
		
	            $context['siguiendo'] = false;
	            
		       if(mysql_num_rows($follow) > 0 ){
	            $context['siguiendo'] = true;
	         }
	                     
		       mysql_free_result($follow);    
}

// UPDATE FOLLOWS
function updateFollowsCount($id, $type, $sig){
   global $context, $settings, $boardurl, $scripturl, $temas, $ID_MEMBER, $txt, $idtema, $modSettings, $sourcedir, $func, $db_prefix, $boardurl;

    switch($type){
       case 2:
          $db = '';
          $wh = "ID_COMUNIDAD = {$id}";
       break;
       case 3:
          $db = '_temas';
          $wh = "ID_TEMA = {$id}";
       break;
    }
    
		// eh! agregame uno mas a la lista :)
  $up = db_query("UPDATE {$db_prefix}comunidades{$db}
             SET seguidores = seguidores {$sig} 1, popularidad = popularidad {$sig} 1
             WHERE {$wh}
             ",__FILE__,__LINE__);
  
  if($up){
	// Success.
	return true;
  }
  else{
	// Error.
	return false;
  }
}

// UPDATE TEMA
function updateTemaBorrador(&$TemaOptions, &$posterOptions){
	global $db_prefix, $txt, $modSettings, $context, $miembros, $ID_MEMBER, $idtema;

	// It's do or die time: forget any user aborts!
	$previous_ignore_user_abort = ignore_user_abort(true);
	
	/*if(!empty($posterOptions['permiso'])){*/
	
	$idtema = $TemaOptions['borrador'];

   $update = db_query("UPDATE {$db_prefix}comunidades_temas
                  SET titulo = '".$TemaOptions['titulo']."',
                      ID_BOARD = '".$TemaOptions['categoria']."',
                      ID_BOARD2 = '".$TemaOptions['categoria2']."',
                      cuerpo = '".$TemaOptions['cuerpo']."',
                      seguidores = '".$TemaOptions['siguiendo']."',
                      cerrado = '".$TemaOptions['cerrado']."',
                      sticky = '".$TemaOptions['sticky']."',
                      borrador = 1
                  WHERE ID_TEMA = '".$TemaOptions['borrador']."'
                  AND ID_COMUNIDAD = '".$TemaOptions['comunidad']."'
                  AND ID_MEMBER_STARTED = '".$posterOptions['id']."'",__FILE__,__LINE__);
  
	// Alright, done now... we can abort now, I guess... at least this much is done.
	ignore_user_abort($previous_ignore_user_abort);
	
	if($update){
	// Success.
	return true;
  }
  else{
	// Error.
	return false;
  }
}




// SESSIONES VISITAS
function updateVisitas($id,$id_member,$type){
   global $context, $db_prefix, $settings, $ID_MEMBER;
   
   switch($type){
      case 1:
         $name = 'comunidad';
         $name_ = 'ID_COMUNIDAD';
         $db = '';
      break;
      case 2:
         $name = 'tema';
         $name_ = 'ID_TEMA';
         $db = '_temas';
      break;
   }
   
   db_query("UPDATE {$db_prefix}comunidades{$db}
				 SET visitas = visitas + 1, popularidad = popularidad + 1
				 WHERE {$name_} = $id
				 AND ID_MEMBER_STARTED = $id_member");
   
if(!empty($name)){
$_SESSION['visita'][$name][$id] = $id;
return true;
}
else{
return false;
}
}

// SESSIONES ANTIFLOOD

function savesession($name){
   global $context, $settings, $ID_MEMBER;
   
if(!empty($name)){
$_SESSION['flood'][$ID_MEMBER.'_'.$name] = time();

return true;
}
else{
return false;
}
}


// UPDATE TEMA
function updateTema(&$TemaOptions, &$posterOptions){
	global $db_prefix, $txt, $modSettings, $context, $miembros, $ID_MEMBER, $idtema;

	// It's do or die time: forget any user aborts!
	$previous_ignore_user_abort = ignore_user_abort(true);
	
	/*if(!empty($posterOptions['permiso'])){*/
	
	$idtema = $TemaOptions['tema'];

   $update = db_query("UPDATE {$db_prefix}comunidades_temas
                  SET titulo = '".$TemaOptions['titulo']."',
                      ID_BOARD = '".$TemaOptions['categoria']."',
                      ID_BOARD2 = '".$TemaOptions['categoria2']."',
                      cuerpo = '".$TemaOptions['cuerpo']."',
                      seguidores = '".$TemaOptions['siguiendo']."',
                      cerrado = '".$TemaOptions['cerrado']."',
                      sticky = '".$TemaOptions['sticky']."',
                      borrador = 0
                  WHERE ID_TEMA = '".$TemaOptions['tema']."'
                  AND ID_COMUNIDAD = '".$TemaOptions['comunidad']."'
                  AND ID_MEMBER_STARTED = '".$posterOptions['id']."'",__FILE__,__LINE__);
        
  updateStats('temas');
  
  updateComunidadTemas($TemaOptions['comunidad'], 'comunidad');
  updateComunidadTemas($TemaOptions['comunidad'], 'tema', $idtema);
  
	// Alright, done now... we can abort now, I guess... at least this much is done.
	ignore_user_abort($previous_ignore_user_abort);
	
	if($update){
	// Success.
	return true;
  }
  else{
	// Error.
	return false;
  }
}

// save eraser
function save_borrador(&$TemaOptions, &$posterOptions){
    global $context, $settings, $boardurl, $scripturl, $ID_MEMBER, $txt, $modSettings, $sourcedir, $func, $db_prefix, $boardurl, $idtema;
    
	// It's do or die time: forget any user aborts!
	$previous_ignore_user_abort = ignore_user_abort(true);

	$nuevo_tema = empty($TemaOptions['comunidad']);
	
	$titulo = str_replace(array('"', '<', '>', '  '), array('&quot;', '&lt;', '&gt;', ' &nbsp;'), $TemaOptions['titulo']);
	$cuerpo = str_replace(array('"', '<', '>', '  '), array('&quot;', '&lt;', '&gt;', ' &nbsp;'), $TemaOptions['cuerpo']);
  
	// Insert the community temas.
	$yalopublico = db_query("INSERT INTO {$db_prefix}comunidades_temas
			(titulo, ID_COMUNIDAD, ID_BOARD, ID_BOARD2, cuerpo, ID_MEMBER_STARTED, fecha, cerrado, sticky, seguidores, borrador)
		VALUES ('$titulo','$TemaOptions[comunidad]','$TemaOptions[categoria]','$TemaOptions[categoria2]','$cuerpo','$posterOptions[id]','".time()."','$TemaOptions[cerrado]','$TemaOptions[sticky]','$TemaOptions[siguiendo]', '1')", __FILE__, __LINE__);

  $idtema = mysql_insert_id();
  
	// Alright, done now... we can abort now, I guess... at least this much is done.
	ignore_user_abort($previous_ignore_user_abort);
  if($idtema){
	   // Success.
	   return true;
	}
	else{
	   // Error.
	   return false;
	}
}

// creando un tema 
function createComunidadTema(&$TemaOptions, &$posterOptions){
	global $db_prefix, $user_info, $ID_MEMBER, $txt, $modSettings, $idtema;
    global $context, $settings, $boardurl, $scripturl, $temas, $ID_MEMBER, $txt, $idtema, $modSettings, $sourcedir, $func, $db_prefix, $boardurl, $comunidades;
	
	// It's do or die time: forget any user aborts!
	$previous_ignore_user_abort = ignore_user_abort(true);

	$nuevo_tema = empty($TemaOptions['comunidad']);
  
  $TemaOptions['titulo'] = parse_html_entities($TemaOptions['titulo']);
  $TemaOptions['cuerpo'] = parse_html_entities($TemaOptions['cuerpo']);
  
	// Insert the community temas.
	$yalopublico = db_query("INSERT INTO {$db_prefix}comunidades_temas
			(titulo, ID_COMUNIDAD, ID_BOARD, ID_BOARD2, cuerpo, ID_MEMBER_STARTED, fecha, cerrado, sticky)
		VALUES ('$TemaOptions[titulo]','$TemaOptions[comunidad]','$TemaOptions[categoria]','$TemaOptions[categoria2]','$TemaOptions[cuerpo]','$posterOptions[id]','".time()."','$TemaOptions[cerrado]','$TemaOptions[sticky]')", __FILE__, __LINE__);

  $idtema = mysql_insert_id();

  
  // notifiquemos! el nuevo tema
   $notifications = new notifications();
   $notifications->add('nuevotema', array(
      'author' => $posterOptions['id'],
      'id' => $idtema
   ));
           
  // sino es borrador lo updateamos
  updateStats('temas');
  
  // agregamos uno mas a la lista de seguidores del tema
  if(!empty($TemaOptions['siguiendo'])){
		 insert_followers($idtema, $posterOptions['id'], 3, time());
		 updateFollowsCount($idtema, 3, '+');
  }
  
  // sino es borrador no hacemos el reconteo
  updateComunidadTemas($TemaOptions['comunidad'], 'tema', $idtema);
  updateComunidadTemas($TemaOptions['comunidad'], 'comunidad');
	// Alright, done now... we can abort now, I guess... at least this much is done.
	ignore_user_abort($previous_ignore_user_abort);

	// Success.
	return true;
}
   // UPDATE TEMES COMMUNITY
function updateComunidadTemas($idco, $name, $idt, $fav){
	global $db_prefix, $txt, $modSettings, $context, $miembros, $ID_MEMBER;
  
  $fav = !empty($fav) ? ", favoritos = favoritos + 1":'';
  
  switch($name){
  case 'tema':
             // eh! agregame uno mas a la lista :)
  $miembros = db_query("UPDATE {$db_prefix}comunidades_temas
                  SET popularidad = popularidad + 1 {$fav}
                  WHERE ID_COMUNIDAD = '$idco'
                  AND ID_TEMA = '$idt'
                  ",__FILE__,__LINE__);
  break;
  case 'comunidad':
  default:
             // eh! agregame uno mas a la lista :)
  $miembros = db_query("UPDATE {$db_prefix}comunidades
                  SET temas = temas + 1, popularidad = popularidad + 1
                  WHERE ID_COMUNIDAD = '$idco'
                  ",__FILE__,__LINE__);
  break;
  }

                  
   return true;
}


// staff de la comunidad
function getStaff($idcomunidad){
   global  $db_prefix, $txt, $context, $staff, $online;
   
   //obtenemos los staff online
	 getUsersOnline();
	 
	 //staff de esta comunidad 
	  $members = db_query("SELECT c.ID_RANGO, c.APROVED, c.ID_COMUNIDAD, c.ID_MIEMBRO, m.ID_MEMBER, m.realName, m.avatar
		                     FROM ({$db_prefix}comunidades_miembros AS c,{$db_prefix}members AS m)
		                     WHERE c.ID_COMUNIDAD = '".$idcomunidad."'
		                     AND m.ID_MEMBER = c.ID_MIEMBRO
		                     AND c.ID_RANGO != 0
		                     AND c.ID_RANGO != 1
		                     AND c.ID_RANGO != 2
		                     AND c.APROVED = 1", __FILE__, __LINE__);
		   $context['staff'] = array();
	  while ($row = mysql_fetch_assoc($members)){
		   $context['staff'][] = array(
			    'online' => $online[$row['ID_MEMBER']]['online'] ? 'on':'off',
			    'id' => $row['ID_MEMBER'],
			    'admin' => $row['ID_RANGO']==4 ? 'admin':($row['ID_RANGO']==3 ? 'moderador':''),
			    'name' => $row['realName'],
			    'avatar' => $row['avatar'],
		   );
		   
		   if(!empty($row['ID_MEMBER'])){
			 $staff[$row['ID_MEMBER']] = array(
			    // es admin o moderador
			    'admin' => $row['ID_RANGO']==4 || $row['ID_RANGO']==3 ? true: false,
			);
		}
		}
	  mysql_free_result($members);	
}

/***** USUARIO EN LINEA*****/
function getUsersOnline(){
global  $db_prefix, $context, $online;

		//usuarios en linea
		$onlines = db_query("SELECT mem.ID_MEMBER , IFNULL(lo.logTime, 0) AS isOnline
		                    FROM ({$db_prefix}members as mem )
		                    LEFT JOIN {$db_prefix}log_online AS lo ON (lo.ID_MEMBER = mem.ID_MEMBER)
		                    WHERE mem.ID_MEMBER > 0
		                    ", __FILE__, __LINE__);
		                    
				   $context['online_u'] = array();
				   
	  while ($row = mysql_fetch_assoc($onlines)){
		   $context['online_u'][] = array(
			    'id' => $row['ID_MEMBER'],
			    'online' => $row['isOnline'],
		   );
		   
		if(!empty($row['ID_MEMBER'])){
			$online[$row['ID_MEMBER']] = array(
		     'id' => $row['ID_MEMBER'],
			    'online' => $row['isOnline'],
			);
		}
		}
	  mysql_free_result($onlines);	
}

// obtener el rango
function querango($rango){
global  $db_prefix, $txt;

$rg = $rango == 1 ?'guest':($rango == 2 ?'poster':($rango == 3 ?'moderador':($rango == 4 ?'admin':'anonimo')));

return $txt['comunidades_rango_'.$rg];
}

  // UPDATE COMUNIDAD EDITADA
function updateComunidad($ComunidadOptions, $posterOptions){
	global $db_prefix, $txt, $modSettings, $context, $miembros, $ID_MEMBER;

	// It's do or die time: forget any user aborts!
	$previous_ignore_user_abort = ignore_user_abort(true);
	
	if(!empty($posterOptions['permiso'])){
	
   $update = db_query("UPDATE {$db_prefix}comunidades
                  SET titulo = '".$ComunidadOptions['titulo']."',
                      portada = '".$ComunidadOptions['portada']."',
                      background = '".$ComunidadOptions['background']."',
                      descripcion = '".$ComunidadOptions['descripcion']."',
                      ID_BOARD = '".$ComunidadOptions['categoria']."',
                      ID_BOARD2 = '".$ComunidadOptions['subcategoria']."',
                      rango = '".$ComunidadOptions['rangos']."',
                      ID_MEMBER_UPDATED = '".$posterOptions['id']."',
                      validacion = '".$ComunidadOptions['miembros']."',
                      privado = '".$ComunidadOptions['privacidad']."',
                      sticky = '".$ComunidadOptions['sticky']."',
                      fecha_update = '".$ComunidadOptions['fecha']."'
                  WHERE ID_COMUNIDAD = '".$ComunidadOptions['comunidad']."'
                  AND ID_MEMBER_STARTED = '".$posterOptions['admin']."'",__FILE__,__LINE__);
                  
                  
  updateStats('comunidad');
  
	// Alright, done now... we can abort now, I guess... at least this much is done.
	ignore_user_abort($previous_ignore_user_abort);
	// Success.
	return true;
  }
  else{
	// Error.
	return false;
  }
}

// Create a community, either as new community (ID_COMUNIDAD = 0) or in an existing one.
function createComunidad(&$ComunidadOptions, &$posterOptions){
	global $db_prefix, $user_info, $ID_MEMBER, $txt, $modSettings, $idco;  
	
	// It's do or die time: forget any user aborts!
	$previous_ignore_user_abort = ignore_user_abort(true);

	$nueva_comunidad = empty($ComunidadOptions['id']);
	
  $ComunidadOptions['titulo'] = parse_html_entities($ComunidadOptions['titulo']);
  $ComunidadOptions['descripcion'] = parse_html_entities($ComunidadOptions['descripcion']);
  
	// Insert the community.

	$yalopublico = db_query("INSERT INTO {$db_prefix}comunidades
			(titulo, background, portada, descripcion, ID_BOARD, ID_BOARD2, ID_MEMBER_STARTED, rango, fecha, validacion, privado, sticky, miembros)
		VALUES ('$ComunidadOptions[titulo]','$ComunidadOptions[background]','$ComunidadOptions[portada]','$ComunidadOptions[descripcion]','$ComunidadOptions[categoria]','$ComunidadOptions[subcategoria]','$posterOptions[id]','$ComunidadOptions[rangos]','".time()."','$ComunidadOptions[miembros]','$ComunidadOptions[privacidad]','$ComunidadOptions[sticky]', '0')", __FILE__, __LINE__);
  
  $idco = mysql_insert_id();

  // Update all the stats so everyone knows about this new community.
  updateStats('comunidad');

  updateMemberComunidad($idco,$posterOptions['id'],4,1); // insert into admin
	// Alright, done now... we can abort now, I guess... at least this much is done.
	ignore_user_abort($previous_ignore_user_abort);

	// Success.
	return true;
}

// UPDATE MEMBER COMMUNITY
function deleteMemberComunidad($idco,$idmember,$range,$pops,$mem,$aprovado){
	global $db_prefix, $txt, $modSettings, $context, $miembros, $ID_MEMBER;
		
	$miembros = db_query("DELETE FROM {$db_prefix}comunidades_miembros
			                  WHERE ID_COMUNIDAD = $idco
			                  AND ID_MIEMBRO = $idmember
			                  AND ID_RANGO = $range
			                  AND APROVED = $aprovado", __FILE__, __LINE__);
			                  
  if($aprovado == 1 && $pops > 1 && $mem > 1){
	// eh! quitame uno mas a la lista :) solo si son aprovados
   db_query("UPDATE {$db_prefix}comunidades
             SET popularidad = popularidad - 1 , miembros = miembros - 1
             WHERE ID_COMUNIDAD = $idco
             ",__FILE__,__LINE__);
  }
  return true;
}

// UPDATE MEMBER COMMUNITY
function updateMemberComunidad($idco,$idmember,$range,$aproved){
	global $db_prefix, $txt, $modSettings, $context, $miembros, $ID_MEMBER;

  $aprovado = $aproved == 1 ? ', miembros = miembros + 1':'';
  
	$miembros = db_query("INSERT INTO {$db_prefix}comunidades_miembros
			(ID_COMUNIDAD, ID_MIEMBRO,ID_RANGO, APROVED)
		VALUES ('$idco','$idmember','$range','$aproved')", __FILE__, __LINE__);
		
	// eh! agregame uno mas a la lista :)
   db_query("UPDATE {$db_prefix}comunidades
             SET popularidad = popularidad + 1 $aprovado
             WHERE ID_COMUNIDAD = $idco
             ",__FILE__,__LINE__);
		
	// eh! agregame uno mas a la lista :)
   db_query("UPDATE {$db_prefix}members
             SET comunidades = comunidades + 1
             WHERE ID_MEMBER = $idmember
             ",__FILE__,__LINE__);
             
  return true;
}

function recortart($texto, $tamano = 11){
if(strlen($texto)>$tamano){
$texto=substr($texto,0,$tamano);
return $texto.'...';
}
else{
return $texto;
}
}

// DETECTOR DE EXTENSIONES 

function extens($str){
        return end(explode(".", $str));
}

// Load a lot of usefull information regarding the members community.
function getComunidadMembers($name,$idco){
	global $db_prefix, $txt, $modSettings, $context, $miembros, $ID_MEMBER;
  
  switch($name){
     case 'history': // por fecha
        $order = "cm.ID, ID_RANGO DESC";
        $limit = "LIMIT 10";
        $ban = "";
        $and = "";
     break;
     case 'todos': // por ID
        $order = "cm.ID_MIEMBRO DESC";
        $limit = "LIMIT 28";
        $ban = "";
        $and = "AND cm.APROVED = 1";
     break;
     case 'unlimited': // caso sin limite
        $order = "cm.ID_MIEMBRO DESC";
        $limit = "";
        $ban = "";
        $and = "";
     break;
     case 'ban': //por baneados
        $order = "cm.ID_MIEMBRO, cm.BAN DESC";
        $limit = "LIMIT 10";
        $ban = "AND cm.BAN = 1";
        $and = "";
     break;
     case 'solicitudes': //por baneados
        $order = "cm.ID_MIEMBRO DESC";
        $limit = "LIMIT 10";
        $ban = "AND cm.BAN = 0";
        $and = "AND cm.APROVED = 0";
     break;
     case 'all': // por ID
     default:
        $name = 'all';
        $order = "cm.ID_MIEMBRO DESC";
        $limit = "LIMIT 10";
        $ban = "AND cm.BAN = 0";
        $and = "AND cm.APROVED = 1";
     break;
  }
  
	// query members
	 $miembro = db_query("SELECT cm.ID_COMUNIDAD, cm.ID_MIEMBRO, cm.ID_RANGO, cm.APROVED, cm.BAN, cm.Razon, m.ID_MEMBER, m.realName, m.avatar
		                    FROM ({$db_prefix}comunidades_miembros as cm,{$db_prefix}members as m)
		                    WHERE cm.ID_COMUNIDAD = '$idco'
		                    AND cm.ID_MIEMBRO = m.ID_MEMBER
		                    $ban
		                    $and
		                    ORDER BY $order
		                    $limit", __FILE__, __LINE__);
	                      
	  $context['miembros'][$name] = array();
	  
	  while ($row = mysql_fetch_assoc($miembro)){

		 $context['miembros'][$name][] = array(
		     'id' => $row['ID_COMUNIDAD'],
		     'idmember' => $row['ID_MIEMBRO'],
		     'id_rango' => $row['ID_RANGO'],
		     'aprovado' => $row['APROVED'],
		     'en_aprovacion' => $row['APROVED']==1 ? 1:2,
		     'aprovacion' => $row['APROVED'],
		     'nombre' => $row['realName'],
		     'avatar' => $row['avatar'],
		     'bloqueado' => $row['BAN'] == 1 ? true:false,
		     'admin' => $row['ID_RANGO'] == 4 ? true:false,
		     'moderador' => $row['ID_RANGO'] == 3 ? true:false,
		     'posteador' => $row['ID_RANGO'] == 2 ? true:false,
		     'visitante' => $row['ID_RANGO'] == 1 ? true:false,
		     'is_member' => $row['APROVED'] == 1 ? true:false,
		     'publicador' => $row['ID_RANGO'] == 2 || $row['ID_RANGO'] == 3 || $row['ID_RANGO'] == 4 ? true:false,
		     'razon' => $row['Razon'],
		     
		     'in_solicitud' => $row['APROVED'] == 0 ? true:false,
		);
		
		if(!empty($row['ID_MIEMBRO'])){
			$miembros[$row['ID_MIEMBRO']] = array(
		     'id' => $row['ID_COMUNIDAD'],
		     'idmember' => $row['ID_MIEMBRO'],
		     'id_rango' => $row['ID_RANGO'],
		     'en_aprovacion' => $row['APROVED']==1 ? 1:2,
		     'aprovacion' => $row['APROVED'],
		     'nombre' => $row['realName'],
		     'avatar' => $row['avatar'],
		     'admin' => $row['ID_RANGO'] == 4 ? true:false,
		     'moderador' => $row['ID_RANGO'] == 3 ? true:false,
		     'posteador' => $row['ID_RANGO'] == 2 ? true:false,
		     'visitante' => $row['ID_RANGO'] == 1 ? true:false,
		     'razon' => $row['Razon'],
		     
		     'bloqueado' => $row['BAN'] == 1 ? true:false,
		     'publicador' => $row['ID_RANGO'] == 2 || $row['ID_RANGO'] == 3 || $row['ID_RANGO'] == 4 ? true:false,
		     'is_member' => $row['APROVED'] == 1 ? true:false,
		     'in_solicitud' => $row['APROVED'] == 0 ? true:false,
			);
		}
	}
	mysql_free_result($request);
	    
}

// obtener solicitudes
function getComunidadSolicitud($idco){
	    global $db_prefix, $txt, $modSettings, $context, $solicitudes, $ID_MEMBER;
  
	   // query members solicitudes
	    $miembro = db_query("SELECT cm.ID_COMUNIDAD, cm.ID_MIEMBRO, cm.ID_RANGO, cm.APROVED, cm.BAN, cm.Razon, m.ID_MEMBER, m.realName, m.avatar
		                       FROM ({$db_prefix}comunidades_miembros as cm,{$db_prefix}members as m)
		                       WHERE cm.ID_COMUNIDAD = '$idco'
		                       AND cm.ID_MIEMBRO = m.ID_MEMBER
		                       AND cm.APROVED = 0
		                       ORDER BY cm.ID_MIEMBRO DESC
		                       ", __FILE__, __LINE__);
	                      
	     $context['solicitudes'] = array();
	  
	     while ($row = mysql_fetch_assoc($miembro)){

		    $context['solicitudes'] = array(
		        'id' => $row['ID_COMUNIDAD'],
		        'idmember' => $row['ID_MIEMBRO'],
		        'id_rango' => $row['ID_RANGO'],
		        'aprovado' => $row['APROVED'],
		        'aprovacion' => $row['APROVED'],
		        'nombre' => $row['realName'],
		        'avatar' => $row['avatar'],
		        'bloqueado' => $row['BAN'] == 1 ? true:false,
		        'admin' => $row['ID_RANGO'] == 4 ? true:false,
		        'moderador' => $row['ID_RANGO'] == 3 ? true:false,
		        'posteador' => $row['ID_RANGO'] == 2 ? true:false,
		        'visitante' => $row['ID_RANGO'] == 1 ? true:false,
		        'is_member' => $row['APROVED'] == 1 ? true:false,
		        'razon' => $row['Razon'],
		   );
		
	   	if(!empty($row['ID_MIEMBRO'])){
		   	$solicitudes[$row['ID_MIEMBRO']] = array(
		        'id' => $row['ID_COMUNIDAD'],
		        'idmember' => $row['ID_MIEMBRO'],
		        'id_rango' => $row['ID_RANGO'],
		        'is_member' => $row['APROVED'] == 1 ? true:false,
		        'aprovado' => $row['APROVED'] == 1 ? 1:2,
		        'aprovacion' => $row['APROVED'],
		        'nombre' => $row['realName'],
		        'avatar' => $row['avatar'],
		        'admin' => $row['ID_RANGO'] == 4 ? true:false,
		        'moderador' => $row['ID_RANGO'] == 3 ? true:false,
		        'posteador' => $row['ID_RANGO'] == 2 ? true:false,
		        'visitante' => $row['ID_RANGO'] == 1 ? true:false,
		        'razon' => $row['Razon'],
		     
		        'en_aprovacion' => $row['APROVED']==0 ? true:false,
		        'bloqueado' => $row['BAN'] == 1 ? true:false,
			   );
	   	}
	   }
	   mysql_free_result($request);
	    
}
   
function getTemas($name, $comunidad,$eraser,$inicio,$fin,$cat, $setTimed){
	global $db_prefix, $txt, $modSettings, $context, $temas, $ID_MEMBER;
	                 
	//Limites
	$LimTemas = !empty($modSettings['temas_index']) ? $modSettings['temas_index'] : 0;
	$LimTemas2 = !empty($inicio) && !empty($fin) ? "{$inicio},{$fin}":"{$LimTemas}";
	
	// FILTRAMOS LAS QUERYS
	switch($name){
	   case 'importantes':
	      $limit = "LIMIT {$LimTemas2}";
	      $and = 'AND cd.sticky = 1';
	      $oder = 'cd.ID_TEMA DESC';
	   break;
	   case 'normales':
	      $limit = "LIMIT {$LimTemas2}";
	      $and = '';
	      $oder = 'cd.ID_TEMA DESC';
	   break;
	   case 'SetTime':
	   case 'SetTime2':
	      $limit = 'LIMIT 5';
	      $and = "AND cd.fecha > {$setTimed}";
	      $oder = 'cd.popularidad DESC';
	   break;
	   case 'SetTime3':
	      $limit = 'LIMIT 5';
	      $and = "";
	      $oder = 'cd.popularidad DESC';
	   break;
	   case 'lista':
	      $limit = "LIMIT {$LimTemas2}";
	      $and = '';
	      $oder = 'cd.ID_TEMA DESC';
	   break;
	   case 'all':
	      $limit = "";
	      $and = '';
	      $oder = 'cd.ID_TEMA DESC';
	   break;
	}
	
	$cat = !empty($cat) ? "AND cd.ID_BOARD = {$cat}":'';
	$eraser = !empty($eraser) ? "AND cd.borrador = {$eraser}":'AND cd.borrador = 0';
	$comunidad = !empty($comunidad) ? "AND cd.ID_COMUNIDAD = {$comunidad}":'';

	// query llena de filtros
	  $request = db_query("SELECT cd.ID_TEMA, cd.titulo, cd.ID_COMUNIDAD, cd.ID_BOARD, cd.ID_BOARD2, cd.cuerpo, cd.ID_MEMBER_STARTED, 
	                              cd.ID_MEMBER_UPDATED, cd.fecha, cd.visitas, cd.cerrado, cd.sticky, cd.positivos, cd.negativos, cd.popularidad,
	                              cd.seguidores, cd.favoritos, cd.borrador, cd.respuestas,
	                              cc.type, cc.ID_BOARD, cc.memberGroups, cc.name, m.ID_MEMBER, m.realName, m.avatar,
	                              cm.ID_COMUNIDAD, cm.titulo as title
		                    FROM ({$db_prefix}comunidades as cm, {$db_prefix}comunidades_temas as cd, {$db_prefix}comunidades_categorias as cc, {$db_prefix}members as m)
		                    WHERE cd.ID_MEMBER_STARTED = m.ID_MEMBER
		                    AND cc.ID_BOARD = cd.ID_BOARD
		                    AND cm.ID_COMUNIDAD = cd.ID_COMUNIDAD
		                    $cat
		                    $comunidad
		                    $eraser
		                    $and
	                      ORDER BY $oder
	                      $limit", __FILE__, __LINE__);
	                      
	  $context['temas'][$name] = array();
	  
	  $context[$name]['count'] = mysql_num_rows($request);
	  
	  while ($row = mysql_fetch_assoc($request)){

		 $context['temas'][$name][] = array(
		     'id' => $row['ID_TEMA'],  
		     'titulo' => censorText($row['titulo']), 
		     'title' => censorText($row['title']),
		     'id_comunidad' => $row['ID_COMUNIDAD'],  
		     'id_categoria' => $row['ID_BOARD'],  
		     'id_subcategoria' => $row['ID_BOARD2'],  
		     'name' => $row['realName'],  
		     'cuerpo' => censorText(parse_bbc($row['cuerpo'])),
		     'id_admin' => $row['ID_MEMBER_STARTED'],  
		     'is_admin' => $row['ID_MEMBER_STARTED']==$ID_MEMBER ? true:false,  
		     'id_updater' => $row['ID_MEMBER_UPDATED'],  
		     'hace' => howlong($row['fecha']), 
		     'fecha_title' => fechaGeneralComunidades($row['fecha']),   
		     'fecha' => $row['fecha'],  
		     'visitas' => $row['visitas'],  
		     'cerrado' => !empty($row['cerrado'])? true:false,  
		     'sticky' => $row['sticky'],  
		     'positivos' => $row['positivos'],  
		     'negativos' => $row['negativos'],  
		     'calificacion' => $row['positivos'] - $row['negativos'],
		     'seguidores' => $row['seguidores'],  
		     'favoritos' => $row['favoritos'],  
		     'popularidad' => $row['popularidad'],  
		     'is_borrador' => !empty($row['borrador']) ? true:false,
		     'borrador' => $row['borrador'] == 1 ? true:false,
		     'eraser' => $row['borrador'],
		     'avatar' => $row['avatar'],
		     'respuestas' => $row['respuestas'],
		);
		
		if ($name == 'all' || $name == 'lista' || !empty($row['ID_TEMA'])){
			$temas[$row['ID_TEMA']] = array(
		     'id' => $row['ID_TEMA'],  
		     'titulo' => censorText($row['titulo']),
		     'id_comunidad' => $row['ID_COMUNIDAD'],  
		     'id_categoria' => $row['ID_BOARD'],  
		     'id_subcategoria' => $row['ID_BOARD2'],  
		     'name' => $row['realName'],    
		     'cuerpo' => censorText(parse_bbc($row['cuerpo'])),
		     'id_admin' => $row['ID_MEMBER_STARTED'],  
		     'is_admin' => $row['ID_MEMBER_STARTED']==$ID_MEMBER ? true:false, 
		     'id_updater' => $row['ID_MEMBER_UPDATED'],  
		     'hace' => howlong($row['fecha']),  
		     'fecha_title' => fechaGeneralComunidades($row['fecha']),  
		     'fecha' => $row['fecha'],  
		     'visitas' => $row['visitas'],  
		     'cerrado' => !empty($row['cerrado'])? true:false,  
		     'sticky' => $row['sticky'],  
		     'positivos' => $row['positivos'],  
		     'negativos' => $row['negativos'],  
		     'calificacion' => $row['positivos'] - $row['negativos'],
		     'seguidores' => $row['seguidores'],  
		     'favoritos' => $row['favoritos'],  
		     'popularidad' => $row['popularidad'],  
		     'is_borrador' => !empty($row['borrador']) ? true:false,
		     'borrador' => $row['borrador'] == 1 ? 1:false,
		     'eraser' => $row['borrador'],
		     'avatar' => $row['avatar'],
		     'respuestas' => $row['respuestas'],
			);
		}
	}
	mysql_free_result($request);
	    
}


// Load a lot of usefull information regarding the community.
function getComunidad($type,$eraser, $setTime){
	global $db_prefix, $txt, $modSettings, $context, $comunidades, $ID_MEMBER;
	                 
	//Limites
	$LimComunidades = !empty($modSettings['comunidades_index']) ? $modSettings['comunidades_index'] : 0;
	
	// FILTRAMOS LAS QUERYS
	switch($type){
	   case 'recientes':
	      $limit = 'LIMIT '.$LimComunidades;
	      $and = 'AND cd.sticky = 0';
	      $oder = 'cd.ID_COMUNIDAD DESC';
	   break;
	   case 'populares':
	      $limit = 'LIMIT '.$LimComunidades;
	      $and = 'AND cd.sticky = 0';
	      $oder = 'cd.visitas, cd.miembros DESC';
	   break;
	   case 'destacada':
	      $limit = 'LIMIT 1';
	      $and = '';
	      $oder = 'cd.ID_COMUNIDAD DESC';
	   break;
	   case 'SetTime':
	   case 'SetTime2':
	      $limit = 'LIMIT 10';
	      $and = "AND cd.fecha > {$setTime}";
	      $oder = 'cd.popularidad DESC';
	   break;
	   case 'SetTime3':
	      $limit = 'LIMIT 10';
	      $and = "";
	      $oder = 'cd.popularidad DESC';
	   break;
	   default:
	      $type = 'query';
	      $limit = '';
	      $and = '';
	      $oder = 'cd.ID_COMUNIDAD DESC';
	   break;
	}
	
	$eraser = !empty($eraser) ? 'AND cd.borrador = '.$eraser:'AND cd.borrador = 0';
	
	// query llena de filtros
	  $request = db_query("SELECT cd.ID_COMUNIDAD, cd.ID_MEMBER_STARTED, cd.titulo, cd.ID_BOARD, cd.ID_BOARD2, cd.portada, 
	                              cd.descripcion, cd.background, cd.validacion, cd.rango, cd.borrador, cd.popularidad,
	                              cc.type, cd.sticky, cd.privado, cd.visitas, cd.miembros, cd.seguidores, cd.temas, cd.fecha,
	                              m.ID_MEMBER, m.realName, cc.ID_BOARD, cc.memberGroups, cc.name
		                    FROM ({$db_prefix}comunidades as cd, {$db_prefix}comunidades_categorias as cc, {$db_prefix}members as m)
		                    WHERE cd.ID_MEMBER_STARTED = m.ID_MEMBER
		                    AND cc.ID_BOARD = cd.ID_BOARD
		                    AND cc.type = 0
		                    $eraser
		                    $and
	                      ORDER BY $oder
	                      $limit", __FILE__, __LINE__);
	  $context['comunidad'][$type] = array();
	  
	  while ($row = mysql_fetch_assoc($request)){

		 $context['comunidad'][$type][] = array(
			   'tipo' => $row['validacion'],
			   'bname' => $row['name'],
			   'temas' => $row['temas'],
			   'fecha' => $row['fecha'],
			   'rango' => $row['rango'],
			   'sticky' => $row['sticky'],
			   'id' => $row['ID_COMUNIDAD'],
			   'portada' => $row['portada'],
			   'miembros' => $row['miembros'],
			   'follows' => $row['seguidores'],
			   'postername' => $row['realName'],
			   'groups' => $row['memberGroups'],
			   'id_categoria' => $row['ID_BOARD'],
			   'background' => $row['background'],
			   'descripcion' => censorText($row['descripcion']),
			   'id_subcategoria' => $row['ID_BOARD2'],
			   'popularidad' => $row['popularidad'],
			   'titulo' => censorText($row['titulo']),
			   'idmember' => $row['ID_MEMBER_STARTED'],
			   'is_borrador' => !empty($row['borrador'])? true:false,
			   'privacidad' => $row['privado'] ? $txt['comunidades_privacy-only-user'] : $txt['comunidades_privacy-public'],
		);
		
		if ($type == 'query' && !empty($row['ID_COMUNIDAD'])){
			$comunidades[$row['ID_COMUNIDAD']] = array(
			   'bname' => $row['name'],
			   'temas' => $row['temas'],
			   'fecha' => $row['fecha'],
			   'rango' => $row['rango'],
			   'sticky' => $row['sticky'],
			   'id' => $row['ID_COMUNIDAD'],
			   'portada' => $row['portada'],
			   'miembros' => $row['miembros'],
			   'follows' => $row['seguidores'],
			   'postername' => $row['realName'],
			   'id_categoria' => $row['ID_BOARD'],
			   'background' => $row['background'],
			   'descripcion' => censorText($row['descripcion']),
			   'id_subcategoria' => $row['ID_BOARD2'],
			   'popularidad' => $row['popularidad'],
			   'titulo' => censorText($row['titulo']),
			   'idmember' => $row['ID_MEMBER_STARTED'],
			   'soyadmin' => $row['ID_MEMBER_STARTED'] == $ID_MEMBER ? true:false,
			   'groups' => explode($row['memberGroups']), // con esto filtramos los usuarios que no pueden ver las categorias
			   'is_borrador' => !empty($row['borrador'])? true:false,
			   'poster' => $row['ID_MEMBER'] == $ID_MEMBER ? true:false,
			   'tipo' => $row['validacion']==1 || $row['validacion']==2 ? true:false,
			   'privacidad' => $row['privado']==0 ? $txt['comunidades_privacy-public']:($row['privado']==1 ? $txt['comunidades_privacy-only-user']:($row['privado']==2 ? $txt['comunidades_privacy-only-members']:(''))),
			   'privacidad2' => $row['privado'],
			   'tipo2' => $row['validacion']==0 ? 0:($row['validacion']==1 ? 0:($row['validacion']==2 ? $row['validacion']:($row['validacion']==3 ?$row['validacion']:0))),
			   'val' => $row['validacion'],
			   'validacion' => $row['validacion']== 0 ? $txt['comunidades_null']:($row['validacion']== 1 ? $txt['comunidades_validate_auto']:($row['validacion']== 2 ? $txt['comunidades_validate_admin']:($row['validacion']== 3 ? $txt['comunidades_validate_no']: ''))),
			   'validacion2' => $row['validacion'],
			   
			   'validation' => array(
			                   'index' => $row['validacion']==1 || $row['validacion']==2 ? true:false,
			                   'tipo' => $row['validacion'],
			                   'txt' => $row['validacion'] == 1? $txt['comunidades_validate_auto']:($row['validacion'] == 2? $txt['comunidades_validate_admin']:($row['validacion'] == 3? $txt['comunidades_validate_no']:'')),
			                   'range' => $row['validacion'] == 1 ? true: false,
			                   'rango' => $row['rango'],
			                   ),
			   'is_admin' => $row['ID_MEMBER_STARTED'] == $ID_MEMBER ? true:false,
			   /*'rango' => $row['ID_RANGO'],*/
			   'privacity' => array(
			                  'tipo' => $row['privado'],
			                  'txt' => $row['privado'] == 0 ? $txt['comunidades_privacy-public']:($row['privado']== 1 ? $txt['comunidades_privacy-only-user']:($row['privado']== 2 ? $txt['comunidades_privacy-only-members']:'')),
			                  ),
			);
		}
	}
	mysql_free_result($request);
	    
}


/* funcion de fechas recomendable */
function fechaGeneralComunidades($time){
	global $txt;
	$fecha =  date('d.m.Y',$time).' '.$txt['comunidades_cuando'].' '.date('H:i',$time).' hs.';
	return $fecha;
}


function dias_mes($time){
	global $txt;
	$valor =  date('m',$time);
	
	   $meses = array(
              '01' => '31',
              '02' => '29',
              '03' => '31',
              '04' => '30',
              '05' => '31',
              '06' => '30',
              '07' => '31',
              '08' => '31',
              '09' => '30',
              '10' => '31',
              '11' => '30',
              '12' => '31',
              );

	return $meses[$valor];
}

// Load a lot of usefull information regarding the categories.
function getCategorias($i){
	global $db_prefix, $cat_tree, $boards, $boardList, $txt, $modSettings, $context;

	// Getting all the board and category information you'd ever wanted.
	$request = db_query("SELECT ID_BOARD, name, boardOrder, memberGroups, type
		                   FROM {$db_prefix}comunidades_categorias
		                   WHERE type = '$i'
			                 ORDER BY boardOrder", __FILE__, __LINE__);
			                 
	$context['categorias'] = array();
	
	while ($row = mysql_fetch_assoc($request)){
		$context['categorias'][] = array(
			'id' => $row['ID_BOARD'],
			'order' => $row['boardOrder'],
			'name' => $row['name'],
			'bname' => explode(' ',$row['name']),
			'tipo' => $row['type'],
			'memberGroups' => explode(',', $row['memberGroups']),
		);
		
		if (!empty($row['ID_BOARD'])){
			$boards[$row['ID_BOARD']] = array(
				'id' => $row['ID_BOARD'],
				'order' => $row['boardOrder'],
				'name' => $row['name'],
			  'bname' => explode(' ',$row['name']),
				'memberGroups' => explode(',', $row['memberGroups'])
			);
		}
	}
	mysql_free_result($request);
}


// Modify the settings and position of a board.
function modifyCategorias($board_id, &$boardOptions){
	global $sourcedir, $cat_tree, $boards, $boardList, $modSettings, $db_prefix, $context;
	global $func;

	// Get some basic information about all boards and categories.
	getCategorias('0');

	// Make sure given boards and categories exist.
	if (!isset($boards[$board_id]))
		fatal_lang_error('smf232');

	// All things that will be updated in the database will be in $boardUpdates.
	$boardUpdates = array();

	// Who's allowed to access this board.
	if (isset($boardOptions['access_groups']))
		$boardUpdates[] = 'memberGroups = \'' . implode(',', $boardOptions['access_groups']) . '\'';

	if (isset($boardOptions['board_name']))
		$boardUpdates[] = 'name = \'' . $boardOptions['board_name'] . '\'';

	// Do the updates (if any).
	if (!empty($boardUpdates))
		$request = db_query("
			UPDATE {$db_prefix}comunidades_categorias
			SET
				" . implode(',
				', $boardUpdates) . "
			WHERE ID_BOARD = $board_id
			LIMIT 1", __FILE__, __LINE__);

	// Set moderators of this board.
	if (isset($boardOptions['moderators']) || isset($boardOptions['moderator_string'])){
		// Reset current moderators for this board - if there are any!
		db_query("
			DELETE FROM {$db_prefix}moderators
			WHERE ID_BOARD = $board_id", __FILE__, __LINE__);

		// Validate and get the IDs of the new moderators.
		if (isset($boardOptions['moderator_string']) && trim($boardOptions['moderator_string']) != '')
		{
			// Divvy out the usernames, remove extra space.
			$moderator_string = strtr(addslashes($func['htmlspecialchars'](stripslashes($boardOptions['moderator_string']), ENT_QUOTES)), array('&quot;' => '"'));
			preg_match_all('~"([^"]+)"~', $moderator_string, $matches);
			$moderators = array_merge($matches[1], explode(',', preg_replace('~"([^"]+)"~', '', $moderator_string)));
			for ($k = 0, $n = count($moderators); $k < $n; $k++)
			{
				$moderators[$k] = trim($moderators[$k]);

				if (strlen($moderators[$k]) == 0)
					unset($moderators[$k]);
			}

			// Find all the ID_MEMBERs for the memberName's in the list.
			$boardOptions['moderators'] = array();
			if (!empty($moderators))
			{
				$request = db_query("
					SELECT ID_MEMBER
					FROM {$db_prefix}members
					WHERE memberName IN ('" . implode("','", $moderators) . "') OR realName IN ('" . implode("','", $moderators) . "')
					LIMIT " . count($moderators), __FILE__, __LINE__);
				while ($row = mysql_fetch_assoc($request))
					$boardOptions['moderators'][] = $row['ID_MEMBER'];
				mysql_free_result($request);
			}
		}

		// Add the moderators to the board.
		if (!empty($boardOptions['moderators']))
		{
			$setString = '';
			foreach ($boardOptions['moderators'] as $moderator)
				$setString .= "
						($board_id, $moderator),";

			db_query("
				INSERT INTO {$db_prefix}moderators
					(ID_BOARD, ID_MEMBER)
				VALUES" . substr($setString, 0, -1), __FILE__, __LINE__);
		}
	}
}


// Remove one or more boards.
function deleteCategorias($boards_to_remove, $moveChildrenTo = null)
{
	global $db_prefix, $sourcedir, $boards, $modSettings;

	// No boards to delete? Return!
	if (empty($boards_to_remove))
		return;

	getCategorias('0');

	// Delete ALL topics in the selected boards (done first so topics can't be marooned.)
	$request = db_query("
		SELECT ID_COMUNIDAD
		FROM {$db_prefix}comunidades
		WHERE ID_BOARD IN (" . implode(', ', $boards_to_remove) . ')', __FILE__, __LINE__);
	$topics = array();
	while ($row = mysql_fetch_assoc($request))
		$topics[] = $row['ID_COMUNIDAD'];
	mysql_free_result($request);
	
	removeComunidades($topics, false);

	// Delete this board's moderators.
	db_query("
		DELETE FROM {$db_prefix}moderators
		WHERE ID_BOARD IN (" . implode(', ', $boards_to_remove) . ')', __FILE__, __LINE__);

	// Delete the boards.
	db_query("
		DELETE FROM {$db_prefix}comunidades_categorias
		WHERE ID_BOARD IN (" . implode(', ', $boards_to_remove) . ")
		LIMIT " . count($boards_to_remove), __FILE__, __LINE__);
		
	// Delete the boards.
	db_query("
		DELETE FROM {$db_prefix}comunidades
		WHERE ID_BOARD IN (" . implode(', ', $boards_to_remove) . ")
		LIMIT " . count($boards_to_remove), __FILE__, __LINE__);

	// Latest message/topic might not be there anymore.
	updateStats('comunidades');

	reorderCategorias();
}

// Put all boards in the right order.
function reorderCategorias()
{
	global $db_prefix, $cat_tree, $boardList, $boards;

	getCategorias('0');

	// Set the board order for each category.
	$boardOrder = 0;
	foreach ($cat_tree as $catID => $dummy)
	{
		foreach ($boardList[$catID] as $boardID)
			if ($boards[$boardID]['order'] != ++$boardOrder)
				db_query("
					UPDATE {$db_prefix}comunidades_categorias
					SET boardOrder = $boardOrder
					WHERE ID_BOARD = $boardID
					LIMIT 1", __FILE__, __LINE__);
	}

	// Sort the records of the boards table on the boardOrder value.
	db_query("
		ALTER TABLE {$db_prefix}comunidades_categorias
		ORDER BY boardOrder", __FILE__, __LINE__);
}

// Removes the passed ID_TOPICs. (permissions are NOT checked here!)
function removeComunidades($topics, $decreasePostCount = true, $ignoreRecycling = false){
	global $db_prefix, $sourcedir, $modSettings;

	// Nothing to do?
	if (empty($topics))
		return;
	// Only a single topic.
	elseif (is_numeric($topics))
	{
		$condition = '= ' . $topics;
		$topics = array($topics);
	}
	elseif (count($topics) == 1)
		$condition = '= ' . $topics[0];
	// More than one topic.
	else
		$condition = 'IN (' . implode(', ', $topics) . ')';

	// Decrease the post counts.
	if ($decreasePostCount){
			$requestMembers = db_query("
			SELECT c.ID_MEMBER, COUNT(*) AS comunidades
			FROM ({$db_prefix}comunidades as c,{$db_prefix}comunidades_categorias as cc)
			WHERE ID_COMUNIDAD $condition
			AND c.ID_BOARD = cc.ID_BOARD
			GROUP BY c.ID_MEMBER", __FILE__, __LINE__);

		if (mysql_num_rows($requestMembers) > 0){

			while ($rowMembers = mysql_fetch_assoc($requestMembers)) {

				updateMemberData($rowMembers['ID_MEMBER'], array('comunidades' => 'comunidades - ' . $rowMembers['comunidades']));

		  }
		mysql_free_result($requestMembers);
	  }
  }

	// Decrease the topic count for member.

	if ($decreasePostCount){

			$requestMembers = db_query("
			SELECT c.ID_MEMBER_STARTED
			FROM ({$db_prefix}comunidades as c,{$db_prefix}comunidades_categorias as cc)
			WHERE ID_COMUNIDAD $condition
			AND c.ID_BOARD = cc.ID_BOARD
			", __FILE__, __LINE__);

			while ($rowMembers = mysql_fetch_assoc($requestMembers))

				updateMemberData($rowMembers['ID_MEMBER_STARTED'], array('comunidades' => 'comunidades - 1'));

		mysql_free_result($requestMembers);

	}

	// Still topics left to delete?
	if (empty($topics))
		return;

	$adjustBoards = array();

	// Find out how many posts we are deleting.
	$request = db_query("
		SELECT ID_BOARD, COUNT(*) AS comunidades
		FROM {$db_prefix}comunidades
		WHERE ID_COMUNIDAD $condition
		GROUP BY ID_BOARD", __FILE__, __LINE__);
	while ($row = mysql_fetch_assoc($request))
	{
		// The numReplies is only the *replies*.  There're also the first posts in the topics.
		$adjustBoards[] = array(
			'comunidades' => $row['comunidades'],
			'ID_BOARD' => $row['ID_BOARD']
		);
	}
	mysql_free_result($request);

	// Decrease the posts/topics...
	foreach ($adjustBoards as $stats)
		db_query("
			UPDATE {$db_prefix}comunidades_categorias
			SET 
				comunidades = IF($stats[comunidades] > comunidades, 0, comunidades - $stats[comunidades]),
			WHERE ID_BOARD = $stats[ID_BOARD]
			LIMIT 1", __FILE__, __LINE__);

	// Delete anything related to the topic.
	db_query("
		DELETE FROM {$db_prefix}comunidades
		WHERE ID_COMUNIDAD $condition", __FILE__, __LINE__);

	// Delete other related stuff
	db_query("
		DELETE FROM {$db_prefix}comunidades_comentarios
		WHERE ID_COMUNIDAD $condition", __FILE__, __LINE__);
		
		//eliminando miembros de comunidad
	db_query("
		DELETE FROM {$db_prefix}comunidades_miembros
		WHERE ID_COMUNIDAD $condition", __FILE__, __LINE__);
		
		//eliminando temas de comunidad
	db_query("
		DELETE FROM {$db_prefix}comunidades_temas
		WHERE ID_COMUNIDAD $condition", __FILE__, __LINE__);
		
	db_query("
		DELETE FROM {$db_prefix}comunidades
		WHERE ID_COMUNIDAD $condition
		LIMIT " . count($topics), __FILE__, __LINE__);

	// Update the totals...
	updateStats('comunidades');

	$updates = array();
	foreach ($adjustBoards as $stats)
		$updates[] = $stats['ID_BOARD'];
	updateLastComunidades($updates);
}

// Update the last message in a board, and its parents.
function updateLastComunidades($setboards, $ID_MSG = 0){
	global $db_prefix, $board_info, $board, $modSettings;

	// Please - let's be sane.
	if (empty($setboards))
		return false;

	if (!is_array($setboards))
		$setboards = array($setboards);

	// If we don't know the ID_MSG we need to find it.
	if (!$ID_MSG)
	{
		// Find the latest message on this board (highest ID_MSG.)
		$request = db_query("
			SELECT ID_BOARD, MAX(ID_LAST_CMD) AS ID_CMD
			FROM {$db_prefix}comunidades
			WHERE ID_BOARD IN (" . implode(', ', $setboards) . ")
			GROUP BY ID_BOARD", __FILE__, __LINE__);
		$lastMsg = array();
		while ($row = mysql_fetch_assoc($request))
			$lastMsg[$row['ID_BOARD']] = $row['ID_CMD'];
		mysql_free_result($request);
	}
	else
	{
		foreach ($setboards as $ID_BOARD)
			$lastMsg[$ID_BOARD] = $ID_MSG;
	}

	$parent_boards = array();
	// Get all the child boards for the parents, if they have some...
	foreach ($setboards as $ID_BOARD)
	{
		if (!isset($lastMsg[$ID_BOARD]))
			$lastMsg[$ID_BOARD] = 0;

		if (!empty($board) && $ID_BOARD == $board)
			$parents = $board_info['parent_boards'];
		else
			$parents = getBoardParents($ID_BOARD);

		// Ignore any parents on the top child level.
		foreach ($parents as $id => $parent)
		{
			if ($parent['level'] == 0)
				unset($parent[$id]);
			else
			{
				// If we're already doing this one as a board, is this a higher last modified?
				if (isset($lastMsg[$id]) && $lastMsg[$ID_BOARD] > $lastMsg[$id])
					$lastMsg[$id] = $lastMsg[$ID_BOARD];
				elseif (!isset($lastMsg[$id]) && (!isset($parent_boards[$id]) || $parent_boards[$id] < $lastMsg[$ID_BOARD]))
					$parent_boards[$id] = $lastMsg[$ID_BOARD];
			}
		}
	}

	$board_updates = array();
	$parent_updates = array();
	// Finally, to save on queries make the changes...
	foreach ($parent_boards as $id => $msg)
	{
		if (!isset($parent_updates[$msg]))
			$parent_updates[$msg] = array($id);
		else
			$parent_updates[$msg][] = $id;
	}

	foreach ($lastMsg as $id => $msg){
		if (!isset($board_updates[$msg]))
			$board_updates[$msg] = array($id);
		else
			$board_updates[$msg][] = $id;
	}

	foreach ($board_updates as $ID_MSG => $boards){
		db_query("
			UPDATE {$db_prefix}comunidades_categorias
			SET ID_LAST_CMD = $ID_MSG
			WHERE ID_BOARD IN (" . implode(',', $boards) . ")
			LIMIT " . count($boards), __FILE__, __LINE__);
	}
}
/***** END COMUNIDADES BY MR.FREACK & FIVEZONE *****/
?>
