<?php
if(!defined('SPIRATE')) die('Are you serius?');


function stream(){
    global $context, $txt, $sourcedir, $boardir, $modSettings, $sourcedir, $stream, $ID_MEMBER, $scripturl, $settings,$db_connection;
	
	// disabled activity stream? ok! You didn't see anything...
    if(false && !$modSettings['enabled_activity_stream']){
        require_once($sourcedir . '/Recent.php');
        RecentPosts();
        return false;
    }
	
	// define 'stream' class
	require_once( $sourcedir . '/classes/stream.class.php' );
	$stream = new stream();
	 
	// set language
	if(loadLanguage('stream') == false)
	   loadLanguage('stream', 'english');
	
    // define template
    loadTemplate('stream');	
	
	// define sub actions
	$sub_actions = array(
		'ajax' => 'ajax_requests',
		'view-stream' => 'view_stream'
	);
	
	// set stream settings
    $context['stream'] = array(
		'url' => $scripturl . '?action=stream',
		'me' => array()
	);
	
    // title page
    $context['page_title'] = '&Uacute;ltimas actividades';
	
	// add script tag to header	
	$context['html_headers'][] = '<script type="text/javascript" src="' . $settings['theme_url'] . '/jquery.overscroll.min.js?update"></script>';
	$context['html_headers'][] = '<script type="text/javascript" src="' . $settings['theme_url'] . '/stream.js?version='.( $_SERVER['HTTP_HOST'] == 'localhost' ? '?upd=' . time() : '0.1' ).'"></script>';
	
	// call the sub action if is called
	if( isset($_GET['do']) && !empty($sub_actions[$_GET['do']]) )
		$sub_actions[$_GET['do']]();
	else
		news_feed();
	
	/* DEBUG 
	db_query("TRUNCATE smf_activity_attachments");
	db_query("TRUNCATE smf_activity_likes");
	db_query("TRUNCATE smf_activity_stream");
	db_query("TRUNCATE smf_activity");
	db_query("TRUNCATE smf_followers");
	db_query("UPDATE smf_members SET streams = 0, followers = 0");
	*/
	
}

function news_feed(){
    global $context, $sourcedir, $settings, $modSettings, $txt, $ID_MEMBER, $scripturl, $stream, $db_prefix, $user_settings;
	
	// construct filter tabs
	$tabs = array(
	
		'navigation' => array(
			'default' => array('text' => 'Todas las actualizaciones'),
			'followers' => array('text' => 'Seguidores'),
			'notifications' =>  array('text' => 'Notificaciones', 'display_filters' => false),
			'activities' => array('text' => 'Actividades', 'display_filters' => false)
		),
		
		'filter' => array(
			'recents' => array('text' => 'recientes'),
			'featured' => array('text' => 'destacadas'),
			'public' => array('text' => 'p&uacute;blicas')
		)
		
	);
	
	
	foreach( $tabs as $type => $tab )
	{		
	
		$request_name = $type == 'navigation' ? 'filter' : 'type';
		$request_tab = $type == 'navigation' ? 'type' : 'filter';
		$keys_tab = array_keys($tabs[$type]);
		
		foreach( $tab as $id => $data)
		{
			if( isset($_GET[$request_name]) && in_array($_GET[$request_name], array_keys($tabs[$request_name == 'type' ? 'navigation' : $request_name])))
			{
				$requests = array(
					'type' => isset($_GET['type']) && $_GET['type'] == $_GET[$request_name] ? $_GET['type'] : $id,
					'filter' => isset($_GET['filter']) && $_GET['filter'] == $_GET[$request_name] ? $_GET['filter'] : $id
				);
				
				$tabs[$type][$id]['href'] = sprintf('%s&type=%s&filter=%s', $context['stream']['url'], $requests['type'], $requests['filter']);
			}
			else
				$tabs[$type][$id]['href'] = $context['stream']['url'] . '&' . $request_tab . '=' . $id;
				
			if(isset($_GET[$type == 'navigation' ? 'type' : 'filter']) && $id == $_GET[$request_tab]){
				$tabs[$type][$id]['selected'] = true;
				$context['stream']['nav_tab_selected'] = $id;
			}
			else if( !isset($_GET[$request_tab])  || !in_array($_GET[$request_tab], $keys_tab))				
				$tabs[$type][$keys_tab[0]]['selected'] = true;			
		}
	}
	
	
	// this tab need filters?
	if( 
		isset($_GET['type']) && 
		in_array($_GET['type'], array_keys($tabs['navigation'])) && 
		isset($tabs['navigation'][$_GET['type']]['display_filters']) && 
		$tabs['navigation'][$_GET['type']]['display_filters'] === false
	  )
		$tabs['filter'] = array();
	
	$context += array(
		'navigation' => $tabs['navigation'],
		'filter' => $tabs['filter']
	);
	
	if(empty($ID_MEMBER))
	{
		
		unset($context['filter']['featured']);
		unset($context['filter']['recents']);
		$context['filter']['public'] = array(
			'text' => 'Historias p&uacute;blicas',
			'selected' => true
		);
		
	}
	
	$context['stream'] += array(
		'stories' => $stream->loadActivities(0, (isset($_GET['filter']) ? $_GET['filter'] : 'recent')),		
		'user' => array(
			'privacy' => $stream->getPrivacyUser('post'),
			'allow_post_comments' => $stream->getPrivacyUser('allow_comments') ? true : false,
			'streams' => $user_settings['streams'],
			'followers' => $user_settings['followers'],
			'follwing' => $user_settings['following']
		)
	);
	
	if( isset($context['stream']['stories']['errors']) ){
	
		foreach( $context['stream']['stories']['errors'] as $error )
			$context['stream']['stories'][] = array(
				'story' => array(
					'type' => 'error',
					'body' => $txt['stream_' . $error['txt']],
					'class' => $error['class']
				),
			);
	
	}
	
	$privacy_stream = array(
		array('P&uacute;blico', 'Todos sin excepcion pueden ver tus publicaciones.', false),
		array('Seguidores y amigos', 'Tanto tus seguidores como tus amigos pueden ver tus publicaciones.', false),
		array('S&oacute;lo seguidores', 'S&oacute;lo tus seguidores pueden ver tus publicaciones.', false),
		array('S&oacute;lo amigos', 'S&oacute;lo tus amigos pueden ver tus publicaciones.', false),
		array('Oculto', 'S&oacute;lo t&uacute; puedes ver tus publicaciones.', false)
	);
	
	if( $context['stream']['user']['privacy'] !== false )
		$privacy_stream[$context['stream']['user']['privacy']][2] = true;
	
	// set online followings
	$request = db_query("SELECT uid as ID_MEM, mem.memberName, mem.avatar, mem.avatar_coords
						 FROM {$db_prefix}followers, {$db_prefix}log_online as l
						 LEFT JOIN {$db_prefix}members as mem ON(mem.ID_MEMBER = l.ID_MEMBER)
						 WHERE uif = $ID_MEMBER
						 AND uid = l.ID_MEMBER
						 LIMIT 15");
	$following_online = array();
	while($row = mysql_fetch_assoc($request))
		$following_online[] = array(
			'id' => $row['ID_MEM'],
			'name' => $row['memberName'],
			'avatar' => array(
				'src' => $row['avatar'],
				'coords' => makeAvatarCoords($row['avatar_coords'], 32, true)
			)
		);
	mysql_free_result($request);
	
	$recommended_users = array();
	
	# && count($stream->followers) < 100
	
	$fs = implode(',', $stream->followers);
	
	if( !empty($stream->followers) ){
		
		// set recommended users
		
		# AND followers > 0
		$result = db_query("SELECT SUM(followers) AS total_following_followers
							FROM {$db_prefix}members, {$db_prefix}followers
							WHERE uif IN($fs)
							AND uid NOT IN ($fs)
							AND uid != $ID_MEMBER
							AND ID_MEMBER = uid
							GROUP BY uid",__FILE__,__LINE__);
		list($tff) = mysql_fetch_row($result);
		
		mysql_free_result($result);
		
		if( !empty($tff) ){
		
			$result = db_query("SELECT ID_MEMBER, memberName, avatar, avatar_coords, followers,
								ROUND((followers*100)/$tff) as relevance
								FROM {$db_prefix}members, {$db_prefix}followers
								WHERE uif IN($fs)
								AND uid NOT IN ($fs)
								AND uid != $ID_MEMBER
								AND ID_MEMBER = uid
								GROUP BY uid
								ORDER BY relevance DESC, ID_MEMBER ASC
								LIMIT 5",__FILE__,__LINE__);
			
			while($row = mysql_fetch_assoc($result))						
				$recommended_users[] = array(
					'id' => $row['ID_MEMBER'],
					'name' => $row['memberName'],
					'avatar' => array(
							'src' => $row['avatar'],
							'coords' => makeAvatarCoords($row['avatar_coords'], 32, true)
						),
					'followers' => $row['followers'],
					'followers-txt' => vsprintf('%s%s', empty($row['followers']) ? array(null, 'sin seguidores') : (array($row['followers'], $row['followers'] == 1 ? ' seguidor' : ' seguidores')))
				);
			
			mysql_free_result($result);
		
		}
	
	}
	else if (!empty($ID_MEMBER))
	{
	
		$result = db_query("SELECT ID_MEMBER, memberName, avatar, avatar_coords, followers
							FROM {$db_prefix}members
							WHERE ID_MEMBER != $ID_MEMBER
							ORDER BY followers DESC
							LIMIT 5",__FILE__,__LINE__);
		
		while($row = mysql_fetch_assoc($result))						
			$recommended_users[] = array(
				'id' => $row['ID_MEMBER'],
				'name' => $row['memberName'],
				'avatar' => array(
						'src' => $row['avatar'],
						'coords' => makeAvatarCoords($row['avatar_coords'], 32, true)
					),
				'followers' => $row['followers'],
				'followers-txt' => vsprintf('%s%s', empty($row['followers']) ? array(null, 'sin seguidores') : (array($row['followers'], $row['followers'] == 1 ? ' seguidor' : ' seguidores')))
			);
		
		mysql_free_result($result);
	
	}
	
	
	$context['stream'] += array(
		'privacy-post' => $privacy_stream,
		'following-online' => $following_online,
		'recommended_users' => $recommended_users
	);
	
	// layers
    $context['template_layers'][] = 'stream';
    
}
function view_stream(){
	global $context, $ID_MEMBER, $modSettings, $settings, $stream;
	
	
	$context['sub_template'] = 'view_stream';
	
	
}
function ajax_requests(){
	global $context, $stream, $ID_MEMBER, $db_prefix;
	
	if( !$context['ajax_request'] )
		die();
	
	$areas = array(
		'check-attach',
		'set-privacy-post',
		'add-story',
		'add-like',
		're-stream',
		'send-subcomment',
		'see-all',
		'see-all-likes',
		'delete-sub',
		'delete-story'
	);
	
	if(isset($_GET['work']) && in_array($_GET['work'], $areas))
	{
		
		switch( $_GET['work'] )
		{
		
			case 'set-privacy-post':
			
				$updated = $stream->setPrivacyUser('post', $_POST['privacy']);
				
				if( $updated )
					json_return(array('status' => 'ok', 'message' => 'privacy:' . $updated), true);
				else
					json_return(array('status' => 'error', 'message' => 'Hubo un error al solicitar lo procesado'), true);
								
			break;
			
			case 'check-attach':
			
				// if( $_SERVER['REMOTE_ADDR'] == '127.0.0.1' )
					// return json_return(array('status' => 'error', 'message' => 'not allowed'), true);;
			
				$data = $stream->checkAttach($_POST['link'], $_POST['force_type'] ? true : false, $_POST['force_type'] ? $_POST['type'] : false, true);
				
				json_return(array('status' => 'ok', 'data' => $data), true);
			
			break;
			
			case 'add-story':
			
				// if( $_SERVER['REMOTE_ADDR'] == '127.0.0.1' )
					// return json_return(array('status' => 'error', 'message' => 'not allowed'), true);;
					
				if( empty($ID_MEMBER) )
					json_return(array('status' => 'error', 'message' => 'Tienes que loguearte para poder publicar.'), true);
				
				$with_attach = isset($_POST['attach_on']);
				
				$story_ID = $stream->addActivity($_POST['type'], "[user, $ID_MEMBER]", "[user, $ID_MEMBER]", array(
					'attach_on' => $_POST['attach_on'],
					'message' => $_POST['message'],
					'disabled_comments' => (int) $_POST['disabled_comments'] ? true : false,
					'privacy' => (int) $_POST['privacy'],
					'attach_data' => array(
						'url' => isset($_POST['url']) ? $_POST['url'] : false,
						'thumbnail' => isset($_POST['thumbnail']) ? $_POST['thumbnail'] : false,
						'image_scroll_top' => isset($_POST['coord-top']) ? (int)$_POST['coord-top'] : false,
						'image_scroll_left' => isset($_POST['coord-left']) ? (int)$_POST['coord-left'] : false
					)
				)
				);
				
				if( $story_ID && !empty($story_ID) ){
				
				
					if( !in_array($_POST['type'], array('follow', 'change_avatar')) ){
					
						$result = db_query("SELECT a.id, s.ID_ATTACH, s.msg, s.thumbnail, s.coords_thumbnail,
											m.memberName, m.avatar, m.avatar_coords, att.params
											FROM {$db_prefix}activity as a
											LEFT JOIN {$db_prefix}activity_stream as s ON (s.activity_id = a.id )
											LEFT JOIN {$db_prefix}members AS m ON( m.ID_MEMBER = a.subject)
											LEFT JOIN {$db_prefix}activity_attachments AS att ON( att.ID_ATTACH = s.ID_ATTACH)
											WHERE a.id = $story_ID",__FILE__,__LINE__);
						
						$r = mysql_fetch_assoc($result);
						mysql_free_result($result);
						
						
						if( !empty($r['ID_ATTACH']) )						
							$params = unserialize($r['params']);
						
						$templates = array(
							'video' => '
								{{if thumbnail}}
								<div class="thumbnail clearfix">
									<img src="${thumbnail}" width="180">
									<a class="play-icon"></a>
								</div>
								{{/if}}
								<div class="attachText clearfix">
									<a href="${url}">${title}</a>
									<span>${description}</span>
								</div>',
							'swf' => '
								<embed width="${width}" height="${height}" wmode="transparent" autoplay="false" allownetworking="internal" allowscriptaccess="never" allowfullscreen="true" type="application/x-shockwave-flash" quality="high" src="${src}" class="swf-untrusted">
							',
							'link' => '
								{{if thumbnail}}
								<div class="thumbnail clearfix">
									<img src="${thumbnail}">
								</div>
								{{/if}}
								<div class="attachText clearfix">
									<h3>${title}</h3>
									<a href="${url}" target="_blank">${url}</a>
									<span>${description}</span>										
								</div>
								{{if domain}}
								<i class="favicon" style="background: url(http://www.google.com/s2/favicons?domain=${domain})"></i>
								{{/if}}
							',
							'image' => '
								<a><img {{if align}}style="${align}"{{/if}} src="${src}"></a>
							',
						);
						
						$template = $templates[isset($params['type']) ? $params['type']: $_POST['type']];
						
						if( $r['coords_thumbnail'] ){
							$offset_thumbnail = unserialize($r['coords_thumbnail']);
							$coordThumbnail =  ($offset_thumbnail['top'] ? sprintf('top: -%dpx; ', $offset_thumbnail['top']) : '') .
												($offset_thumbnail['left'] ?  sprintf('left: -%dpx; ', $offset_thumbnail['left']) : '');
						}
						
						if($params['type'] == 'swf'){
							$params['width'] > 372 ? 372 : $params['width'];
							$params['height'] > 350 ? 350 : $params['height'];
						}
						
						$make_json = array(
							'story_time' => hace(time()-1),
							'story_action' => $stream->getActionTextByType($_POST['type']),
							'story_date' => date('Y-m-d g:i:s'),
							'story_type' => $_POST['type'],
							'message' => $stream->parseActivityMsg($r['msg']),
							'attach_on' => !empty($r['ID_ATTACH']) ? true : false,
							'avatar_src' => $r['avatar'],
							'avatar_coords' => makeAvatarCoords($r['avatar_coords'], 48, true),
							'member_href' => $scripturl . '?action=profile&u=' . $ID_MEMBER,
							'member_name' => $r['memberName'],
							'attach_thumbnail' => isset($r['thumbnail']) && !empty($r['thumbnail']) ? true : false,
							'template' => $template
						);
						
						foreach( $params as $key => $val )
							$make_json['attach_data'][$key] = $val;
							
						if( isset($r['thumbnail']) && !empty($r['thumbnail']) )
							$make_json['attach_data']['thumbnail'] = $r['thumbnail'];
							
						if( isset($coordThumbnail) )
							$make_json['attach_data']['align'] = $coordThumbnail;
												
						json_return(array('status' => 'ok', 'data' => $make_json), true);
						
					}
					
			
					json_return(array('status' => 'ok', 'data' => $story_ID), true);
				
				}
				else
					json_return(array('status' => 'error', 'message' => 'ocurrio un error al intentar agregar tu historia.'), true);
			
			break;
			
			case 'add-like':
				
				if( !$stream->addLike($_POST['story']) )
					json_return(array('status' => 'error', 'message' => 'ocurrio un error al intentar dar like.'), true);
				else
					json_return(array('status' => 'ok', 'message' => 'liked.'), true);
				
			break;
			
			case 're-stream':
				
				$stream->addReStream($_POST['story']);
				json_return(array('status' => 'ok', 'message' => 'shared.'), true);
				
				
			break;
			
		
			
			case 'send-subcomment':
			
				$s = (INT) $_POST['story'];
				$i = htmlspecialchars($_POST['comment'], ENT_QUOTES, 'UTF-8');
				
				if(empty($i) or empty($s)){
					json_return(array('status' => 'error', 'message' => 'Error detected'), true);
				}
				
				if( empty($ID_MEMBER) )
					json_return(array('status' => 'error', 'message' => 'Tienes que loguearte para poder publicar.'), true);
			
				$time = time();
				
				$da = db_query("INSERT INTO {$db_prefix}substream (ID_STREAM_COMMENT,ID_MEMBER,COMMENT,DATE)
					VALUES( $s, $ID_MEMBER, '$i',$time)",__FILE__,__LINE__);
				
				db_query("UPDATE {$db_prefix}activity_stream SET comments = comments +1 WHERE activity_id = $s LIMIT 1");
			
				$query = db_query("SELECT ID,ID_STREAM_COMMENT,ID_MEMBER,COMMENT 
								   FROM {$db_prefix}substream
								   WHERE ID_STREAM_COMMENT = $s
								   AND ID_MEMBER = $ID_MEMBER
								   AND COMMENT = '".$i."'
								   AND DATE = $time
								   LIMIT 1
								   ");
				list($id_comment) = mysql_fetch_row($query);
				mysql_free_result($query);	
						
				$data = array();

				$data[] = array(
					'comentario'=> $i,
					'id'=> $id_comment

				);

				json_return(array('status' => 'ok', 'data' => $data), true);

				
			break;
			
			case 'see-all':
			
			$s = (INT) $_POST['story'];

			if(empty($s) && !is_numeric()){
				json_return(array('status' => 'error', 'message' => 'Error'), true);
			}
			
			//Last showed
		$qt = 	 db_query("	SELECT ID,ID_STREAM_COMMENT
						FROM {$db_prefix}substream
						WHERE ID_STREAM_COMMENT  = $s	
						");	
			$total = mysql_num_rows($qt);	
			$limit = $total - 5;
			$c = 'LIMIT '.$limit.', '.$limit.'';
		
			
	
		$queryl = db_query("SELECT ID,ID_STREAM_COMMENT
							FROM {$db_prefix}substream
							WHERE ID_STREAM_COMMENT  = $s
							ORDER BY ID ASC
							{$c}");	
		list($id) = mysql_fetch_row($queryl);					
		mysql_free_result($queryl);
	
			$query = db_query("SELECT s.ID AS subid,s.ID_STREAM_COMMENT,s.ID_MEMBER,s.DATE AS dat1,s.comment,m.ID_MEMBER AS memberdid,m.memberName,m.avatar
					 FROM {$db_prefix}substream AS s,{$db_prefix}members AS m
					 WHERE s.ID_STREAM_COMMENT  = $s
					 AND s.ID < $id
					 AND m.ID_MEMBER = s.ID_MEMBER
					 ORDER BY ID ASC
					 ");	
					 
			$data = array();	
			
		
			while ($d = mysql_fetch_assoc($query)){
			
						$delete = false;
						
						if(!empty($ID_MEMBER)){
						
						if(($creator = getCreatorID($s)) == $ID_MEMBER){
							$delete = true;
						}
						
						elseif($ID_MEMBER == $d['memberdid']){
							$delete = true;
						}
						
						}
			
				$data[] = array(
					'avatar'=> $d['avatar'],
					'name'=> $d['memberName'],
					'id'=> $d['subid'],
					'fecha'=> hace($d['dat1']),
					'comment'=>$d['comment'],
					'delete_item' => $delete,
					'iduser' => $d['memberdid']

				);
			}
			
			json_return(array('status' => 'ok', 'data' => $data), true);

			
			break;
			
			case 'delete-sub':
			
				$s = (INT) $_POST['story'];
				
				if(empty($s)){
					json_return(array('status' => 'error', 'message' => 'Error detected'), true);
				}
				
				if( empty($ID_MEMBER) )
					json_return(array('status' => 'error', 'message' => 'Tienes que loguearte para poder publicar.'), true);
			
				$time = time();
				
				db_query("DELETE FROM {$db_prefix}substream WHERE ID = $s ");

				db_query("UPDATE {$db_prefix}activity_stream SET comments = comments -1 WHERE activity_id = $s LIMIT 1");

				

				json_return(array('status' => 'ok'), true);

				
			
			break;
			
			case 'delete-story':
			
				$s = (INT) $_POST['story'];
				
				if(empty($s)){
					json_return(array('status' => 'error', 'message' => 'Error detected'), true);
				}
				
				if( empty($ID_MEMBER) )
					json_return(array('status' => 'error', 'message' => 'Tienes que loguearte para poder publicar.'), true);
			
				
				db_query("DELETE FROM {$db_prefix}activity WHERE id = $s ");
				db_query("DELETE FROM {$db_prefix}activity_likes WHERE ID_STORY = $s ");
				db_query("DELETE FROM {$db_prefix}activity_re_streams WHERE ID_STORY = $s ");
				db_query("DELETE FROM {$db_prefix}activity_stream WHERE activity_id = $s ");
				db_query("DELETE FROM {$db_prefix}substream WHERE ID_STREAM_COMMENT = $s ");
				

				json_return(array('status' => 'ok'), true);

				
			
			break;
			
			case 'see-all-likes':
			
				if(empty($_POST['story']) or !is_numeric($_POST['story']))
					return false;
				$id = (INT )$_POST['story'];
			
				$query = db_query(
					"SELECT s.ID_MEMBER,s.ID_STORY,s.ID_LIKE,m.ID_MEMBER,m.memberName,m.avatar
					FROM {$db_prefix}activity_likes AS s,{$db_prefix}members AS m
					WHERE ID_STORY  = $id
					AND m.ID_MEMBER = s.ID_MEMBER
					ORDER BY s.ID_LIKE DESC
					");	

				$data = array();
			
				while ($d = mysql_fetch_assoc($query)){
					
					$data[] = array(
						'avatar'=> $d['avatar'],
						'membername'=> $d['memberName'],
						'iduser'=> $d['ID_MEMBER']
					);
								
				}
				
			json_return(array('status' => 'ok', 'data' => $data), true);

			
			break;
		}
	
	}
	else
		die(json_encode(array('status' => 'error', 'message' => 'bad request')));

}

function getScaledCoords($mw, $mh = 0, $w, $h){
	global $stream;
	
	return $stream->getScaledCoords($mw, $mh, $w, $h);

}

function getCreatorID($i){
	global $ID_MEMBER,$db_prefix;
	
	if(empty($i) or !is_numeric($i))
			return false;
			
	if( empty($ID_MEMBER) )
		return false;

	$q = db_query("SELECT subject,id
					 FROM {$db_prefix}activity
					 WHERE id = $i
					 LIMIT 1");	
	list($subject) = mysql_fetch_row($q);
	mysql_free_result($q);		
			
	return 	$subject;	
		
}

function getPrivacyStory($i){
	global $ID_MEMBER,$db_prefix;
	
	if(empty($i) or !is_numeric($i))
			return false;
	
	if( empty($ID_MEMBER) )
		return false;				
	
	$q = db_query("SELECT privacy,id
					 FROM {$db_prefix}activity
					 WHERE id = $i
					 LIMIT 1");	
	list($privacy) = mysql_fetch_row($q);
	mysql_free_result($q);

	return $privacy;
			
}

function getPrivacyID($i){
		global $ID_MEMBER,$db_prefix;
	
	if(empty($i) or !is_numeric($i))
			return false;
	
	if( empty($ID_MEMBER) )
		return false;	

			
	if(($creator = getCreatorID($i)) == 0)
		return false;
				
	$q2 = db_query("SELECT stream_allow_comments,ID_MEMBER
					 FROM {$db_prefix}privacy
					 WHERE ID_MEMBER = $creator
					 LIMIT 1");	
	list($allows) = mysql_fetch_row($q2);
	mysql_free_result($q2);
	
	if($ID_MEMBER == $creator)
		$allows = 1;
		
	return $allows;
			
}

function imFollower($i){
	global $ID_MEMBER,$db_prefix;
	
	if(empty($i) or !is_numeric($i))
			return false;
	
	if( empty($ID_MEMBER) )
		return false;	

	if(($creator = getCreatorID($i)) == 0)
		return false;
	
	$q2 = db_query("SELECT uid,uif
					 FROM {$db_prefix}followers
					 WHERE uid  = $creator
					 AND uif = $ID_MEMBER
					 LIMIT 1");	
	$exist = mysql_num_rows($q2);

	return $exist;

}

function imFriend($i){
	global $ID_MEMBER,$db_prefix;
	
	if(empty($i) or !is_numeric($i))
			return false;
	
	if( empty($ID_MEMBER) )
		return false;	

	if(($creator = getCreatorID($i)) == 0)
		return false;
	
	$q2 = db_query("SELECT ID_MEMBER,BUDDY_ID
					 FROM {$db_prefix}buddies
					 WHERE BUDDY_ID  = $creator
					 AND ID_MEMBER = $ID_MEMBER
					 LIMIT 1");	
	$exist = mysql_num_rows($q2);

	return $exist;

}

function checkPriv($story){
global $ID_MEMBER;
	
	if(empty($ID_MEMBER))
		return false;
			
	if(empty($story))
		return false;
		
	if(($creator = getCreatorID($story)) == 0)
		return false;

			
	if(($privacy = getPrivacyStory($story)) === false)
		return false;
				
	if(($privacySTOP = getPrivacyID($story)) == 0)
		return false;
		
			//Its me bitch, don't need privacy
	if($creator != $ID_MEMBER){
		switch($privacy){
			case '0':
				/*Public*/
					return true;
				break;
					
			case '1':
					/* Followers and friends */
				if(($imFollowing = imFollower($story)) == 0){
					
					if(($imFriend = imFriend($story)) == 0){
						return false;
					}
					else{
						//Si es amigo, puede comentar
						return true;
					}
					
				}
				else{
					return true;
				}
								
			break;
					
			case '2':
				/* Just followers*/
				if(($imFollowing = imFollower($_POST['story'])) == 0){
					return false;
				}
				else{
					//Si lo sigue, puede comentar
					return true;
				}

			break;
					
			case '3':
					/* Just friends*/
				if(($imFriend = imFriend($_POST['story'])) == 0){
					return false;
				}
				
				else{
					//Si es amigo, puede comentar
					return true;
				}
			break;
					
			case '4':
				/* Just me, el parametro $creator es igual a $ID_MEMBER por lo que no aplica*/
			break;
					
					
				}
			}
	
	else{
		return true;
	}		

}

function getsubsComments($id){
global $ID_MEMBER,$db_prefix;
	
	if(empty($id) or !is_numeric($id))
			return false;
			
	$qt = 	 db_query("	SELECT ID,ID_STREAM_COMMENT
						FROM {$db_prefix}substream
						WHERE ID_STREAM_COMMENT  = $id	
						");	
	$total = mysql_num_rows($qt);	
		
	
		if($total > 5){
			$limit = $total - 5;
			$c = 'LIMIT '.$limit.', 5';
		}
		
		else{
			$c = 'LIMIT 5';
		}
			
	
	$query = db_query("SELECT s.ID AS subid,s.ID_STREAM_COMMENT,s.ID_MEMBER,s.DATE AS dat1,s.comment,m.ID_MEMBER,m.memberName,m.avatar
					 FROM {$db_prefix}substream AS s,{$db_prefix}members AS m
					 WHERE s.ID_STREAM_COMMENT  = $id
					 AND m.ID_MEMBER = s.ID_MEMBER
					 ORDER BY ID ASC
					{$c}");	
					 
	while ($d = mysql_fetch_assoc($query)){
		echo'
			<li class="clearfix" id="cc_'.$d['subid'].'">
			<a class="author-com">
				<img src="'.$d['avatar'].'" width="150" height="150">
			</a>
				<div class="inner-comment">
					<span class="author"><a href="'.$scripturl . '?action=profile&u=' . $d['ID_MEMBER'].'">'.$d['memberName'].'</a> coment&oacute;:</span>
						<span class="msg">'.$d['comment'].'</span>
						<span class="time time-upd">'.hace($d['dat1']).' 
						';
						$delete = false;
						
						if(!empty($ID_MEMBER)){
						
						if(($creator = getCreatorID($id)) == $ID_MEMBER){
							$delete = true;
						}
						
						elseif($ID_MEMBER == $d['ID_MEMBER']){
							$delete = true;
						}
						
						if($delete == true)
						{echo'
						- <span style="cursor:pointer;" class="deleteSub" id="'.$d['subid'].'">Borrar</span>
						';}
						
						}echo'
						</span>
				</div>
		</li>
		';
	
	}
}

function getLikes($id){
global $db_prefix;

	if(empty($id) or !is_numeric($id))
		return false;
		
	$total = db_query(
		"SELECT ID_STORY,ID_LIKE
		FROM {$db_prefix}activity_likes
		WHERE ID_STORY  = $id
		"); 	
	$count = mysql_num_rows($total);
		
	$query = db_query(
		"SELECT s.ID_MEMBER,s.ID_STORY,s.ID_LIKE,m.ID_MEMBER,m.memberName,m.avatar
		FROM {$db_prefix}activity_likes AS s,{$db_prefix}members AS m
		WHERE ID_STORY  = $id
		AND m.ID_MEMBER = s.ID_MEMBER
		ORDER BY s.ID_LIKE DESC
		LIMIT 9");	
		
	echo'<div class="likes_wrapp">
			<ul id="content_likes_'.$id.'">';	
			
	while ($d = mysql_fetch_assoc($query)){
		echo'
			<li><a title="'.$d['memberName'].'" href="'.$scripturl . '?action=profile&u=' . $d['ID_MEMBER'].'"><img src="'.$d['avatar'].'"></a></li>
		';
	
	}
	
	echo'
		</ul>
			</div>';
		if($count > 9){	
			$resta = $count - 9;
		echo'
		<div class="count_wrapp" id="'.$id.'" style="cursor:pointer;">
				'.$resta.' m&aacute;s
		</div>';}
}
?>