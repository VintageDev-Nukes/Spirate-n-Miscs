<?php
/* Spirate Script - Version 2.4
******   Bloques-AgregarF.php     ******/

require("../Settings.php");

$conexion = mysql_connect($db_server, $db_user, $db_passwd) OR die("Error al procesar lo solicitado");
require("../SSI.php");
mysql_select_db($db_name, $conexion) OR die("Error al procesar lo solicitado");


/*Seguridad SOLO ADMINS ENTRAN ACA*/
$autor = $context['user']['id'];
$isadmin = mysql_query("SELECT ID_GROUP
                        FROM smf_members
                        WHERE ID_MEMBER = '$autor' LIMIT 1");
	while ($row = mysql_fetch_assoc($isadmin))
              if($row['ID_GROUP']!=1){die('No tienes permisos para ingresar aqui');}                                
	mysql_free_result($isadmin);
/**********************************/


global $context;

$id = $_POST['id'];

$requestbloques = mysql_query("SELECT *
                        FROM smf_bloquesf
                        WHERE id_columna = '$id' ORDER BY filabloque DESC LIMIT 1");
                          
$context['bloques'] = array();
	while ($row = mysql_fetch_assoc($requestbloques))
              $filase = $row['filabloque'];                                
	mysql_free_result($requestbloques);

$fila= $filase + 1;
$titulo = $_POST['titulo'];
$contenido = $_POST['contenido'];
$conttipe = $_POST['conttipe'];
$on = $_POST['on'];
$rss = $_POST['rss'];
$bd = $_POST['bd'];



if($context['user']['id']=='' || $id=='')
{
	echo'<span style="color: red;" class="size11"><b>Que joraca queres hacer!!!!!!!</b></span>';
}
elseif($contenido=='')
{
       echo'<span style="color: red;" class="size11"><b>No has agregado ningun contenido</b></span>';
}
else
{

$finalizado = mysql_query("INSERT INTO {$db_prefix}bloquesf
				(id_columna,tibloque,cobloque,conttipe,filabloque,onbloque,rssbloque,bdbloque)
				VALUES ('$id', '$titulo','$contenido', '$conttipe','$fila','$on', '$rss', '$bd')");


if($finalizado){
echo'<center><font color="#24B011"><b>Agregado Correctamente!!!</b></font><br></center>';}
else{
echo'<center><font color="red"><b>Un error ha ocurrido...</b></font><br></center>';}

}

?>