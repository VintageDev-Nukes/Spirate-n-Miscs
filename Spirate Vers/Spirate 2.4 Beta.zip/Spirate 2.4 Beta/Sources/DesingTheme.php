<?php 

/* Spirate Script - Version 2.4
******   DesingTheme.php     ******/

//Indispensable para realizar themes
//Groso Kawasakipanga y Resuper002
function DTMain()
{
	global $settings, $user_info, $language, $context, $txt, $db_prefix, $setting_mon;


	isAllowedTo('admin_forum');
/*
	echo'<style>input{margin:3px;}</style>';
*/	
    //Titulo y Lenguaje
    loadlanguage('DesingTheme');
	$context['page_title'] = $txt['dt_title'];

    //marco el Monitor en la admin
	adminIndex('desingtheme');
        
    //Descripcion y Tabs		
    $context['admin_tabs'] = array(
		'title' => &$txt['dt_title'],
		'description' => $txt['dt_descripcion'],
		'tabs' => array(
			'general' => array(
				'title' => $txt['tab_general'],
				'href' => $scripturl . '?action=desingtheme',
			                  ),
			'menu' => array(
				'title' => $txt['tab_menu'],
				'href' => $scripturl . '?action=desingtheme;sa=menu',
			                  ),
							  
			'bloques' => array(
				'title' => $txt['tab_bloques'],
				'href' => $scripturl . '?action=desingtheme;sa=bloques',
			                  ),
			'posts' => array(
				'title' => $txt['tab_posts'],
				'href' => $scripturl . '?action=desingtheme;sa=posts',
			                  ),
							  
						),
	);
	
	//Array de Subacciones
    $subActions = array(
		'general' => 'general',
		'menu' => 'menu',
		'bloques' => 'bloques',
		'posts' => 'posts',
	);

	$sa = $_GET['sa'];
	
	// Seleccionamos el tab correcto
	if (isset($context['admin_tabs']['tabs'][$sa]))
		$context['admin_tabs']['tabs'][$sa]['is_selected'] = true;
		    	
	//Llamando a las Subacciones!!!
	$_REQUEST['sa'] = isset($_REQUEST['sa']) && isset($subActions[$_REQUEST['sa']]) ? $_REQUEST['sa'] : 'general';
	$subActions[$_REQUEST['sa']]();
	
}


function general(){

	global $sourcedir, $settings, $user_info, $language, $context, $txt, $db_prefix, $setting_mon;
	
	$context['admin_tabs']['tabs']['general']['is_selected'] = true;
		
	//Cargamos el ModSettings y el ManageServer
	//Utilidades MUY necesarias para el funcionamiento de este mod
	require_once($sourcedir . '/ModSettings.php');
	require_once($sourcedir . '/ManageServer.php');
	
	$context['sub_template'] = 'show_settings';
	
	$config_vars = array(
	
	array('check', 'activar_el_disenador'),
    array('check', 'activar_el_disenador_general'),
	$txt['separador'],
    array('text', 'ancho_del_logo'),
    array('text_color', 'alto_del_logo'),
	array('select', 'fondoweb_repeat', array('no-repeat' => 'No Repetir', 'repeat-x' => 'Horizontal', 'repeat-y' => 'Vertical', 'repeat' => 'En todo Sentido')),
	$txt['separador'],
	array('text', 'url_cabeza'),
	array('text_color', 'color_cabeza'),
	array('select', 'cabeza_repeat', array('no-repeat' => 'No Repetir', 'repeat-x' => 'Horizontal', 'repeat-y' => 'Vertical', 'repeat' => 'En todo Sentido')),
    $txt['separador'],	
	array('text', 'url_fondo_interno'),
	array('text_color', 'color_fondo_interno'),
    array('select', 'interno_repeat', array('no-repeat' => 'No Repetir', 'repeat-x' => 'Horizontal', 'repeat-y' => 'Vertical', 'repeat' => 'En todo Sentido')),	
	array('text_color', 'borde_fondo_interno'),
	$txt['separador'],	
	array('text_color', 'color_texto'),
    array('text_color', 'color_de_enlaces'),
    array('text_color', 'color_de_enlaces_hover'),	
	array('select', 'elegir_tipo', array('bold' => 'Negrita', 'normal' => 'Normal')),
	array('select', 'elegir_letra', array('arial' => 'Arial', 'verdana' => 'Verdana', 'Times New Roman' => 'Times New Roman', 'Georgia' => 'Georgia')),	
	
	);
	
   if ($return_config)
      return $config_vars;
   $context['post_url'] = $scripturl . '?action=desingtheme;save';
   $context['settings_title'] = $txt['dt_title'];
   if (empty($config_vars)){
      $context['settings_save_dont_show'] = true;
      $context['settings_message'] = '<div class="centertext">' . $txt['modification_no_misc_settings'] . '</div>';
      return prepareDBSettingContext($config_vars);
   }
   // guardamos los cambios hechos!
   if (isset($_GET['save'])){
      checkSession();
      $save_vars = $config_vars;
      saveDBSettings($save_vars);
      redirectexit('action=desingtheme');
   }
   prepareDBSettingContext($config_vars);
}


function menu(){

	global $sourcedir, $settings, $user_info, $language, $context, $txt, $db_prefix, $setting_mon;
		
	loadlanguage('DesingTheme');
	
	//Cargamos el ModSettings y el ManageServer
	//Utilidades MUY necesarias para el funcionamiento de este mod
	require_once($sourcedir . '/ModSettings.php');
	require_once($sourcedir . '/ManageServer.php');
	
	$context['sub_template'] = 'show_settings';
	
	$config_vars = array(
    array('check', 'activar_el_disenador_menu'),
	$txt['separador'],
    array('text', 'barra_height'),
	array('text', 'barra'),
	array('text_color', 'color_barra'),
	$txt['separador'],
	array('text', 'barra_back'),
	array('text_color', 'color_barra_back'),
	array('text_color', 'color_barra_back_hover'),	
	$txt['separador'],
	array('text', 'barra_hover'),
	array('text_color', 'color_barra_hover'),
	$txt['separador'],
    array('text_color', 'barra_border_left'),
	array('text_color', 'barra_border_right'),
	$txt['separador'],
    array('text_color', 'color_text_barra'),		
	array('select', 'barra_tipo', array('bold' => 'Negrita', 'normal' => 'Normal')),
	array('select', 'barra_letra', array('arial' => 'Arial', 'verdana' => 'Verdana', 'Times New Roman' => 'Times New Roman', 'Georgia' => 'Georgia')),
	
	);
	
   if ($return_config)
      return $config_vars;
   $context['post_url'] = $scripturl . '?action=desingtheme;sa=menu;save';
   $context['settings_title'] = $txt['dt_title'];
   if (empty($config_vars)){
      $context['settings_save_dont_show'] = true;
      $context['settings_message'] = '<div class="centertext">' . $txt['modification_no_misc_settings'] . '</div>';
      return prepareDBSettingContext($config_vars);
   }
   // guardamos los cambios hechos!
   if (isset($_GET['save'])){
      checkSession();
      $save_vars = $config_vars;
      saveDBSettings($save_vars);
      redirectexit('action=desingtheme;sa=menu');
   }
   prepareDBSettingContext($config_vars);
}

function bloques(){

	global $sourcedir, $settings, $user_info, $language, $context, $txt, $db_prefix, $setting_mon;
	
		
	//Cargamos el ModSettings y el ManageServer
	//Utilidades MUY necesarias para el funcionamiento de este mod
	require_once($sourcedir . '/ModSettings.php');
	require_once($sourcedir . '/ManageServer.php');
	
	$context['sub_template'] = 'show_settings';
	
	$config_vars = array(
	
	array('check', 'activar_el_disenador_bloques'),
    $txt['separador'],
	array('text', 'url_titulos_box'),
	array('text_color', 'color_titulos_box'),
	array('text', 'alto_titulos_box'),
	$txt['separador'],
	array('text_color', 'box_title_border_left'),
	array('text_color', 'box_title_border_top'),
	array('text_color', 'box_title_border_right'),
	array('text_color', 'box_title_border_bottom'),
	$txt['separador'],
	array('text_color', 'text_titulos_box'),	
	array('text', 'tamano_titulos_box'),
	$txt['separador'],
	array('text', 'url_fondo_de_bloques'),	
	array('text_color', 'color_fondo_de_bloques'),
	$txt['separador'],
	array('text_color', 'box_cuerpo_border_left'),
	array('text_color', 'box_cuerpo_border_top'),
	array('text_color', 'box_cuerpo_border_right'),
	array('text_color', 'box_cuerpo_border_bottom'),	
	);
	
   if ($return_config)
      return $config_vars;
   $context['post_url'] = $scripturl . '?action=desingtheme;sa=bloques;save';
   $context['settings_title'] = $txt['dt_title'];
   if (empty($config_vars)){
      $context['settings_save_dont_show'] = true;
      $context['settings_message'] = '<div class="centertext">' . $txt['modification_no_misc_settings'] . '</div>';
      return prepareDBSettingContext($config_vars);
   }
   // guardamos los cambios hechos!
   if (isset($_GET['save'])){
      checkSession();
      $save_vars = $config_vars;
      saveDBSettings($save_vars);
      redirectexit('action=desingtheme;sa=bloques');
   }
   prepareDBSettingContext($config_vars);
}

function posts(){

	global $sourcedir, $settings, $user_info, $language, $context, $txt, $db_prefix, $setting_mon;
			
	//Cargamos el ModSettings y el ManageServer
	//Utilidades MUY necesarias para el funcionamiento de este mod
	require_once($sourcedir . '/ModSettings.php');
	require_once($sourcedir . '/ManageServer.php');
	
	$context['sub_template'] = 'show_settings';
	
	$config_vars = array(
    array('check', 'activar_el_disenador_display'),
	$txt['separador'],
    array('text', 'url_infocabezal'),
    array('text_color', 'color_infocabezal'),
	$txt['separador'],
    array('text_color', 'infoc_border_left'),
	array('text_color', 'infoc_border_top'),
	array('text_color', 'infoc_border_right'),
	array('text_color', 'infoc_border_bottom'),
	$txt['separador'],
    array('text', 'url_coment'),
    array('text_color', 'color_coment'),
	array('select', 'coment_repeat', array('no-repeat' => 'No Repetir', 'repeat-x' => 'Horizontal', 'repeat-y' => 'Vertical', 'repeat' => 'En todo Sentido')),
	$txt['separador'],
	array('text_color', 'cc_border_left'),
	array('text_color', 'cc_border_top'),
	array('text_color', 'cc_border_right'),
	array('text_color', 'cc_border_bottom'),
    $txt['separador'],	
	array('text_color', 'infoccolor_texto'),
	array('text_color', 'ccolor_texto'),
	);
	
   if ($return_config)
      return $config_vars;
   $context['post_url'] = $scripturl . '?action=desingtheme;sa=posts;save';
   $context['settings_title'] = $txt['dt_title'];
   if (empty($config_vars)){
      $context['settings_save_dont_show'] = true;
      $context['settings_message'] = '<div class="centertext">' . $txt['modification_no_misc_settings'] . '</div>';
      return prepareDBSettingContext($config_vars);
   }
   // guardamos los cambios hechos!
   if (isset($_GET['save'])){
      checkSession();
      $save_vars = $config_vars;
      saveDBSettings($save_vars);
      redirectexit('action=desingtheme;sa=posts');
   }
   prepareDBSettingContext($config_vars);
}

?>