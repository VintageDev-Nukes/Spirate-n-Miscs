<?php
/* Spirate Script - Version 2.4
******   Bloques-EditarC.php     ******/

require("../Settings.php");

$conexion = mysql_connect($db_server, $db_user, $db_passwd) OR die("Error al procesar lo solicitado");
require("../SSI.php");
mysql_select_db($db_name, $conexion) OR die("Error al procesar lo solicitado");


/*Seguridad SOLO ADMINS ENTRAN ACA*/
$autor = $context['user']['id'];
$isadmin = mysql_query("SELECT ID_GROUP
                        FROM smf_members
                        WHERE ID_MEMBER = '$autor' LIMIT 1");
	while ($row = mysql_fetch_assoc($isadmin))
              if($row['ID_GROUP']!=1){die('No tienes permisos para ingresar aqui');}                                
	mysql_free_result($isadmin);
/**********************************/


global $context;

$edit = $_POST['edit'];
$que = $_POST['que'];

if($edit==1)
{

$requestbloques = mysql_query("SELECT *
                        FROM smf_bloques
                        WHERE ID = '$que'");

	$context['bloques'] = array();
	while ($row = mysql_fetch_assoc($requestbloques))
			{
			$ancho = $row['ancho'];
			$tituloimg = $row['tituloimg'];
			$contcolor = $row['contcolor'];
			$bordera = $row['bordera'];
			$borderc = $row['borderc'];
			$custom = $row['custom'];}
	mysql_free_result($requestbloques);


echo'<br>
<form method="post">
<table width="410px" style="border: 4px dashed #025AC7;padding:5px;margin-left:50px;"><tr>

<td>Ancho de la columna:
<div class="smalltext">(Ancho en pixeles, ej: 365)</div>
</td><td><input type="int" name="ancho" maxlength="4" value="',$ancho,'"></td></tr>';

if($custom==1)
echo'<tr><td><hr><b>Usar Dise&#241;o customizado?:</b></td><td> <div class="relative"><input type="checkbox" name="custom" value="1" checked><div class="tip_ayuda warning2" style="display:inline;"><span><strong>Rellena todos los cubiculos de abajo.</strong></span></div></div>
</td></tr>';
else
{echo'<tr><td><hr><b>Usar Dise&#241;o customizado?:</b></td><td><input type="checkbox" name="custom" value="1"></td></tr>';}

echo'<tr><td>Im&#225;gen de Fondo del titulo:
<div class="smalltext">(URL de la imagen que se repetira horizontalmente)</div></td><td> <input type="text" name="tituloimg" value="',$tituloimg,'"></td></tr>

<td><hr><b>Para el Contenido <font color="red"></font>:</b></td></tr>

<td>Color de Fondo del Contenido: <div class="smalltext">(Codigo de color html, ej: <b>#FFFFFF</b>)</div></td><td><input type="text" name="contcolor" maxlength="7" value="',$contcolor,'"></td></tr>

<td>Ancho del Borde:
<div class="smalltext">(Recomendado 1)</div> </td><td><input type="int" name="bordera" maxlength="1" value="',$bordera,'"></td></tr>

<td>Tipo del Borde: </td><td><select name="bordert">
<option value="none" selected="selected">Ninguno</option>
<option value="solid">Solido</option>
<option value="inset">Recuadrado</option>
<option value="dotted">Punteado</option>
<option value="dashed">Discontinua</option>
<option value="outset">Por Fuera</option>
<option value="groove">Surcado</option>
</select></td></tr>

<tr><td>Color del Borde:<div class="smalltext">(Codigo de color html, ej: <b>#FFFFFF</b>)</div></td><td> <input type="text" name="borderc" maxlength="7" value="',$borderc,'"></td></tr>
<input type="hidden" name="id" value="',$que,'">
<tr><td><center><input class="botondown" type="button" onclick="javascript:guardar(this.form,this.form.ancho.value,this.form.tituloimg.value,this.form.contcolor.value,this.form.bordera.value,this.form.bordert.value,this.form.borderc.value,this.form.custom.value,this.form.id.value);" style="cursor:pointer" value="Editar" tabindex="2" /><center></td></tr>
</table></form>
</br>';

}
elseif($edit==2)
{

$id = $_POST['id'];
$ancho = $_POST['ancho'];
$customon = $_POST['customon'];
$tituloimg = $_POST['tituloimg'];
$contcolor = $_POST['contcolor'];
$bordera = $_POST['bordera'];
$bordert = $_POST['bordert'];
$borderc = $_POST['borderc'];



$finalizado = mysql_query("
			UPDATE {$db_prefix}bloques
			SET  ancho = '$ancho', tituloimg = '$tituloimg', contcolor = '$contcolor', bordera = '$bordera', bordert = '$bordert', borderc = '$borderc', custom = '$customon'
			WHERE id = '$id' 
		LIMIT 1");

if($finalizado){
echo'<center><font color="#24B011"><b>Editado Correctamente!!!</b></font><br></center>';}
else{
echo'<center><font color="red"><b>Un error ha ocurrido...</b></font><br></center>';}
}
?>