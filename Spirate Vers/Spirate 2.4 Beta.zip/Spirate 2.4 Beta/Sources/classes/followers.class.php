<?php

if(!defined('SPIRATE'))
	die('Are you serious?');

	
class followers{

	public function follow( $uid, $die = true ){
		global $context, $ID_MEMBER, $db_prefix, $txt, $sourcedir;
		
		$target = (int) $uid;
		$time = time();
				
		if(empty($ID_MEMBER))
			$this->_return(json_encode(array('status' => 'error', 'msg' => 'Debes estar logueado para realizar esta acci&oacute;n')), $die, 0);
		
		if(empty($target))
			$this->_return( json_encode(array('status' => 'error', 'msg' => 'No seleccionaste a quien seguir.')), $die, 0 );
		
		if( $target == $ID_MEMBER )
			$this->_return( json_encode(array('status' => 'error', 'msg' => 'No puedes seguirte a ti mismo.')), $die, 0 );
		
		$request = db_query("SELECT ID_MEMBER FROM {$db_prefix}members WHERE ID_MEMBER = $target LIMIT 1",__FILE__,__LINE__);
	
		if(mysql_num_rows($request) == 0)
			$this->_return( json_encode(array('status' => 'error', 'msg' => 'El usuario a quien intentas seguir no existe.')), $die, 0 );
		
		mysql_free_result($request);
		
		$request = db_query("SELECT uif FROM {$db_prefix}followers WHERE uif = $ID_MEMBER AND uid = $target LIMIT 1",__FILE__,__LINE__);
		
		if( mysql_num_rows($request) > 0 )
			$this->_return(json_encode(array('status' => 'error', 'msg' => 'Ya estas seguiendo a este usuario')), $die, 0);
			
		mysql_free_result($request);
	
	
		db_query("INSERT IGNORE INTO {$db_prefix}followers (uid, uif, time)
			VALUES( $target, $ID_MEMBER, $time)",__FILE__,__LINE__);
			
		$check = db_query("SELECT uif FROM {$db_prefix}followers WHERE uif = $ID_MEMBER AND uid = $target LIMIT 1",__FILE__,__LINE__);
		
		if(!$check)
			$this->_return(json_encode(array('status' => 'error')), $die, 0);
		
		$inserted = mysql_num_rows($check) > 0;
		
		mysql_free_result($check);
		
		if( $inserted ){
		
			updateMemberData($target, array('followers' => '+'));
			updateMemberData($ID_MEMBER, array('following' => '+'));
			
			require_once($sourcedir . '/classes/stream.class.php');
			
			$stream = new stream();
			
			$stream->addActivity('follow', array('user', $target), array('user', $ID_MEMBER), null, false);
			
			$this->_return(json_encode(array('status' => 'ok')), $die, 0);
		
		}else
			$this->_return(json_encode(array('status' => 'error')), $die, 0);
		
		
	}
	public function unfollow( $uid, $die = true ){
		global $context, $ID_MEMBER, $db_prefix, $txt;
		
		$target = (int) $uid;
		
		if(empty($ID_MEMBER))
			$this->_return(json_encode(array('status' => 'error', 'msg' => 'Debes estar logueado para realizar esta acci&oacute;n')), $die, 0);
		
		if(empty($target))
			$this->_return( json_encode(array('status' => 'error', 'msg' => 'No seleccionaste a quien dejar de seguir.')), $die, 0 );
		
		$request = db_query("SELECT ID_MEMBER FROM {$db_prefix}members WHERE ID_MEMBER = $target",__FILE__,__LINE__);
		
		if(mysql_num_rows($request) == 0)
			$this->_return( json_encode(array('status' => 'error', 'msg' => 'Ese usuario no existe.')), $die, 0 );
			
		mysql_free_result($request);
		
		db_query("DELETE FROM {$db_prefix}followers WHERE uif = $ID_MEMBER AND uid = $target",__FILE__,__LINE__);
		
		updateMemberData($target, array('followers' => '-'));
		updateMemberData($ID_MEMBER, array('following' => '-'));
		
		$this->_return( json_encode(array('status' => 'ok')), $die, 0 );
		
	}
	public function get_followers( $limit = 0, $start = 0, $extra_rows = array() ){
		global $context, $db_prefix, $txt, $ID_MEMBER;
		
		if(empty($ID_MEMBER))
			return false;
		
		$limit = (int) $limit;
		$limit_statement = 'LIMIT ';
		
		if( !empty($limit) )
		{
			$start = (int) $start;			
			$limit_statement .= $limit . ', ' . $start;
		}else
			$limit_statement = '';
		
		$select_statement = '';
		if(!empty($extra_rows))
		{
			foreach($extra_rows as $row)
				$select_statement .= ', m.' . $row;
		}
		
		$result = db_query("SELECT f.uid, f.uif, f.time AS follow_time, m.realName, m.avatar, m.avatar_coords
							$select_statement
							FROM {$db_prefix}followers as f
							LEFT JOIN {$db_prefix}members AS m ON(f.uif = m.ID_MEMBER)
							WHERE f.uid = $ID_MEMBER
							$limit_statement",__FILE__,__LINE__);
		$followers = array();
		while($row = mysql_fetch_assoc($result)){
			$follower = array(
				'id' => $row['uif'],
				'name' => $row['realName'],
				'avatar' => $row['avatar'],
				'avatar_coords' => makeAvatarCoords($row['avatar_coords'])
			);
			
			if(!empty($extra_rows))
			{
				foreach($extra_rows as $key_row)
					$follower[$key_row] = $row[$key_row];
			}
			$followers[$row['uid']][] = $follower;
		}
		mysql_free_result($result);
		
		return !empty($followers) ? $followers : false;
		
	}
	public function is_followed($uid = 0){
		global $db_prefix, $ID_MEMBER;
		
		$uid = (int)$uid;
		
		if(empty($uid) || empty($ID_MEMBER))
			return false;
						
		$result = db_query("SELECT uid FROM {$db_prefix}followers WHERE uif = $ID_MEMBER AND uid = $uid LIMIT 1",__FILE__,__LINE__);
		
		$num_rows = mysql_num_rows($result);
		
		mysql_free_result($result);
		
		return empty($num_rows) ? false : true;		
		
	}
	private function _return( $msg = '', $die = false, $bool_return ){
	
		if( $die )
			die( $msg );
		else
			return $bool_return == 0 ? false : true;
		
	}
	

}

?>