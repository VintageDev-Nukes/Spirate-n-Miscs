﻿/**

ADD NEW STORY EFFECT

var cloned = $('.container-stories .stream-stories li.story:first-child').clone();
var ul_test = $('<ul class="stream-stories hideObj"></ul>').append(cloned);
$(ul_test).appendTo('body')
$('.container-stories .stream-stories').css('top', '-' + $(ul_test).height() + 'px');
$('.container-stories .stream-stories').prepend(cloned).animate({'top' : '0'}, 'slow', function(){

$('.container-stories .stream-stories li.story:first-child').addClass('advertise');

});


**/

var stream_actions = {

    __init : function(){
	
	if( !global.stream ){
		
		console.log('Error: global.stream is undefined');
		return false;
	
	}
	
	$('a.option.comment').click(function(){
		if($(this).parent().find('.stream-tt-comment').css('display') == 'block')
		  $(this).parent().find('.stream-tt-comment').hide();
		else{
		  $('.stream-tt-comment').hide();
		  stream_actions.center_comment_box($(this).parent().find('.stream-tt-comment')).show();
		}
	});
	
	$('.follow-list li:not(.followed) a.follow').live('click', function(){
		return follow_u(this, $(this).attr('uid'), 'stream');
	});
	
	$('.follow-list li.followed a.follow').live('click', function(){
		return unfollow_u(this, $(this).attr('uid'), 'stream');
	});
	
	$('textarea.stream-content').mentionsInput({
		onDataRequest:function (mode, query, callback) {
		
			var data = global.stream.follow_list;
			data = _.filter(data, function(item) { return item.name.toLowerCase().indexOf(query.toLowerCase()) > -1 });
			callback.call(this, data);
			
		}
	});
	
	$('.new-activity').click(function(){
        $(this).find('.hideInputStream').focus();
    });
	
	post_stream.set_privacy();
	
	$('li.story .outter-footer-story ul.stats li.likes:not(.disabled) a').live('click', function(){
		stream_actions.add_like(this, $(this).parents().filter('li.story').attr('story_id'));
	});
	
	$('li.story .outter-footer-story ul.stats li.re-streams:not(.disabled) a').live('click', function(){
		stream_actions.re_stream_prompt(this, $(this).parents().filter('li.story').attr('story_id'));
	});

},
ajax_on_progress : false,
add_like : function(element, story){
	
	if(this.ajax_on_progress)
		return;
		
	this.ajax_on_progress = true;
	
	$.ajax({		
		type : 'post',
		dataType : 'json',
		data : 'story=' + parseInt(story),
		url : global.data.scripturl + '?action=stream&do=ajax&work=add-like',
		success : function(r){
				
			if( r.status == 'error' )
				return false;
			
			if( parseInt($(element).html()) == 0 )
				$(element).parent().addClass('filled');				
						
			$(element).html(parseInt($(element).html()) + 1).parent().addClass('disabled');
			
		},
		complete : function(){
			stream_actions.ajax_on_progress = false;
		}
	
	});
	
},
re_stream_prompt : function(element, story){

	if( this.ajax_on_progress )
		return;

	sp_dialog.options = {
			'title' : 'Compartir publicaci&oacute;n',
			'body' : 'Estas seguro que deseas compartir esta publicaci&oacute;n',
			'noclose' : true
			
		}
		sp_dialog.show();

		sp_dialog.buttons([{
			text : 'Compartir',
			"class" : 'sp-button green left',
			click : function(){
				return stream_actions.re_stream(element, story);
			}
		},
		{
			text : 'Cancelar',
			"class" : 'right close-button-dialog',
			click : function(){
				sp_dialog.close();
			}
		}
		]);

},
re_stream : function(element, story){
	
	if( this.ajax_on_progress )
		return;
	
	this.ajax_on_progress = true;
	
	sp_dialog.show('load');
	
	$.ajax({
		type : 'POST',
		dataType : 'json',
		data : 'story=' + parseInt(story),
		url : global.data.scripturl + '?action=stream&do=ajax&work=share-post',
		success : function(r){
			
			sp_dialog.close();
			
			sp_dialog.options = {
				'body' : 'La historia se ha compartido',
				'title' : 'Compartir publicaci&oacute;n'
			}
			sp_dialog.show();
			
			sp_dialog.buttons([
				{
					text : 'Aceptar',
					'class' : 'sp-button blue right',
					click : function(){
						sp_dialog.close(function(){
						
								if( parseInt($(element).html()) == 0 )
									$(element).parent().addClass('filled');	
								
								$(element).html(parseInt($(element).html()) + 1).parent().addClass('disabled');
								
						});
					}
				}
			]);
			
		},
		complete : function(){
			sp_dialog.endload(false, true);
			stream_actions.ajax_on_progress = false;
		}
	
	});


}

}

var post_stream = {
	current_privacy : 0,
	current_type : false,
	current_url : false,
	current_thumbnail : false,
	post_vars : {
		'privacy' : false,
		'type' : false,
		'url' : false,
		'thumbnail' : false,
		'coord-top' : false,
		'coord-left' : false
	},
	attachments_cache : {},
	cache_urls : [],
    attachment_on : false,
    ajax_on : false,
    attach_regexp : {
        video : new RegExp('http://((?:www|uk|fr|ie|it|jp|pl|es|nl|br|au|hk|mx|nz|de|ca)\.|)youtube\.com/(?:(?:watch|)\?v=|v/|jp\.swf\?video_id=)([0-9A-Za-z-_]{11})(?:.*?)', 'i'),
        image : new RegExp('(http[s]?://[a-z0-9-_\.]+\.[a-z0-9]{2,3}(/[^\/]+)*\.(jpg|jpeg|png|gif|bmp)(/\S*)?)', 'i'),
        link : /(ftp|http|https):\/\/(\w+:{0,1}\w*@)?(\S+)(:[0-9]+)?(\/|\/([\w#!:.?+=&%@!\-\/]))?/
    },
	keys : {
		8 : 'backspace',
		9 : 'tab',
		13 : 'return',
		27 : 'esc',
		37 : 'left',
		38 : 'up',
		39 : 'right',
		40 : 'down',
		188 : 'comma',
		32 : 'space',
		36 : 'home',
		35 : 'end'
	},
	detect_key : function(e){
	
		var key = (document.all)?e.keyCode:e.which;
		
		return (this.keys[key] ? this.keys[key] : false );
	
	},
    textarea : {},
    __init : function(){
		
		this.current_type = $('.attach-options li.selected').attr('attach');
		this.post_vars['type'] = $('.attach-options li.selected').attr('attach');
		
        this.textarea = $('textarea.stream-content');
		
		if( global.stream && global.stream.privacy ){
			
			this.current_privacy = global.stream.privacy;
			this.post_vars['privacy'] = global.stream.privacy;
			
		}
		$('.attach-post .sp-button').click(function(){
			
			var regexp = post_stream.attach_regexp.link,
				_match = regexp.exec($('.attach-post .attach-link-input').val());
			
			if(_match === null)
				return;
			
			post_stream.check_attach(_match[0], true);
			
		});
			
		this.detect_attach();
		
		$('.attach-options a').click(function(){		
			
			post_stream.set_type_attach($(this).parent().attr('attach'), this);
			
		});
		
		$('a.removeAttach').live('click',function(){
			
			post_stream.remove_attach();
			
		});
		
		$('.footer-post-area .sp-button').click(function(){
			post_stream.add_story();
		});

    },
	set_post_area_availability : function(enabled, has_attachment){
		
		if( !enabled )
		{
			
			$('.post-area .stream-content, .post-area .submit-btn .sp-button').addClass('disabled').attr('disabled', 'disabled');
			
			$('.preview-story').find('.preview_disabled_overlay').remove();
			
			if(has_attachment){		
			
				$('.preview-story').append($('<div class="preview_disabled_overlay"></div>').css({
					'position' : 'absolute',
					'width' : $('.preview-story')[0].offsetWidth,
					'height' : $('.preview-story')[0].offsetHeight,
					'display' : 'block',
					'right' : 0,
					'top' : 0
				}));
				
				$('.preview-story').addClass('low-opacity');
				$('.removeAttach').hide();
			}
		
		}
		else
		{
		
			$('.post-area .stream-content, .post-area .submit-btn .sp-button').removeClass('disabled').removeAttr('disabled');		
		
			if( has_attachment ){
		
				$('.preview-story').removeClass('low-opacity').find('.preview_disabled_overlay').remove();
				$('.removeAttach').show();
		
			}
		
		}
	
	},
	add_story : function(){
	
		var markupTextarea; $(this.textarea).mentionsInput('val', function(text){ markupTextarea = text; });
		
		if( markupTextarea == $(this.textarea).attr('placeholder') )
			markupTextarea = '';
		
		if( trim(markupTextarea) == '' && !this.attachment_on)
			return false;
		
		var data = new Array(
			'message=' + encodeURIComponent(markupTextarea),
			'disabled_comments=' + $('.UIdrop.privacy ul li.extra-option input[name=disable_comments]').is(':checked') ? 1 : 0,
			'attach_on=' + (this.attachment_on ? 1 : 0)
		);

		if(this.image_preview_drag_started)
		{
		
			this.post_vars['coord-top'] = parseInt(-($('#templateAttachContent .thumbWrap').scrollTop()));
			this.post_vars['coord-left'] = parseInt(-($('#templateAttachContent .thumbWrap').scrollLeft()));
		
		}
		
		for ( var_ in this.post_vars )
			if( this.post_vars[var_] )
				data.push(var_ + '=' + encodeURIComponent(this.post_vars[var_]));
		
		if(this.ajax_on_progress)
			return;
			
		this.ajax_on_progress = true;
		
		this.set_post_area_availability( false, true);
		
		$.ajax({
			
			type : 'POST',
			dataType : 'json',
			data : data.join('&'),
			url : global.data.scripturl + '?action=stream&do=ajax&work=add-story',
			timeout : 120000,
			success : function(r){
				
				if( !r.data )
					return false;
				
				
				post_stream.post_vars = {
					'privacy' : false,
					'type' : false,
					'url' : false,
					'thumbnail' : false
				};
				post_stream.remove_attach();
				post_stream.attachments_cache = {};
				post_stream.cache_urls = [];
				
				$(post_stream.textarea).val('').focus().stop().blur();
				
				$('#story_tmpl_own').template( "template_recent_story" );
				
				var ul_test = $('<ul class="stream-stories hideObj"></ul>').append(story_element);
				$(ul_test).appendTo('body')
				var story_element = $.tmpl( "template_recent_story", r.data);
				
				$(ul_test).prepend(story_element);
					
				if( r.data.attach_on ){
					
					if( r.data.attach_data.description )
						r.data.attach_data.description = r.data.attach_data.description.substring(0, 90) + (r.data.attach_data.description.length > 90 ? '...' : '');
					
					var attach_tmpl = $.tmpl( r.data.template, r.data.attach_data)
					$(story_element).find('.streamAttachContext').html(attach_tmpl);
					
				}
				
				
				$('.container-stories .stream-stories').css('top', '-' + $(ul_test).height() + 'px');
				$('.container-stories .stream-stories').prepend(story_element).animate({'top' : '0'}, 'slow', function(){

					$('.container-stories .stream-stories li.story:first-child').addClass('recent');
					$('.stats .count-streams').html(parseInt($('.stats .count-streams').html()) + 1);

				});
					
			},
			complete : function(){
				
				post_stream.set_post_area_availability(true, true);
				post_stream.ajax_on_progress = false;
				
			},
			error : function(){
				//...
			},
			
		});
		
		
	},
	remove_attach : function(){
		
		$('.preview-story').hide();
		$('#templateAttachContent').empty().removeClass('thumbnailVisible');
		$(this.textarea).focus();
		this.attachment_on = false;
		this.cache_thumbnails = [];
		this.set_type_attach('status');
		this.current_url = false;
		this.current_thumbnail = false;
		this.thumbnail_pages_images = [];
		this.current_page = 1;
		this.paginate_on = false;
	
	},
	detect_attach : function(){
	
		var pressed = 0;
		
		$(this.textarea).bind('keypress paste', function(event){
			
			if( post_stream.attachment_on )
				return;
			
			if( event.type == "keypress" )			
				pressed++;
			
			var _this = this, no_detect = false;			
			
			setTimeout(function(){
			
				if( pressed > 1 )
					if( post_stream.detect_key(event) != 'space' )
						return;
				
				var regexp = post_stream.attach_regexp.link;
				var _match = regexp.exec($(_this).val());
				
				if(_match !== null)
				{
					
					if( typeof post_stream.cache_urls[_match[0]] != 'undefined' )
						return;
					
					post_stream.check_attach(_match[0]);
				
				}
			
			}, 100);
		
		});
	
	},
	ajax_on_progress : false,
	check_attach : function(url_attach, force_type){
		
		if( this.attachment_on || this.ajax_on_progress)
			return;
			
		if(force_type){
			
			if( !$('.attach-post .attach-link-input').val().match(post_stream.attach_regexp.link) )
				return false;
			
			$('.attach-post .attach-link-input').val('');
			
		}
		
		this.ajax_on_progress = true;
		
		this.set_post_area_availability(false);
		
		$.ajax({
			type : 'post',
			data : 'link=' + encodeURIComponent(url_attach) + '&force_type=' + ( force_type ? ( 1 + '&type=' + this.current_type ) : 0 ),
			dataType : 'json',
			url : global.data.scripturl + '?action=stream&do=ajax&work=check-attach',
			success : function(r){
				
				if(!r.data || !r.data.result)
					return;
				
				post_stream.cache_urls[url_attach] = url_attach;
				
				post_stream.current_url = url_attach;
				
				post_stream.post_vars['url'] = url_attach;
				
				post_stream.attachments_cache[url_attach] = r.data.result;
				
				post_stream.set_type_attach(r.data.type == 'swf' ? 'video' : r.data.type);
				
				post_stream.prepare_attach_preview(r.data);
				
				post_stream.attachment_on = true;
				
			},
			complete : function(){
			
				post_stream.ajax_on_progress = false;
				
				post_stream.set_post_area_availability(true);
				
			},
			error: function(){ post_stream.ajax_on_progress = false; }
		});
	
	},
	image_preview_drag_started : false,
	prepare_attach_preview : function(data){
		
		if( data.result.thumbnail )
			$('#templateAttachContent').addClass('thumbnailVisible');		
		else if( data.result.thumbnails )
			this.prepare_thumbnails(data.result.thumbnails);
				
		$('#attachment_tmpl_' + data.type).template( "template_attachment" );
		$.tmpl( "template_attachment",data.result ).appendTo('#templateAttachContent');
		
		if( !$('#templateAttachContent').hasClass('thumbnailVisible') )
			$('#templateAttachContent .attachThumbnail').hide();
		
		$('.preview-story').fadeIn();
		
		$(this.textarea).blur();
		
		setTimeout(function(){
			$(post_stream.textarea).focus();
		}, 1000);
		
		if( data.type == 'image' ){
				
			$('#templateAttachContent .thumbWrap img').css({
				'width' : data.result.width,
				'height' : data.result.height
			}).attr('src', global.data.images_url + '/transparent.gif');
			
			$.preload([data.result.src], {
				loaded_all: function() {
				
					$('#templateAttachContent .thumbWrap img').attr('src', data.result.src);
					$('#templateAttachContent .thumbWrap').overscroll({
						hoverThumbs: false,
						wheelDelta : 0,
						showThumbs: false
					}).on('overscroll:dragstart overscroll:dragend overscroll:driftstart overscroll:driftend', function(){
					
					if(!post_stream.image_preview_drag_started)
						image_preview_drag_started = true;
					
					post_stream.post_vars['coord-top'] = parseInt($('#templateAttachContent .thumbWrap').scrollTop());
					post_stream.post_vars['coord-left'] = parseInt($('#templateAttachContent .thumbWrap').scrollLeft());
					
					}).find('img').removePropertyStyle('width').removePropertyStyle('height');
					
					setTimeout(function(){
					
						if( 
							$('#templateAttachContent .thumbWrap').get(0).scrollHeight > $('#templateAttachContent .thumbWrap').height() ||
							$('#templateAttachContent .thumbWrap').get(0).scrollWidth > $('#templateAttachContent .thumbWrap').width()
							){
							
								var drag_instr = $('<div class="drag-instruction"><strong class="rounded disabled-select"></strong></div>');
								
								$(drag_instr).find('strong').html('Arrastra la imagen');
								$(drag_instr).appendTo('#templateAttachContent').css({
								
									'top' : $('#templateAttachContent .thumbWrap').height()/2 - $('#templateAttachContent .drag-instruction').height()/2
								
								}).fadeIn('slow', function(){
									
									$('#templateAttachContent .drag-instruction').hover(function(){ $(this).hide() });
									$('#templateAttachContent .thumbWrap').bind('mouseout mouseleave mouseover',function(e){
										
										if( e.type == 'mouseout' || e.type == 'mouseleave')
											$('#templateAttachContent .drag-instruction').show();
										else
											$('#templateAttachContent .drag-instruction').hide();
											
									});
									
								});
							
							}
					}, 500);
				},
				
			});
			
			/*
			$('.testScroll .thumbWrap img').css({
				'top' : -($('#templateAttachContent .thumbWrap').scrollTop()),
				'left' : -($('#templateAttachContent .thumbWrap').scrollLeft())
			});
			*/
			
		}
		
	},
	current_page : 1,
	paginate_on : false,
	thumbnail_pages_images : [],
	paginate_thumbnails : function(page, only_calc_pages){
		
		$("#templateAttachContent .attachThumbnail .thumbnails_list img").each(function(){
			post_stream.thumbnail_pages_images[$(this).index() + 1] = $(this);
	
		});
		
		if( only_calc_pages )
			return;
		
		if( !this.paginate_on ){
			
			$('.attachThumbnail .thumbnail-options .paginate_thumbnails').show();
			
			var prev, next;
			
			prev = $('<a></a>').addClass('prevButton').bind('click', function(){
				
				var pag = post_stream.current_page - 1;
				
				$(this).next().removeClass('disabled');
				
				if( pag < 1 ){
				
					post_stream.current_page = 1;
					
					return;
					
				}				
				else if( pag == 1 )
					$(this).addClass('disabled');
				else
					$(this).removeClass('disabled');
				
				post_stream.current_page--;
				post_stream.paginate_thumbnails(post_stream.current_page);
				$('.thumbnail-options span.count span').html(post_stream.current_page);			
				
			}).append('<i></i>');
			next = $('<a></a>').addClass('nextButton').bind('click', function(){
				
				var pag = post_stream.current_page + 1;
				var total_images = $("#templateAttachContent .attachThumbnail .thumbnails_list img").size();
				
				$(this).prev().removeClass('disabled');
				
				if( pag > total_images ){
				
					post_stream.current_page = total_images;
					
					return;
					
				}
				else if( pag == total_images )
					$(this).addClass('disabled');
				else
					$(this).removeClass('disabled');
				
				post_stream.current_page++;
				post_stream.paginate_thumbnails(post_stream.current_page);
				$('.thumbnail-options span.count span').html(post_stream.current_page);
				
			}).append('<i></i>');
			
			$(prev).addClass('disabled');
			
			$('#templateAttachContent .attachThumbnail .paginate_thumbnails').append(prev).append(next);
		
		}
		
		this.paginate_on = true;
		
		
		if( !page )
			return;
		
		this.post_vars['thumbnail'] = $(post_stream.thumbnail_pages_images[page]).attr('src');
		$("#templateAttachContent .attachThumbnail .thumbnails_list img").hide();
		$(post_stream.thumbnail_pages_images[page]).show();
		
		
	
	},
	prepare_thumbnails : function(thumbnails){
		
		var cache_thumbnails = new Array(),
			images = new Array();
		
		$.preload(thumbnails, {
				config : {'min_width' : 100, 'min_height' : 70},
				init: function(loaded, total) {
					//...
				},
				
				loaded: function(img, loaded, total) {
					
					var img_src = $(img).attr('src');
					
					$("#templateAttachContent .attachThumbnail .thumbnail-options .count").html(sprintf('<span>%d</span> de <strong>%s</strong>', post_stream.current_page, loaded));
					
					
					if( !$('#templateAttachContent').hasClass('thumbnailVisible'))
						$('#templateAttachContent').addClass('thumbnailVisible');
					
					post_stream.cache_thumbnails[loaded] = img_src;

					if( loaded == 1 ){
						
						$('#templateAttachContent').addClass('thumbnailVisible').find('.attachThumbnail').show();
						$("#templateAttachContent .attachThumbnail .thumbnails_list img").attr('src', post_stream.cache_thumbnails[1]).show();
						post_stream.post_vars['thumbnail'] = post_stream.cache_thumbnails[1];
						post_stream.paginate_thumbnails(1);
					
					}
					
					if( loaded > 1 ){
							
						var img = $('<img>').attr('src', img_src).hide();
						
						$("#templateAttachContent .attachThumbnail .thumbnails_list").append(img);						
						
					}
					
					post_stream.paginate_thumbnails(false, true);
					
				}
			});
			
	
	},
	cache_thumbnails : [],
	set_type_attach : function(type, obj){
		
		if( post_stream.attachment_on )
			return;
		
		$('.attach-options li').removeClass('selected');
		
		if(obj)
			$(obj).parent().addClass('selected');
		else
			$('.attach-options li[attach=' +  type + ']').addClass('selected');
			
		this.current_type = type;
		this.post_vars['type'] = type;
			
		$('.main-stream .post-area .stream-input i.top-dialog').removeClass('link').removeClass('video').removeClass('image').addClass(type);
		$('.preview-story .streamAttachContext').removeClass('link').removeClass('video').removeClass('image').addClass(type);
		
		if( type != 'status' && obj && !post_stream.attachment_on)
		{
		
			$('.attach-post').show()
			$('.stream-input').addClass('attach-on').find('.stream-content');
		
		}
		else
		{
		
			$('.attach-post').hide();
			$('.stream-input').removeClass('attach-on').find('.stream-content');
			
		}
	
	},
	set_privacy : function(){
		
		$('.UIdrop.privacy ul li a').live('click', function(){
		
			$('.tipsy').remove();
			
			var parent, a_data, _this;
			
			parent = $(this).parent();
			a_data = [$(this).attr('title') ? $(this).attr('title') : $(this).attr('original-title'), $(this).attr('privacy_id'), $(this).html()];
			_this = $(this);
			
			$(this).addClass('loading');
			
			$.ajax({
				type : 'POST',
				url : global.data.scripturl + '?action=stream&do=ajax&work=set-privacy-post',
				data : 'privacy=' + parseInt(a_data[1]),
				dataType: 'json',
				success : function(data){
					
					if( data.status == 'error' )
					{
						
						$(_this).removeClass('loading');
						return false;
						
					}
					
					post_stream.post_vars['privacy'] = a_data[1];
					
					$('.UIdrop.privacy a.privacy').attr('title', a_data[0]);
					
					$('.UIdrop.privacy ul li strong').each(function(){
					
						var a = $(sprintf('<a class="tt-element" gravity="e" privacy_id="%d" title="%s"></a>', $(this).attr('privacy_id'), $(this).attr('title')));
						$(this).parent().html(a);
						$(a).html($(this).html());
						
					});
					
					$(parent).html(sprintf('<strong class="selected" title="%s" privacy_id="%d">%s</strong>', a_data[0], a_data[1], a_data[2]));
				},
				complete : function(){
				
					$(_this).removeClass('loading');
					
				}
			});
		});
		
	},

}

$(document).ready(function(){

    post_stream.__init();
    stream_actions.__init();

});

/*
 * Lazy Load - jQuery plugin for lazy loading images
 *
 * Copyright (c) 2007-2012 Mika Tuupola
 *
 * Licensed under the MIT license:
 *   http://www.opensource.org/licenses/mit-license.php
 *
 * Project home:
 *   http://www.appelsiini.net/projects/lazyload
 *
 * Version:  1.7.2
 *
 */
;(function(a,b){$window=a(b),a.fn.lazyload=function(c){function f(){var b=0;d.each(function(){var c=a(this);if(e.skip_invisible&&!c.is(":visible"))return;if(!a.abovethetop(this,e)&&!a.leftofbegin(this,e))if(!a.belowthefold(this,e)&&!a.rightoffold(this,e))c.trigger("appear");else if(++b>e.failure_limit)return!1})}var d=this,e={threshold:0,failure_limit:0,event:"scroll",effect:"show",container:b,data_attribute:"original",skip_invisible:!0,appear:null,load:null};return c&&(undefined!==c.failurelimit&&(c.failure_limit=c.failurelimit,delete c.failurelimit),undefined!==c.effectspeed&&(c.effect_speed=c.effectspeed,delete c.effectspeed),a.extend(e,c)),$container=e.container===undefined||e.container===b?$window:a(e.container),0===e.event.indexOf("scroll")&&$container.bind(e.event,function(a){return f()}),this.each(function(){var b=this,c=a(b);b.loaded=!1,c.one("appear",function(){if(!this.loaded){if(e.appear){var f=d.length;e.appear.call(b,f,e)}a("<img />").bind("load",function(){c.hide().attr("src",c.data(e.data_attribute))[e.effect](e.effect_speed),b.loaded=!0;var f=a.grep(d,function(a){return!a.loaded});d=a(f);if(e.load){var g=d.length;e.load.call(b,g,e)}}).attr("src",c.data(e.data_attribute))}}),0!==e.event.indexOf("scroll")&&c.bind(e.event,function(a){b.loaded||c.trigger("appear")})}),$window.bind("resize",function(a){f()}),f(),this},a.belowthefold=function(c,d){var e;return d.container===undefined||d.container===b?e=$window.height()+$window.scrollTop():e=$container.offset().top+$container.height(),e<=a(c).offset().top-d.threshold},a.rightoffold=function(c,d){var e;return d.container===undefined||d.container===b?e=$window.width()+$window.scrollLeft():e=$container.offset().left+$container.width(),e<=a(c).offset().left-d.threshold},a.abovethetop=function(c,d){var e;return d.container===undefined||d.container===b?e=$window.scrollTop():e=$container.offset().top,e>=a(c).offset().top+d.threshold+a(c).height()},a.leftofbegin=function(c,d){var e;return d.container===undefined||d.container===b?e=$window.scrollLeft():e=$container.offset().left,e>=a(c).offset().left+d.threshold+a(c).width()},a.inviewport=function(b,c){return!a.rightofscreen(b,c)&&!a.leftofscreen(b,c)&&!a.belowthefold(b,c)&&!a.abovethetop(b,c)},a.extend(a.expr[":"],{"below-the-fold":function(c){return a.belowthefold(c,{threshold:0,container:b})},"above-the-top":function(c){return!a.belowthefold(c,{threshold:0,container:b})},"right-of-screen":function(c){return a.rightoffold(c,{threshold:0,container:b})},"left-of-screen":function(c){return!a.rightoffold(c,{threshold:0,container:b})},"in-viewport":function(c){return!a.inviewport(c,{threshold:0,container:b})},"above-the-fold":function(c){return!a.belowthefold(c,{threshold:0,container:b})},"right-of-fold":function(c){return a.rightoffold(c,{threshold:0,container:b})},"left-of-fold":function(c){return!a.rightoffold(c,{threshold:0,container:b})}})})(jQuery,window)


// Underscore.js 1.3.1
// (c) 2009-2012 Jeremy Ashkenas, DocumentCloud Inc.
// Underscore is freely distributable under the MIT license.
// Portions of Underscore are inspired or borrowed from Prototype,
// Oliver Steele's Functional, and John Resig's Micro-Templating.
// For all details and documentation:
// http://documentcloud.github.com/underscore
;(function(){function q(a,c,d){if(a===c)return a!==0||1/a==1/c;if(a==null||c==null)return a===c;if(a._chain)a=a._wrapped;if(c._chain)c=c._wrapped;if(a.isEqual&&b.isFunction(a.isEqual))return a.isEqual(c);if(c.isEqual&&b.isFunction(c.isEqual))return c.isEqual(a);var e=l.call(a);if(e!=l.call(c))return false;switch(e){case "[object String]":return a==String(c);case "[object Number]":return a!=+a?c!=+c:a==0?1/a==1/c:a==+c;case "[object Date]":case "[object Boolean]":return+a==+c;case "[object RegExp]":return a.source==
c.source&&a.global==c.global&&a.multiline==c.multiline&&a.ignoreCase==c.ignoreCase}if(typeof a!="object"||typeof c!="object")return false;for(var f=d.length;f--;)if(d[f]==a)return true;d.push(a);var f=0,g=true;if(e=="[object Array]"){if(f=a.length,g=f==c.length)for(;f--;)if(!(g=f in a==f in c&&q(a[f],c[f],d)))break}else{if("constructor"in a!="constructor"in c||a.constructor!=c.constructor)return false;for(var h in a)if(b.has(a,h)&&(f++,!(g=b.has(c,h)&&q(a[h],c[h],d))))break;if(g){for(h in c)if(b.has(c,
h)&&!f--)break;g=!f}}d.pop();return g}var r=this,G=r._,n={},k=Array.prototype,o=Object.prototype,i=k.slice,H=k.unshift,l=o.toString,I=o.hasOwnProperty,w=k.forEach,x=k.map,y=k.reduce,z=k.reduceRight,A=k.filter,B=k.every,C=k.some,p=k.indexOf,D=k.lastIndexOf,o=Array.isArray,J=Object.keys,s=Function.prototype.bind,b=function(a){return new m(a)};if(typeof exports!=="undefined"){if(typeof module!=="undefined"&&module.exports)exports=module.exports=b;exports._=b}else r._=b;b.VERSION="1.3.1";var j=b.each=
b.forEach=function(a,c,d){if(a!=null)if(w&&a.forEach===w)a.forEach(c,d);else if(a.length===+a.length)for(var e=0,f=a.length;e<f;e++){if(e in a&&c.call(d,a[e],e,a)===n)break}else for(e in a)if(b.has(a,e)&&c.call(d,a[e],e,a)===n)break};b.map=b.collect=function(a,c,b){var e=[];if(a==null)return e;if(x&&a.map===x)return a.map(c,b);j(a,function(a,g,h){e[e.length]=c.call(b,a,g,h)});if(a.length===+a.length)e.length=a.length;return e};b.reduce=b.foldl=b.inject=function(a,c,d,e){var f=arguments.length>2;a==
null&&(a=[]);if(y&&a.reduce===y)return e&&(c=b.bind(c,e)),f?a.reduce(c,d):a.reduce(c);j(a,function(a,b,i){f?d=c.call(e,d,a,b,i):(d=a,f=true)});if(!f)throw new TypeError("Reduce of empty array with no initial value");return d};b.reduceRight=b.foldr=function(a,c,d,e){var f=arguments.length>2;a==null&&(a=[]);if(z&&a.reduceRight===z)return e&&(c=b.bind(c,e)),f?a.reduceRight(c,d):a.reduceRight(c);var g=b.toArray(a).reverse();e&&!f&&(c=b.bind(c,e));return f?b.reduce(g,c,d,e):b.reduce(g,c)};b.find=b.detect=
function(a,c,b){var e;E(a,function(a,g,h){if(c.call(b,a,g,h))return e=a,true});return e};b.filter=b.select=function(a,c,b){var e=[];if(a==null)return e;if(A&&a.filter===A)return a.filter(c,b);j(a,function(a,g,h){c.call(b,a,g,h)&&(e[e.length]=a)});return e};b.reject=function(a,c,b){var e=[];if(a==null)return e;j(a,function(a,g,h){c.call(b,a,g,h)||(e[e.length]=a)});return e};b.every=b.all=function(a,c,b){var e=true;if(a==null)return e;if(B&&a.every===B)return a.every(c,b);j(a,function(a,g,h){if(!(e=
e&&c.call(b,a,g,h)))return n});return e};var E=b.some=b.any=function(a,c,d){c||(c=b.identity);var e=false;if(a==null)return e;if(C&&a.some===C)return a.some(c,d);j(a,function(a,b,h){if(e||(e=c.call(d,a,b,h)))return n});return!!e};b.include=b.contains=function(a,c){var b=false;if(a==null)return b;return p&&a.indexOf===p?a.indexOf(c)!=-1:b=E(a,function(a){return a===c})};b.invoke=function(a,c){var d=i.call(arguments,2);return b.map(a,function(a){return(b.isFunction(c)?c||a:a[c]).apply(a,d)})};b.pluck=
function(a,c){return b.map(a,function(a){return a[c]})};b.max=function(a,c,d){if(!c&&b.isArray(a))return Math.max.apply(Math,a);if(!c&&b.isEmpty(a))return-Infinity;var e={computed:-Infinity};j(a,function(a,b,h){b=c?c.call(d,a,b,h):a;b>=e.computed&&(e={value:a,computed:b})});return e.value};b.min=function(a,c,d){if(!c&&b.isArray(a))return Math.min.apply(Math,a);if(!c&&b.isEmpty(a))return Infinity;var e={computed:Infinity};j(a,function(a,b,h){b=c?c.call(d,a,b,h):a;b<e.computed&&(e={value:a,computed:b})});
return e.value};b.shuffle=function(a){var b=[],d;j(a,function(a,f){f==0?b[0]=a:(d=Math.floor(Math.random()*(f+1)),b[f]=b[d],b[d]=a)});return b};b.sortBy=function(a,c,d){return b.pluck(b.map(a,function(a,b,g){return{value:a,criteria:c.call(d,a,b,g)}}).sort(function(a,b){var c=a.criteria,d=b.criteria;return c<d?-1:c>d?1:0}),"value")};b.groupBy=function(a,c){var d={},e=b.isFunction(c)?c:function(a){return a[c]};j(a,function(a,b){var c=e(a,b);(d[c]||(d[c]=[])).push(a)});return d};b.sortedIndex=function(a,
c,d){d||(d=b.identity);for(var e=0,f=a.length;e<f;){var g=e+f>>1;d(a[g])<d(c)?e=g+1:f=g}return e};b.toArray=function(a){return!a?[]:a.toArray?a.toArray():b.isArray(a)?i.call(a):b.isArguments(a)?i.call(a):b.values(a)};b.size=function(a){return b.toArray(a).length};b.first=b.head=function(a,b,d){return b!=null&&!d?i.call(a,0,b):a[0]};b.initial=function(a,b,d){return i.call(a,0,a.length-(b==null||d?1:b))};b.last=function(a,b,d){return b!=null&&!d?i.call(a,Math.max(a.length-b,0)):a[a.length-1]};b.rest=
b.tail=function(a,b,d){return i.call(a,b==null||d?1:b)};b.compact=function(a){return b.filter(a,function(a){return!!a})};b.flatten=function(a,c){return b.reduce(a,function(a,e){if(b.isArray(e))return a.concat(c?e:b.flatten(e));a[a.length]=e;return a},[])};b.without=function(a){return b.difference(a,i.call(arguments,1))};b.uniq=b.unique=function(a,c,d){var d=d?b.map(a,d):a,e=[];b.reduce(d,function(d,g,h){if(0==h||(c===true?b.last(d)!=g:!b.include(d,g)))d[d.length]=g,e[e.length]=a[h];return d},[]);
return e};b.union=function(){return b.uniq(b.flatten(arguments,true))};b.intersection=b.intersect=function(a){var c=i.call(arguments,1);return b.filter(b.uniq(a),function(a){return b.every(c,function(c){return b.indexOf(c,a)>=0})})};b.difference=function(a){var c=b.flatten(i.call(arguments,1));return b.filter(a,function(a){return!b.include(c,a)})};b.zip=function(){for(var a=i.call(arguments),c=b.max(b.pluck(a,"length")),d=Array(c),e=0;e<c;e++)d[e]=b.pluck(a,""+e);return d};b.indexOf=function(a,c,
d){if(a==null)return-1;var e;if(d)return d=b.sortedIndex(a,c),a[d]===c?d:-1;if(p&&a.indexOf===p)return a.indexOf(c);for(d=0,e=a.length;d<e;d++)if(d in a&&a[d]===c)return d;return-1};b.lastIndexOf=function(a,b){if(a==null)return-1;if(D&&a.lastIndexOf===D)return a.lastIndexOf(b);for(var d=a.length;d--;)if(d in a&&a[d]===b)return d;return-1};b.range=function(a,b,d){arguments.length<=1&&(b=a||0,a=0);for(var d=arguments[2]||1,e=Math.max(Math.ceil((b-a)/d),0),f=0,g=Array(e);f<e;)g[f++]=a,a+=d;return g};
var F=function(){};b.bind=function(a,c){var d,e;if(a.bind===s&&s)return s.apply(a,i.call(arguments,1));if(!b.isFunction(a))throw new TypeError;e=i.call(arguments,2);return d=function(){if(!(this instanceof d))return a.apply(c,e.concat(i.call(arguments)));F.prototype=a.prototype;var b=new F,g=a.apply(b,e.concat(i.call(arguments)));return Object(g)===g?g:b}};b.bindAll=function(a){var c=i.call(arguments,1);c.length==0&&(c=b.functions(a));j(c,function(c){a[c]=b.bind(a[c],a)});return a};b.memoize=function(a,
c){var d={};c||(c=b.identity);return function(){var e=c.apply(this,arguments);return b.has(d,e)?d[e]:d[e]=a.apply(this,arguments)}};b.delay=function(a,b){var d=i.call(arguments,2);return setTimeout(function(){return a.apply(a,d)},b)};b.defer=function(a){return b.delay.apply(b,[a,1].concat(i.call(arguments,1)))};b.throttle=function(a,c){var d,e,f,g,h,i=b.debounce(function(){h=g=false},c);return function(){d=this;e=arguments;var b;f||(f=setTimeout(function(){f=null;h&&a.apply(d,e);i()},c));g?h=true:
a.apply(d,e);i();g=true}};b.debounce=function(a,b){var d;return function(){var e=this,f=arguments;clearTimeout(d);d=setTimeout(function(){d=null;a.apply(e,f)},b)}};b.once=function(a){var b=false,d;return function(){if(b)return d;b=true;return d=a.apply(this,arguments)}};b.wrap=function(a,b){return function(){var d=[a].concat(i.call(arguments,0));return b.apply(this,d)}};b.compose=function(){var a=arguments;return function(){for(var b=arguments,d=a.length-1;d>=0;d--)b=[a[d].apply(this,b)];return b[0]}};
b.after=function(a,b){return a<=0?b():function(){if(--a<1)return b.apply(this,arguments)}};b.keys=J||function(a){if(a!==Object(a))throw new TypeError("Invalid object");var c=[],d;for(d in a)b.has(a,d)&&(c[c.length]=d);return c};b.values=function(a){return b.map(a,b.identity)};b.functions=b.methods=function(a){var c=[],d;for(d in a)b.isFunction(a[d])&&c.push(d);return c.sort()};b.extend=function(a){j(i.call(arguments,1),function(b){for(var d in b)a[d]=b[d]});return a};b.defaults=function(a){j(i.call(arguments,
1),function(b){for(var d in b)a[d]==null&&(a[d]=b[d])});return a};b.clone=function(a){return!b.isObject(a)?a:b.isArray(a)?a.slice():b.extend({},a)};b.tap=function(a,b){b(a);return a};b.isEqual=function(a,b){return q(a,b,[])};b.isEmpty=function(a){if(b.isArray(a)||b.isString(a))return a.length===0;for(var c in a)if(b.has(a,c))return false;return true};b.isElement=function(a){return!!(a&&a.nodeType==1)};b.isArray=o||function(a){return l.call(a)=="[object Array]"};b.isObject=function(a){return a===Object(a)};
b.isArguments=function(a){return l.call(a)=="[object Arguments]"};if(!b.isArguments(arguments))b.isArguments=function(a){return!(!a||!b.has(a,"callee"))};b.isFunction=function(a){return l.call(a)=="[object Function]"};b.isString=function(a){return l.call(a)=="[object String]"};b.isNumber=function(a){return l.call(a)=="[object Number]"};b.isNaN=function(a){return a!==a};b.isBoolean=function(a){return a===true||a===false||l.call(a)=="[object Boolean]"};b.isDate=function(a){return l.call(a)=="[object Date]"};
b.isRegExp=function(a){return l.call(a)=="[object RegExp]"};b.isNull=function(a){return a===null};b.isUndefined=function(a){return a===void 0};b.has=function(a,b){return I.call(a,b)};b.noConflict=function(){r._=G;return this};b.identity=function(a){return a};b.times=function(a,b,d){for(var e=0;e<a;e++)b.call(d,e)};b.escape=function(a){return(""+a).replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;").replace(/"/g,"&quot;").replace(/'/g,"&#x27;").replace(/\//g,"&#x2F;")};b.mixin=function(a){j(b.functions(a),
function(c){K(c,b[c]=a[c])})};var L=0;b.uniqueId=function(a){var b=L++;return a?a+b:b};b.templateSettings={evaluate:/<%([\s\S]+?)%>/g,interpolate:/<%=([\s\S]+?)%>/g,escape:/<%-([\s\S]+?)%>/g};var t=/.^/,u=function(a){return a.replace(/\\\\/g,"\\").replace(/\\'/g,"'")};b.template=function(a,c){var d=b.templateSettings,d="var __p=[],print=function(){__p.push.apply(__p,arguments);};with(obj||{}){__p.push('"+a.replace(/\\/g,"\\\\").replace(/'/g,"\\'").replace(d.escape||t,function(a,b){return"',_.escape("+
u(b)+"),'"}).replace(d.interpolate||t,function(a,b){return"',"+u(b)+",'"}).replace(d.evaluate||t,function(a,b){return"');"+u(b).replace(/[\r\n\t]/g," ")+";__p.push('"}).replace(/\r/g,"\\r").replace(/\n/g,"\\n").replace(/\t/g,"\\t")+"');}return __p.join('');",e=new Function("obj","_",d);return c?e(c,b):function(a){return e.call(this,a,b)}};b.chain=function(a){return b(a).chain()};var m=function(a){this._wrapped=a};b.prototype=m.prototype;var v=function(a,c){return c?b(a).chain():a},K=function(a,c){m.prototype[a]=
function(){var a=i.call(arguments);H.call(a,this._wrapped);return v(c.apply(b,a),this._chain)}};b.mixin(b);j("pop,push,reverse,shift,sort,splice,unshift".split(","),function(a){var b=k[a];m.prototype[a]=function(){var d=this._wrapped;b.apply(d,arguments);var e=d.length;(a=="shift"||a=="splice")&&e===0&&delete d[0];return v(d,this._chain)}});j(["concat","join","slice"],function(a){var b=k[a];m.prototype[a]=function(){return v(b.apply(this._wrapped,arguments),this._chain)}});m.prototype.chain=function(){this._chain=
true;return this};m.prototype.value=function(){return this._wrapped}}).call(this);

/*
 * Mentions Input
 * Version 1.0.1
 * Written by: Kenneth Auchenberg (Podio)
 *
 * Using underscore.js
 *
 * License: MIT License - http://www.opensource.org/licenses/mit-license.php
 */

;(function(a,b,c){var d={BACKSPACE:8,TAB:9,RETURN:13,ESC:27,LEFT:37,UP:38,RIGHT:39,DOWN:40,COMMA:188,SPACE:32,HOME:36,END:35};var e={triggerChar:"@",onDataRequest:a.noop,minChars:2,showAvatars:true,classes:{autoCompleteItemActive:"active"},templates:{wrapper:b.template('<div class="mentions-input-box"></div>'),autocompleteList:b.template('<div class="mentions-autocomplete-list"></div>'),autocompleteListItem:b.template('<li data-ref-id="<%= id %>" data-ref-type="<%= type %>" data-display="<%= display %>"><%= content %></li>'),autocompleteListItemAvatar:b.template('<img  src="<%= avatar %>" />'),autocompleteListItemIcon:b.template('<div class="icon <%= icon %>"></div>'),mentionsOverlay:b.template('<div class="mentions"><div></div></div>'),mentionItemSyntax:b.template("@[<%= value %>](<%= type %>:<%= id %>)"),mentionItemHighlight:b.template("<strong><span><%= value %></span></strong>")}};var f={htmlEncode:function(a){return b.escape(a)},highlightTerm:function(a,b){if(!b&&!b.length){return a}return a.replace(new RegExp("(?![^&;]+;)(?!<[^<>]*)("+b+")(?![^<>]*>)(?![^&;]+;)","gi"),"<b>$1</b>")},setCaratPosition:function(a,b){if(a.createTextRange){var c=a.createTextRange();c.move("character",b);c.select()}else{if(a.selectionStart){a.focus();a.setSelectionRange(b,b)}else{a.focus()}}},rtrim:function(a){return a.replace(/\s+$/,"")}};var g=function(c){function F(a){if(a&&a.length&&a.length>=e.minChars){e.onDataRequest.call(this,"search",a,function(b){E(a,b)})}}function E(c,d){i.show();var g=b.pluck(m,"value");d=b.reject(d,function(a){return b.include(g,a.name)});if(!d.length){C();return}i.empty();var h=a("<ul>").appendTo(i).hide();b.each(d,function(b,d){var g=a(e.templates.autocompleteListItem({id:f.htmlEncode(b.id),display:f.htmlEncode(b.name),type:f.htmlEncode(b.type),content:f.highlightTerm(f.htmlEncode(b.name),c)}));if(d===0){D(g)}if(e.showAvatars){var i;if(b.avatar){i=a(e.templates.autocompleteListItemAvatar({avatar:b.avatar}))}else{i=a(e.templates.autocompleteListItemIcon({icon:b.icon}))}i.prependTo(g)}g=g.appendTo(h)});i.show();h.show()}function D(a){a.addClass(e.classes.autoCompleteItemActive);a.siblings().removeClass(e.classes.autoCompleteItemActive);l=a}function C(){l=null;i.empty().hide()}function B(c){if(c.keyCode==d.LEFT||c.keyCode==d.RIGHT||c.keyCode==d.HOME||c.keyCode==d.END){b.defer(t);return}if(c.keyCode==d.BACKSPACE){n=n.slice(0,-1+n.length);return}if(!i.is(":visible")){return true}switch(c.keyCode){case d.UP:case d.DOWN:var e=null;if(c.keyCode==d.DOWN){if(l&&l.length){e=l.next()}else{e=i.find("li").first()}}else{e=a(l).prev()}if(e.length){D(e)}return false;case d.RETURN:case d.TAB:if(l&&l.length){l.click();return false}break}return true}function A(a){var b=String.fromCharCode(a.which||a.keyCode);n.push(b)}function z(a){s();u();C();var c=b.lastIndexOf(n,e.triggerChar);if(c>-1){o=n.slice(c+1).join("");o=f.rtrim(o);b.defer(b.bind(F,this,o))}}function y(a){t()}function x(b){var c=a(this);v(c.attr("data-display"),c.attr("data-ref-id"),c.attr("data-ref-type"));return false}function w(){return a.trim(g.val())}function v(a,b,c){var d=w();var h=new RegExp("\\"+e.triggerChar+o,"gi");h.exec(d);var i=h.lastIndex-o.length-1;var j=h.lastIndex;var k=d.substr(0,i);var l=d.substr(j,d.length);var n=(k+a).length;var p=k+a+l;m.push({id:b,type:c,value:a});t();o="";C();g.val(p);s();g.focus();f.setCaratPosition(g[0],n)}function u(){var a=w();m=b.reject(m,function(b,c){return!b.value||a.indexOf(b.value)==-1});m=b.compact(m)}function t(){n=[]}function s(){var a=w();b.each(m,function(b){var c=e.templates.mentionItemSyntax({value:b.value,type:b.type,id:b.id});a=a.replace(b.value,c)});var c=f.htmlEncode(a);b.each(m,function(a){var b=e.templates.mentionItemSyntax({value:f.htmlEncode(a.value),type:a.type,id:a.id});var d=e.templates.mentionItemHighlight({value:f.htmlEncode(a.value)});c=c.replace(b,d)});c=c.replace(/\n/g,"<br />");c=c.replace(/ {2}/g,"  ");g.data("messageText",a);k.find("div").html(c)}function r(){k=a(e.templates.mentionsOverlay());k.prependTo(j)}function q(){i=a(e.templates.autocompleteList());i.appendTo(j);i.delegate("li","click",x)}function p(){g=a(c);if(g.attr("data-mentions-input")=="true"){return}h=g.parent();j=a(e.templates.wrapper());g.wrapAll(j);j=h.find("> div");g.attr("data-mentions-input","true");g.bind("keydown",B);g.bind("keypress",A);g.bind("input",z);g.bind("click",y);g.elastic()}var e;var g,h,i,j,k,l;var m=[];var n=[];var o;return{init:function(a){e=a;p();q();r()},val:function(a){if(!b.isFunction(a)){return}var c=m.length?g.data("messageText"):w();a.call(this,c)},reset:function(){g.val("");m=[];s()},getMentions:function(a){if(!b.isFunction(a)){return}a.call(this,m)}}};a.fn.mentionsInput=function(c,d){if(typeof c==="object"||!c){d=a.extend(true,{},e,c)}var f=arguments;return this.each(function(){var e=a.data(this,"mentionsInput")||a.data(this,"mentionsInput",new g(this));if(b.isFunction(e[c])){return e[c].apply(this,Array.prototype.slice.call(f,1))}else if(typeof c==="object"||!c){return e.init.call(this,d)}else{a.error("Method "+c+" does not exist")}})}})(jQuery,_)
/**
 *    @name                            Elastic
 *    @descripton                        Elastic is jQuery plugin that grow and shrink your textareas automatically
 *    @version                        1.6.10
 *    @requires                        jQuery 1.2.6+
 *
 *    @author                            Jan Jarfalk
 *    @author-email                    jan.jarfalk@unwrongest.com
 *    @author-website                    http://www.unwrongest.com
 *
 *    @licence                        MIT License - http://www.opensource.org/licenses/mit-license.php
 */
;(function(a){a.fn.extend({elastic:function(){var b=["paddingTop","paddingRight","paddingBottom","paddingLeft","marginTop","marginRight","marginBottom","marginLeft","fontSize","lineHeight","fontFamily","width","fontWeight","border-top-width","border-right-width","border-bottom-width","border-left-width","borderTopStyle","borderTopColor","borderRightStyle","borderRightColor","borderBottomStyle","borderBottomColor","borderLeftStyle","borderLeftColor","box-sizing","-moz-box-sizing","-webkit-box-sizing"];return this.each(function(){function l(a){var b=c.val().replace(/&/g,"&").replace(/ {2}/g," ").replace(/<|>/g,">").replace(/\n/g,"<br />");var h=d.html().replace(/<br>/ig,"<br />");if(a||b+" "!==h){d.html(b+" ");if(Math.abs(d.outerHeight()+e-c.outerHeight())>3){var i=d.outerHeight();if(i>=g){k(g,"auto")}else if(i<=f){k(f,"hidden")}else{k(i,"hidden")}}}}function k(a,b){var d=Math.floor(parseInt(a,10));if(c.height()!==d){c.css({height:d+"px",overflow:b});c.triggerHandler("resize")}}function j(){curatedWidth=Math.floor(parseInt(c.width(),10));if(d.width()!==curatedWidth){d.css({width:curatedWidth+"px"});l(true)}}if(this.type!=="textarea"){return false}var c=a(this),d=a("<div />").css({position:"absolute",display:"none","word-wrap":"break-word"}),e=parseInt(c.css("line-height"),10)||parseInt(c.css("font-size"),"10"),f=parseInt(c.css("height"),10)||e*3,g=parseInt(c.css("max-height"),10)||Number.MAX_VALUE,h=0;if(g<0){g=Number.MAX_VALUE}d.appendTo(c.parent());var i=b.length;while(i--){if(b[i].toString()==="width"&&c.css(b[i].toString())==="0px"){j()}else{d.css(b[i].toString(),c.css(b[i].toString()))}}l(true);c.bind("input",l);c.bind("change",l);$(window).bind("resize",j)})}})})(jQuery)