﻿<?php
if(!defined('SPIRATE'))
    die('Are you serious?');


require_once($sourcedir . '/classes/parser.class.php');

class stream{

    var $environment = 'guest';
	var $limit_act = 50;
	var $order_act = 'recents';
	var $parser = null;
	var $activity_types = array(
		'status',
		'image',
		'video',
		'link',
		'follow',
		'multi-follow',
		'multi-shared',
		're-stream'
	);
    var $followers = array();
	var $following = array();
	var $buddies = array();

    /* constructor */
    public function stream() {
        global $settings, $modSettings, $context, $ID_MEMBER;
		
        // load classes			
		if( is_null($this->parser) )
			$this->parser = new parser();
        
        // set enviroment
			$this->environment = empty($ID_MEMBER) ? 'guest' : 'logged';
        
        // set activity settings
        if(!empty($modSettings['limit_activities_feed']))
            $this->limit_activities = $modSettings['limit_activities_feed'];
		
		// activities order
		if( isset($_SESSION['order_activities']) )
			$this->order = $_SESSION['order_activities'];
		else
			$this->order = 'recents';
			
		$this->fix_stream();
		
    }
	private function fix_stream(){
		global $db_prefix, $modSettings;		
		
		// cronjonb, etc
	
	}
    /** loadActivities
     *
     * obtenemos todas las actividades, filtramos si es necesario.
     *
     * Privacy[visibilidad]
     *
     * 0 => todos pueden ver la actividad.
     * 1 => Solo tus seguidores pueden ver la actividad.
     * 2 => []
     *
     * @param string $filter
     * @return array
     */
    public function loadActivities($offset = 0, $filter = 'recent'){
        global $context, $settings, $scripturl, $db_prefix, $txt, $modSettings, $sourcedir;
        global $mbname, $ID_MEMBER, $func, $stats, $func;
		
		// $notifications = new notifications();
				
		// if( !$ID_MEMBER)
			// return false; // delete this!!! but before... schedule the environment
		
		// filtramos las actividades
		if( !in_array($filter, array('recent', 'featured', 'public')) )
			$filter = 'recent';
		
		$privacy_statement = $member_statement = '';
		
		
		if( !empty($ID_MEMBER) ){
			// obtenemos los usuarios seguidos del usuario actual.
			$result = db_query("SELECT uid FROM {$db_prefix}followers WHERE uif = $ID_MEMBER",__FILE__,__LINE__);
			$followers = array();
			while($row = mysql_fetch_assoc($result))
			{
				
				$followers[] = $row['uid'];
				$this->followers[] = $row['uid'];
				
			}
			
			// obtenemos los amigos del usuario actual
			$result = db_query("SELECT BUDDY_ID FROM {$db_prefix}buddies WHERE ID_MEMBER = $ID_MEMBER");
			$friends = array();
			while($row = mysql_fetch_assoc($result))
			{
			
				$friends[] = $row['BUDDY_ID'];
				$this->friends[] = $row['BUDDY_ID'];
			
			}
			mysql_free_result($result);
		}
		
		// si son públicas no necesitamos cargar los seguidos ni amigos del usuario actual.
		if( $filter != 'public' && !empty($ID_MEMBER) ){			
			
			// incluimoslos autores de las historias a mostrar ( incluyendo el usuario actual ).
			$match_members = array();
			
			if(!empty($followers))
				$match_members = array_merge($match_members, $followers);		
			
			if(!empty($friends))		
				$match_members = array_merge($match_members, $friends);
			
			if(!empty($ID_MEMBER))
			{
			
				array_push($followers, $ID_MEMBER);
				array_push($friends, $ID_MEMBER);
				array_push($match_members, $ID_MEMBER);
			
			}
			
			
			$match_members = array_unique($match_members);
			
			$privacy_statement = 'AND (CASE';		
			
			$privacy_statement .= "
				WHEN a.privacy = 1
					THEN a.privacy IN(1, 2, 3)
				";
			
			$privacy_statement .= "
				WHEN a.privacy = 2
					THEN (CASE
							WHEN a.subject NOT IN(" . implode(',', empty($followers) ? array(-1) : $followers) . ")
							THEN a.privacy IN(0, 1)
							ELSE a.privacy IN(0, 1, 2)
						END)
				";
			
			$privacy_statement .= "
				WHEN a.privacy = 3
					THEN (CASE
							WHEN a.subject NOT IN(" . implode(',', empty($friends) ? array(-1) : $friends) . ")
							THEN a.privacy IN(0, 1)
							ELSE a.privacy IN(0, 1, 3)
						END)
				";
			
			$privacy_statement .= "
				WHEN a.privacy = 4
					THEN a.subject = $ID_MEMBER
				";
			
			$privacy_statement .= '
			ELSE a.privacy = 0
				END)';
				
			$member_statement = "
			(CASE WHEN a.object = $ID_MEMBER
								THEN 
									a.subject = mem.ID_MEMBER
								ELSE
									a.subject IN(".implode(',', $match_members).")
									AND a.subject = mem.ID_MEMBER
							END)
							";
			
		}else{
			
			$member_statement = 'a.subject = mem.ID_MEMBER';
			$privacy_statement = 'AND a.privacy = 0';
		
		}
		
		$allowed_types = array('status', 'video', 'link', 'image', 'follow', 're-stream');
		array_walk($allowed_types, create_function('&$type', '$type = "\'" . $type . "\'"; '));
		
		// Monster query
		$result = db_query("SELECT a.id as ID, a.type, a.subject, a.object, a.subj_type, a.obj_type, a.time, a.privacy, s.msg,
							s.thumbnail, s.coords_thumbnail, s.likes, s.comments, s.re_streams, mem.memberName, mem.realName, mem.avatar,
							mem.avatar_coords, attach.url AS attach_url, attach.ID_ATTACH, attach.width AS attach_width,
							attach.height AS attach_height, attach.params AS attach_params
							FROM ({$db_prefix}activity as a, {$db_prefix}members as mem)
							LEFT JOIN {$db_prefix}activity_stream AS s ON ( s.activity_id = a.id )
							LEFT JOIN {$db_prefix}activity_attachments AS attach ON ( s.ID_ATTACH = attach.ID_ATTACH )
							WHERE
							{$member_statement}
							AND a.type IN(".implode(', ', $allowed_types).")
							{$privacy_statement}
							ORDER BY a.id DESC
							LIMIT {$offset}, {$this->limit_act}
							",__FILE__,__LINE__);
		$stories = array();
		$temp_reStreams = array();
		
		while( $row = mysql_fetch_assoc($result) )
		{
				
			$object = false;
			
			if( $row['subject'] != $row['object'] )
				switch( $row['obj_type'] )
				{
				
					case 'user':
						
						$r_obj = db_query("SELECT ID_MEMBER AS id, memberName AS name, avatar_coords, avatar FROM {$db_prefix}members WHERE ID_MEMBER = $row[object] LIMIT 1",__FILE__,__LINE__);
						$object = mysql_fetch_assoc($r_obj);
						
						$object['href'] = $scripturl . '?action=profile;u=' . $object['id'];
						
						$object['avatar'] = array(
							'src' => $object['avatar'],
							'coords' =>  makeAvatarCoords($object['avatar_coords'], 48, true)
						);
						unset($object['avatar_coords']);
						
						mysql_free_result($r_obj);
					
					break;
					case 'post':
					
						$r_obj = db_query("SELECT ID_TOPIC AS id, subject AS name FROM {$db_prefix}members WHERE ID_TOPIC = $row[object] LIMIT 1",__FILE__,__LINE__);
						$object = mysql_fetch_assoc($r_obj);
						$object['href'] = $scripturl . '?topic=' . $object['id'] . ';rel=stream';
						mysql_free_result($r_obj);
						
					break;
				}
				
			if( $row['type'] == 're-stream' )
				$temp_reStreams[] = array(
							'id' => $row['ID'],
							'object' => $row['object']
						);
			
			
			// key with timestamp, js facility
			$key_time = $row['time'] . '.' . $row['ID'];
			
			
			$this->prepareStoryRow($row, $stories, $object);
			
		}
		mysql_free_result($result);
		
		// agregamos los re streams a las historias.
		
		$missedReStreams = array();
		
		// estos re streams contienen historias ya vistas en la consulta anterior.
		foreach( $temp_reStreams as $key => $re_stream ){
		
			if( in_array($re_stream['object'], array_keys($stories)) )
			{
				
				$stories[$re_stream['id']]['is_own_author'] = $stories[$re_stream['object']]['member']['id'] ==  $stories[$re_stream['id']]['member']['id'];
				$stories[$re_stream['id']]['story']['type'] = $stories[$re_stream['object']]['story']['type'];
				$stories[$re_stream['id']]['story']['body'] = $stories[$re_stream['object']]['story']['body'];
				$stories[$re_stream['id']]['story']['stats'] = $stories[$re_stream['object']]['story']['stats'];
				$stories[$re_stream['object']]['member']['avatar']['coords'] = makeAvatarCoords($stories[$re_stream['object']]['member']['avatar']['source_coords'], 32, true);
				$stories[$re_stream['id']]['object'] = array(
					'member' => $stories[$re_stream['object']]['member'],
					'stream' => $stories[$re_stream['object']]['story']
				);
				$stories[$re_stream['id']]['story']['action'] = $this->getActionTextByType(
					$stories[$re_stream['object']]['story']['type'],
					$stories[$re_stream['id']]['is_own_author'] ? 'own-author' : ($ID_MEMBER == $stories[$re_stream['object']]['member']['id']), 
					true,
					$stories[$re_stream['object']]
				);
				$stories[$re_stream['id']]['attach'] = $stories[$re_stream['object']]['attach'];
				
				unset($temp_reStreams[$key]);
				
			}
			else
				$missedReStreams[$re_stream['object']] = $re_stream['id'];
				
			$stories[$re_stream['id']]['story'] += array(
					'is_shared' => true
				);
		
		}
		
		// buscamos streams en la base de datos.
		if( !empty( $missedReStreams ) )
		{
		
			$result = db_query("SELECT a.id as ID, a.type, a.subject, a.object, a.subj_type, a.obj_type, a.time, a.privacy, s.msg,
								s.thumbnail, s.coords_thumbnail, s.likes, s.comments, s.re_streams, mem.memberName, mem.realName, mem.avatar,
								mem.avatar_coords, attach.url AS attach_url, attach.ID_ATTACH, attach.width AS attach_width,
								attach.height AS attach_height, attach.params AS attach_params
								FROM ({$db_prefix}activity as a, {$db_prefix}members as mem)
								LEFT JOIN {$db_prefix}activity_stream AS s ON ( s.activity_id = a.id )
								LEFT JOIN {$db_prefix}activity_attachments AS attach ON ( s.ID_ATTACH = attach.ID_ATTACH )
								WHERE a.id IN(" . implode(',', array_keys($missedReStreams)) . ")
								AND mem.ID_MEMBER = a.subject
								{$privacy_statement}",__FILE__,__LINE__);
		
			while($row = mysql_fetch_assoc($result)){
			
				$this->prepareStoryRow($row, $stories, false);
				
				$stories[$missedReStreams[$row['ID']]]['is_own_author'] = $stories[$row['ID']]['member']['id'] == $stories[$missedReStreams[$row['ID']]]['member']['id'];
				$stories[$missedReStreams[$row['ID']]]['story']['type'] = $row['type'];
				$stories[$missedReStreams[$row['ID']]]['story']['body'] = $stories[$row['ID']]['story']['body'];
				$stories[$missedReStreams[$row['ID']]]['story']['stats'] = $stories[$row['ID']]['story']['stats'];
				$stories[$missedReStreams[$row['ID']]]['story']['object'] = array(
					'member' => $stories[$row['ID']]['member'],
					'stream' => $stories[$row['ID']]['story']
				);
				$stories[$missedReStreams[$row['ID']]]['story']['action'] = $this->getActionTextByType(
					$row['type'],
					$stories[$missedReStreams[$row['ID']]]['is_own_author'] ? 'own-author' : ($ID_MEMBER == $stories[$row['ID']]['member']['id']), 
					true,
					$stories[$row['ID']]
				);
				$stories[$missedReStreams[$row['ID']]]['attach'] = $stories[$row['ID']]['attach'];
				
				unset($stories[$row['ID']]);
				
			}
		
		}
		
		
		if(empty($stories))
			return array(
			'errors' => array(
				array('txt' => 'empty_stories', 'class' => 'empty-stories')
			)
		);
		
		// agroup stories
		$this->clusterStories($stories);
		
        return $stories;
    }
	private function prepareStoryRow($row, &$stories, $object){
		global $context, $settings, $scripturl, $db_prefix, $txt, $modSettings, $sourcedir;
        global $mbname, $ID_MEMBER, $func, $stats, $func;
		
		$google_cache = true;
		$expire_param_gc = 31536000; // one year!
		
		//verificar si el usuario ya comento, dio un like o hizo un re-stream en una publicacion.
			$disabled_comment = $disabled_like = $disabled_reStream = false;			
			
			if( !$this->isShortActivity($row['type']) && !empty($ID_MEMBER))
			{
				
				$r_comments = db_query("SELECT ID_COMMENT FROM {$db_prefix}activity_comments WHERE ID_MEMBER = $ID_MEMBER AND ID_STORY = $row[ID] LIMIT 1",__FILE__,__LINE__);
				$disabled_comment = mysql_num_rows($r_comments) > 0 ? true : false;
				mysql_free_result($r_comments);
				
				// check comment | privacy => 3 ? nobody can comment
				if($row['privacy'] != 3)
				{
				
					//...
				
				}
				
				if( $row['subject'] != $ID_MEMBER ){
					// check like
					$r_likes = db_query("SELECT ID_LIKE FROM {$db_prefix}activity_likes WHERE ID_MEMBER = $ID_MEMBER AND ID_STORY = $row[ID] LIMIT 1",__FILE__,__LINE__);
					$disabled_like = mysql_num_rows($r_likes) > 0 ? true : false;
					mysql_free_result($r_likes);
					
				}
				else
					$disabled_like = true;
				
				// check re stream <-- only logged, schedule!!
				if( $this->environment == 'guest' )
					$disabled_reStream = 'hide';
				else{
					
					$r_reStreams = db_query("SELECT ID_STORY FROM {$db_prefix}activity_re_streams WHERE ID_MEMBER = $ID_MEMBER AND ID_STORY = $row[ID] LIMIT 1",__FILE__,__LINE__);
					$disabled_reStream = mysql_num_rows($r_reStreams) > 0 ? true : false;
					mysql_free_result($r_reStreams);
				
				}
				
			}
			else
				$disabled_like = $disabled_reStream = 'hide';
		
		$stories[$row['ID']] = array(
				'member' => array(
					'id' => $row['subject'],
					'href' => $scripturl . '?action=profile;u=' . $row['subject'],
					'name' => $row['memberName'],
					'real_name' => $row['realName'],
					'avatar' => array(
						'src' => $row['avatar'],
						'source_coords' => $row['avatar_coords'],
						'coords' => makeAvatarCoords( $row['avatar_coords'], 48, true )
					)
				),
				'object' => $object && !empty($object) ? array(
					'id' => $object['id'],
					'name' => $object['name'],
					'href' => $object['href'],
					'image' => isset($object['avatar']) ? array(
						'avatar' => array(
							'src' => $object['avatar']['src'],
							'coords' => $object['avatar']['coords']
						)
					) : false,
				) : false,
				'story' => array(
					'id' => $row['ID'],
					'type' => $row['type'],
					'time' => array(
						'stamp' => $row['time'],
						'text' => strtolower(hace($row['time'])),
						'date' => date('d/m/Y - g:i:s', $row['time']),
						'date-row' => $row['date']
					),
					'date' => $row['date'],
					'privacy' => $row['privacy'],					
					'stats' => array(
						'comments' => $row['comments'],
						'likes' => $row['likes'],
						're_streams' => $row['re_streams'],
						'disabled' => array(
							'comment' => $disabled_comment,
							'like' => $disabled_like, //'hide',
							're_stream' => $disabled_reStream //'hide'
						)
					)
				),
				'attach' => false
			);
			
			// add avatar coords
			if( $row['obj_type'] == 'user' )
				$stories[$row['ID']]['object']['avatar']['coords'] = makeAvatarCoords( $object['avatar']['coords'] , 48, true );
			
			// add body
			if( !$this->isShortActivity($row['type']) ){
				$this->parseActivityMsg($row['msg'], true, true);
				$stories[$row['ID']]['story']['body'] = $row['msg'];
				
			}
			
			// add action sentence
			$stories[$row['ID']]['story']['action'] = $this->getActionTextByType($row['type'], $ID_MEMBER == $row['object'], 
				false, $this->isShortActivity($row['type']) ? $stories[$row['ID']] : false
			);
			
			// add attachment
			if( !empty($row['ID_ATTACH']) ){
				
				$coordThumbnail = false;
				
				if( $row['coords_thumbnail'] ){
					$offset_thumbnail = unserialize($row['coords_thumbnail']);
					$coordThumbnail =  ($offset_thumbnail['top'] ? sprintf('top: -%dpx; ', $offset_thumbnail['top']) : '') .
										($offset_thumbnail['left'] ?  sprintf('left: -%dpx; ', $offset_thumbnail['left']) : '');
				}
				
				$stories[$row['ID']]['attach'] = array(
					'id' => $row['ID_ATTACH'],
					'url' => urldecode($row['attach_url']),
					'width' => $row['attach_width'] ? $row['attach_width'] : false,
					'height' => $row['attach_height'] ? $row['attach_'] : false,
					'align' => $coordThumbnail ? $coordThumbnail : false,
					'thumbnail' => !empty($row['thumbnail']) ? $row['thumbnail'] : false,
					'params' => unserialize($row['attach_params']),
				);
				
				$google_cache_srvcs = array(
					'http://images0-focus-opensocial.googleusercontent.com/gadgets/proxy?container=focus&gadget=a&resize_w=%d&resize_h=%d&refresh=%d&url=%s',
					'http://images1-focus-opensocial.googleusercontent.com/gadgets/proxy?container=focus&gadget=a&resize_w=%d&resize_h=%d&refresh=%d&url=%s',
					'http://images2-focus-opensocial.googleusercontent.com/gadgets/proxy?container=focus&gadget=a&resize_w=%d&resize_h=%d&refresh=%d&url=%s',
					'http://images3-focus-opensocial.googleusercontent.com/gadgets/proxy?container=focus&gadget=a&resize_w=%d&resize_h=%d&refresh=%d&url=%s',
					'http://images4-focus-opensocial.googleusercontent.com/gadgets/proxy?container=focus&gadget=a&resize_w=%&resize_h=%d&refresh=%d&url=%s',
					'http://images5-focus-opensocial.googleusercontent.com/gadgets/proxy?container=focus&gadget=a&resize_w=%d&resize_h=%d&refresh=%d&url=%s',
					'http://images6-focus-opensocial.googleusercontent.com/gadgets/proxy?container=focus&gadget=a&resize_w=%d&resize_h=%d&refresh=%d&url=%s'
				);
				
				if($stories[$row['ID']]['attach']['thumbnail'] && $google_cache)
						$stories[$row['ID']]['attach']['thumbnail'] = sprintf(str_replace('&resize_h=%d', '', $google_cache_srvcs[0]), 110, $expire_param_gc, urlencode($stories[$row['ID']]['attach']['thumbnail']));
				
				if( $row['type'] == 'image' ){
					
					if( $google_cache ){
					
						$sprintf_params = array();
						
						if( isset($stories[$row['ID']]['attach']['params']['maxWidth']) )
							$sprintf_params[] = $stories[$row['ID']]['attach']['params']['maxWidth'];
						else
							$google_cache_srvcs[1] = str_replace('&resize_w=%d', '', $google_cache_srvcs[1]);
						
						if( isset($stories[$row['ID']]['attach']['params']['maxHeight']) )
							$sprintf_params[] = $stories[$row['ID']]['attach']['params']['maxHeight'];
						else
							$google_cache_srvcs[1] = str_replace('&resize_h=%d', '', $google_cache_srvcs[1]);
						
						$sprintf_params[] = $expire_param_gc;
						$sprintf_params[] = $row['attach_url'];
						
						$stories[$row['ID']]['attach']['src'] = vsprintf($google_cache_srvcs[1], $sprintf_params);
					
					}
					else
						$stories[$row['ID']]['attach']['src'] = $stories[$row['ID']]['attach']['url'];
						
					unset($stories[$row['ID']]['attach']['url']);
					
				}
				
				if( $row['type'] == 'video' && isset($stories[$row['ID']]['attach']['params']['mime']) && $stories[$row['ID']]['attach']['params']['mime'] == 'application/x-shockwave-flash')
					$stories[$row['ID']]['story']['type'] = 'video/swf';					
					
				if( isset($stories[$row['ID']]['attach']['params']['domain']) )
					$stories[$row['ID']]['attach']['favicon'] = 'http://www.google.com/s2/favicons?domain=' . $stories[$row['ID']]['attach']['params']['domain'];
				
				if( isset($stories[$row['ID']]['attach']['params']['description']) && !empty($stories[$row['ID']]['attach']['params']['description']) )
					$stories[$row['ID']]['attach']['params']['description'] = $func['substr']($stories[$row['ID']]['attach']['params']['description'], 0, 90) . (strlen($stories[$row['ID']]['attach']['params']['description']) > 90 ? '...' : '');
					
			}
	
	}
	public function addLike($story){
		global $db_prefix, $ID_MEMBER;
		
		$story = (int) $story;
		
		if(empty($story))
			return false;
			
		if(empty($ID_MEMBER))
			return false;
		
		$enabled_likes = array(
			'status',
			'video',
			'image',
			'link'
		);
		
		array_walk($enabled_likes, create_function('&$type', '$type = "\'" . $type . "\'"; '));
		
		$result = db_query("SELECT id, privacy, subject
							FROM {$db_prefix}activity
							WHERE id = $story
							AND type IN (" . implode(', ', $enabled_likes) . ")",__FILE__,__LINE__);
		
		$exists = (mysql_num_rows($result) > 0);
		list($activity_id, $privacy, $subject) = mysql_fetch_row($result);
		mysql_free_result($result);
		
		if(!$exists)
			return false;
		
		if( $ID_MEMBER == $subject )
			return false;
		
		if( !$this->isAllowed($subject, $ID_MEMBER, $privacy) )
			return false;
		
		$result = db_query("SELECT ID_MEMBER FROM {$db_prefix}activity_likes WHERE ID_MEMBER = $ID_MEMBER AND ID_STORY = $story",__FILE__,__LINE__);
		$did_like = (mysql_num_rows($result) > 0);
		mysql_free_result($result);
		
		if( $did_like )
			return false;
		
		db_query("INSERT INTO {$db_prefix}activity_likes(ID_MEMBER, ID_STORY, time)
					VALUES( $ID_MEMBER, $story, " . time() . ")",__FILE__,__LINE__);
		
		$this->addActivity('like', array('story', $story), array('user', $ID_MEMBER), null, false);
		
		db_query("UPDATE {$db_prefix}activity_stream SET likes = likes + 1 WHERE activity_id = $story",__FILE__,__LINE__);
		
		return true;
		
	}
	public function addReStream($story){
		global $db_prefix, $ID_MEMBER;
		
		$story = (int) $story;
		
		if(empty($story))
			return false;
			
		if(empty($ID_MEMBER))
			return false;
			
		$result = db_query("SELECT id, privacy, subject
							FROM {$db_prefix}activity
							WHERE id = $story",__FILE__,__LINE__);
		
		$exists = (mysql_num_rows($result) > 0);
		list($activity_id, $privacy, $subject) = mysql_fetch_row($result);
		mysql_free_result($result);
		
		if(!$exists)
			return false;
		
		if( !$this->isAllowed($subject, $ID_MEMBER, $privacy) )
			return false;
			
		$result = db_query("SELECT ID_STORY FROM {$db_prefix}activity_re_streams WHERE ID_MEMBER = $ID_MEMBER AND ID_STORY = $story",__FILE__,__LINE__);
		$really_shared = (mysql_num_rows($result) > 0);
		mysql_free_result($result);
		
		if( $really_shared )
			return false;
		
		db_query("INSERT INTO {$db_prefix}activity_re_streams(ID_MEMBER, ID_STORY, time)
					VALUES( $ID_MEMBER, $story, " . time() . ")",__FILE__,__LINE__);
		
		
		$this->addActivity('re-stream', array('story', $story), array('user', $ID_MEMBER), null, false);
		
		db_query("UPDATE {$db_prefix}activity_stream SET re_streams = re_streams + 1 WHERE activity_id = $story",__FILE__,__LINE__);
	
	}
	public function isAllowed($subject, $object, $privacy){
		$db_prefix;
		
		$allowed = false;
		
		switch($privacy){
			
			case 0:
				$allowed = true;
			break;
			case 1:
			case 2:
			case 3:
				
				if( $privacy == 1 || $privacy == 2 ){
				
				$result = db_query("SELECT uif FROM {$db_prefix}followers WHERE uif = $subject AND uid = $object LIMIT 1",__FILE__,__LINE__);
				$is_follower = (mysql_num_rows($result) > 0);
				mysql_free_result($result);
				
				$allowed = $is_follower;
				
				}
				
				$check_buddy = ($privacy == 1 ? (!$is_follower) : ($privacy == 3));
				
				if( $check_buddy ){
				
					$result = db_query("SELECT BUDDY_ID FROM {$db_prefix}buddies WHERE BUDDY_ID = $subject AND ID_MEMBER = $object LIMIT 1",__FILE__,__LINE__);
					$is_buddy = (mysql_num_rows($result) > 0);
					mysql_free_result($result);
					
					$allowed = $is_buddy;
					
				}
			
			break;
			case 4:
				// nadie mas que el autor puede saber de esta publicacion.
				$allowed = false;
			break;
			
		}
		
		return $allowed;
	}
	public function addAttach($attach){
		global $context, $db_prefix, $ID_MEMBER, $skip_image;
		
		$data = $this->checkAttach($attach['url'], true, $attach['type']);
		
		if( !$data || !$data['result'])
			return false;
		
		$cache_attach_id = isset($data['attachment_id']) ? $data['attachment_id'] : false;
		
		if( isset($data['attachment_id']) )
			unset($data['attachment_id']);
		
		$data = $data['result'];
		$push_data = array();
		
		if( $attach['type'] == 'link' && (!isset($data['thumbnail']) || empty($data['thumbnail'])) && isset($attach['thumbnail']) )
		{
			
			if( in_array($attach['thumbnail'], $data['thumbnails']) ){
				
				$size_thumbnail = getimagesize($attach['thumbnail']);
				$scaled = $this->getScaledCoords(100, 0, $size_thumbnail[0], $size_thumbnail[1]);
				
				if( $size_thumbnail && $scaled[0] >= 100 && $scaled[1] >= 70)
					$data['thumbnail'] = $attach['thumbnail'];
				
			}
		
		}
		
		$thumbnail = '';
		
		
		if( $data['thumbnail'] ){
			$thumbnail = $data['thumbnail'];
			$push_data['thumbnail'] = $data['thumbnail'];
		}
		
		unset($data['thumbnails']);
		
		if( $attach['type'] == 'link' )
			unset($data['thumbnail']);
		
		//	720 es el maximo ancho de la imagen, 372 x 350, son las dimensiones de ( .preview-story .thumbwrap )
		$max_width = 720;
		
		if( ($attach['image_scroll_top'] || $attach['image_scroll_left']) && ($data['width'] > 372 || $data['height'] > 350))
		{
			
			//	calculate scaled images
			$scaled = $this->getScaledCoords($max_width, 0, $data['width'], $data['height']);
			
			if($attach['image_scroll_top'])
				$push_data['img_pos_top'] = (($scaled[1]-$attach['image_scroll_top']) >= 350) ? $attach['image_scroll_top'] : ($scaled[1] - 350);
						
			if($attach['image_scroll_left'])
				$push_data['img_pos_left'] = (($scaled[0]-$attach['image_scroll_left']) >= 372) ? $attach['image_scroll_left'] : ($scaled[0] - 372);
			
			$data += array(
				'maxWidth' => $scaled[0],
				'maxHeight' => $scaled[1]
			);
			
			unset($attach['image_scroll_top']);
			unset($attach['image_scroll_left']);
		
		}
		
		$serialized_parameters = serialize($data);
		
		if( !$cache_attach_id )
		{
			
			$prepare_url = preg_replace(array('~^\+{1,}~', '~\+{1,}$~'), '', urlencode($attach['url']));
			
			db_query("INSERT INTO {$db_prefix}activity_attachments ( attachmentType, url, width, height, time_add, params)
						VALUES('$attach[type]', '$prepare_url', '$data[width]', '$data[height]', '" . time() . "', '$serialized_parameters')",__FILE__,__LINE__);
			
			$attach_ID = mysql_insert_id();
			
			if( !empty($attach_ID) )
				return array($attach_ID, $push_data);
			else
				return false;
		}
		else
			return array($cache_attach_id, $push_data);
		
		
	}
	public function addActivity($type, $object = array('type' => 'user', 'id' => 'own'), $subject = array('type' => 'user', 'id' => 'own'), $data = array(), $is_post = true){
		global $ID_MEMBER, $db_prefix, $context, $settings, $modSettings, $topic, $story_id;
		
		$parse_params = false;
		$params = array('object' => $object, 'subject' => $subject);
		
		foreach( $params as $key => $target )
		{
		
			if( is_string($target) )
			{
				$target = preg_replace('~\s|\r|\n|\t~', '', $target);
							
				if( preg_match('~^\[([^,]+),([^\]]+)]$~', $target, $toArray) )
				{
				
					$params[$key] = array('type' => $toArray[1], 'id' => $toArray[2]);					
					$parse_params = true;
					
				}
				
			}
			else if( is_array($target) && count($target) == 2 && is_string($target[0]) && is_numeric($target[1]))
			{
			
				$params[$key] = array('type' => $target[0], 'id' => $target[1]);
				$parse_params = true;
			
			}
		
		}
		
		if( $parse_params )
		{
			
			if( $params['object'] )
				$object = $params['object'];
			
			if( $params['subject'] )
				$subject = $params['subject'];
			
		}		
		
		// determine id		
		$skipCheckSubjectID = false;
		if( $subject['id'] == 'own' )
		{
			switch( $subject['type'] )
			{
				case 'user':
				
					$subject['id'] = $ID_MEMBER;
					
				break;
				case 'post':
				
					$subject['id'] = $topic;
					
				break;
				case 'story':
					
					$object['id'] = $story_id;
					
				break;
				default:
				
					$subject['id'] = 0;
					
				break;
			}
			
			$skipCheckSubjectID = !empty($subject['id']);
			
		}
		
		if( $object['id'] == 'own' )
		{
			switch( $object['type'] )
			{
				case 'user':
				
					$object['id'] = $ID_MEMBER;
					
				break;
				case 'post':
				
					$object['id'] = $topic;
					
				break;
				case 'story':
					
					$object['id'] = $story_id;
					
				break;
				default:
				
					$object['id'] = 0;
					
				break;
			}			
		}		
				
		$object['id'] = (int)$object['id'];
		$subject['id'] = (int)$subject['id'];
		
		// no id ? 
		if(empty($subject['id']) || empty($object['id']))
			return false;
		
		$queriesCheckID = array(
				'user' => array('ID_MEMBER', $db_prefix . 'members'),
				'post' => array('ID_TOPIC', $db_prefix . 'topics'),
				'story' => array('activity_id', $db_prefix . 'activity_stream')
		);
		
		if(empty($queriesCheckID[$subject['type']]) || empty($queriesCheckID[$object['type']]))
			return false;		
		
		// check subject ID
		if( !$skipCheckSubjectID )
		{
		
			$result = db_query("SELECT " . $queriesCheckID[$subject['type']][0] . "
								FROM " . $queriesCheckID[$subject['type']][1] . "
								WHERE " . $queriesCheckID[$subject['type']][0] . " = " . $subject['id'] . "
								LIMIT 1",__FILE__,__LINE__);
			if( mysql_num_rows($result) == 0 )
				return false; // log error ( 'subject not exists' )
				
			mysql_free_result($result);
			
		}
		
		// check object ID
		if( count(array_diff(array($subject['id'], $subject['type']), array($object['id'], $object['type']))) > 0 )
		{
			
			$result = db_query("SELECT " . $queriesCheckID[$object['type']][0] . "
								FROM " . $queriesCheckID[$object['type']][1] . "
								WHERE " . $queriesCheckID[$object['type']][0] . " = " . $object['id'] . "
								LIMIT 1",__FILE__,__LINE__);
			if( mysql_num_rows($result) == 0 )
				return false; // log error ( 'object not exists' )
			
			mysql_free_result($result);
		
		}
		
		// Don't forget! => comma and space "var1, var2"
		$set_privacy = array(
			'status, video, image, link, re-stream' => 'post',
			'follow' => 'see_follows',
			'like' => 'see_likes'
		);
		
		foreach( $set_privacy as $types => $privacy_check ){
		
			$types = explode(', ', $types);
			
			if( in_array($type, $types) ){		
				$check_privacy_field = $privacy_check;
				break;				
			}
			
		}
		
		$ignore_abort = ignore_user_abort(true);
		
		if( !isset($check_privacy_field) )
			return false;
		
		$privacy_activity = $this->getPrivacyUser($check_privacy_field);
		
		if( isset($data['disabled_comments']) && ($data['disabled_comments'] ? '0' : '1') !== $this->getPrivacyUser('allow_comments') )
			$this->setPrivacyUser('allow_comments', $data['disabled_comments'] ? 0 : 1);
		
		
		if( !in_array($type, array('follow', 'change_avatar')) )
			$allow_comments = $this->getPrivacyUser('allow_comments'); // !!! agregar columna allow_comments a smf_activity_stream
		else
			$allow_comments = 0;
		
		$time = time();
		$date = date('Y-m-d', time());
		
		
		if( !$is_post ){
			
			db_query("INSERT INTO {$db_prefix}activity (type, subject, object, subj_type, obj_type, time, date, privacy)
					VALUES('$type', $subject[id], $object[id], '$subject[type]', '$object[type]', $time, '$date', $privacy_activity)",__FILE__,__LINE__);
		
			$activity_id = db_insert_id();
			
			ignore_user_abort($ignore_abort);
			
			return (empty($activity_id));
			
		}
		
		
		// message text, mentions
		if( (empty($data['message']) || !isset($data['message']) || trim($data['message']) == '') && !$this->isShortActivity($type) )
			$data['message'] = '';
		else
			$data['message'] = htmlspecialchars($data['message'], ENT_QUOTES, 'UTF-8');
		
		
		$attachment_ID = 0;
		$optional_rows = array();
		
		if( $data['attach_on'] ){
			
			$data['attach_data']['type'] = $type;			
			
			$attachment = $this->addAttach($data['attach_data']);
			list($attachment_ID, $attach_data) = $attachment;
			
			if( $attachment === false ){
			
				$attachment_ID = 0;
			
			}else{
				
				if( $attach_data['thumbnail'] )
					$optional_rows['thumbnail'] = "'$attach_data[thumbnail]'";
				
				if( $attach_data['img_pos_top']  || $attach_data['img_pos_left'] )
				{
				
					$coords_thumbnail = array();
					
					if( $attach_data['img_pos_top'] )
						$coords_thumbnail['top'] = $attach_data['img_pos_top'];
						
					if( $attach_data['img_pos_left'] )
						$coords_thumbnail['left'] = $attach_data['img_pos_left'];
				
					if(!empty($coords_thumbnail))
						$optional_rows['coords_thumbnail'] = "'" . serialize($coords_thumbnail) . "'";
					
				}
			}
		}
		
		if( empty($attachment_ID) )
			$type = 'status';
			
		db_query("INSERT INTO {$db_prefix}activity (type, subject, object, subj_type, obj_type, time, date, privacy)
					VALUES('$type', $subject[id], $object[id], '$subject[type]', '$object[type]', $time, '$date', $privacy_activity)",__FILE__,__LINE__);
		
		$activity_id = db_insert_id();
		
		if( empty($activity_id) )
			return false;
		
		$stream_rows = array(
			'activity_id' => $activity_id,
			'ID_ATTACH' => $attachment_ID,
			'msg' => "'$data[message]'"
		);
		
		if( !empty($optional_rows) )
		{
						
			$stream_rows = array_slice($stream_rows, 0, array_search('msg', array_keys($stream_rows))+1, true) +
						   $optional_rows +
						   array_slice($stream_rows, array_search('msg', array_keys($stream_rows))+1, null, true);
		
		}
		
		
		db_query("INSERT INTO {$db_prefix}activity_stream (" . implode(', ', array_keys($stream_rows)) . ")
					VALUES(" . implode(', ', array_values($stream_rows)) . ")",__FILE__,__LINE__);
		
		$result = db_query("SELECT activity_id FROM {$db_prefix}activity_stream WHERE activity_id = $activity_id LIMIT 1",__FILE__,__LINE__);
		$inserted = (mysql_num_rows($result) > 0);
		mysql_free_result($result);
		
		ignore_user_abort($ignore_abort);

		if( !$inserted )
			return false;
		
		// more one stream
		updateMemberData($subject['id'], array('streams' => '+'));
		trackStats(array('streams' => '+'));
		trackStats();
		
		return $activity_id;
		
	}
	public function setPrivacyUser($row, $value, $user = 'own'){
		global $context, $db_prefix, $ID_MEMBER;
		
		if( $user == 'own' )
			$user = $ID_MEMBER;
		else
			$user = (int) $user;			
		
		if(empty($user))
			return false;
		
		if(empty($row))
			return false;
		
		$updated = updatePrivacyUser($user, array('stream' => $row), $value);
		
		return $updated;
	
	}
	public function getPrivacyUser($row, $user = 'own'){
		global $ID_MEMBER, $db_prefix;
		
		if( $user == 'own' )
			$user = $ID_MEMBER;
		else
			$user = (int) $user;			
		
		if(empty($user))
			return false;
		
		if(empty($row))
			return false;
		
		if(($privacy = getPrivacyUser($user, array('stream' => $row))) === false)
			return false;
		
		return $privacy;
	
	}
	public function checkAttach($link, $force = false, $type_recursive = false, $is_preview = false){
		global $context, $db_prefix, $skip_image;
		
		$data = array();
		$filter_search = array();
		
		if(!preg_match('~((?:http|https|ftp|ftps)://[\w\-_%@:|]+(?:\.[\w\-_%]+)*(?::\d+)?(?:/[\w\-_\~%\.@,\?&;=#(){}+:\'\\\\]*)*[/\w\-_\~%@\?;=#}\\\\])~i', $link))
			return false;
		
		$url_encode = preg_replace(array('~^\+{1,}~', '~\+{1,}$~'), '', urlencode($link));
		//echo 'checkAttach: "' . $url_encode . '"';
		$result = db_query("SELECT ID_ATTACH, attachmentType, width, height, params, url
							FROM {$db_prefix}activity_attachments
							WHERE url = '$url_encode'
							LIMIT 1",__FILE__,__LINE__);
		
		if( mysql_num_rows($result) > 0 ){
			
			list($attach_ID, $row_type, $width, $height, $parameters) = mysql_fetch_row($result);
			
			if( $row_type != 'link' ){
			
				mysql_free_result($result);
				
				$parameters = unserialize($parameters);
				
				$merge = array();

				if( $width )
					$merge['width'] = $width;
				
				if( $height )
					$merge['height'] = $height;
					
				if( $row_type == 'video' && isset($parameters['thumbnail']) )
					$merge['thumbnail'] = $parameters['thumbnail'];
				
				return array(
					'type' => $parameters['mime'] == 'application/x-shockwave-flash' ? 'swf' : $row_type,
					'attachment_id' => $attach_ID,
					'result' => array_merge($parameters, $merge)
				);
			
			}else{
				
				$merge = $this->extractDataFromLink($link, $row_type, array('thumbnails'));
				
				return array(
					'type' => $row_type,
					'attachment_id' => $attach_ID,
					'result' => array_merge(unserialize($parameters), $merge),
				);
				
			}
		}
		unset($result);
		set_time_limit(120);
		
		if( !$force || $type_recursive == 'video' )
			$type = $this->determineTypeAttach($link, $image_size);
		else
			$type = $type_recursive;
			
		if( $image_size && $image_size['mime'] == 'application/x-shockwave-flash' )
			$result =  array(
						'src' => $link,
						'mime' => $image_size['mime'],
						'width' => $image_size[0],
						'height' => $image_size[1],
						'type' => 'swf'
					);
		
		if(!in_array($type, array('video', 'link', 'image')))
			return false;		
		
		if( $type == 'image' && !isset($result)){
			
			if($force){
				$break = false;
				
				$image_size = getimagesize($link);
				
				if( $image_size['mime'] == 'application/x-shockwave-flash' ){
					$result =  array(
						'src' => $link,
						'mime' => $image_size['mime'],
						'width' => $image_size[0],
						'height' => $image_size[1],
						'type' => 'swf',
					);
					$break = true;
				}
				
				if(!$image_size && !$break){
					
					$skip_image = true;					
					$type = $this->determineTypeAttach($link);
					$result = $this->extractDataFromLink($link, $type);					
				
				}
			}
			
			
			if( !isset($skip_image) && !$break ){
				
				$result = array(
					'src' => $link,
					'mime' => $image_size['mime'],
					'width' => $image_size[0],
					'height' => $image_size[1],
					'type' => 'image'
				);
				
			}
			
		}
		else if( !isset($result) )
			$result = $this->extractDataFromLink($link, $type, $filter_search);
		
		$data += array(
			'type' => isset($result['type']) ? $result['type'] : $type,
			'result' => $result
		);
		
		return $data;
	
	}
	private function determineTypeAttach($link, &$image_size){
		global $skip_image;
		
		$videos_regexp = array(
			'#^http(?:s)?://(?:(?:www|uk|fr|ie|it|jp|pl|es|nl|br|au|hk|mx|nz|de|ca)\.|)?(?:youtube.com/(?:(?:watch|))(?:[^=]+=[^&]+)*(?:&v=|[?]v=|v/|jp\.swf\?video_id=)([0-9A-Za-z-_]{11})|youtu.be/([0-9A-Za-z-_]{11}))#',
			'~^http(?:s)?://(?:www\.)?vimeo\.com/(\d)+~i'
		);
		
		foreach($videos_regexp as $regexp)
			if(preg_match($regexp, $link))
				return 'video';
		
		if(!$skip_image && ($image_size = getimagesize($link)))
			return 'image';
		
		else
			return 'link';
	
	}
	private function scrapPage($url, $max_redirections = 10, $redirected){
	static $redirections = 0, $last_url = false, $last_html_object = false;
	global $http_response_header;
	
		if( $redirected )
			$redirections++;
		
		
		if( function_exists('curl_init') ){
		
			$ch = curl_init();
			
			$options = array(
				CURLOPT_URL			   => $url,
				CURLOPT_RETURNTRANSFER => true,
				CURLOPT_HEADER         => false,
				CURLOPT_FOLLOWLOCATION => true,
				CURLOPT_USERAGENT      => $_SERVER['HTTP_USER_AGENT'],
				CURLOPT_HTTPHEADER     => array(
					"Accept-Language: es-es,es"
				),
				CURLOPT_AUTOREFERER    => true,
				CURLOPT_CONNECTTIMEOUT => 120,
				CURLOPT_TIMEOUT        => 120,
				CURLOPT_MAXREDIRS      => $max_redirections,
			);
			
			curl_setopt_array( $ch, $options ); 
			$content = curl_exec( $ch ); 
			$header  = curl_getinfo( $ch );
			$redirected_url = curl_getinfo($ch, CURLINFO_EFFECTIVE_URL);
			curl_close( $ch );
			
			$html = str_get_html($content);
			
			if( $url != $redirected_url )
				$last_url = $redirected_url;
			else
				$last_url = $url;
			
			// error 4xx or 5xx
			if( in_array(substr($header['http_code'],0, 1), array('4', '5')) )
			{
			
				return false;
			
			}
			
			// http code 30x redirection!
			if( substr($header['http_code'],0, 2) == '30' && $redirections <= $max_redirections){
			
				switch( $header['http_code'] )
				{
					case '301':
					case '302':
						
						if( preg_match('~<a.+?href="([^"]+)"(?:[^>])*>here<\/a>|location.href=(?:[\'\"])([^\"\']+)(?:[\'\"])"~i', trim($content), $match) ){
							
							return $this->scrapPage($match[1], $max_redirections, true);
						
						}
						
						return $this->scrapPage($redirected_url, $max_redirections, true);
						
					break;
				}
				
			}
			
		}
		else if(function_exists('file_get_contents')){
		
			$context_array = array(
			  'http'=>array(
				'method'=> "GET",
				'header'=> "Accept-language: {$_SERVER[HTTP_ACCEPT_LANGUAGE]}\r\n" .
						   "User-Agent: {$_SERVER[HTTP_USER_AGENT]}\r\n"
			  )
			);
		
			$set_context = stream_context_create($context_array);
			$html = file_get_html($url, false, $set_context);
				
			$status_code = preg_match('~http\/[0-9]\.[0-9]+ (\d)~i', $http_response_header[0], $match);
			$status_code = $match[1];
			
			if( in_array($status_code, array('4', '5')) )
				return false;
				
		}
		else return false;
		
		if( !is_object($html) )
			return $last_html_object ? $last_html_object : false;
		
		$refresh_meta = $html->find('meta[http-equiv=refresh]', 0);
		$refresh_meta->attr['content'] = preg_replace('~\'|"~', '', $refresh_meta->attr['content']);		
		
		if( $refresh_meta->attr['content']  && $redirections <= $max_redirections){
			
			$last_url = substr($refresh_meta->attr['content'], strpos($refresh_meta->attr['content'], 'http'));
			$last_html_object = $html;
			return $this->scrapPage(substr($refresh_meta->attr['content'], strpos($refresh_meta->attr['content'], 'http')), $max_redirections, true);
			
		}
		else
			return $last_url ? array($html, $last_url) : $html;
	
	}
	public function extractDataFromLink($link, $type, $filter_search = array()){
		global $sourcedir, $scripturl;
		
		require_once($sourcedir . '/classes/simple_html_dom.php');
		
		$parse_url = parse_url($link);
		
		if($parse_url['scheme'] == 'https' && !extension_loaded ('openssl'))
			$not_allowed = true;
		
		// if( $_SERVER['REMOTE_ADDR'] == '127.0.0.1' )
					// return json_return(array('status' => 'error', 'message' => 'not allowed'), true);;		
		
		$scrap = $this->scrapPage($link);
		
		if( is_array($scrap) )
			list($html, $scrap_url, $h) = $scrap;
		else
			$html = $scrap;
		
		if( isset($scrap_url) )
			$parse_url = parse_url($scrap_url);
		
		list($scheme_url, $domain, $path, $query) = array($parse_url['scheme'], $parse_url['host'], $parse_url['path'], $parse_url['query']);
		$url = $parse_url['scheme'] . '://' . $domain;
		$all_url = $url . ($path ? $path : '') . ($query ? '?' . $query : '');
		
		if(!$html || !is_object($html) || isset($not_allowed))
			return array(
				'title' => $all_url,
				'url' => $all_url,
				'type' => 'link'
			);
		
		
		$find = array(
			'link' => array(
				'title' => array(
					array('tag' => 'meta', 'attr' => 'property', 'attr_content' => 'og:title'),
					array('tag' => 'meta', 'attr' => 'name', 'attr_content' => 'title'),
					array('tag' => 'title', 'get' => 'plaintext')
				),
				'description' => array(					
					array('tag' => 'meta', 'attr' => 'property', 'attr_content' => 'og:description'),
					array('tag' => 'meta', 'attr' => 'name', 'attr_content' => 'description'),					
					array('selector' => 'p', 'get' => 'plaintext', 'index' => false)
				),
				'keywords' => array(
					array('tag' => 'meta', 'attr' => 'property', 'attr_content' => 'og:keywords'),
					array('tag' => 'meta', 'attr' => 'name', 'attr_content' => 'keywords'),					
				),
				'thumbnail' => array(
					array('tag' => 'meta', 'attr' => 'property', 'attr_content' => 'og:image'),
					array('tag' => 'meta', 'attr' => 'itemprop', 'attr_content' => 'image'),
					array('tag' => 'link', 'attr' => 'rel', 'attr_content' => 'image_src')
				),
				'thumbnails' => array(
					array('tag' => 'img', 'get' => 'attribute', 'attribute' => 'src')
				)
			),
			'video' => array(
				'title' => array(
					array('tag' => 'meta', 'attr' => 'property', 'attr_content' => 'og:title'),
					array('tag' => 'meta', 'attr' => 'name', 'attr_content' => 'title'),
					array('tag' => 'title', 'get' => 'plaintext')
				),
				'description' => array(
					array('tag' => 'meta', 'attr' => 'property', 'attr_content' => 'og:description'),
					array('tag' => 'meta', 'attr' => 'name', 'attr_content' => 'description'),
				),
				'keywords' => array(
					array('tag' => 'meta', 'attr' => 'property', 'attr_content' => 'og:keywords'),
					array('tag' => 'meta', 'attr' => 'name', 'attr_content' => 'keywords'),
				),
				'thumbnail' => array(
					array('tag' => 'meta', 'attr' => 'property', 'attr_content' => 'og:image')
				)
			)
		);
		
		if( !empty($filter_search) ){
			
			$new_find = array();
			
			foreach( $filter_search as $filter )
			{
				
				if( array_key_exists($filter, $find[$type]) )
					$new_find[$filter] = $find[$type][$filter];
					
			}
			
			if(!empty($new_find))
				$find[$type] = $new_find;
		
		}
		
		$found = array();
		
		foreach( $find[$type] as $term => $schemes )
		{
			
			if( !$found[$type] )
				$found[$type] = array();
				
			$found[$type][$term] = null;
			
			foreach( $schemes as $scheme )
			{
				
				if(!empty($found[$type][$term]))
					continue;
				
				if( $scheme['tag'] == 'meta' || $scheme['tag'] == 'link')
				{
					
					$content = $html->find(vsprintf('%s[%s=%s]', array_values($scheme)), 0);
					
					$attr_select = array(
						'meta' => 'content',
						'link' => 'href'
					);
					
					$attr = $attr_select[$scheme['tag']];
					
					if(!empty($content)){
						
						if( in_array($scheme['attr_content'], array('og:image', 'image', 'thumbnail', 'image_src', 'apple-touch-icon')) )
						{
						
							if( substr($content->attr[$attr], 0, 2) == '//' )
								$content->attr[$attr] = $scheme_url . $content->attr[$attr];
										
							if( substr($img->$attr, 0, 1) == '/' )
								$content->attr[$attr] = $url . $content->attr[$attr];
								
							if( !in_array(substr($content->attr[$attr], 0, strrpos($content->attr[$attr], ':')), array('http', 'https')) )
								$content->attr[$attr] = $url . '/' . $content->attr[$attr];
						
						}
						
						$content = $content->attr[$attr];
					
					}
				}
				else{
					
					$get = $scheme['get'];
					
					if( $get == 'attribute' )
					{
						
						if( $term == 'thumbnails')
						{
							
							
							if( !empty($found[$type]['thumbnail']) )
								continue;							
							
							$content = array();
							$thumbnails = array();
							
							foreach( $html->find($scheme['tag']) as $img )
							{
							
								if( count($thumbnails) >= 101 )
									break;
								
								$attr = $scheme['attribute'];
								
								if( substr($img->$attr, 0, 2) == '//' )
									$img->$attr = $scheme_url . $img->$attr;
									
								if( substr($img->$attr, 0, 1) == '/' )
									$img->$attr = $url . $img->$attr;
									
								if( substr($img->$attr, 0, strrpos($img->$attr, ':')) != 'http' )
									$img->$attr = $url . '/' . $img->$attr;
								
								if( in_array($img->$attr, $thumbnails) )
									continue;
								
								$thumbnails[] = $img->$attr;
								$content[] = htmlspecialchars($img->$attr, ENT_QUOTES, 'UTF-8');
							
							}
							
						}
						
						
					
					}else
					{
						$index = isset($scheme['index']) && is_numeric($scheme['index']) ? $scheme['index'] : ($scheme['index'] === false ? null : 0);
						$term_find = isset($scheme['selector']) ? $scheme['selector'] : $scheme['tag'];
						
						$find = $html->find($term_find, $index);
						
						if( count($find) > 1 )
						{
						
							foreach($find as $tag)
							{
								switch( $term )
								{
									case 'description':
									
										if(strlen($tag->plaintext) > 100){
											$content = $tag->plaintext;
											break;
										}
										
									break;
									default:
										
										$content = false;
										break;
										
									break;
								}
							}
							
						}
						else
							$content = $find->$get;
				
					}
				}
				
				if($content){
				
						if(!is_array($content)){
						
						// clear spaces
						$content = preg_replace('~\s+~', ' ', $content);
						
						$content = htmlspecialchars($content, ENT_QUOTES, 'UTF-8');
						
						$content = strtr($content, array('&amp;' => '&'));
						
						}
						
						// set
						$found[$type][$term] = $content;
				
				}
			}
			
		}
		
		if( empty($new_find) )
			$found[$type] += array(
				'url' => $all_url,
				'domain' => $domain
			);
		
		foreach( $found[$type] as $term => $content )
			if( empty($content) )
				unset($found[$type][$term]);
		
		$html->clear();
		
		return $found[$type];
	
	}
	public function parseActivityMsg(&$msg){
		global $context, $db_prefix, $func;
		
		// removemos los caracteres especiales temporalmente
		$msg = un_htmlspecialchars($msg);
		
		// parse specialcharacters
		$this->parseAsciiCharacters($msg);
		
		// encode special characters once again
		$msg = htmlspecialchars($msg, ENT_QUOTES, 'UTF-8');
		
		// newlines
		$wordwrap = false;
		preg_match_all('~[^\n]+?\n~', $msg, $brklns, PREG_OFFSET_CAPTURE );
		
		if( count($brklns[0]) > 10 )
			foreach( $brklns[0] as $newline => $br ){
				
				if( $newline >= 10 ){
					
					$see_more = '<span class="see-more"><span class="ellipsis-sufix">... </span><a class="toggleHideText">ver m&aacute;s</a><span class="hideText">' . mb_substr($msg, $br[1]) . '</span></span>';
					$msg = mb_substr($msg, 0, $br[1]) . $see_more;
					$wordwrap = true;
					break;
					
				}
					
			
			}
		
		// fix characters
		$msg = strtr($msg, array(
			"\n" => '<br />',
			'&amp;' => '&'
		));
		
		
		// parse mentions
		$this->parseMentions($msg, true);
		
		// wordwrap!
		preg_match_all('~(?P<word>[^\s\n\r\t]{10})|(?P<html>(<[^>]+>(?:[^<]+<[^>]+>)?))~', $msg, $terms, PREG_OFFSET_CAPTURE  );
		$terms = array('words' => $terms['word'], 'html' => $terms['html']);
		
		$count_terms = array(
			'words' => 0,
			'html' => 0
		);
		
		foreach( $terms as $k => $group ){
		
			switch( $k ){
				
				case 'words':
					
					foreach( $group as $term )
						if( $term[1] !== -1 )
							$count_terms['words']++;
					
				break;
				case 'html':
				
					foreach( $group as $term )
						if( is_array($term) )
							$count_terms['html']++;
				
				break;
			
			}
			
		}
		if( $count_terms['words'] > 0 )
			$msg = mb_word_wrap($msg, 10, '<span class="word_break">%s</span>', true);
		
		
		// cut text
		if( !$wordwrap  && mb_strlen($msg) > 400 )
		{
		
			$temp_msg = $msg;
			$msg = htmlTruncate(400, $msg);
			
			if( mb_strlen($temp_msg) <= 5000 && mb_strlen($msg) < mb_strlen($temp_msg) )
			{
			
				$hiddenText = mb_substr($temp_msg, mb_strlen($msg));
				
				$msg .= '<span class="see-more"><span class="ellipsis-sufix">... </span><a class="toggleHideText">ver m&aacute;s</a><span class="hideText">' . $hiddenText . '</span></span>';
			
			}
			else if ( mb_strlen($temp_msg) > 5000 )
			{
			
				$msg .= '<span class="see-all">...<a href="'. $scripturl . '?action=stream&do=view-stream&id=" target="_blank" title="ver todo el mensaje">Ver todo</a></span>';
			
			}
			
		}
		
		return $msg;
	
	}
	private function parseAsciiCharacters(&$msg){
	
		$characters = array(
			'~(?<=[\s_\-\.]|^)<3~' => '&hearts;',
		);
		
		$msg = preg_replace(array_keys($characters), array_values($characters), $msg);
	
	}
	private function parseMentions(&$msg, $fix_nicks = false){
		global $context, $db_prefix, $scripturl, $ID_MEMBER;
		
		$allowed_types = array('user'); // install here more plugins ( communities, gallery, etc )
				
		preg_match_all('~(?P<raw>@\[(?P<name>[^\]]+)\]\((?P<type>[a-z]+):(?P<id>\d+)\))~', $msg, $match, PREG_SET_ORDER);
		
		if( empty($match) )
			return false;
		
		$matches = array();
		
		foreach($match as $k => $m)
		{ 
			
			$matches[$m['raw']] = $m;
			
		}
		
		$replaces = array();
		$mentions = array();
		$identificators = array();		
		$templates = array(
		
			'user' => array(
				'enabled' => '<a class="hover-card user mention" href="{$data:href}" title="{$data:name}">{$data:name}</a>',
				'disabled' => '<strong title="{$data:name}">{$data:name}</strong>'
			),
			/*
			'community' => array(
				'enabled' => '<a class="hover-card community" href="{$data:href}" title="{$data:nick}">{$data:name}</a>',
				'disabled' => '<strong title="{$data:name}">{$data:name}</strong>'
			)
			*/
		);
		
		foreach( $matches as $raw => $data )
		{
			
			if( !in_array($data['type'], $allowed_types) )
			{
			
				$msg = str_replace($data['raw'], $data['name'], $msg);
				continue;
			
			}
			
			// replaces
			$replaces[$raw] = $templates[$data['type']];
			
			// set nicks statement IN()
			$identificators[$data['type']][] = $data['id'];
			
			// order all data
			$mentions[$data['type']][$data['id']] = array(
				'data' => array(
					'id' => $data['id'],
					'name' => $data['name'],
					'href' => $scripturl . '?action=profile;u=' . $data['id'],
					'raw' => $data['raw'],
					'parse' => 'disabled'
				)
			);
		
		}
		// [0] => las columnas a seleccionar
		// [1] => la tabla
		// [3] la columna que tiene un id unico del objeto ( ej: [mention:id] = ID_MEMBER )
		
		$scheme_queries = array(
			'user' => array('ID_MEMBER, memberName', $db_prefix . 'members', 'ID_MEMBER'),
			// 'comunnity' => array('ID_COMMUNITY', $db_prefix . 'communities', 'community_name')
		);
		
		foreach( array_keys($mentions) as $type )
		{
				
				$skip_query = false;
				
				if( $type == 'user' && in_array($ID_MEMBER, $identificators[$type]) )
					$own_user = true;
					
				if( $own_user )
					foreach( $identificators[$type] as $k => $id )
						if( $id == $ID_MEMBER )
							unset($identificators[$type][$k]);
				
				if( !empty($identificators[$type]) )
					$result = db_query("SELECT " . $scheme_queries[$type][0] . "
										FROM " . $scheme_queries[$type][1] . "
										WHERE " . $scheme_queries[$type][2] . " IN (" . implode(', ', $identificators[$type]) . ")",__FILE__,__LINE__);
				
				// skipped query?
				if( $own_user )
				{
					
					$mentions[$type][$ID_MEMBER]['data']['name'] = $context['user']['name'];
					$mentions[$type][$ID_MEMBER]['data']['parse'] = 'enabled';
				}
				
				while($row = mysql_fetch_assoc($result))
				{
					
					switch( $type ){
					
						case 'user':
							
							if( $fix_nicks )
								if( $row['memberName'] != $mentions[$type][$row['ID_MEMBER']]['data']['name'] )
									$mentions[$type][$row['ID_MEMBER']]['data']['name'] = $row['memberName'];
							
							if( $ID_MEMBER != $row['ID_MEMBER'] )
							{
								$result = db_query("SELECT uid FROM {$db_prefix}followers WHERE uif = $ID_MEMBER AND uid = $row[ID_MEMBER]",__FILE__,__LINE__);
								$enabled_mention = ( mysql_num_rows($result) > 0 );
								mysql_free_result($result);
							}else
								$enabled_mention = true;
							
							if( !$enabled_mention ){
								
								$result = db_query("SELECT BUDDY_ID FROM {$db_prefix}buddies WHERE ID_MEMBER = $ID_MEMBER AND BUDDY_ID = $row[ID_MEMBER]",__FILE__,__LINE__);
								$enabled_mention = ( mysql_num_rows($result) > 0 );
								mysql_free_result($result);
							
							}
						
						break;
						// case 'community': break;
						
					}
						
					$mentions[$type][$row['ID_MEMBER']]['data']['parse'] = $enabled_mention ? 'enabled' : 'disabled';
				
				}
				
				mysql_free_result($result);
		
		}
		
		foreach($mentions as $type => $mention)
		{
			
			foreach( $mention as $data )
			{
				
				$msg = str_replace($data['data']['raw'], $this->parseStringFromData($replaces[$data['data']['raw']][$data['data']['parse']], $data), $msg);
			
			}
			
		}
	
	}
	private function insertAdvertiseOnStories(&$stories){
		
		// por terminar...
		$elements = count($stories);
		$advertise = array(
			'story' => array(
				'type' => 'advertise',
				'adv-type' => 'image',
				'content' => ''
			)
		);
		
		return false;
	
	}
	private function clusterStories(&$stories){
		global $ID_MEMBER;
		
		$clusterStories = array();
		$types = array();
		$multi_def = array(
			'follow' => 'multi-follow',
			'change-avatar' => 'multi-change-avatar',
			're-stream' => 'multi-shared'
			
		);
		
		// count types
		foreach( $stories as $story )
				$types[] = (isset($story['story']['is_shared']) ? 're-stream' : $story['story']['type']);
		
		$count_types = array_count_values($types);
		
		foreach( $stories as $id => $story )
		{
			
			$story['story']['type'] = (isset($story['story']['is_shared']) ? 're-stream' : $story['story']['type']);
			
			if( $count_types[$story['story']['type']] <= 1 )
				continue;
			
			$keysCluster = array(
				'follow' => array($story['story']['type'], $story['member']['id']),
				're-stream' => array($story['story']['type'], $story['object']['member']['id'])
			);
			
			if( !in_array($story['story']['type'], array_keys($keysCluster)) )
				continue;
			
			$keyCluster = $keysCluster[$story['story']['type']];
			
			$key = implode('.', $keyCluster);
						
			if( $ID_MEMBER == $story['object']['id'] ){
				$key = $story['story']['type'];
				$story['is_own'] = true;
			}
			
			if( !$clusterStories[$key] )
				$clusterStories[$key] = array(
					'source' => $story,
					'type' => $story['story']['type'],
					'keys' => array()
				);
			
			$clusterStories[$key]['keys'][$story['story']['id']] = $story['story']['id'];
			
		}
		

		foreach( $clusterStories as $key => $r )
		{
			
			list( $story, $subject, $object, $keys, $type ) = array( $r['source']['story'], $r['source']['member'], $r['source']['object'], $r['keys'], $r['type']);
			
			$parent = max($keys);
			$childrens = array_intersect_key($stories, $keys);
			$childrens_id = array_keys($childrens);
			$ek = explode('.', $key);
			$members = array();
			$members_ids = array();
			$first_member = $r['source']['member'];
			
			foreach( $keys as $delete )
				if( $delete != $parent )
					unset($stories[$delete]);
			
			$stories[$parent]['is_agrouped'] = true;
			
			switch($type){
					
				case 'follow':
					
					foreach( $childrens as $mem )
					{
						
						$story_id = $mem['story']['id'];
						$mem = ($r['source']['is_own'] ? $mem['member'] : $mem['object']);
						
						if( $mem['image'] ){
							$mem['avatar'] = $mem['image']['avatar'];
							unset($mem['image']);
						}
						
						$members[$mem['id']] = $mem;
						
					}
					
					if( count($members) <= 1 )
						continue;
					
					//print_r($members);
					$stories[$parent] = array(
						'members' => $members,
						'main-authors' => array(
							'total' => isset($r['source']['is_own']) ? count($members)-1 : count($members)
						),
						'first-member' => $first_member,
						'story' => array(
							'type' => 'multi-follow'
						),
						'is_own_author' => $ID_MEMBER == $subject['id']
					);
					
					$stories[$parent]['story']['action'] = $this->getActionTextByType('multi-follow', isset($r['source']['is_own']), false, $stories[$parent]);
					
				break;
				case 're-stream':
					
					foreach( $childrens as $mem )
					{
						
						$mem = $mem['member'];
						
						if( $mem['image'] ){
							$mem['avatar'] = $mem['image']['avatar'];
							unset($mem['image']);
						}
						
						$members[$mem['id']] = $mem;
						
					}
					
					$is_own = $stories[$parent]['object']['member']['id'] == $ID_MEMBER;
					$is_own_author = in_array($ID_MEMBER, array_keys($members));
					
					$stories[$parent] += array(
						'members' => $members,
						'main-authors' => array(
							'total' => count($members)-1
						),
						'first-member' => $is_own_author ? $members[$ID_MEMBER] : $stories[$parent]['member'],
						'first-author' => $stories[$parent]['object']['member'],
					);
					
					if( $is_own_author )
						$stories[$parent]['member'] = $members[$ID_MEMBER];
					
					$stories[$parent]['is_own_author'] = $is_own_author;
					$stories[$parent]['story']['action'] = $this->getActionTextByType('multi-shared', $is_own, false, $stories[$parent]);
					
				break;
				
			}		
		}
		
		
		return $stories;
	
	}
	private function isShortActivity($type){
	
		$short_activities = array(
			'follow',
			'avatar',
			'comment_post'
		);
	
		return in_array($type, $short_activities);
	}
	public function getScaledCoords($max_width = 0, $max_height = 0, $width, $height){
		
		if(empty($max_height))
			$max_height = $max_width;
		
		$f = min($max_width/$width, $max_height/$height, 1);
		$scaled_width = round($f * $width);
		$scaled_height = round($f * $height);
		
		return array($scaled_width, $scaled_height);
	
	}
	public function getActionTextByType($type = null, $is_own = false, $shared = false, $data = false){
		global $ID_MEMBER;
		
		if(null === $type || !in_array($type, $this->activity_types))
			return false;
		
		$parse = $data ? true : false;		
		$template = false;
		
		$templates = array(
			'status' => array(
				'author' => 'dijo',
				'shared' => array(
					'own' => 'comparti&oacute; <strong>t&uacute;</strong> estado',
					'own-author' => 'comparti&oacute; <strong>su</strong> estado',
					'author' => 'comparti&oacute; el estado de <a href="{$memberm:href}" title="{$member:name}">{$member:name}</a>'
					)
				),
			'image' => array(
				'author' => 'comparti&oacute; una imagen',
				'shared' => array(
					'own' => 'comparti&oacute; <strong>t&uacute;</strong> imagen.',
					'own-author' => 'comparti&oacute; <strong>su</strong> imagen',
					'author' => 'comparti&oacute; la imagen de <a href="{$memberm:href}" title="{$member:name}">{$member:name}</a>'
					),
			),
			'video' => array(
				'author' => 'comparti&oacute; un video',
				'shared' => array(
					'own' => 'comparti&oacute; <strong>t&uacute;</strong> video',
					'own-author' => 'comparti&oacute; <strong>su</strong> video',
					'author' => 'comparti&oacute; el video de <a href="{$memberm:href}" title="{$member:name}">{$member:name}</a>'
					)
			),
			'link' => array(
				'author' => 'compartio un enlace.',
				'shared' => array(
					'own' => 'Comparti&oacute; <strong>t&uacute;</strong> enlace',
					'own-author' => 'Comparti&oacute; <strong>su</strong> enlace',
					'author' => 'compartio el enlace de <a href="{$memberm:href}" title="{$member:name}">{$member:name}</a>'
					)
				
			),
			'follow' => array(
				'author' => '<a href="{$member:href}" title="{$member:name}">{$member:name}</a> esta siguiendo a <a href="{$object:href}" title="{$object:name}">{$object:name}</a>',
				'own' => '<a class="nick" href="{$member:href}" title="{$member:name}">{$member:name}</a> te esta siguiendo',
				'own-author' => 'estas siguiendo a <a href="{$object:href}" title="{$object:name}">{$object:name}</a>'
			),
			'comment_post' => array(
				'author' => '<a href="{$member:href}" title="{$member:name}">{$member:name}</a> coment&oacute; en un post',
				'own' => 'comento en tu <a href="{$object:href}" title="{$object:name}">post</a>',
				'own-author' => 'comentaste en el <a href="{$object:href}" title="{$object:name}">post</a>',
			),
			'multi-shared' => array(
				'author' => 'comparti&oacute; la publicacion de <a href="{$first-author:href}" title="{$first-author:name}">{$first-author:name}</a>',
				'own' => 'comparti&oacute; su publicacion',
				'own-author' => ' y <a href="#">{$main-authors:total}</a> ' . sprintf('usuario%s ', $data['main-authors']['total'] > 1 ? 's' : '') . ' m&aacute;s compartieron la publicacion de <a href="{$first-author:href}" title="{$first-author:name}">{$first-author:name}</a>'
			),
			'multi-follow' => array(
				'author' => '<a href="{$first-member:href}" title="{$first-member:name}">{$first-member:name}</a> esta siguiendo a <a href="#">{$main-authors:total}</a> ' . sprintf('usuario%s ', $data['main-authors']['total'] > 1 ? 's' : '') . '.',
				'own' => '<a href="{$first-member:href}" title="{$first-member:name}">{$first-member:name}</a> y <a href="#">{$main-authors:total}</a> ' . sprintf('usuario%s ', $data['main-authors']['total'] > 1 ? 's' : '') . ' m&aacute;s te estan siguiendo.',
				'own-author' => 'Estas siguiendo a <a href="#">{$main-authors:total}</a> ' . sprintf('usuario%s ', $data['main-authors']['total'] > 1 ? 's' : '') . '.'
			),
			'change-avatar' => '<a href="{$member:href}" title="{$member:name}">{$member:name}</a> cambio su avatar',
			'multi-change-avatar' => 'y <a href="#">{$main-authors:total}</a> ' . sprintf('usuario%s ', $data['main-authors']['total'] > 1 ? 's' : '') . ' m&aacute;s cambiaron su foto de perfil.'
		);
		
		if( in_array($type, array('status', 'image', 'video', 'link' )) )
		{
			if($shared)
				$template = $templates[$type]['shared'][$is_own == 'own' ? 'own' : ($is_own == 'own-author' ? 'own-author' : 'author')];
			else
				$template = $templates[$type]['author'];
		}
		
		else if( in_array($type, array('multi-follow', 'follow', 'comment_post', 'multi-shared')) )
		{
			if($is_own)
				$template = $templates[$type]['own'];
			else if( /*$data['member']['id'] == $ID_MEMBER ||*/ $data['is_own_author'] )
				$template = $templates[$type]['own-author'];
			else
				$template = $templates[$type]['author'];
		}
		else
			$template = $templates[$type];
		
		
		return $parse ? $this->parseStringFromData($template, $data) : $template;
	}
	private function parseStringFromData($template, $data){
		
		
		preg_match_all('~\{\$([^\}]+)\}~', $template, $match_temp);
		
		
		foreach( $match_temp[1] as $vars )
		{
			
			$keys = explode(':', $vars);
			
			$first_key = $keys[0];
			unset($keys[0]);
			
			$value = $data[$first_key];
			
			foreach( $keys as $key )
				$value = $value[$key];
			
			$template = str_replace('{$' . $vars . '}', $value, $template);
		
		}
		
		return $template;
		
	}

}
?>