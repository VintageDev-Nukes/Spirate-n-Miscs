<?php
if(!defined('SPIRATE'))
	die('Are you serius?');

/**
 * notifications
 * @author j0n4th4ntub3
 * @version 1.0
 * 
 */
require_once($sourcedir . '/classes/parser.class.php');
class notifications extends parser{
    /**
     * lista del tipo de notificaciones por defecto, auxiliar.
     * @access private
     * @static
     * @var array types
     */
    private static $info_notify = array();
    private $types = array(
        'comment',
        'bookmark',
        'points',
        'new_user',
        'update_avatar',
        'menctions'
        );
    public $clean = false;
    /**
     * Constructor 
     */
    public function __construct() {
        //...
    }
    /**
     * Preparamos parametros para agregar una nueva notificacion
     * 
     * ACTIONS:
     * ------------------------------------------------------------------------------
     * comment => nuevo comentario | nuevos comentarios. [comentarios]
     * bookmark => x usuario(s) agrego un post a favoritos. [favoritos]
     * points => x usuario(s) dio puntos a x post. [puntos]
     * update_avatar => x usuario actualizo su avatar. [perfil]
     * menctions => x usuario(s) menciono/mencionaron a alguien en un [post|comentario|stream history|stream comment]
     * ------------------------------------------------------------------------------
     * 
     * @access public
     * @param string $type
     * @param array $data 
     * @return int|bool
     */
    public function add($type, $data){
        global $context, $txt, $settings, $modSettings, $db_prefix, $ID_MEMBER;

        if(!$ID_MEMBER)
            return false;
    
        if(empty($type) || !in_array($type, $this->types))
            return false;

        return $this->setNotification($type, $data);
    }
    public function getNotifications($minimal = true, &$noreads = array()){
        global $context, $ID_MEMBER, $db_prefix;

        if(!$ID_MEMBER)
            return false;
			
		

        $result = db_query("SELECT ID_NOTIFICATION FROM {$db_prefix}notifications WHERE ID_MEMBER = $ID_MEMBER AND is_read = 0 ORDER BY ID_NOTIFICATION DESC",__FILE__,__LINE__);
        while($r = mysql_fetch_assoc($result))
            $noreads[] = $r['ID_NOTIFICATION'];
        
        $total_no_reads = mysql_num_rows($result);
        mysql_free_result($result);

        $limit = $total_no_reads < 5 ? (5 - $total_no_reads) + $total_no_reads : $total_no_reads;

        if(!$minimal)
            $limit = 50;

        $result = db_query("SELECT n.ID_NOTIFICATION, n.ID_MEMBER, n.ID_SUBJECT as fs_id, m.memberName as fs_name, m.avatar as fs_avatar, m.avatar_coords as fs_avatar_coords,
                            n.object_type, n.ID_OBJECT, n.type, n.is_read, n.time, n.timeForMark,
                            p.notifiers_params, p.tmpl_extended,
                            p.tmpl_minimal
                            FROM {$db_prefix}notifications as n
                            LEFT JOIN {$db_prefix}members as m ON m.ID_MEMBER = n.ID_SUBJECT
                            LEFT JOIN {$db_prefix}notifications_params as p ON p.ID_NOTIF = n.ID_NOTIFICATION
                            WHERE n.ID_MEMBER = $ID_MEMBER
                            ORDER BY n.ID_NOTIFICATION DESC
                            LIMIT $limit",__FILE__,__LINE__);
        // $context['split_date_notifs'] = array();
        $ids = array();
        while($row = mysql_fetch_assoc($result)){
            $params = unserialize($row['parameters']);
            $row['templates'] = unserialize($row['templates']);
            $notifiers_data = unserialize($row['notifiers_params']);
            $notifiers = array();

            foreach($notifiers_data as $id => $user)
                    $notifiers[] = array(
                        'id' => $id,
                        'name' => $user['name'],
                        'avatar' => $user['avatar']
                    );
            $each_day = time()-$row['time'];
            $each_day = floor($each_day/86400);
            $key = $each_day == 0 ? 'today' : ($each_day == 1 ? 'yesterday' : $each_day);

            // $context['split_date_notifs'][$key] = $row['time'];

            // $output[ hace($row['time']) ]
            $output[$key][] = array(
                'id' => $row['ID_NOTIFICATION'],
                'first_sender' => array(
                    'id' => $row['fs_id'],
                    'name' => $row['fs_name'],
                    'avatar' => $row['fs_avatar'],
					'avatar_coords' => makeAvatarCoords($row['fs_avatar_coords'])
                ),
                'notifiers' => $notifiers,
                'object_type' => $row['object_type'],
                'type' => $row['type'],
                'template' => array(
                    'minimal' => $row['tmpl_minimal'],
                    'extended' => $row['tmpl_extended']
                ),
                'params' => $params,
                'is_read' => $minimal ? $row['is_read'] : (empty($row['timeForMark']) ? $row['is_read'] : $row['timeForMark'] < time()),
                'date' => hace($row['time']),
                'time' => $row['time']
            );

            if(!$row['is_read'])
                $ids[] = $row['ID_NOTIFICATION'];

        }
        
        if($this->clean){
                $this->markAsRead($ids);
                updateMemberData($ID_MEMBER, array('notifications' => 0));
        }
        
        return $output;

    }
    public function markAsRead($ids){
        global $scripturl, $db_prefix, $ID_MEMBER;

        if(!$ID_MEMBER)
            return false;

        $where_statement = 'WHERE ID_MEMBER = ' . $ID_MEMBER;
        
        if($ids != 'all'){
            $ids = (array) $ids;
            $updates = false;

            // clean bad ids
            $notifications = array();
            foreach($ids as $id)
                $notifications[] = (int) $id;

            $where_statement = 'WHERE ID_NOTIFICATION IN(' . implode(', ', $notifications) . ') AND ID_MEMBER = ' . $ID_MEMBER;
        }

        if(!empty($notifications)){
            db_query("UPDATE {$db_prefix}notifications
                      SET is_read = 1,
                      timeForMark = " . (time() + 900) /* 15 minutos de gracia :) */ . "
                      " . $where_statement,__FILE__,__LINE__);
            $updates = mysql_affected_rows();
        }

        return $updates;
    }
    private function prepareNotification($type, $params){
        global $db_prefix, $txt, $context, $modSettings, $settings, $scripturl, $ID_MEMBER;

        $output = array();
        $necessary = array(
            'comment' => array('author', 'topic'),
            'bookmark' => array('author', 'topic'),
            'points' => array('author', 'topic', 'points'),
        );
        
        foreach($necessary[$type] as $k => $v)
            if(!isset($params[$v]))
                return false;
        
           
        switch($type){
            case 'comment':
            case 'bookmark':
            case 'points':
				
                // get info author and post
                $data = array();
                $request = db_query("SELECT t.ID_TOPIC as topic_id, t.ID_MEMBER_STARTED AS TARGET_ID, m.ID_MEMBER as author_id, 
                                     m.memberName as author_name, m.avatar as author_avatar, ms.subject as topic_name, m.notifications
                                     FROM {$db_prefix}topics as t, {$db_prefix}members as m, {$db_prefix}messages as ms
                                     WHERE t.ID_TOPIC = $params[topic]
                                     AND ms.ID_TOPIC = t.ID_TOPIC
                                     AND m.ID_MEMBER = $params[author]
                                     LIMIT 1",__FILE__,__LINE__);
                if(mysql_num_rows($request) == 0)
                    return false;
                
                // get data from database!
                $data = mysql_fetch_assoc($request);
                $output['fetch'] = $data;
                mysql_free_result($request);
                
                // is own?
                if($data['TARGET_ID'] == $params['author'])
                    return false;
                    
               // get templates
                $templates = $this->GetTemplate(array($type), true);
                $output['templates'] = $templates;

                // set type
                $output['type'] = $type;

                // set extra parameters
                $extraParams = array();
                
                // Determine if is a comentators group or a single commentator
                $fetchgroup = $this->agroupNotification($type, array('topic' => $data['topic_id'], 'author' => $data['author_id'], 'ID_SUBJECT' => $data['TARGET_ID']));
                $notifiers = explode(',', $fetchgroup['notifiers_id']);
                $noagroup = (!isset($fetchgroup['notifiers_id']) && count($notifiers) == 1 || !$fetchgroup);
				

                if( $noagroup ){
                // set templates
                $template = $templates['minimal']['single'];
                $template_extended = $templates['extended']['single'];
                
                $template_data = array(
                    'post_name' => $data['topic_name'],
                    'post' => array(
                        'topic_href' => $scripturl . '?topic=' . $data['topic_id'],
                        'topic_name' => $data['topic_name']
                    ),
                    'user' => array(
                        'profile_href' => $scripturl . '?action=profile;u=' . $data['author_id'],
                        'nick' => $data['author_name']
                    ),
                );

                if($type == 'points'){
                    $template_data['puntos'] = (int) $params['points'];
                    $extraParams['points'] = $params['points'];
                }
                
                // get parsed templates
                $parsed_templates = array(
                    'minimal' => self::init($template, $template_data),
                    'extended' => self::init($template_extended, $template_data),
                    );
                
                }else{
                    
                    $sub_notifiers = explode(',', $fetchgroup['sub_notifiers']);
                    $all_notifiers = array_merge($sub_notifiers, $notifiers);
                    $fetchgroup['extra_params'] = unserialize($fetchgroup['extra_params']);
                    
                    // The same pirate? arrggh figure elsewhere.
                    if(in_array($data['author_id'], $all_notifiers))
                        return false;
                    
                    $data_templates = array(); $data_notifiers = array(); $tmpl_users = array();
                    
                    // agregamos un pirata a la lista ;)
                    $total_notifiers = count($notifiers)+1;

                    if(count($notifiers) < 4)
                        $notifiers[] = $data['author_id'];

                    if($total_notifiers > 4){
                        if($sub_notifiers['0'] == 0)
                            $sub_notifiers = array($data['author_id']);
                        else
                            $sub_notifiers[] = $data['author_id'];
                    }
					
					
                    
                    if($total_notifiers <= 4){
                        
                    $request = db_query("SELECT ID_MEMBER, memberName, avatar FROM {$db_prefix}members WHERE ID_MEMBER IN (".implode(', ', $notifiers) . ")");
                        while($row = mysql_fetch_assoc($request)){
                            $tmpl_users[$row['ID_MEMBER']] = array(
                                'nick' => $row['memberName'],
                                'profile_href' => $scripturl . '?action=profile;u=' . $row['ID_MEMBER'],
                                'prefix' => ', '
                                );	
                            $data_notifiers[$row['ID_MEMBER']] = array(
                                'id' => $row['ID_MEMBER'],
                                'name' => $row['memberName'],
                                'avatar' => $row['avatar']
                            );
                        }
                        mysql_free_result($request);
                        
                    }else{
                        
                        $data_notifiers = unserialize($fetchgroup['notifiers_params']);

                        foreach($data_notifiers as $id => $u)
                            $tmpl_users[$id] = array(
                                'nick' => $u['name'],
                                'profile_href' => $scripturl . '?action=profile;u=' . $id,
                                'prefix' => ', '
                            );
                    }
					

                    foreach($tmpl_users as $k => $user){
                        $user['prefix'] = end($tmpl_users) == $user ? (count($all_notifiers) > 4 ? ', ' : ' y ') : (reset($tmpl_users) == $user ? '' : ', ');
                        $data_templates['users'][$k] = $user;
                    }

                    $data_templates += array(
                        'post_name' => $data['topic_name'],
                        'post' => array(
                            'topic_href' => $scripturl . '?topic=' . $data['topic_id'],
                            'topic_name' => $data['topic_name']
                            ),
                        'restant_users' => count($all_notifiers) > 4 ? (' y ' . sprintf('<a onclick="notificaciones.getLastUsers(%d)">%d</a> usuario%s m&aacute;s', $fetchgroup['ID_NOTIFICATION'], (count($all_notifiers)-4), (count($all_notifiers)-4 > 1 ? 's' : ''))) : ''
                    );

                    if($type == 'points'){
                        $last_points = $fetchgroup['extra_params']['points'];                        
                        $points = (int) $params['points'] + (int) $last_points;
                        $data_templates['puntos'] = $points;
                        $fetchgroup['extra_params']['points'] = $points;
                    }
					
                    
                    $parsed_templates = array(
                        'minimal' => self::init($templates['minimal']['plural'], $data_templates),
                        'extended' => self::init($templates['extended']['plural'], $data_templates),
                    );
					

                    $output['queries'] = array(
                        'updates' => array(
                            'notifications_params' => array(
                                'notifiers_id' => "'". implode(',', $notifiers) ."'",
                                'sub_notifiers' => "'". implode(',', $sub_notifiers) ."'",
                                'object_id' => "'$data[topic_id]'",
                                'notifiers_params' => "'".serialize($data_notifiers)."'",
                                'extra_params' => "'" . serialize($fetchgroup['extra_params']) . "'",
                                'tmpl_minimal' => "'" . $parsed_templates['minimal'] . "'",
                                'tmpl_extended' => "'" . $parsed_templates['extended'] . "'",
                                'WHERE' => array(
                                    'ID_NOTIF' => $fetchgroup['ID_NOTIFICATION']
                                )
                            )
                        )
                    );
                    
                    return $output;
                    
                }

                // the affortunate
                $output['ID_MEMBER'] = $data['TARGET_ID'];
                
                // construct query                
                $output['queries'] = array(
                    'inserts' => array(
                        'notifications' => array(
                            'ID_MEMBER' => $data['TARGET_ID'],
                            'ID_SUBJECT' => $data['author_id'],
                            'ID_OBJECT' => $data['topic_id'],
                            'object_type' => "'user'",
                            'type' => "'$type'",
                            'parameters' => "'" . ($output['parameters'] ? serialize($output['parameters']) : '') . "'",
                            'is_read' => 0,
                            'time' => time()
                        ),
                        'notifications_params' => array(
                            'ID_NOTIF' => 'LAST_ID::notifications',
                            'notifiers_id' => "'$data[author_id]'",
                            'object_id' => "'$data[topic_id]'",
                            'notifiers_params' => "''",
                            'extra_params' => "'" . ($extraParams ? serialize($extraParams) : '') . "'",
                            'tmpl_minimal' => "'" . $parsed_templates['minimal'] . "'",
                            'tmpl_extended' => "'" . $parsed_templates['extended'] . "'"
                        )
                    )
                );

            break;
        }

        return $output ? $output : false;

    }
    private function setNotification($type, $params){
        global $db_prefix, $txt, $context, $modSettings, $settings, $scripturl, $ID_MEMBER;
        
        if(!($data = $this->prepareNotification($type, $params)))
                return false;

        ignore_user_abort(true);
		@set_time_limit(200);
        
        $this->insert($data['queries'], $insert_ids);

        if(!empty($insert_ids))
            updateMemberData($data['ID_MEMBER'], array('notifications' => '+'));

        return $id;

    }
    private function agroupNotification($type, $params){
        global $db_prefix, $txt, $context, $modSettings, $settings, $scripturl, $ID_MEMBER;

        $return = false;

        switch($type){

            case 'comment':
            case 'bookmark':
            case 'points':
                
                $request = db_query("SELECT n.ID_NOTIFICATION, n.ID_OBJECT as last_topic_id,
                                     n.ID_SUBJECT as last_subject_id, p.ID_NOTIF, p.notifiers_id, p.sub_notifiers, p.object_id,
                                     p.notifiers_params, p.tmpl_minimal, p.tmpl_extended, p.extra_params
                                     FROM {$db_prefix}notifications as n
                                     LEFT JOIN {$db_prefix}notifications_params as p ON n.ID_NOTIFICATION = p.ID_NOTIF
                                     WHERE n.ID_MEMBER = $params[ID_SUBJECT]
                                     AND n.type = '$type'
                                     AND FIND_IN_SET($params[topic], p.object_id)
                                     AND n.is_read = 0
                                     AND n.time + 86400 > ".time()."
                                     ORDER BY n.ID_NOTIFICATION DESC
                                     LIMIT 1",__FILE__,__LINE__);
                if(mysql_num_rows($request) == 0)
                    return false;

                $return = mysql_fetch_assoc($request);
                $return['parameters'] = unserialize($return['parameters']);

            break;

        }

        return $return;
    }
    private function insert($queries, &$insert_ids = array()){
        global $db_prefix, $txt, $context, $modSettings, $settings, $scripturl, $ID_MEMBER;

        static $inserted = array();
        
        
        if($queries['inserts']){
            foreach($queries['inserts'] as $table => $rows){
                foreach($rows as $k => $v)
                    if(substr($v, 0, 7) == 'LAST_ID'){
                        if($inserted[$v])
                            $rows[$k] =  $inserted[$v];
                        else
                            unset($rows[$k]);
                    }
                db_query("INSERT INTO " . $db_prefix . $table . "(" . implode(',', array_keys($rows)). ")
                          VALUES(" . implode(',', array_values($rows)) . ")");
                $last = mysql_insert_id();
                if(!empty($last)){
                    $insert_ids[] = $last;
                    $inserted['LAST_ID::' . $table] = $last;
                }
            }
            $insert_ids = count($insert_ids) > 1 ? $insert_ids : $insert_ids[0];            
        }

        if($queries['updates']){
            $makeUpdate = '';
            $where = '';
            $i = 0;
                foreach($queries['updates'] as $table => $rows){
                    foreach($rows['WHERE'] as $k => $v)
                            $where .= (($i++ < 1 ? ' WHERE ' . $k : ' AND ' . $k) . ' = ' . $v . ' ');
                    
                    unset($rows['WHERE']);
                    
                    foreach($rows as $k => $v)
                        $makeUpdate .= (reset($rows) == $v ? 'SET ' : '') . $k . ' = ' . $v . (end($rows) == $v ? ' ' : ', ');
                    db_query("UPDATE " . $db_prefix . $table . "
                             " . $makeUpdate . "
                             " . $where,__FILE__,__LINE__);                     
                }
        }

        
    }
    /**
     * Obtenemos el template para la notificacion.
     * 
     * @access private
     * @param string $type
     * @return string|bool
     */
    private function GetTemplate($tmpl = array(), $find = false){
        global $context, $txt, $modSettings;
        
        $output = array();
        
        // Templates para la accion.
        $templates = array(
            'comment' => array(
                'minimal' => array(
                    'single' => '{user html:<a class="notifier-link" href="#profile_href#" title="#nick#">#nick#</a>} <span class="notif-action">coment&oacute;</span> en tu {post html:<a class="tt-element object-link" href="#topic_href#" title="#topic_name#">post</a>}.',
                    'plural' => '{array:users html:<a class="notifier-link"  href="#profile_href#" title="#nick#">#nick#</a>} {restant_users} <span class="notif-action">comentaron</span> en tu {post html:<a class="tt-element object-link" href="#topic_href#" title="#topic_name#">post</a>}.'
                    ),
                'extended' => array(
                    'single' => '{user html:<a class="notifier-link" href="#profile_href#" title="#nick#">#nick#</a>} <span class="notif-action">coment&oacute;</span> en tu post {post html:<a class="object-link" href="#topic_href#" title="#topic_name#">#topic_name#</a>}.',
                    'plural' => '{array:users html:<a class="notifier-link" href="#profile_href#" title="#nick#">#nick#</a>} {restant_users} <span class="notif-action">comentaron</span> en tu post {post html:<a class="object-link" href="#topic_href#" title="#topic_name#">#topic_name#</a>}.'
                )
            ),
            'bookmark' => array(
                'minimal' => array(
                    'single' => '{user html:<a href="#profile_href#" title="#nick#">#nick#</a>} agreg&oacute; a favoritos tu {post html:<a class="tt-element object-link" href="#topic_href#" title="#topic_name#">post</a>}.',
                    'plural' => '{array:users html:<a href="#profile_href#" title="#nick#">#nick#</a>} {restant_users} agregaron a favoritos tu {post html:<a class="tt-element object-link" href="#topic_href#" title="#topic_name#">post</a>}.'
                    ),
                'extended' => array(
                    'single' => '{user html:<a class="notifier-link" href="#profile_href#" title="#nick#">#nick#</a>} agreg&oacute; a favoritos tu post {post html:<a class="object-link" href="#topic_href#" title="#topic_name#">#topic_name#</a>}.',
                    'plural' => '{array:users html:<a class="notifier-link" href="#profile_href#" title="#nick#">#nick#</a>} {restant_users} agregaron a favoritos tu post {post html:<a class="object-link" href="#topic_href#" title="#topic_name#">#topic_name#</a>}.'
                    )
            ),
            'points' => array(
                'minimal' => array(
                    'single' => '{user html:<a class="notifier-link" href="#profile_href#" title="#nick#">#nick#</a>} dej&oacute; <strong class="notif_points">{puntos}</strong> puntos en tu {post html:<a class="tt-element object-link" href="#topic_href#" title="#topic_name#">post</a>}.',
                    'plural' => '<strong class="notif_points">{puntos}</strong> puntos nuevos en tu {post html:<a class="tt-element object-link" href="#topic_href#" title="#topic_name#">post</a>} por parte de {array:users html:<a class="notifier-link" href="#profile_href#" title="#nick#">#nick#</a>} {restant_users}.'
                    ),
                'extended' => array(
                    'single' => '{user html:<a class="notifier-link" href="#profile_href#" title="#nick#">#nick#</a>} dej&oacute; <strong class="notif_points">{puntos}</strong> puntos en tu post {post html:<a class="object-link" href="#topic_href#" title="#topic_name#">#topic_name#</a>}.',
                    'plural' => '<strong class="notif_points">{puntos}</strong> puntos nuevos en tu post {post html:<a class="object-link" href="#topic_href#" title="#topic_name#">#topic_name#</a>} por parte de {array:users html:<a class="notifier-link" href="#profile_href#" title="#nick#">#nick#</a>} {restant_users}.'
                    ),
            ),
            'new_user' => array(
                'minimal' => '',
                'extended' => ''
            )
        );

        if(!$find){
        foreach($tmpl as $key => $value)
            if($templates[$key][$value])
                $output = $templates[$key][$value];
        }else{
            foreach($tmpl as $filter){
                $ouput = $templates[$filter];
                $templates = $ouput;                
            }
            return $ouput;
        }
        
        return $output;
    }
    
    
}

?>