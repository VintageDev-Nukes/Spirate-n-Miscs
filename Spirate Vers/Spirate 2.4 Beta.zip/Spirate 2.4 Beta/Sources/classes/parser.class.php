<?php
/**
 * class parser
 *
 * obtenemos de un array los datos para luego convertir una cadena
 * con sus expresiones a sus respectivos valores, segun el array dado.
 *
 * @author Jonathan Andres
 * @version 1.0
 * @example
 *  $object = new parser;
 *  echo $object->run('hola {world}', array('world' => 'mundo')); // print: hola mundo
 */
class parser{
    /**
     * init
     * 
     * @access public
     * @param string $var
     * @param array $data
     * @return string
     */
    public function init($value, $data){

        // find all advanced expressions
        preg_match_all('~\{array:(?P<expression>[a-z0-9_]+)\shtml:(?P<sub_template>[^\}]+)\}~i', $value, $pair_matches, PREG_SET_ORDER);
        // find all simple expressions
        preg_match_all('~\{(?P<expression>[a-z0-9_]+)(?:\shtml:(?P<sub_template>[^\}]+))*\}~i', $value, $single_matches, PREG_SET_ORDER);

        if(count($pair_matches + $single_matches) == 0 || empty($data) || !is_array($data))
            return $value;

        if(!empty($pair_matches)){
            foreach($pair_matches as $key => $val)
                if(isset($data[$val['expression']]))
                    $value = $this->parse($val['expression'], $val['sub_template'], $data[$val['expression']], $value, $val[0]);
        }
        if(!empty($single_matches))
            foreach($single_matches as $key => $val)
                if(isset($data[$val['expression']])){
                    if(!is_array($data[$val['expression']]))
                        $value = str_replace($val[0], (string)$data[$val['expression']], $value);
                    else if(isset($val['sub_template'])){
                        foreach($data[$val['expression']] as $expr => $replace)
                            $val['sub_template'] = str_replace('#'.$expr.'#', $replace, $val['sub_template']);

                        $value = str_replace($val[0], $val['sub_template'], $value);
                    }
                }

        return $value;

    }
    private function parse($expr, $sub_template, $data, $template, $string){

        $data = (array)$data;

        // extract sub expressions
       preg_match_all('~\#(?P<expr>[a-z0-9_]+)\#~i', $sub_template, $sub_expressions, PREG_SET_ORDER);
       
       $temp_sub_expressions = array();
       foreach($sub_expressions as $key => $val)
           foreach($val as $k => $v)
                $temp_sub_expressions[$val[$k]] = array($val[0], $val['expr']);

       $tmp = ''; $str = '';
       foreach($data as $row){
           // separator [y|,|etc]
           $separator = ''; $prefix;
           if(isset($row['separator'])){
               $separator = $row['separator'];
               unset($row['separator']);
           }
           if(isset($row['prefix'])){
               $prefix = $row['prefix'];
               unset($row['prefix']);
           }
          // template
          $tmp = $sub_template;
          // replace all data
              foreach($row as $k => $v)
                  if(isset($temp_sub_expressions[$k]))
                    $tmp = str_replace($temp_sub_expressions[$k][0], $row[$temp_sub_expressions[$k][1]], $tmp);
          // add a separator and a prefix?
          $tmp = $prefix . $tmp . $separator;
          $str .= $tmp;
       }
       // replace all template
       $str = str_replace($string, $str, $template);
       
       return $str;

    }

}
?>