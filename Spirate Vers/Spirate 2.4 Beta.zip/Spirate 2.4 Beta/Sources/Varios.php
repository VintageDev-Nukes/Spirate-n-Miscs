<?php
/* Spirate Script - Version 2.4
******   Varios.php     ******/

if (!defined('SPIRATE'))
	die('Hacking attempt...');
	
function SendTopic(){
	global $topic, $txt, $db_prefix, $context, $scripturl, $sourcedir, $url;

	isAllowedTo('send_topic');

	// loadlanguage() -> SendTopic.*.php
    loadLanguage('SendTopic');

	$context['sub_template']  = 'sendtopic';

	if (empty($topic))
		fatal_lang_error(472, false);

	$request = db_query("
		SELECT m.subject
		FROM ({$db_prefix}messages AS m, {$db_prefix}topics AS t)
		WHERE t.ID_TOPIC = $topic
			AND t.ID_FIRST_MSG = m.ID_MSG
		LIMIT 1", __FILE__, __LINE__);
	if (mysql_num_rows($request) == 0)
	fatal_lang_error(472, false);
	$row = mysql_fetch_assoc($request);
	mysql_free_result($request);
	censorText($row['subject']);
	if (empty($_POST['send']))
	{
		loadTemplate('Varios');
		loadLanguage('Varios');
		$context['page_title'] = $row['subject'];
		$context['start'] = $_REQUEST['start'];

		return;
	}

	checkSession();
	spamProtection('spam');

	require_once($sourcedir . '/Subs-Post.php');

	$_POST['y_name'] = trim($_POST['y_name']);
	$_POST['r_name'] = trim($_POST['r_name']);

	if ($_POST['y_name'] == '_' || !isset($_POST['y_name']) || $_POST['y_name'] == '')
		fatal_lang_error(75, false);
	if (!isset($_POST['y_email']) || $_POST['y_email'] == '')
		fatal_lang_error(76, false);
	if (preg_match('~^[0-9A-Za-z=_+\-/][0-9A-Za-z=_\'+\-/\.]*@[\w\-]+(\.[\w\-]+)*(\.[\w]{2,6})$~', stripslashes($_POST['y_email'])) == 0)
		fatal_lang_error(243, false);

if ($_POST['r_name'] == '_' || !isset($_POST['r_name']) || $_POST['r_name'] == '')
		fatal_lang_error(75, false);
	if (!isset($_POST['r_email']) || $_POST['r_email'] == '')
	fatal_lang_error(76, false);
	if (preg_match('~^[0-9A-Za-z=_+\-/][0-9A-Za-z=_\'+\-/\.]*@[\w\-]+(\.[\w\-]+)*(\.[\w]{2,6})$~', stripslashes($_POST['r_email'])) == 0)
		fatal_lang_error(243, false);

	$row['subject'] = un_htmlspecialchars($row['subject']);

	sendmail($_POST['r_email'], ''.$row['subject'].'',
		sprintf($txt['send_from'].': '. $url) . "\n\n" .
		sprintf($_POST['comment']) . "\n\n" .
		$txt['send_link']. $scripturl .'?topic=' . $topic . '');

	redirectexit(''. $scripturl .'?topic=' . $topic . '');
}
function Enlazanos(){
	global $context, $txt;
	
	// loadTemplate() -> Varios.template.php
	loadTemplate('Varios');
	
	// loadLanguage() -> Manual.*.php
	loadLanguage('Manual');
	
	// page_title -> titulo de pagina
	$context['page_title'] = 'Enlazanos';
	
	// sub_template -> template_enlazanos
	$context['sub_template']  = 'enlazanos';
}

function Terminos(){
	global $context, $txt;
	
	// loadTemplate() -> Varios.template.php
	loadTemplate('Varios');
	
	// loadLanguage() -> Manual.*.php
	loadLanguage('Manual');
	
	// page_title -> titulo de pagina
	$context['page_title'] = 'T&eacute;rminos y Condiciones';
	
	// sub_template -> template_terminos
	$context['sub_template']  = 'terminos';
}

function Protocolo(){
	global $context, $txt;
	
	// loadTemplate() -> Varios.template.php
	loadTemplate('Varios');
	
	// loadLanguage() -> Manual.*.php
	loadLanguage('Manual');
	
	// page_title -> titulo de pagina
	$context['page_title'] = 'Protocolo';
	
	// sub_template -> template_protocolo
	$context['sub_template']  = 'protocolo';
}
function Contactenos(){
	global $settings, $user_info, $language, $context, $txt;

        if(loadLanguage('Manual') == false)
            loadLanguage('Manual','spanish');
			
	loadTemplate('Varios');
	

	$subActions = array(
		'enviado' => 'enviado',
	                   );

        if (!empty($subActions[@$_GET['sa']]))
		$subActions[$_GET['sa']]();
	else
		intro();    

}

function intro(){
 	global $settings, $user_info, $language, $context, $txt;

	$context['page_title'] = 'Contactenos';
	$context['sub_template'] = 'intro';
}

function enviado(){

	global $settings, $user_info, $language, $context, $txt;

	$context['page_title'] = 'Enviado';
	$context['sub_template'] = 'enviado';

}

function AdminPaises(){

	global $settings, $user_info, $language, $context, $txt, $db_prefix, $subActions;
	
	//Solo lo ven los admins
        isAllowedTo('admin_forum');
	    loadLanguage('Manual');
		
        $subActions = array(
		'pais' => 'pais',
		'guardar' => 'guardar',
	);

		if (!empty($subActions[@$_GET['get']]) && $_GET['get']!='guardar')
		$subActions[$_GET['get']]();


	loadTemplate('Varios');
	
	//marco Administrar Paises
	adminIndex('paises');
	
	$context['page_title'] = $txt['pais_title'];
	$context['sub_template'] = 'AdminPaises';
	
	$context['admin_tabs'] = array(
		'title' => &$txt['paises'],
		'description' => $txt['pais_descripcion'],
		'tabs' => array(

		),
	);
		
	$paises = db_query("SELECT *
                        FROM {$db_prefix}paises
                        ORDER BY nombre ASC", __FILE__, __LINE__);
	
	while ($row = mysql_fetch_assoc($paises))
		$context['paises'][] = array(
                'ID_MEMBER' => $row['ID_MEMBER'],
                'ID_PAIS' => $row['ID_PAIS'],
                'nombre' => $row['nombre'],
                'img' => $row['img'], 
			);
	mysql_free_result($paises);

}

function pais(){
	global $settings, $txt, $db_prefix;
	
	$id = (int) $_POST['id'];
	
	if(empty($id) || $id < 1){
		die('Error.');
	}
	
	$paises = db_query("SELECT *
	FROM {$db_prefix}paises
	WHERE ID_PAIS = '$id'", __FILE__, __LINE__);
	$row = mysql_fetch_assoc($paises);
	mysql_free_result($paises);
	
	echo'
	<form name="editando" action="'.$scripturl.'?action=paises;get=guardar" method="POST">
		',$txt['pais_name'],': <input type="text" style="width:250px" name="nombre" value="',$row['nombre'],'" />
		<br /><br />
		',$txt['pais_name_img'],': <input type="text" style="width:100px" name="img" value="',$row['img'],'" />.png <img src="',$settings['default_images_url'],'/icons/banderas/',$row['img'],'.png" />
		<br /><br />
		',$txt['pais_edit'],' <input type="radio" name="borrar" value="0" checked="1" /> ',$txt['pais_delete'],' <input type="radio" name="borrar" value="1" />
		<input type="hidden" name="ID_PAIS" value="',$row['ID_PAIS'],'" />
		<div class="alignC">
			<input class="button" type="submit" name="editar" value="',$txt['pais_edit'],'" />
		</div>
	</form>';
	
	die();
}

function guardar(){
	global $txt, $db_prefix, $ID_MEMBER;
	
	$nombre = $_POST['nombre'];
	$img = $_POST['img'];
	
	if(empty($nombre)){
		echo'<div class="alignC" style="color:red;font-weight:bold;">',$txt['pais_no_name'],'</div>';
	}
	else if(empty($img)){
		echo'<div class="alignC" style="color:red;font-weight:bold;">',$txt['pais_no_img'],'</div>';
	}
	else{
		if(empty($_POST['ID_PAIS'])){
			$paises = db_query("INSERT INTO {$db_prefix}paises (nombre,img,ID_MEMBER)
			VALUES('$nombre','$img','$ID_MEMBER')", __FILE__, __LINE__);
			echo'<div class="alignC" style="color:green;font-weight:bold;">',$txt['pais_thec'],' ',$nombre,' ',$txt['pais_wasc'],'</div>';
		}
        else{
			$id = (int) $_POST['ID_PAIS'];
			if(!empty($id) || $id > 0){
				if($_POST['borrar']==1){
					$paises = db_query("DELETE FROM {$db_prefix}paises WHERE ID_PAIS = '$id' LIMIT 1", __FILE__, __LINE__);
					echo'<div class="alignC" style="color:red;font-weight:bold;">',$txt['pais_thec'],' ',$nombre,' ',$txt['pais_waser'],'</div>';
				}
				else{
					$paises = db_query("UPDATE {$db_prefix}paises SET nombre = '$nombre', img = '$img', ID_MEMBER = '$ID_MEMBER' WHERE ID_PAIS = '$id'", __FILE__, __LINE__);
					echo'<div class="alignC" style="color:green;font-weight:bold;">',$txt['pais_thec'],' ',$nombre,' ',$txt['pais_wased'],'</div>';
				}
			}
		}
	}
}


?>