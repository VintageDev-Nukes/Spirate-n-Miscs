<?php 

/*****************************
*         Galeria.php         *
*=============================*
*        Spirate v2.4         *
*******************************
* Version 1.0                 *
* Creado por 002              *
* Gracias a:                  *
* - Crazyfrog                 *
******************************/

/* IMPORTANT NOTES / NOTAS IMPORTANTES***
The privacy is managed like this:
0 is public, everyone can see the image;
1 is private, only the uploader, the mods and admins can see the image;
2 can only be watched by uploader's friends and itself.
--------------------
La privacidad se maneja asi:
0 es publico, cualquiera puede ver la imagen;
1 es privado, solo el usuario, los moderadores y administradores pueden ver la imagen;
2 la imagen solo puede ser vista por los amigos del usuario y el usuario.
*/


if (!defined('SPIRATE'))
die('Hacking attempt...');
  
function GMain(){

 global $context, $Imagen, $settings, $Pag, $scripturl;

 $sact = $_GET['sa'];
 $Imagen = (int) $_GET['imagen'];
 $Pag = (int) $_GET['pag'];
 
 
 if($Imagen<1)
 $Imagen = 0;

 $Sactions = array(
                  'prueba' => 'prueba',
                  'admin' => 'admin',
                  'album' => 'album',
                  'agregar' => 'agregar',
                  'agregar2' => 'agregar2',
                  'crearalbum' => 'crearalbum',
                  'crearalbum2' => 'crearalbum2',
				  'borrarAlbum' => 'borrarAlbum',
                  'borrar' => 'borrar',
                  'puntuar' => 'puntuar',
                  'comentar' => 'comentar',
                 );


	loadTemplate('Galeria');
	loadLanguage('Galeria');

 // Sub Menu Galeria
 $context['sub_tabs'] = 
          array( 
                 'galeria' => array(
        array(
            'txt' => 'Inicio',
            'href' => $scripturl . '?action=galeria',
            'title' => 'Inicio'
            ),
        array(
            'txt' => 'Agregar Im&aacute;gen',
            'href' => $scripturl . '?action=galeria;sa=agregar',
            'title' => 'Agregar Im&aacute;gen',
			'who' => 'on'
            ),                       
        array(
            'txt' => 'Crear Album',
            'href' => $scripturl . '?action=galeria;sa=crearalbum',
            'title' => 'Crear Album',
            'who' => 'on'
            ),
        array(
            'txt' => 'Mis Im&aacute;genes',
            'href' => $scripturl . '?action=galeria;sa=album',
            'title' => 'Mis Im&aacute;genes',
            'who' => 'on'),
        array(
            'txt' => 'Administrar',
            'href' => $scripturl . '?action=galeria;sa=admin',
            'title' => 'Administracion',
            'who' => 'admin'
            )
                                    ),
                ); 

				
 // agregamos el .js de la galeria a => head
 $context['html_headers'][] = '<script type="text/javascript" src="' . $settings['theme_url'] . '/galeria.js"></script>';

 // agregamos el .css de la galeria a => head
 $context['html_headers'][] = '<link rel="stylesheet" type="text/css" href="'.$settings['theme_url'].'/galeria.css"/>
                               <!--[if IE]>
                                <link rel="stylesheet" type="text/css" href="'.$settings['theme_url'].'/galeria-ie.css"/>
                               <![endif]-->';


 if(empty($Imagen) && $Imagen==0 && $Album==0)
 {
 if(!empty($sact) && function_exists($Sactions[$sact]))
  $Sactions[$sact]();
 else
 rindex();
 }
 elseif($Imagen>0)
 display_image();


}

function display_image(){

 global $context, $Imagen, $db_prefix, $img, $scripturl, $_GET, $ID_MEMBER, $owner, $nextImg, $prevImg;

 $imglist = db_query("SELECT *, i.fecha as ifecha, a.nombre as anombre, i.privacy as privacy
                     FROM {$db_prefix}imagenes as i, {$db_prefix}img_album as a, {$db_prefix}members as m 
                      WHERE i.IDI = '$Imagen' 
                      AND m.ID_MEMBER = i.ID_MEMBER
                      AND a.IDA = i.album
                      LIMIT 1",__FILE__, __LINE__);
 while($row = mysql_fetch_assoc($imglist)){

       $img = array(

                      'IDI' => $row['IDI'],
                      'ID_MEMBER' => $row['ID_MEMBER'],
                      'titulo' => $row['titulo'],
                      'descripcion' => $row['descripcion'],
                      'url' => $row['url_img'],
					  'privacy' => $row['privacy'],
                      'puntos' => $row['puntos'],
                      'comentarios' => $row['comentarios'],
                      'fecha' => $row['ifecha'],
                      'album' => $row['album'],
                      'nombre' => $row['anombre'],
                      'nick' => $row['realName'],
                      'avatar' => $row['avatar'],
                      'posts' => $row['topics'],
                      'money' => $row['money'],
                      'photos' => $row['photos'],
                      'comments' => $row['comments'],                        
         );

 }
 mysql_free_result($imglist);

 $owner = $ID_MEMBER==$img['ID_MEMBER'];
 
 if($img['IDI']!=$Imagen)
 fatal_error("La Imagen no existe o fue eliminada.",false);
 
 if(!allowedTo('manage_bans')){
 if($img['privacy'] == 1 && $context['user']['id'] !== $img['ID_MEMBER'])
	fatal_error("No tienes los permisos suficientes para visualizar la im&aacute;gen.",false);
 if($img['privacy'] == 2 && !esAmigo($img['ID_MEMBER']) && $img['ID_MEMBER']!=$context['user']['id'])
	fatal_error("Debes ser Amigo de <a href='".$scripturl."/?action=profile;user=".$img['nick']."'>".$img['nick']."</a> para ver esta Im&aacute;gen.",false);
	}


mysql_free_result($request);

 $cmtlist = db_query("SELECT * FROM {$db_prefix}img_comentarios as c,{$db_prefix}members as m 
                      WHERE c.IDI = '$Imagen'
                      AND m.ID_MEMBER = c.ID_MEMBER
                      ",__FILE__, __LINE__);
 while($row = mysql_fetch_assoc($cmtlist)){

       $context['comentarios'][] = array(

                      'IDI' => $row['IDI'],
                      'ID_MEMBER' => $row['ID_MEMBER'],
                      'comentario' => parse_bbc($row['comentario']),
                      'fecha' => howlong($row['fecha']),
                      'nick' => $row['realName'],
                      'avatar' => $row['avatar'],                       
         );

 }
 mysql_free_result($cmtlist);
 
  setNextPrev();

 $context['sub_template'] = 'display';
 $context['page_title'] = $img['titulo'];

}

function setNextPrev(){

 global $context, $db_prefix, $img, $scripturl, $ID_MEMBER, $owner, $nextImg, $prevImg;
 
 /* Obetenemos la siguiente y anterior ID de la imagen del album */
 $actual = $img['IDI'];
 $dueno = $img['ID_MEMBER'];
 $nextImg = 0;
 $prevImg = 0;
 $album = $img['album'];
 
 $privacidad = '';
 
 if(!allowedTo('manage_bans')){
 if(!$owner)
	$privacidad = 'AND privacy != 1';
	
 if(!esAmigo($dueno) && !$owner)
	$privacidad = $privacidad.' AND privacy != 2';
	}
 
 //primero la anterior
 $ant = db_query("SELECT IDI
                     FROM {$db_prefix}imagenes
                      WHERE IDI < '$actual' 
                      AND ID_MEMBER = '$dueno'
                      AND album = '$album'
					  ".$privacidad."
					  ORDER BY IDI DESC
                      LIMIT 1",__FILE__, __LINE__);
 while($idant = mysql_fetch_assoc($ant))
  $prevImg = $idant['IDI'];
 mysql_free_result($ant);
 
 //obtenemos la siguiente
 $sig = db_query("SELECT IDI
                     FROM {$db_prefix}imagenes
                      WHERE IDI > '$actual' 
                      AND ID_MEMBER = '$dueno'
                      AND album = '$album'
					  ".$privacidad."
					  ORDER BY IDI ASC
                      LIMIT 1",__FILE__, __LINE__);
 while($idsig = mysql_fetch_assoc($sig))
  $nextImg = $idsig['IDI'];
 mysql_free_result($asig);
 

}

function album(){

 global $context, $Album, $db_prefix, $ID_MEMBER, $Member, $pagetitle, $fecha_album, $owner, $sourcedir, $scripturl;

 $Album = (int) $_GET['id'];
 $Album = $Album<0 ? 0 : $Album;
 $user = ((int) $_GET['user'])<0 || empty($_GET['user'])  ? $ID_MEMBER : ((int) $_GET['user']);
 
 //Verificamos el nivel de privacidad
 if($ID_MEMBER==$user || allowedTo('manage_bans'))
  $privacidad = '';
 elseif(esAmigo($user))
  $privacidad = 'AND (privacy=0 OR privacy=2)';
 else
  $privacidad = 'AND privacy=0';
 
 if($Album!=0){
 
 
 // Album
 $alblist = db_query("SELECT * FROM {$db_prefix}img_album 
                      WHERE IDA = '$Album'
                      LIMIT 1",__FILE__, __LINE__);
 while($row = mysql_fetch_assoc($alblist)){

       $context['album'] = array(
               
                      'ID_MEMBER' => $row['ID_MEMBER'],
                      'afecha' => $row['fecha'],
                      'album' => $row['IDA'],
                      'nombre' => $row['nombre'],
					  'privacy' => $row['privacy'],
                                          
         );

 //Datos Importantes del album
 $id_member = $row['ID_MEMBER'];
 $pagetitle = $row['nombre'];
 $fecha_album = $row['fecha'];
 
 if($ID_MEMBER==$id_member || allowedTo('manage_bans'))
  $privacidad = '';
 elseif(esAmigo($id_member))
  $privacidad = 'AND (privacy=0 OR privacy=2)';
 else
  $privacidad = 'AND privacy=0';
 
 $request = db_query("SELECT COUNT(*) FROM {$db_prefix}imagenes WHERE album = '$Album' ".$privacidad." ORDER BY IDI DESC",__FILE__, __LINE__);
	
	 list($totalImg) = mysql_fetch_row($request);
     mysql_free_result($request);
	 
	 $limite=16;
 
     $_REQUEST['page'] = (int)$_REQUEST['page'];
	 if($_REQUEST['page']<0)
	  $_REQUEST['page']=1;
	  
     require_once($sourcedir . '/classes/Pagination.php');
    $paginator = new Pagination(array(
        'base_url' => $scripturl . '?action=galeria;sa=album;user='.$user.';id='.$Album.';page=',
        'total_rows' => $totalImg,
        'per_page' => $limite,
        'first_link' => '',
        'last_link' => '',
        'query_string_segment' => 'page',
        'full_tag_open' => '<ul class="paginator smallfont clearfix">',
        'full_tag_close' => '</ul>'
    ));

    $context['paginacion'] = $paginator->create_links($getData);
    $context['total_pages'] = $getData['num_pages'];
 

  //Lista de imagenes del Album
  $imglist = db_query("SELECT * FROM {$db_prefix}imagenes
                      WHERE album = '$Album' 
					  ".$privacidad."
                      ORDER BY IDI DESC
                      LIMIT {$_REQUEST[page]}, {$limite}",__FILE__, __LINE__);
 while($img = mysql_fetch_assoc($imglist)){

       
       $context['images'][] = array(

                      'IDI' => $img['IDI'],
                      'ID_MEMBER' => $img['ID_MEMBER'],
                      'titulo' => $img['titulo'],
                      'descripcion' => $img['descripcion'],
                      'url' => $img['url_img'],
                      'privacy' => $img['privacy'],
                      'puntos' => $img['puntos'],
                      'comentarios' => $img['comentarios'],
                      'fecha' => $img['ifecha'],
                      'album' => $img['album'],
                      'nombre' => $img['anombre'],                                          
         );
		 

        }

}

 if(!$context['album'])
	fatal_error("El Album no existe o fue eliminado.",false);
  
 if(!allowedTo('manage_bans'))
	if($context['album']['privacy'] == 1 && $ID_MEMBER!=$context['album']['ID_MEMBER'])
		fatal_error("No tienes los permisos suficientes para visualizar el &aacute;lbum",false);

if($context['album']['privacy'] == 2)
	if(!allowedTo('manage_bans'))
		if($context['album']['ID_MEMBER'] !== $context['user']['id']){
			$id_m = (int)$context['album']['ID_MEMBER'];
			$id_b = (int)$context['user']['id'];
			$request = db_query('SELECT approved FROM ' . $db_prefix . 'buddies WHERE ID_MEMBER = ' . $id_m . ' AND BUDDY_ID = ' . $id_b, __FILE__, __LINE__);
				if (mysql_num_rows ($request) == 0){
				$memberName = db_query("SELECT memberName FROM {$db_prefix}members WHERE ID_MEMBER = {$context['album']['ID_MEMBER']} LIMIT 1",__FILE__,__LINE__);
				$memberName = mysql_fetch_assoc($memberName);
					fatal_error("Para visualizar el &aacute;lbum tienes que ser amigo de <a href='".$scripturl."/?action=profile;user=".$memberName['memberName']."'>".$memberName['memberName']."</a>",false);
				}
		}
mysql_free_result($request);
		
}
else{

 $alblist = db_query("SELECT * FROM {$db_prefix}img_album
                      WHERE ID_MEMBER = '$user'
					  ".$privacidad."
                      ORDER BY IDA DESC",__FILE__, __LINE__);
 while($row = mysql_fetch_assoc($alblist)){


       $context['albums'][] = array(

                      'IDA' => $row['IDA'],
                      'ID_MEMBER' => $row['ID_MEMBER'],
                      'nombre' => $row['nombre'],
                      'cantimg' => $row['cantimg'],
                      'privacy' => $row['privacy'],
                      'fecha' => howlong($row['fecha']),                                                 
         );
		 

  //Obtenemos la primer imagen del album, si es que la tiene
  $first_img = db_query("SELECT url_img FROM {$db_prefix}imagenes WHERE album = '".$row['IDA']."' ORDER BY IDI ASC LIMIT 1",__FILE__, __LINE__);
  $fimg = mysql_fetch_assoc($first_img);
  $context['img_'.$row['IDA']] = array('url' => $fimg['url_img'],);       
  mysql_free_result($first_img);


 }
 mysql_free_result($alblist);
 
     
     $request = db_query("SELECT COUNT(*) FROM {$db_prefix}imagenes WHERE ID_MEMBER = '$user' AND album = 0 ".$privacidad." ORDER BY IDI DESC",__FILE__, __LINE__);
	
	 list($totalImg) = mysql_fetch_row($request);
     mysql_free_result($request);
	 
	 $limite=16;
 
     $_REQUEST['page'] = (int)$_REQUEST['page'];
	 if($_REQUEST['page']<0)
	  $_REQUEST['page']=1;
	  
     require_once($sourcedir . '/classes/Pagination.php');
    $paginator = new Pagination(array(
        'base_url' => $scripturl . '?action=galeria;sa=album;user='.$user.';page=',
        'total_rows' => $totalImg,
        'per_page' => $limite,
        'first_link' => '',
        'last_link' => '',
        'query_string_segment' => 'page',
        'full_tag_open' => '<ul class="paginator smallfont clearfix">',
        'full_tag_close' => '</ul>'
    ));

    $context['paginacion'] = $paginator->create_links($getData);
    $context['total_pages'] = $getData['num_pages'];
	
  //Obtenemos todas las imagenes sin album
  $images = db_query("SELECT * FROM {$db_prefix}imagenes 
                      WHERE ID_MEMBER = '$user' 
					  AND album = 0
					  ".$privacidad."
                      ORDER BY IDI DESC
					  LIMIT {$_REQUEST[page]}, {$limite}",__FILE__, __LINE__);

  while($row = mysql_fetch_assoc($images))
         {
		 
           $context['imglist'][] = array(

                      'IDI' => $row['IDI'],
                      'ID_MEMBER' => $row['ID_MEMBER'],
                      'url' => $row['url_img'],
                      'puntos' => $row['puntos'],
                      'privacy' => $row['privacy'],
                      'fecha' => howlong($row['fecha']),
                                                 
          );
		 
          }
  mysql_free_result($images);
 
 
}

 $id_member = !empty($id_member) ? $id_member : $user;

 $user = db_query("SELECT * FROM {$db_prefix}members
                      WHERE ID_MEMBER = '$id_member'
                      LIMIT 1",__FILE__, __LINE__);
 while($row = mysql_fetch_assoc($user)){

       $Member = array(
                      'ID_MEMBER' => $row['ID_MEMBER'],                
                      'nick' => $row['realName'],
                      'avatar' => $row['avatar'],
                      'posts' => $row['topics'],
                      'money' => $row['money'],
                      'comments' => $row['comments'],
                      'photos' => $row['photos'],
         );

 }
 mysql_free_result($user);

 if(empty($Member))
 fatal_error("Usuario Inexistente.",false);

 //Dueno de la imagen?
 $owner = $ID_MEMBER==$Member['ID_MEMBER'];

 $context['sub_template'] = 'album';
 $context['page_title'] = empty($pagetitle) ? 'Mis Im&aacute;genes' : $pagetitle;

}

function rindex(){

 global $context, $db_prefix, $Pag, $scripturl, $Paginacion, $settings, $boarddir, $modSettings, $ID_MEMBER;

  switch((string)$_GET['filtro']){
 case 'ultimasImagenes':
	$filtro = 'ORDER BY IDI DESC';
	break;
 case 'puntos':
	$filtro = 'ORDER BY puntos DESC';
	break;
 case 'comentarios':
	$filtro = 'ORDER BY comentarios DESC';
	break;
 default:
	$filtro = 'ORDER BY IDI DESC';
 }
 
 $context['sub_template'] = 'reindex';
 $context['page_title'] = 'Galeria';

 $cantimglist = db_query("SELECT IDI FROM {$db_prefix}imagenes 
                      ",__FILE__, __LINE__);
 $CantImg = mysql_num_rows($cantimglist);

 $corte = $modSettings['pag_recent'];
 $num_img = $modSettings['cant_img_recent'];

 //Paginacion
 $Paginacion = paginator3000($Pag,$corte,$num_img,$CantImg,$scripturl.'?action=galeria;filtro='.$_GET['filtro'].';pag=',0);

  if(!isset($Paginacion['inicio']) || !isset($Paginacion['registros']))
   {
     $Paginacion['inicio']=0;
	 $Paginacion['registros']=0;
   }
 /* Listado de Imagenes */

 $imglist = db_query("SELECT *, i.fecha as ifecha, i.privacy as privacy FROM {$db_prefix}imagenes as i, {$db_prefix}img_album as a, {$db_prefix}members as m 
                      WHERE m.ID_MEMBER = i.ID_MEMBER
                      AND a.IDA = i.album
					  AND (i.privacy = 0 OR i.privacy = 2)
                      {$filtro}
                      LIMIT {$Paginacion['inicio']},{$Paginacion['registros']}",__FILE__, __LINE__);
 while($row = mysql_fetch_assoc($imglist)){
      
	   //Verificamos la privacidad
	   if($row['privacy']==0 || $row['ID_MEMBER']==$ID_MEMBER){
	   
       $thumb = $boarddir."/Themes/default/images/galeria/thumbnails/thumb_user".$row['ID_MEMBER']."-".$row['IDI'].".jpg";
       $thumb_url =  $settings['images_url']."/galeria/thumbnails/thumb_user".$row['ID_MEMBER']."-".$row['IDI'].".jpg";     

       $context['imglist'][] = array(

                      'IDI' => $row['IDI'],
                      'ID_MEMBER' => $row['ID_MEMBER'],
                      'titulo' => $row['titulo'],
                      'descripcion' => $row['descripcion'],
                      'url' =>  file_exists($thumb) ? $thumb_url : $row['url_img'],
                      'privacy' => $row['privacy'],
                      'puntos' => $row['puntos'],
                      'comentarios' => $row['comentarios'],
                      'fecha' => $row['ifecha'],
                      'album' => $row['album'],
                      'nick' => $row['realName'],                        
                                       );
		 }
		 elseif($row['privacy']==2 && esAmigo($row['ID_MEMBER']) ){
	   
          $thumb = $boarddir."/Themes/default/images/galeria/thumbnails/thumb_user".$row['ID_MEMBER']."-".$row['IDI'].".jpg";
          $thumb_url =  $settings['images_url']."/galeria/thumbnails/thumb_user".$row['ID_MEMBER']."-".$row['IDI'].".jpg";     

          $context['imglist'][] = array(

                      'IDI' => $row['IDI'],
                      'ID_MEMBER' => $row['ID_MEMBER'],
                      'titulo' => $row['titulo'],
                      'descripcion' => $row['descripcion'],
                      'url' =>  file_exists($thumb) ? $thumb_url : $row['url_img'],
                      'privacy' => $row['privacy'],
                      'puntos' => $row['puntos'],
                      'comentarios' => $row['comentarios'],
                      'fecha' => $row['ifecha'],
                      'album' => $row['album'],
                      'nick' => $row['realName'],                        
                                          );
		 }

 }
 mysql_free_result($imglist);

 /* Ultimos comentarios */

$cmt = db_query("SELECT m.realName, c.ID_MEMBER, i.titulo, i.IDI
                      FROM {$db_prefix}imagenes as i, {$db_prefix}img_comentarios as c, {$db_prefix}members as m 
                      WHERE i.IDI = c.IDI
                      AND m.ID_MEMBER = c.ID_MEMBER
                      ORDER BY c.fecha DESC 
                      LIMIT 10",__FILE__, __LINE__);
 while($row = mysql_fetch_assoc($cmt)){
      
       $context['lastcmt'][] = array(

                      
                      'ID_MEMBER' => $row['ID_MEMBER'],           
                      'titulo' => strlen($row['titulo'])>25 ? substr($row['titulo'], 0, 25 )  : $row['titulo'],
                      'nick' => $row['realName'],         
                      'IDI' => $row['IDI'],                
         );

 }
 mysql_free_result($cmt);
 
 /* Top Semanal */

 $semana = time() - (3600*24*7); 

 $top10 = db_query("SELECT  ID_MEMBER, titulo, IDI, puntos, url_img, privacy
                      FROM {$db_prefix}imagenes
                      WHERE fecha > '$semana' 
					  AND (privacy = 0 OR privacy = 2)
                      ORDER BY puntos DESC 
                      LIMIT 10",__FILE__, __LINE__);
 while($row = mysql_fetch_assoc($top10)){
      
       $context['topten'][] = array(
                    
                      'ID_MEMBER' => $row['ID_MEMBER'],           
                      'title' => $row['titulo'],
                      'titulo' => strlen($row['titulo'])>29 ? substr($row['titulo'], 0, 29 )  : $row['titulo'],
                      'puntos' => $row['puntos'],         
                      'IDI' => $row['IDI'],
                      'url_img' => $row['url_img'],                 
         );

 }
 mysql_free_result($top10);

}

function agregar(){

 global $context, $id, $db_prefix, $img, $ID_MEMBER;

 $context['sub_template'] = 'agregar';
 $context['page_title'] = 'Agregar Imagen';

 $id = (int) $_GET['id'];
 if($id<1)
 $id = 0;
 $img['editar'] = false;


 if(empty($ID_MEMBER))
 fatal_error("Para agregar imagenes debes estar logueado");


   /*Estoy editando una imagen?*/
 if(!empty($id) || $id>0)
 {

  /* Cargo los datos de la imagen a editar*/
$imglist = db_query("SELECT *, i.fecha as ifecha, i.privacy as privacy FROM {$db_prefix}imagenes as i, {$db_prefix}img_album as a, {$db_prefix}members as m 
                      WHERE i.IDI = '$id' 
                      AND m.ID_MEMBER = i.ID_MEMBER
                      AND a.IDA = i.album
                      LIMIT 1",__FILE__, __LINE__);
 while($row = mysql_fetch_assoc($imglist)){

       $img = array(

                      'IDI' => $row['IDI'],
                      'ID_MEMBER' => $row['ID_MEMBER'],
                      'titulo' => $row['titulo'],
                      'descripcion' => $row['descripcion'],
                      'url' => $row['url_img'],
                      'privacy' => $row['privacy'],
                      'puntos' => $row['puntos'],
                      'comentarios' => $row['comentarios'],
                      'fecha' => $row['ifecha'],
                      'album' => $row['album'],                       
         );
       $img['editar'] = true;

 }
 mysql_free_result($imglist);

 if($img['IDI']!=$id)
 fatal_error("La imagen que quiere editar no existe.",false);

 if(!allowedTo('manage_bans'))
  if($ID_MEMBER!=$img['ID_MEMBER'])
   fatal_error("No puede editar esta imagen",false);

 }

 $member = !empty($img['ID_MEMBER']) ? $img['ID_MEMBER'] : $ID_MEMBER;

$albumlist = db_query("SELECT * FROM {$db_prefix}img_album 
                     WHERE ID_MEMBER = '".$member."'
                      ORDER BY IDA ASC
                      ",__FILE__, __LINE__);
 while($row = mysql_fetch_assoc($albumlist)){

       $context['albums'][] = array(

                      'IDA' => $row['IDA'],
                      'ID_MEMBER' => $row['ID_MEMBER'],
                      'nombre' => $row['nombre'],
                       
         );

 }
 mysql_free_result($albumlist);

}

function agregar2(){

 global $context, $func, $db_prefix, $ID_MEMBER, $url_img, $id;

 $context['page_title'] = 'Agregar Imagen';

 /* Cargo y filtro los datos para agregar o editar la imagen */
 $titulo = $func['htmlspecialchars']($_POST['titulo'], ENT_QUOTES, 'UTF-8');
 $url_img = $_POST['url_img'];
 $desc = $func['htmlspecialchars']($_POST['descripcion'], ENT_QUOTES, 'UTF-8');
 $album = (int) $_POST['album'];
 $privacy = (int) $_POST['privacy'];
 $fecha = time();
 $id_img = (int) $_POST['id_img'];
 $oldalbum = (int) $_POST['oldalbum'];


 /* Veo que no haya nada raro */

if(empty($titulo) || is_real_empty($titulo))
fatal_error("No has ingresado un titulo.", false);

if(empty($url_img) || is_real_empty($url_img))
fatal_error("No has ingresado una URL.", false);

if(empty($ID_MEMBER))
fatal_error("Debes estar logueado.", false);

if(!getimagesize($url_img))
fatal_error("No existe ninguna imagen en la URL.", false);

if($id_img<1)
{
  /* Agrego una imagen nueva */

 $query = db_query("INSERT INTO {$db_prefix}imagenes (ID_MEMBER,titulo,descripcion,url_img,album,privacy,puntos,comentarios,fecha)
        VALUES('$ID_MEMBER','$titulo','$desc','$url_img','$album','$privacy',0,0,'$fecha')",__FILE__, __LINE__);


if($query){

 $query = db_query("UPDATE {$db_prefix}img_album SET cantimg = cantimg + 1 WHERE IDA = '$album' LIMIT 1",__FILE__, __LINE__);
 $query = db_query("UPDATE {$db_prefix}members SET photos = photos + 1 WHERE ID_MEMBER = '$ID_MEMBER' LIMIT 1",__FILE__, __LINE__);

 $se = db_query("SELECT IDI FROM {$db_prefix}imagenes ORDER BY IDI DESC LIMIT 1",__FILE__, __LINE__);
 $id = mysql_fetch_assoc($se);
 $id = $id['IDI'];
  
 agregado("Felicidades!","La imagen ".$titulo." fu&eacute; agregada con &eacute;xito.",$id,false);
 }
}
else{

 /* Edito una imagen */

  $imagen = db_query("SELECT ID_MEMBER FROM {$db_prefix}imagenes 
                     WHERE IDI = '".$id_img."'
                     LIMIT 1",__FILE__, __LINE__);
 $imge = mysql_fetch_assoc($imagen);
 $dueno = $imge['ID_MEMBER'];
 
 if(empty($dueno))
 fatal_error("La imagen no existe o ya fue eliminada",false);

 if(!allowedTo('manage_bans'))
  if($ID_MEMBER!=$dueno)
   fatal_error("No puede editar esta imagen",false);

if($album!=$oldalbum){
$query = db_query("UPDATE {$db_prefix}img_album SET cantimg = cantimg + 1 WHERE IDA = '$album' LIMIT 1",__FILE__, __LINE__);
$query = db_query("UPDATE {$db_prefix}img_album SET cantimg = cantimg - 1 WHERE IDA = '$oldalbum' LIMIT 1",__FILE__, __LINE__);

}
$query = db_query("UPDATE {$db_prefix}imagenes SET titulo = '$titulo', descripcion = '$desc', url_img = '$url_img', album = '$album', privacy = $privacy WHERE IDI = '$id_img' LIMIT 1",__FILE__, __LINE__);

 $id = $id_img;

if($query)
agregado("Felicidades!","La imagen ".$titulo." fu&eacute; editada con &eacute;xito.",$id,false);

}
}

function borrar(){

 global $context, $ID_MEMBER, $func, $db_prefix, $dueno, $id;

 $context['page_title'] = 'Borrar Imagen';
 
 $idimg = (int) $_POST['id_img'];
 $causa = $func['htmlspecialchars']($_POST['causa'], ENT_QUOTES, 'UTF-8');

 if($idimg<1)
 fatal_error("La imagen es invalida",false);

 if(is_real_empty($causa)) 
 fatal_error("Debes ingresar una causa",false); 

 $imagen = db_query("SELECT ID_MEMBER, album, titulo FROM {$db_prefix}imagenes 
                     WHERE IDI = '$idimg'
                     LIMIT 1",__FILE__, __LINE__);
 $img = mysql_fetch_assoc($imagen);
 $album = $img['album'];
 
 if(empty($img['ID_MEMBER']))
 fatal_error("La imagen no existe",false);


  if(!allowedTo('manage_bans'))
  if($ID_MEMBER!=$img['ID_MEMBER'])
   fatal_error("No puede borrar esta imagen",false);

 $dueno = $img['ID_MEMBER'];

$query = db_query("DELETE FROM {$db_prefix}imagenes WHERE IDI = '$idimg' LIMIT 1",__FILE__, __LINE__);

if($query){
$query = db_query("UPDATE {$db_prefix}img_album SET cantimg = cantimg - 1 WHERE IDA = '$album' LIMIT 1",__FILE__, __LINE__);
$query = db_query("UPDATE {$db_prefix}members SET photos = photos - 1 WHERE ID_MEMBER = '".$img['ID_MEMBER']."' LIMIT 1",__FILE__, __LINE__);

logAction('Imagen Borrada', array('topic' => $idimg, 'subject' => $img['titulo'], 'member' => $ID_MEMBER, 'causa' => $causa));
 $id = $idimg;
 agregado("Atencion!","La imagen ".$img['titulo']." fu&eacute; eliminada con &eacute;xito.","",false,true);
 }
}


function agregado($titulo,$contenido,$id,$album=true,$volver=false){

 global $context, $url_img, $id, $dueno;

 $context['titulo'] = $titulo;
 $context['contenido'] = $contenido;
 $context['id'] = $id;
 $context['album'] = $album;
 $context['volver'] = $volver;
 
 $context['sub_template'] = 'agregado';
 $context['page_title'] = 'Agregar '. $album ? 'Im&aacute;gen' : 'Album';

 
}

function puntuar(){

 global $context, $db_prefix, $ID_MEMBER;

        if(!$context['ajax_request'])
            die();
        // make sure is ajax
        $_REQUEST['ajax'] = 1;


 $con = $_POST['con'];
 $imagen = (int) $_POST['imagen'];

 if($imagen<1 || is_real_empty($con))
 die(json_encode(array('status' => 'error', 'message' => 'Datos invalidos.')));

 if(empty($ID_MEMBER))
 die(json_encode(array('status' => 'error', 'message' => 'Debes estar logueado para poder puntuar.')));

 $query = db_query("SELECT ID_MEMBER, titulo FROM {$db_prefix}imagenes 
                     WHERE IDI = '$imagen'
                     LIMIT 1",__FILE__, __LINE__);
 $img = mysql_fetch_assoc($query);
 $member = $img['ID_MEMBER'];
 
 if(mysql_num_rows($query)==0)
 die(json_encode(array('status' => 'error', 'message' => 'La imagen no es valida o fue eliminada.')));

 if($member==$ID_MEMBER)
 die(json_encode(array('status' => 'error', 'message' => 'No puedes dar puntos a tus Imagenes.')));

 $query2 = db_query("SELECT ID_MEMBER, IDI FROM {$db_prefix}img_plog 
                     WHERE IDI = '$imagen'
                     AND ID_MEMBER = '$ID_MEMBER'
                     LIMIT 1",__FILE__, __LINE__);  

 if(mysql_num_rows($query2)==1)
 die(json_encode(array('status' => 'error', 'message' => 'Ya has dado puntos a esta imagen.')));

 $cp = $con=='masuno' ? '+1' : ($con=='menosuno' ? '-1' : 0);

 if($cp==0)
  die(json_encode(array('status' => 'error', 'message' => 'Codigo Invalido.')));

 $fecha = time();

 $puntuar = db_query("UPDATE {$db_prefix}imagenes SET puntos  = puntos ".$cp." WHERE IDI = '$imagen' LIMIT 1",__FILE__, __LINE__);

 $plog = db_query("INSERT INTO {$db_prefix}img_plog (IDI,ID_MEMBER,fecha,punto) 
                   VALUES('$imagen','$ID_MEMBER','$fecha','$cp')",__FILE__, __LINE__);


die(json_encode(array('status' => 'fin')));

}

function crearalbum(){

 global $context, $id, $db_prefix, $alb, $ID_MEMBER, $modSettings;

 $context['sub_template'] = 'crearalbum';
 $context['page_title'] = 'Crear Album';

 $id = (int) $_GET['id'];
 if($id<1)
 $id = 0;
 $alb['editar'] = false;


 if(empty($ID_MEMBER))
 fatal_error("Para crear un album debes estar logueado");


   /*Estoy editando un album?*/
 if(!empty($id) || $id>0)
 {

  /* Cargo los datos de la imagen a editar*/
$alblist = db_query("SELECT *, a.nombre as anombre FROM {$db_prefix}img_album as a, {$db_prefix}members as m 
                      WHERE a.IDA = '$id' 
                      AND m.ID_MEMBER = a.ID_MEMBER
                      LIMIT 1",__FILE__, __LINE__);
 while($row = mysql_fetch_assoc($alblist)){

       $alb = array(

                      'IDA' => $row['IDA'],
                      'ID_MEMBER' => $row['ID_MEMBER'],
                      'nombre' => $row['anombre'],
                      'privacy' => $row['privacy'],
                      'fecha' => $row['fecha'],                       
         );
       $alb['editar'] = true;

 }
 mysql_free_result($alblist);

 if($alb['IDA']!=$id)
 fatal_error("El Album que quiere editar no existe.",false);

 if(!allowedTo('manage_bans'))
  if($ID_MEMBER!=$alb['ID_MEMBER'])
   fatal_error("No puede editar este Album",false);

 $ida = $alb['IDA'];
 $user = $alb['ID_MEMBER'];

$imglist = db_query("SELECT * FROM {$db_prefix}imagenes
                     WHERE ID_MEMBER = '".$user."'
                     AND album = '$ida'
                      ORDER BY IDI ASC
                      ",__FILE__, __LINE__);
 while($row = mysql_fetch_assoc($imglist)){

       $context['imgenalbum'][] = array(

                      'IDI' => $row['IDI'],
                      'titulo' => $row['titulo'],
                      'img_url' => $row['img_url'],
                       
         );

 }
 mysql_free_result($imglist);


 }else{

  //Verifico la cantidad maxima de albums a crear
  $caa = db_query("SELECT IDA FROM {$db_prefix}img_album WHERE ID_MEMBER = '$ID_MEMBER'",__FILE__, __LINE__);
  $cant_album = mysql_num_rows($caa);
  if($modSettings['cant_album']>0 && $modSettings['cant_album']<=$cant_album)
  fatal_error("Has superado la cantidad maxima de albums creados.",false); 

 }

 //Cargo el id del usuario creador
 $member = !empty($alb['ID_MEMBER']) ? $alb['ID_MEMBER'] : $ID_MEMBER;


 $imglist = db_query("SELECT * FROM {$db_prefix}imagenes
                     WHERE ID_MEMBER = '".$member."'
                     AND album = 0
                      ORDER BY IDI ASC
                      ",__FILE__, __LINE__);
 while($row = mysql_fetch_assoc($imglist)){

       $context['imgensinalbum'][] = array(

                      'IDI' => $row['IDI'],
                      'titulo' => $row['titulo'],
                      'img_url' => $row['img_url'],
                       
         );

 }
 mysql_free_result($imglist);

}

function crearalbum2(){

 global $context, $func, $db_prefix, $ID_MEMBER;

 $imagenes = explode(",",$_POST['newimg']);
 $nombre = $func['htmlspecialchars']($_POST['nombre'], ENT_QUOTES, 'UTF-8');
 $IDA = (int) $_POST['ida'];
 $id = (int) $_POST['ida'];
  
 //filtramos
 for($i=0;$i<COUNT($imagenes);$i++)
 $imagenes[$i] = (int) $imagenes[$i];
 $imagenes = implode(",",$imagenes);
 $imagenes = str_replace(",0","",$imagenes);

 $privacy = (int) $_POST['privacy'];
 $IDA = ($IDA<1 || empty($IDA)) ? 0 : $IDA;


 //El nombre esta vacio?
 if(is_real_empty($nombre))
 fatal_error("No has ingresado un Nombre",false);

 $newname = db_query("SELECT IDA,nombre FROM {$db_prefix}img_album WHERE nombre = '$nombre' AND ID_MEMBER = '$ID_MEMBER' AND IDA != '$IDA'",__FILE__, __LINE__);
 $name = mysql_fetch_assoc($newname);
 $vname = $name['nombre'];

 //Verificamos que no tengas otro album con el mismo nombre
 if(!empty($vname))
 fatal_error("Ya tienes un Album con el mismo nombre.",false);

 if($IDA==0){
   /* Agregamos un nuevo album */

   $fecha = time();
  $query = db_query("INSERT INTO {$db_prefix}img_album (ID_MEMBER,nombre,cantimg,privacy,fecha)
        VALUES('$ID_MEMBER','$nombre',0,'$privacy','$fecha')",__FILE__, __LINE__);

  if($query){

 //Buscamos el ID del nuevo album
 $album = db_query("SELECT IDA FROM {$db_prefix}img_album WHERE ID_MEMBER = '$ID_MEMBER' ORDER BY IDA DESC LIMIT 1",__FILE__, __LINE__);
 $row = mysql_fetch_assoc($album);
 $last_id = $row['IDA'];

 mysql_free_result($album); 

   if($imagenes!=0)
   {
     /* Agregamos las imagenes al nuevo album */
     $imagealb = db_query("UPDATE {$db_prefix}imagenes SET album = '$last_id' 
                           WHERE IDI IN (".$imagenes.") AND ID_MEMBER = '$ID_MEMBER'",__FILE__, __LINE__);

     //Cantidad de imagenes agregadas
     $cantimg = COUNT(explode(",",$imagenes)); 

     //Actualizamos la cantidad de imagenes al nuevo y viejo album
     $albUp = db_query("UPDATE {$db_prefix}img_album SET cantimg = cantimg + '$cantimg' 
                           WHERE IDA = '$last_id' LIMIT 1",__FILE__, __LINE__);

     $albUp = db_query("UPDATE {$db_prefix}img_album SET cantimg = cantimg - '$cantimg' 
                           WHERE IDA = 0 LIMIT 1",__FILE__, __LINE__);
 
   }
  
  agregado("Felicidades!","El &aacute;lbum ".$nombre." fu&eacute; agregado con &eacute;xito.",$last_id);

             }
  else
  fatal_error("Error: la imagen no se agrego.",false);
 }
 else{
   /* Editamos un Album */

 //Buscamos los datos del album a editar
 $album = db_query("SELECT IDA, ID_MEMBER FROM {$db_prefix}img_album WHERE IDA = '$IDA' LIMIT 1",__FILE__, __LINE__);
 while($row = mysql_fetch_assoc($album)){
	$alb = array(
	'IDA' => $row['IDA'],
	'ID_MEMBER' => $row['ID_MEMBER'],
	);
 }

 if(mysql_num_rows($album)==0)
   fatal_error("El Album no es valido o fue eliminado.",false);
mysql_free_result($album);
 $dueno = $alb['ID_MEMBER'];
 
 //Permisos para editar, moderador o dueno
 if(!allowedTo('manage_bans'))
  if($ID_MEMBER!=$dueno)
   fatal_error("No puede editar este Album",false);

    //Editamos el Album
    $query = db_query("UPDATE {$db_prefix}img_album SET nombre = '$nombre', privacy = '$privacy'
                       WHERE IDA = '$IDA' AND ID_MEMBER = '$dueno' LIMIT 1",__FILE__, __LINE__);

  if($query){

     /* Editamos las imagenes del album */

     //Reestablecemos las imagenes del album al default
     //para no crear errores
     $imagealb = db_query("UPDATE {$db_prefix}imagenes SET album = 0 
                           WHERE album = '$IDA' AND ID_MEMBER = '$dueno'",__FILE__, __LINE__);
     $cuantas = mysql_num_rows($imagealb);

     $albUp = db_query("UPDATE {$db_prefix}img_album SET cantimg = 0 
                           WHERE IDA = '$IDA' LIMIT 1",__FILE__, __LINE__);

     $albUp = db_query("UPDATE {$db_prefix}img_album SET cantimg = cantimg + '$cuantas' 
                           WHERE IDA = 0 LIMIT 1",__FILE__, __LINE__);
     //imagenes album al default reestablecidos

   if($imagenes!=0)
   {
     //Volvemos a mover las imagenes al album
     $imagealb = db_query("UPDATE {$db_prefix}imagenes SET album = '$IDA' 
                           WHERE IDI IN (".$imagenes.") AND ID_MEMBER = '$dueno'",__FILE__, __LINE__);

     //Cantidad de imagenes agregadas
     $cantimg = COUNT(explode(",",$imagenes)); 

     //Actualizamos la cantidad de imagenes al nuevo y viejo album
     $albUp = db_query("UPDATE {$db_prefix}img_album SET cantimg = cantimg + '$cantimg' 
                           WHERE IDA = '$IDA' LIMIT 1",__FILE__, __LINE__);

     $albUp = db_query("UPDATE {$db_prefix}img_album SET cantimg = cantimg - '$cantimg' 
                           WHERE IDA = 0 LIMIT 1",__FILE__, __LINE__);
 
   }

  agregado("Felicidades!","El &aacute;lbum ".$nombre." fu&eacute; editado con &eacute;xito.",$id);   
  }
  else
   fatal_error("Error: la imagen no se edito.",false);

 }
 
 
}

function comentar(){

global $context, $ID_MEMBER, $db_prefix, $no_avatar, $func;

        if(!$context['ajax_request'])
            die();

        // make sure is ajax
        $_REQUEST['ajax'] = 1;

 $Tempcomentario = $func['htmlspecialchars']($_POST['comentario'], ENT_QUOTES, 'UTF-8');
 $ID_IMG = (int) $_POST['imagen'];
 $fecha = time();

 // Usuario no logueado? error
 if(empty($ID_MEMBER))
 die(json_encode(array('status' => 'error', 'message' => 'Solo usuarios registrados pueden comentar.')));

 // Anti Flood
 if($_SESSION['stop_flood:comments'] > time() - 15){
    $timeout = $_SESSION['stop_flood:comments'] - time() + 15;
    die(json_encode(array('status' => 'error', 'type' => 'timeout', 'timeout' => $timeout, 'message' => 'Debes esperar unos segundos antes de comentar de nuevo')));
        }
        $_SESSION['stop_flood:comments'] = time();

  //Comentario Vacio
  if(is_real_empty($Tempcomentario) || $Tempcomentario == 'undefined')
  die(json_encode(array('status' => 'error', 'message' => 'Dejaste el campo vacio.')));

   // existe la imagen
   $request = db_query("SELECT IDI, ID_MEMBER FROM {$db_prefix}imagenes WHERE IDI = '$ID_IMG'",__FILE__,__LINE__);

   list($idimg, $Autor) = mysql_fetch_row($request);

   if(mysql_num_rows($request) == 0)
      die(json_encode(array('status' => 'error', 'message' => 'La imagen no es valida o ha sido eliminado.')));

  
        // usuario inexistente?
        $request = db_query("SELECT memberName, realName, avatar FROM {$db_prefix}members WHERE ID_MEMBER = '$ID_MEMBER' LIMIT 1",__FILE__,__LINE__);
        list($memberName, $realName, $avatar) = mysql_fetch_row($request);

        if(mysql_num_rows($request)==0)
            die(json_encode(array('status' => 'error', 'message' => 'Usuario inexistente.')));

        mysql_free_result($request);


  // Insertamos el Comentario en La base de datos
  db_query("INSERT INTO {$db_prefix}img_comentarios (ID_MEMBER,IDI,comentario,fecha)
        VALUES('$ID_MEMBER','$ID_IMG','$Tempcomentario','$fecha')",__FILE__, __LINE__);


  $last_id = mysql_insert_id();
  $TopicAutor = $Autor==$ID_MEMBER; 


  db_query("UPDATE {$db_prefix}imagenes SET comentarios = comentarios + 1 WHERE IDI = '$ID_IMG' LIMIT 1",__FILE__, __LINE__);

$templateData = array(
            'avatar' => !empty($avatar) ? $avatar : $no_avatar,
            'nick' => $context['user']['name'],
            'comment' => parse_bbc($Tempcomentario),
            'id_member' => $ID_MEMBER,
            'time' => hace($fecha),
            'id_comment' => $last_id,
            'type_comment' => ' ' . ($tempAutorCom == $TopicAutor ? ' author' : ' own')
        );

die(json_encode($templateData));

}

/* Administracion */
function admin(){

 global $context, $txt, $scripturl, $modSettings, $db_prefix, $helptxt, $sourcedir;

 $context['page_title'] = 'Administrar Galeria';
 $context['sub_template'] = 'show_settings';

        //Permitido solo Administradores
	isAllowedTo('admin_forum');

        // Barra de Administracion.
	adminIndex('galeria');

        // ManageServer se necesitara para guardar variables
	require_once($sourcedir . '/ManageServer.php');

        //Descripcion
        $context['admin_tabs'] = array(
		'title' => &$txt['admin_title'],
		'description' => $txt['admin_gal_descripcion'],
		
	);

	
	$config_vars = array(
                        array('int', 'cant_album'),
                        '',
                        array('int', 'pag_recent'),
			array('int', 'cant_img_recent'),
                        '',
			array('check', 'thumbnail'),
                        '',
                        array('check', 'act_publi'),
			array('large_text', 'publi'),
	);
	
	// Guardar?
	if (isset($_GET['save']))
	{

		saveDBSettings($config_vars);
		writeLog();
		
		redirectexit('action=galeria;sa=admin');
	}
	
	$context['post_url'] = $scripturl . '?action=galeria;save;sa=admin';
	$context['settings_title'] = $context['page_title'];
	
	prepareDBSettingContext($config_vars);

}
/*Fin Administracion*/

function esAmigo($id_buddy){

 global $context, $ID_MEMBER, $db_prefix;
 
 if(empty($ID_MEMBER))
  return false;
  
  $esamigo = false;
  
  $amigo = db_query("SELECT * FROM {$db_prefix}buddies
                      WHERE ID_MEMBER = '$ID_MEMBER'
					  AND BUDDY_ID = '$id_buddy'
					  AND approved = 1
                      LIMIT 1",__FILE__, __LINE__);
  while(mysql_fetch_assoc($amigo))
    $esamigo = true;
  
  mysql_free_result($amigo);

  return $esamigo;
  
}

function borrarAlbum(){

 global $context, $ID_MEMBER, $func, $db_prefix, $dueno, $id;

 $context['page_title'] = 'Borrar Album';
 
 $idAlbum = (int) $_GET['id'];
 $causa = $func['htmlspecialchars']($_POST['causa'], ENT_QUOTES, 'UTF-8');
 $borrarImages = $_POST['imagenes'];
 
 if($idAlbum<1)
 fatal_error("El Album es invalido o no Existe",false);

 if(is_real_empty($causa)) 
 fatal_error("Debes ingresar una causa",false); 

 $album = db_query("SELECT * FROM {$db_prefix}img_album 
                     WHERE IDA = '$idAlbum'
                     LIMIT 1",__FILE__, __LINE__);
 $album = mysql_fetch_assoc($album);
 $albumID = $album['IDA'];
 
 if($albumID!=$idAlbum)
 fatal_error("El Album es invalido o no Existe",false);
 
  if(!allowedTo('manage_bans'))
  if($ID_MEMBER!=$album['ID_MEMBER'])
   fatal_error("No puede borrar esta imagen",false);

 $dueno = $album['ID_MEMBER'];
 
 $cantImg = 0;
 
 if($borrarImages){
  $query1 = db_query("DELETE FROM {$db_prefix}imagenes WHERE album = '$idAlbum'",__FILE__, __LINE__);
  $cantImg = mysql_affected_rows();
  }
  else{
  $query1 = db_query("UPDATE {$db_prefix}imagenes SET album = 0 WHERE album = '$idAlbum'",__FILE__, __LINE__);
  }

  $query2 = db_query("DELETE FROM {$db_prefix}img_album WHERE IDA = '$idAlbum'",__FILE__, __LINE__);

if($query1 && $query2){

 if(!$borrarImages)
 $query = db_query("UPDATE {$db_prefix}img_album SET cantimg = cantimg + '$cantImg' WHERE IDA = 0 LIMIT 1",__FILE__, __LINE__);

 $query = db_query("UPDATE {$db_prefix}members SET photos = photos - '$cantImg' WHERE ID_MEMBER = '".$album['ID_MEMBER']."' LIMIT 1",__FILE__, __LINE__);

logAction('Album Borrado', array('topic' => $idAlbum, 'subject' => $album['titulo'], 'member' => $ID_MEMBER, 'causa' => $causa));
 $id = $idAlbum;
 
   if(!$borrarImages)
    agregado("Atencion!","El Album ".$album['nombre']." fu&eacute; eliminado con &eacute;xito.<br/>Las Im&aacute;genes del Album fueron movidas.","",false,true);
   else
    agregado("Atencion!","El Album ".$album['nombre']." y su contenido fu&eacute; eliminado con &eacute;xito.","",false,true);
 }

}

function prueba(){

global $context, $sourcedir, $settings, $boarddir;


 $context['sub_template'] = 'prueba';
 $context['page_title'] = 'Pruebas';



}

?>