<?php
/* Spirate Script - Version 2.4
******   Recent.php     ******/

if (!defined('SPIRATE'))
	die('Hacking attempt...');

	
function RecentPosts(){
	
	global $txt, $scripturl, $db_prefix, $user_info, $context, $ID_MEMBER, $modSettings, $sourcedir, $board;
	global $settings, $limit_posts, $mbname, $boarddir, $tcomments, $tmembers, $tposts;
        global $pagarray, $id, $func;
	
        if(loadLanguage('Recent') == false)
            loadLanguage('Recent', 'spanish');

    //Configuracion desde el admin
    $limit_posts = $modSettings['defaultMaxTopics'];
	
	/* ultimos posts */
    $id = (int) $_GET['id'];
    if($id == '')
		$cat_condition = '';
    else
		$cat_condition = ' AND m.ID_BOARD = ' . $id;

    $limite = 50;

	//Cantidad de Comentarios
	 $tcomments = $modSettings['totalComments']== null ? 0 : $modSettings['totalComments'];
	 $tmembers = $modSettings['totalMembers']== null ? 0 : $modSettings['totalMembers'];
	 $tposts = $modSettings['totalTopics']== null ? 0 : $modSettings['totalTopics'];
	
    //Determinar las paginas

    $request = db_query("SELECT COUNT(*) FROM {$db_prefix}topics WHERE isSticky = 0",__FILE__,__LINE__);
    list($totalPosts) = mysql_fetch_row($request);
    mysql_free_result($request);
    
    
    $context['total_posts'] = $totalPosts;
    $_REQUEST['page'] = (int)$_REQUEST['page'];

    require_once($sourcedir . '/classes/Pagination.php');
    $paginator = new Pagination(array(
        'base_url' => $scripturl . '?page=',
        'total_rows' => $totalPosts,
        'per_page' => $limite,
        'first_link' => '',
        'last_link' => '',
        'query_string_segment' => 'page',
        'full_tag_open' => '<ul class="paginator smallfont clearfix">',
        'full_tag_close' => '</ul>'
    ));

    $context['paginacion'] = $paginator->create_links($getData);
    $context['total_pages'] = $getData['num_pages'];
    
    // Consulta de Sticky, solo si estamos en pagina 1 
    if(!isset($_REQUEST['page']) || empty($_REQUEST['page']) || $paginator->cur_page == 1){
        $request = db_query("
		SELECT m.ID_MEMBER, m.ID_TOPIC, subject, name, t.ID_BOARD, posterName, m.hiddenOption, posterTime
		FROM {$db_prefix}messages as m, {$db_prefix}boards as c, {$db_prefix}topics as t
		WHERE c.ID_BOARD = m.ID_BOARD
		AND t.ID_TOPIC = m.ID_TOPIC
		AND t.isSticky = 1
		{$cat_condition}
		ORDER BY m.ID_TOPIC DESC", __FILE__, __LINE__);    
        while($posts = mysql_fetch_array($request))
			$context['sticky'][] = array(
				'ID_MEMBER' => $posts['ID_MEMBER'],
				'id' => $posts['ID_TOPIC'],
				'title' => $posts['subject'],
				'category' => $posts['name'],
				'id_category' => $posts['ID_BOARD'],
				'user' => $posts['posterName'],
				'date' => $posts['posterTime'],
				'private' => $posts['hiddenOption'],
			);
		
	mysql_free_result($request);
	}        

    
    $request=db_query("SELECT m.ID_MEMBER, m.ID_TOPIC, subject, name, t.ID_BOARD, posterName, m.hiddenOption, posterTime
	FROM {$db_prefix}messages as m, {$db_prefix}boards as c, {$db_prefix}topics as t
	WHERE c.ID_BOARD = m.ID_BOARD
	AND t.ID_TOPIC = m.ID_TOPIC
	AND t.isSticky = 0
	{$cat_condition}
	ORDER BY m.ID_TOPIC DESC
	LIMIT $_REQUEST[page], $limite", __FILE__, __LINE__);
	while($posts = mysql_fetch_array($request)){
		$context['normal_posts'][] = array(
			'ID_MEMBER' => $posts['ID_MEMBER'],
			'id' => $posts['ID_TOPIC'],
			'title' => $posts['subject'],
			'category' => $posts['name'],
			'id_category' => $posts['ID_BOARD'],
			'user' => $posts['posterName'],
			'date' => $posts['posterTime'],
			'private' => $posts['hiddenOption'],
		);
	}
	mysql_free_result($request);
	/* fin ultimos posts */
	
	/* Actualizamos los top post cada 10 minutos*/
        if($modSettings['top_post_act']<(time()-600))
        actualizar_tops();
		
		
	/* tops posts */
	
	$request = db_query("SELECT *
	FROM {$db_prefix}tops
	WHERE codigo IN (1,2,3)
	ORDER BY posicion ASC, codigo ASC
	", __FILE__, __LINE__);
	$context['top_posts_week'] = array();
	$context['top_posts_month'] = array();
	$context['top_posts_all'] = array();
	while ($row = mysql_fetch_assoc($request)){

               $codname = "";
               switch($row['codigo']){ case 1: $codname = "week";break; case 2: $codname = "month";break; case 3: $codname = "all";}


		$context['top_posts_'.$codname][] = array(
			'titulo' => $row['titulo'],
			'puntos' => $row['cantidad'],
			'id' => $row['id_top']

		);
          }
	mysql_free_result($request);	
	
	/*$destacados_vars = array(
		'15min' => array('destacados_15min', 900),
		'1hour' => array('destacados_1hour', 3600),
		'3hours' => array('tdestacados_3hours', 10800),
		'6hours' => array('destacados_6hours', 21600),
	);
	
	$tops_vars = array(
		'yesterday' => array('top_post_from_yesterday', '<', 86400), 
		'semana' => array('top_post_weekly', '>', 604800),
		'mes' => array('top_post_monthly', '>', 2592000)
	);
	
	// crear un log para los tops periodicamente... [ DEVELOPERS ]
	foreach( $tops_vars as $period => $var )
	{
	
		$request = db_query("SELECT SUM(p.amount) as points, m.ID_TOPIC, m.subject
						 FROM ({$db_prefix}puntos as p, {$db_prefix}topics as t)
						 LEFT JOIN {$db_prefix}messages AS m ON (m.ID_TOPIC = p.id_post)
						 WHERE p.id_post = t.ID_TOPIC
						 AND p.time " . sprintf('%s %d', $var[1], (time()-$var[2])) . "
						 {$var[3]}
						 GROUP BY p.id_post
						 ORDER BY points ASC
						 LIMIT 10
						 ", __FILE__, __LINE__);
		$context[$var[0]] = array();
		while ($row = mysql_fetch_assoc($request))
		{
			
			$context[$var[0]][] = array(
				'post' => array(
					'id' => $row['ID_TOPIC'],
					'title' => $row['subject'],
					'puntos' => $row['points'],
					'href' => $scripturl . '?topic=' . $row['ID_TOPIC']
				)
			);
		
		}
		mysql_free_result($request);
	
	}*/
	
	/* Ultimos comentarios */
	
	$disable_own_comments = false;	// CAMBIAR A "true" SI DESEAS NO VISUALIZAR COMENTARIOS DEL PROPIO AUTOR DEL POST
	
	$context['ult_comms'] = array();
	
	if(($context['ult_comms'] = cache_get_data('recent:comments', 900)) == null){
	$rs = db_query("SELECT c.id_post, c.id_coment, m.subject, m.ID_TOPIC, c.id_user, mem.ID_MEMBER, mem.realName
					FROM ({$db_prefix}comentarios AS c, {$db_prefix}messages AS m, {$db_prefix}members AS mem)
					INNER JOIN {$db_prefix}topics as t ON m.ID_TOPIC = t.ID_TOPIC
					WHERE id_post = m.ID_TOPIC AND c.id_user = mem.ID_MEMBER
					" .( $disable_own_comments ? 'AND t.ID_MEMBER_STARTED != c.id_user' : '' ). "
					ORDER BY c.id_coment DESC
					LIMIT 15", __FILE__, __LINE__);
					
	while ($row = mysql_fetch_assoc($rs))
		$context['ult_comms'][] = array(
			'id_comment' => $row['id_coment'],
			'titulo' => $row['subject'],
			'ID_TOPIC' => $row['ID_TOPIC'],
			'memberName' => $row['memberName'],
			'realName' => $row['realName'],
		);
		
	if(!empty($modSettings['cache_enable']))
		cache_put_data('recent:comments', $context['ult_comms'], 900);
	
	mysql_free_result($rs);
	
	}
        
	/* posteadores de la semana */
	$starttime = mktime(0, 0, 0, date("n"), date("j")-7, date("Y"));
	$starttime = forum_time(false, $starttime);
	
	$request = db_query("SELECT me.ID_MEMBER, me.memberName, me.realName, COUNT(*) as count_posts
	FROM {$db_prefix}messages AS m
		LEFT JOIN {$db_prefix}members AS me ON (me.ID_MEMBER = m.ID_MEMBER)
	WHERE m.posterTime > $starttime
	AND m.ID_MEMBER != 0
	GROUP BY me.ID_MEMBER
	ORDER BY count_posts DESC
	LIMIT 10", __FILE__, __LINE__);
	$context['top_posters_week'] = array();
	$max_num_posts = 1;
	while ($row_members = mysql_fetch_assoc($request)){
		$context['top_posters_week'][] = array(
			'name' => $row_members['realName'],
			'id' => $row_members['ID_MEMBER'],
			'num_posts' => $row_members['count_posts'],
			'href' => $scripturl.'?action=profile&user='.$row_members['realName'],
			'link' => '<a href="'.$scripturl.'?action=profile&user='.$row_members['realName'].'">'.$row_members['realName'].'</a>'
		);
		if ($max_num_posts < $row_members['count_posts'])
			$max_num_posts = $row_members['count_posts'];
	}
	mysql_free_result($request);

	foreach ($context['top_posters_week'] as $i => $j)
		$context['top_posters_week'][$i]['post_percent'] = round(($j['num_posts'] * 100) / $max_num_posts);

	unset($max_num_posts, $row_members, $j, $i);
	
	/* usuarios con mas puntos */
	if(($context['shop_richest'] = cache_get_data('recent:top_user_points', 900)) == null){
	
	$result = db_query("SELECT ID_MEMBER, realName, memberName, money
	FROM {$db_prefix}members
	WHERE money > 0
	ORDER BY money DESC, realName
	LIMIT 10", __FILE__, __LINE__);
	
	while ($row = mysql_fetch_assoc($result))
		$context['shop_richest'][] = array(
			'ID_MEMBER' => $row['ID_MEMBER'],
			'memberName' => $row['memberName'],
			'realName' => $row['realName'],
			'money' => $row['money'],
			'link' => '<a href="'.$scripturl.'?action=profile&user='.$row['realName'].'">'.$row['realName'].'</a>'
		);
	
	
	if(!empty($modSettings['cache_enable']))
		cache_put_data('recent:top_user_points', $context['shop_richest'], 900);
		
	mysql_free_result($result);
	
	}
	
	
	/* usuarios con mas posts */
	$members_result = db_query("SELECT ID_MEMBER, realName, memberName, topics
	FROM {$db_prefix}members
	WHERE topics > 0
	ORDER BY topics DESC
	LIMIT 10", __FILE__, __LINE__);
	$context['top_starters'] = array();
	$max_num_topics = 1;
	while ($row_members = mysql_fetch_assoc($members_result)){
		$context['top_starters'][] = array(
			'name' => $row_members['realName'],
			'id' => $row_members['ID_MEMBER'],
			'num_topics' => $row_members['topics'],
			'href' => $scripturl . '?action=profile&user=' . $row_members['realName'],
			'link' => '<a href="' . $scripturl . '?action=profile&user=' . $row_members['realName'] . '">' . $row_members['realName'] . '</a>'
		);
		
		if ($max_num_topics < $row_members['topics'])
			$max_num_topics = $row_members['topics'];
	}
	mysql_free_result($members_result);
	
	/* ultimos usuarios registrados */
	$context['yeniuyeler'] = array();
        
   if( ($context['yeniuyeler'] = cache_get_data('recent:new_users', 900)) == null )
   {
		
		$members_result = db_query("SELECT ID_MEMBER, realName, memberName, avatar, avatar_coords, posts, dateRegistered
		FROM {$db_prefix}members
		ORDER BY ID_MEMBER DESC
		LIMIT 5", __FILE__, __LINE__);
		
		while($row_members = mysql_fetch_assoc($members_result))
			$context['yeniuyeler'][] = array(
				'name' => $row_members['realName'],
				'id' => $row_members['ID_MEMBER'],
				'avatar' => array(
					'src' => $row_members['avatar'],
					'coords' => makeAvatarCoords($row_members['avatar_coords'], 48, true)
				),
				'num_posts' => $row_members['posts'],
				'href' => $scripturl.'?action=profile;u='.$row_members['ID_MEMBER'],
				'link' => '<a href="'.$scripturl.'?action=profile&user='.$row_members['realName'].'">'.$row_members['realName'].'</a>',
				'time-registered' => howlong($row_members['dateRegistered']),
				'time_stamp' => $row_members['dateRegistered']
			);
		
		if(!empty($modSettings['cache_enable']))
			cache_put_data('recent:new_users', $context['yeniuyeler'], 900);
	
	}

        
	$result = db_query("SELECT lo.ID_MEMBER, lo.logTime, mem.realName, mem.memberName, mem.showOnline, mg.onlineColor, mg.ID_GROUP, mg.groupName
	FROM {$db_prefix}log_online AS lo
		LEFT JOIN {$db_prefix}members AS mem ON (mem.ID_MEMBER = lo.ID_MEMBER)
		LEFT JOIN {$db_prefix}membergroups AS mg ON (mg.ID_GROUP = IF(mem.ID_GROUP = 0, mem.ID_POST_GROUP, mem.ID_GROUP))", __FILE__, __LINE__);
	
	$context['users_online'] = array();
	$context['list_users_online'] = array();
	$context['online_groups'] = array();
	$context['num_guests'] = 0;
	$context['num_buddies'] = 0;
	$context['num_users_hidden'] = 0;
	
	$context['show_buddies'] = !empty($user_info['buddies']);
	
	while ($row = mysql_fetch_assoc($result)){
		if (empty($row['realName']))
		{
			$context['num_guests']++;
			continue;
		}
		elseif (empty($row['showOnline']) && !allowedTo('moderate_forum'))
		{
			$context['num_users_hidden']++;
			continue;
		}

			
			$link = '';
	
		$is_buddy = in_array($row['ID_MEMBER'], $user_info['buddies']);
		if ($is_buddy)
		{
			$context['num_buddies']++;
			$link = '' . $link . '';
		}

		$context['users_online'][$row['logTime'] . $row['memberName']] = array(
			'id' => $row['ID_MEMBER'],
			'username' => $row['memberName'],
			'name' => $row['realName'],
			'group' => $row['ID_GROUP'],
			'href' => $scripturl . '?action=profile;u=' . $row['ID_MEMBER'],
			'link' => $link,
			'is_buddy' => $is_buddy,
			'hidden' => empty($row['showOnline']),
		);

		$context['list_users_online'][$row['logTime'] . $row['memberName']] = empty($row['showOnline']) ? '<i>' . $link . '</i>' : $link;

		if (!isset($context['online_groups'][$row['ID_GROUP']]))
			$context['online_groups'][$row['ID_GROUP']] = array(
				'id' => $row['ID_GROUP'],
				'name' => $row['groupName'],
				'color' => $row['onlineColor']
			);
	}
	mysql_free_result($result);

	krsort($context['users_online']);
	krsort($context['list_users_online']);
	ksort($context['online_groups']);
	
	$context['num_users_online_today'] = count($context['users_online_today']);
	if (!$user_info['is_admin'])
	{
		$context['num_users_online_today'] = $context['num_users_online_today'] + $context['num_hidden_users_online_today'];
	}

	$context['only_users_online'] = count($context['users_online']);
        $context['total_online'] = count($context['users_online']) + $context['num_users_hidden'];

	while ($row = mysql_fetch_assoc($request))
	{
		$actions = @unserialize($row['url']);
		if ($actions === false)
			continue;

		$context['members'][$row['session']] = array(
			'id' => $row['ID_MEMBER'],
			'ip' => allowedTo('moderate_forum') ? $row['ip'] : '',
			'time' => strtr(timeformat($row['logTime']), array($txt['smf10'] => '', $txt['smf10b'] => '')),
			'timestamp' => forum_time(true, $row['logTime']),
			'query' => $actions,
			'color' => empty($row['onlineColor']) ? '' : $row['onlineColor']
		);

		$url_data[$row['session']] = array($row['url'], $row['ID_MEMBER']);
		$member_ids[] = $row['ID_MEMBER'];
	}
	mysql_free_result($request);

        if (!empty($modSettings['MemberColorStats']))
                                $MemberColor_ID_MEMBER[$row_members['ID_MEMBER']] = $row_members['ID_MEMBER'];


        if ($max_num_posts < $row_members['posts'])
                                $max_num_posts = $row_members['posts'];

	loadTemplate('Recent');
	$context['page_title'] = $txt[214];
	
	
	

}

function actualizar_tops(){

global $db_prefix;


        /* Borramos antiguo Log*/
        db_query("DELETE FROM {$db_prefix}tops WHERE codigo IN (1,2,3)", __FILE__, __LINE__);

        /* tops posts de la semana */
	$starttime = mktime(0, 0, 0, date("n"), date("j")-7, date("Y"));
	$starttime = forum_time(false, $starttime);
	
	$request = db_query("SELECT m.subject, m.ID_TOPIC, t.ID_TOPIC, t.puntos, t.ID_MEMBER_STARTED as idm,m.posterTime
	FROM {$db_prefix}topics AS t INNER JOIN {$db_prefix}messages AS m ON t.ID_TOPIC = m.ID_TOPIC
	WHERE m.posterTime > $starttime
	ORDER BY t.puntos DESC
	LIMIT 10", __FILE__, __LINE__);
        $c=0;
	while ($row = mysql_fetch_assoc($request)){
        $c++;
               db_query("INSERT INTO {$db_prefix}tops 
                         (titulo,dato,id_top,cantidad,posicion,codigo,fecha)
                         VALUES ('".htmlspecialchars($row['subject'])."','".$row['idm']."','".$row['ID_TOPIC']."','".$row['puntos']."','$c',1,'".$row['posterTime']."')", __FILE__, __LINE__);

		}
	mysql_free_result($request);

        /* tops posts del mes */
	$starttime2 = time() - (3600*24*30);


	$request = db_query("SELECT m.subject, m.ID_TOPIC, t.ID_TOPIC, t.puntos, t.ID_MEMBER_STARTED as idm,m.posterTime
	FROM {$db_prefix}topics AS t INNER JOIN {$db_prefix}messages AS m ON t.ID_TOPIC = m.ID_TOPIC
	WHERE m.posterTime > $starttime2
	ORDER BY t.puntos DESC
	LIMIT 10", __FILE__, __LINE__);
        $c=0;
	while ($row = mysql_fetch_assoc($request)){
        $c++;
               db_query("INSERT INTO {$db_prefix}tops 
                         (titulo,dato,id_top,cantidad,posicion,codigo,fecha)
                         VALUES ('".$row['subject']."','".$row['idm']."','".$row['ID_TOPIC']."','".$row['puntos']."','$c',2,'".$row['posterTime']."')", __FILE__, __LINE__);

		}
	mysql_free_result($request);


        /* top post de siempre*/

	$request = db_query("SELECT m.subject, m.ID_TOPIC, t.ID_TOPIC, t.puntos, t.ID_MEMBER_STARTED as idm,m.posterTime
	FROM {$db_prefix}topics AS t INNER JOIN {$db_prefix}messages AS m ON t.ID_TOPIC = m.ID_TOPIC
	ORDER BY t.puntos DESC
	LIMIT 10", __FILE__, __LINE__);
        $c=0;
	while ($row = mysql_fetch_assoc($request)){
        $c++;
               db_query("INSERT INTO {$db_prefix}tops 
                         (titulo,dato,id_top,cantidad,posicion,codigo,fecha)
                         VALUES ('".$row['subject']."','".$row['idm']."','".$row['ID_TOPIC']."','".$row['puntos']."','$c',3,'".$row['posterTime']."')", __FILE__, __LINE__);

		}
	mysql_free_result($request);

     db_query("UPDATE {$db_prefix}settings SET value = '".time()."' WHERE variable = 'top_post_act'", __FILE__, __LINE__);


}

?>