<?php
/* Spirate Script - Version 2.4
******   Bloques-Borrar.php     ******/

require("../Settings.php");

$conexion = mysql_connect($db_server, $db_user, $db_passwd) OR die("Error al procesar lo solicitado");
require("../SSI.php");
mysql_select_db($db_name, $conexion) OR die("Error al procesar lo solicitado");


/*Seguridad SOLO ADMINS ENTRAN ACA*/
$autor = $context['user']['id'];
$isadmin = mysql_query("SELECT ID_GROUP
                        FROM smf_members
                        WHERE ID_MEMBER = '$autor' LIMIT 1");
	while ($row = mysql_fetch_assoc($isadmin))
              if($row['ID_GROUP']!=1){die('No tienes permisos para ingresar aqui');}                                
	mysql_free_result($isadmin);
/**********************************/


$id = $_POST['id'];
$columna = $_POST['columna'];
$borrarque = $_POST['borrarque'];

if($borrarque==1){
if($id!='')
if($columna!=''){

$borrarcolumna = mysql_query("DELETE FROM {$db_prefix}bloques WHERE ID = '$id' LIMIT 1");
$borrarfilas = mysql_query("DELETE FROM {$db_prefix}bloquesf WHERE id_columna = '$id' ");

$requestbloques = mysql_query("SELECT *
                        FROM smf_bloques
                        ORDER BY ID ASC");

	$context['bloques'] = array();
	while ($row = mysql_fetch_assoc($requestbloques))
		$context['bloques'][] = array(
			'ID' => $row['ID'],
			'columna' => $row['columna'],
			);
	mysql_free_result($requestbloques);

foreach($context['bloques'] as $bloques){

if($columna<$bloques['columna'])
{

$result1 = mysql_query("
			UPDATE {$db_prefix}bloques
			SET  columna = columna - 1
                        WHERE ID = '".$bloques['ID']."' 
		LIMIT 1");

$columna = $bloques['columna'];

}

}

echo'<center><font color="green"><b>Columna Eliminada</b></font></center>';

}
else
{echo'<center><font color="red">Que queres hacer cabezon</font></center>';}

}//fin borrarque = 1
elseif($borrarque==2){

$fila = $_POST['fila'];
$bloque = $_POST['bloque'];
$id_columna = $_POST['id_columna'];

$borrarfilas = mysql_query("DELETE FROM {$db_prefix}bloquesf WHERE ID_BLOQUE = '$bloque' AND filabloque = '$fila' LIMIT 1");

$requestbloques = mysql_query("SELECT *
                        FROM smf_bloquesf
                        WHERE id_columna = '$id_columna'
                        ORDER BY filabloque ASC");

	$context['bloques'] = array();
	while ($row = mysql_fetch_assoc($requestbloques))
		$context['bloques'][] = array(
			'ID_BLOQUE' => $row['ID_BLOQUE'],
			'fila' => $row['filabloque'],
			);
	mysql_free_result($requestbloques);

foreach($context['bloques'] as $filas){

if($fila<$filas['fila'])
{

$result1 = mysql_query("
			UPDATE {$db_prefix}bloquesf
			SET  filabloque = filabloque - 1
                        WHERE ID_BLOQUE = '".$filas['ID_BLOQUE']."' 
		LIMIT 1");

$fila = $filas['fila'];

}

}

if($borrarfilas)
{echo'<center><font color="green"><b>Fila Eliminada</b></font></center>';}
else
{echo'<center><font color="red"><b>Un error ha ocurrido</b></font></center>';}

}
?>