<?php
/* Spirate Script - Version 2.4
******   Bloques-Act.php     ******/

require('../Settings.php');

global $db_prefix;



$conexion = mysql_connect($db_server, $db_user, $db_passwd) OR die("No se puedo conectar a la BDD ".mysql_error()."...!!!");

require("../SSI.php");
mysql_query("SET NAMES 'utf8'");
mysql_select_db($db_name, $conexion) OR die("No se pudo seleccionar la BDD ".mysql_error()."...!!!");

$request = mysql_query("SELECT COUNT(ID) AS cantidad FROM {$db_prefix}bloques");
$rrr = mysql_fetch_assoc($request);

$requestbloques = mysql_query("SELECT *
                        FROM smf_bloques
                        ORDER BY columna ASC");

	$context['bloques'] = array();
	while ($row = mysql_fetch_assoc($requestbloques))
		$context['bloques'][] = array(
			'ID' => $row['ID'],
			'columna' => $row['columna'],
			'ancho' => $row['ancho'],
			'tituloimg' => $row['tituloimg'],
			'contcolor' => $row['contcolor'],
			'bordera' => $row['bordera'],
			'bordert' => $row['bordert'],
			'borderc' => $row['borderc'],
			'custom' => $row['custom'],
			);
	mysql_free_result($requestbloques);

$columnas=0;
$anchomax=980;

echo'<div id="solobloques" style="margin-top:5px;margin-bottom:10px;min-height:300px;">';

foreach($context['bloques'] as $bloques){

$bordes = '';
$tituloimg = '';
$contenido = '';
$columnas=$columnas+1;
$anchomax = $anchomax - ($bloques['ancho'] + 4);

if($bloques['custom']==1)
{
$tituloimg = 'background: url('.$bloques['tituloimg'].') repeat-x';
$contenido = 'background:'.$bloques['contcolor'];
$bordes = 'border: '.$bloques['bordera'].'px '.$bloques['bordert'].' '.$bloques['borderc'];
}

echo'<div id="',$columnas,'" style="float:left; padding-left:',(4*735)/960,'px;width: ',($bloques['ancho']*717)/(960-(4*$columnas)),'px;">

<div class="box_title" style="',$tituloimg,'">Columna ',$bloques['columna'],'
<div class="box_rss"></div></div>
<div class="box_cuerpo" style="',$contenido,'; ',$bordes,'"><center>';

if($columnas>1)
{echo'<span onclick="javascript:mover(',$columnas - 1,',',$bloques['ID'],', ',$columnas,')" style="align:left;margin:2px;cursor:pointer;">
<img title="Mover a la columna ',$columnas - 1,'" src="', $settings['default_images_url'], '/atras.png"></span>';}

if($columnas!=$rrr['cantidad']){
echo'<span onclick="javascript:mover(',$columnas + 1,', ',$bloques['ID'],', ',$columnas,')" style="align:right;margin:2px;cursor:pointer;">
<img title="Mover a la columna ',$columnas + 1,'" src="', $settings['default_images_url'], '/adelante.png"></span>';}

echo'</center><br><center><span class="botondown" onclick="javascript:filas(',$bloques['ID'],',',$columnas,')">Filas</span><br><br>
<span class="botondown" onclick="javascript:editar(',$bloques['ID'],')">Editar</span>
<br><br>
<span class="botondown" onclick="javascript:borrar(',$bloques['ID'],',',$columnas,')">Borrar</span><br></center><br>
<span style="color:#ABD113;"><b>ID: ',$bloques['ID'],'</b></span> | 
<span style="color:blue;"><b>Ancho: ',$bloques['ancho'],'px</b></span>
</div>
</div>';

}

echo'</div><span style="color:red;float:right;text-align:right;"><table><tr><td>Ancho Disponible en el Inicio:</td> <td><b>';if($anchomax<=0){echo'<span style="text-decoration:blink;">',$anchomax,'px</span>';}else{echo'',$anchomax-6,'px';} echo'</b></td></tr><tr><td>Numero de Columnas:</td> <td><b>',$columnas,'</b></td></tr></table></span>';

?>