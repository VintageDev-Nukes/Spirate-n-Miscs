<?php
/* Spirate Script - Version 2.4
******   Shop-Send.php     ******/

if (!defined('SPIRATE'))
die('Hacking attempt...');

global $db_prefix, $txt;

if ($_GET['do'] == 'sendmoney')
{
	$context['linktree'][] = array(
		'url' => $scripturl . '?action=shop;do=sendmoney',
		'name' => $txt['shop_send_money'],
	);
	// Are they allowed to send money to someone?
	isAllowedTo('shop_sendmoney');
	// If $_GET['member'] is set, pass it to the page. Otherwise, set it to blank.
	$context['shopSendMoneyMember'] = isset($_GET['member']) ?  $_GET['member'] : '';
	// The shop action
	$context['shop_do'] = 'sendmoney';
	// Use the sendmoney template
	$context['sub_template'] = 'sendmoney';
}
// If they've submitted the form - Actually send the money

if($_GET['do'] == 'sendmoney2')
    call_user_func('sendMoney');


function sendMoney(){
    global $context, $txt, $scripturl, $db_prefix, $ID_MEMBER;
    
	$context['linktree'][] = array(
		'url' => $scripturl . '?action=shop;do=sendmoney',
		'name' => $txt['shop_send_money'],
	);
	// Are they allowed to send money to someone?
	isAllowedTo('shop_sendmoney');
	// Make sure amount is numeric
	$amount = (int) $_GET['amount'];
        if ($amount < 0)
		$context['shop_buy_message'] = $txt['shop_give_negative'];
	elseif ($amount == 0)
		$context['shop_buy_message'] = $txt['shop_invalid_send_amount'];
	else {
	
$topic = $_GET['topic'];
		if ($topic)
		{
		
		$result = db_query("
			SELECT *
			FROM smf_topics
			WHERE ID_TOPIC = '$topic'
			LIMIT 1", __FILE__, __LINE__);
		$row = mysql_fetch_array($result, MYSQL_ASSOC);
	mysql_free_result($result);
			$creador=$row['ID_MEMBER_STARTED'];
			
$request = mysql_query("
                        SELECT *
                        FROM smf_members AS m
                        WHERE ".$context['user']['id']." = m.ID_MEMBER");
while ($grup = mysql_fetch_assoc($request)){
 if($grup['ID_GROUP']!=0)	
 $migrupo = $grup['ID_GROUP'];
 else
 $migrupo = $grup['ID_POST_GROUP'];
}	
mysql_free_result($request);


$errorr = db_query("
                    SELECT *
                    FROM {$db_prefix}puntos
                    WHERE
                    id_member = $ID_MEMBER AND
                    id_post = $topic
                    LIMIT 1", __FILE__, __LINE__);
$yadio = mysql_num_rows($errorr) != 0 ? true : false;
mysql_free_result($errorr);

$nodebosuperar = 0;
$maxpuntos= 0;
$maxpuntos_puedo = 0;

        $rangos = db_query("SELECT puntos
                        FROM {$db_prefix}membergroups
                        ORDER BY puntos DESC
                        LIMIT 1", __FILE__, __LINE__);
	while ($row3 = mysql_fetch_assoc($rangos))
		$maxpuntos = $row3['puntos'];
	mysql_free_result($rangos);

$rangos = db_query("SELECT *
                        FROM {$db_prefix}membergroups
                        WHERE ID_GROUP = $migrupo", __FILE__, __LINE__);
	while ($row2 = mysql_fetch_assoc($rangos))
		$maxpuntos_puedo = $row2['puntos'];
	mysql_free_result($rangos);

$nodebosuperar = $maxpuntos - $maxpuntos_puedo;

     	if ($yadio){
            $text = 'Ya has dado puntos a este post.';
            if(!isset($_REQUEST['ajax']))
                fatal_error($text, false);
            else
                return array('error' => $text);
        }

      	if($amount > $maxpuntos_puedo){
            $text = 'No puedes dar m&aacute;s de '.$maxpuntos.' puntos.';
            
            if(!isset($_REQUEST['ajax']))
                fatal_error($text, false);
            else
                return array('error' => $text);
        }

    	if($creador == $context['user']['id']){
            $text = 'No puedes dar puntos a tus posts.';
            
            if(!isset($_REQUEST['ajax']))
                fatal_error($text, false);
            else
                return array('error' => $text);
            }

	//Cuantos puntos me quedan
        $request1 = db_query("SELECT points
                                 FROM {$db_prefix}points_per_day
                                 WHERE ID_MEMBER = {$ID_MEMBER}", __FILE__, __LINE__);
        $row1 = mysql_fetch_assoc($request1);
        mysql_free_result($request1);

        $mequeda = $row1['points'] - $amount;

            if ( $amount > $row1['points'] || $row1['points'] <= $nodebosuperar || $mequeda < $nodebosuperar){
                $text = 'No tienes puntos suficientes. Debes esperar hasta ma&ntilde;ana.';
                if(!isset($_REQUEST['ajax']))
                    fatal_error($text, false);
                else
                    return array('error' => $text);
            }

		//Quita los puntos del dia
			 db_query("UPDATE {$db_prefix}points_per_day
				 SET points = points - {$amount}
				 WHERE ID_MEMBER = {$ID_MEMBER}
				 LIMIT 1", __FILE__, __LINE__);

				 
	//Filtramos Por Puntos/Por posts by Mr.Freack
	
	if($modSettings['por_posts']){$rankeding = "";}
	elseif($modSettings['por_puntos']){$rankeding = ", moneyrankpp = moneyrankpp + {$amount}";}
        else{$rankeding = "";}

			// Dar los puntos al usuario
			db_query("
				UPDATE {$db_prefix}members
				SET money = money + {$amount} {$rankeding}
				WHERE ID_MEMBER = {$row['ID_MEMBER_STARTED']}
				LIMIT 1", __FILE__, __LINE__);
				
                        //Dar los puntos al post
                        db_query("
				UPDATE {$db_prefix}topics
				SET puntos = puntos + {$amount}
				WHERE ID_TOPIC = '$topic'
				LIMIT 1", __FILE__, __LINE__);
						
	       db_query("INSERT INTO {$db_prefix}puntos (id_post,id_member,amount, time)
                         values($topic, $ID_MEMBER, '$amount', " . time() . ")", __FILE__, __LINE__);
	


	 $request = db_query("
                            SELECT ID_TOPIC, subject
                            FROM smf_messages
                            WHERE ID_TOPIC = $topic
                            ORDER BY subject ASC
                            LIMIT 1", __FILE__, __LINE__);

	while ($row = mysql_fetch_assoc($request)){
            
        $text = '<center><font color="green">'.$amount.' puntos agregados correctamente.</font></center>';

        if(!isset($_REQUEST['ajax']))
            fatal_error($text, false);
        else
            return true;
        
        }
	mysql_free_result($request);
						}
	
	}

        if(!isset($_REQUEST['ajax'])){
            $context['shop_do'] = 'sendmoney';
            $context['page_title'] = $txt['shop'] . '' . $txt['shop_send_money'];
            $context['sub_template'] = 'message';
        }

}
?>
