<?php
/* Spirate Script - Version 2.4
******   Shopversion.php     ******/

$shopVersion['develVersion'] = false; // Is this version a testing/development version?
$shopVersion['version'] = "3.1.5";
$shopVersion['build'] = "1";
$shopVersion['date'] = "November 23, 2009";
$shopVersion['SVNdate'] = '$Date: $'; 
$shopVersion['SVNid'] = '$Id: $';
// SMFShop 3.0 (Build 12) -- Public release
?>