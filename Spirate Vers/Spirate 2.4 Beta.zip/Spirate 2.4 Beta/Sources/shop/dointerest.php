<?php
/* Spirate Script - Version 2.4
******   dointerest.php   ******/

if(!isset($_SERVER["HTTP_HOST"])) {

	include("../../SSI.php");
	
	$interest_rate = $modSettings['shopInterest'] / 100;
	db_query("UPDATE {$db_prefix}members
			  SET moneyBank = moneyBank + (moneyBank*{$interest_rate})", __FILE__, __LINE__);
	
	echo "Interest added at ".date("d/m/Y h:i:s A");
}
?>
