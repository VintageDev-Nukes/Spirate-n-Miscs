<?php 
/** 
 * 
 * @package:    shoutcast 
 * @version:    $Id: shoutcast.php 4 2011-12-02 17:27:36Z MADxHAWK $ 
 * @copyright:    (c) 2010 by Martin H. (madxhawk@radio-blackpearl.de) 
 * @licence:    [url]http://opensource.org/licenses/gpl-license.php[/url] GNU Public License
 INFO STAT DE RADIO SERVER - Spirate 
 * 
 */
// ---------------------------------------------------------------------------- 
// Aqui los datos para la conexion
// ---------------------------------------------------------------------------- 
$useragent    = "Mozilla (DNAS 2 Statuscheck)"; 
$sc_host    = '184.107.221.58'; 
$sc_port    = '9980'; 
$sc_user    = 'admin'; 
$sc_pass    = 'yahoo7010'; 
$sc_sid        = '1'; 


// ---------------------------------------------------------------------------- 
// NO EDITAR
// ---------------------------------------------------------------------------- 

//inicia curl conexion
$ch = curl_init($sc_host . '/admin.cgi?mode=viewxml&sid=$sc_sid'); 

// set curl connection parameter 
curl_setopt($ch, CURLOPT_PORT, $sc_port); 
curl_setopt($ch, CURLOPT_USERAGENT, $useragent); 
curl_setopt($ch, CURLOPT_TIMEOUT, 5); 
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true); 
curl_setopt($ch, CURLOPT_HTTPAUTH, CURLAUTH_BASIC); 
curl_setopt($ch, CURLOPT_USERPWD, $sc_user . ':' . $sc_pass); 

// conectamos el shoutcast server
$curl = curl_exec($ch); 

// Ahora obtenemos la informacion xml
if ($curl) 
{ 
    $xml = @simplexml_load_string($curl); 

    $dnas_data = array ( 
        'CURRENTLISTENERS'    => (string)$xml->CURRENTLISTENERS, 
        'PEAKLISTENERS'        => (string)$xml->PEAKLISTENERS, 
        'MAXLISTENERS'        => (string)$xml->MAXLISTENERS, 
        'REPORTEDLISTENERS'    => (string)$xml->REPORTEDLISTENERS, 
        'AVERAGETIME'        => (string)$xml->AVERAGETIME, 
        'SERVERGENRE'        => (string)$xml->SERVERGENRE, 
        'SERVERURL'            => (string)$xml->SERVERURL, 
        'SERVERTITLE'        => (string)$xml->SERVERTITLE, 
        'SONGTITLE'            => (string)$xml->SONGTITLE, 
        'NEXTTITLE'            => (string)$xml->NEXTTITLE, 
        'SONGURL'            => (string)$xml->SONGURL, 
        'IRC'                => (string)$xml->IRC, 
        'ICQ'                => (string)$xml->ICQ, 
        'AIM'                => (string)$xml->AIM, 
        'STREAMHITS'        => (string)$xml->STREAMHITS, 
        'STREAMSTATUS'        => (string)$xml->STREAMSTATUS, 
        'BITRATE'            => (string)$xml->BITRATE, 
        'CONTENT'            => (string)$xml->CONTENT, 
        'VERSION'            => (string)$xml->VERSION, 
    ); 

    // Get Listeners and Songhistory 
    if ($dnas_data['STREAMSTATUS'] == 1) 
    { 
        // store listener in array 
        foreach ($xml->LISTENERS->LISTENER as $listener) 
        { 
            $sc_data['LISTENERS'][] = array( 
                'HOSTNAME' => (string) $listener->HOSTNAME, 
                'USERAGENT' => (string) $listener->USERAGENT, 
                'CONNECTTIME' => (string) $listener->CONNECTTIME, 
                'POINTER' => (string) $listener->POINTER, 
                'UID' => (string) $listener->UID, 
            ); 
        } 

       
        
    } 
} 
else 
{ 
    $dnas_data = array('ERROR' => 'No se puede conectar al server!'); 
} 

print_r($xml);
?>

<html>

<br /><b><h1>

Oyentes escuchando: Spirate | Community Radio: <?php echo $dnas_data['CURRENTLISTENERS']; ?><br /></b></h1>




</body>

</html>