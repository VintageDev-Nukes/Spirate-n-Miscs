<?php

/* Spirate Script - Version 2.4
******   MoveBloques.php     ******/

if (!defined('SPIRATE'))
	die('Hacking attempt...');

function TMain()
{

global $txt, $context, $scripturl, $db_prefix, $settings, $modSettings, $user_info, $activado;


	isAllowedTo('admin_forum');

        //marco Gestionar bloques
	adminIndex('gbloques');

        loadlanguage('MoveBloques');
	loadtemplate('MoveBloques');
	$subActions = array(
		'editar' => 'editar',
	);

	if (!empty($subActions[@$_GET['sa']]))
		$subActions[$_GET['sa']]();
	else
		main();

$context['admin_tabs'] = array(
		'title' => &$txt['bloque'],
		'description' => $txt['bloque_descripcion'],
		'tabs' => array(

		),
	);

global $requestbloques;

$requestbloques = db_query("SELECT *
                        FROM {$db_prefix}bloques
                        ORDER BY columna ASC", __FILE__, __LINE__);

	$context['bloques'] = array();
	while ($row = mysql_fetch_assoc($requestbloques))
		$context['bloques'][] = array(
			'ID' => $row['ID'],
			'columna' => $row['columna'],
			'ancho' => $row['ancho'],
			'tituloimg' => $row['tituloimg'],
			'contcolor' => $row['contcolor'],
			'bordera' => $row['bordera'],
			'bordert' => $row['bordert'],
			'borderc' => $row['borderc'],
			'custom' => $row['custom'],
			);
	mysql_free_result($requestbloques);

$requestbloques = db_query("SELECT *
                        FROM {$db_prefix}settings
                        WHERE variable = 'gestorbloques'", __FILE__, __LINE__);
	while ($row = mysql_fetch_assoc($requestbloques))
		$activado = $row['value'];
	mysql_free_result($requestbloques);
	

}

function main(){

global $txt, $context, $scripturl, $db_prefix, $settings, $modSettings, $user_info, $pag;

	$context['sub_template']  = 'main';
	$context['page_title'] = ' Gestor de Bloques';
	$context['linktree'][] = array(
		'url' => $scripturl,
		'name' => 'bloques',
		);
	$context['linktree'][] = array(
		'url' => '#',
		'name' => 'move',
		);

	$id_member = $context['user']['id'];
	$id =$_GET['id'];
}

function editar(){

global $txt, $context, $scripturl, $db_prefix, $settings, $modSettings, $user_info;

	$context['page_title'] = ' Editando';
	$context['sub_template']  = 'editar';
	$id_member = $context['user']['id'];
	$id=$_GET['id'];


}




?>