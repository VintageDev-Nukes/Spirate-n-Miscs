-- phpMyAdmin SQL Dump
-- version 3.5.2.2
-- http://www.phpmyadmin.net
--
-- Servidor: 127.0.0.1
-- Tiempo de generación: 01-04-2013 a las 18:04:10
-- Versión del servidor: 5.5.27
-- Versión de PHP: 5.4.7

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Base de datos: `sp24fixear`
--

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `smf_activity`
--

CREATE TABLE IF NOT EXISTS `smf_activity` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `type` varchar(40) NOT NULL,
  `subject` int(11) NOT NULL,
  `object` int(11) NOT NULL,
  `subj_type` varchar(40) NOT NULL,
  `obj_type` varchar(40) NOT NULL,
  `time` int(11) NOT NULL,
  `date` date NOT NULL,
  `privacy` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `smf_activity_attachments`
--

CREATE TABLE IF NOT EXISTS `smf_activity_attachments` (
  `ID_ATTACH` int(11) NOT NULL AUTO_INCREMENT,
  `attachmentType` varchar(40) NOT NULL,
  `url` text NOT NULL,
  `width` mediumint(8) NOT NULL,
  `height` mediumint(8) NOT NULL,
  `time_add` int(11) NOT NULL,
  `params` mediumtext CHARACTER SET utf8 COLLATE utf8_spanish_ci NOT NULL,
  PRIMARY KEY (`ID_ATTACH`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `smf_activity_comments`
--

CREATE TABLE IF NOT EXISTS `smf_activity_comments` (
  `ID_COMMENT` int(11) NOT NULL AUTO_INCREMENT,
  `ID_MEMBER` mediumint(8) NOT NULL,
  `ID_STORY` int(11) NOT NULL,
  `time` int(11) NOT NULL,
  `is_spam` int(11) NOT NULL DEFAULT '0',
  `comment` mediumtext NOT NULL,
  PRIMARY KEY (`ID_COMMENT`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `smf_activity_likes`
--

CREATE TABLE IF NOT EXISTS `smf_activity_likes` (
  `ID_LIKE` int(11) NOT NULL AUTO_INCREMENT,
  `ID_MEMBER` mediumint(8) NOT NULL,
  `ID_STORY` int(11) NOT NULL,
  `time` int(11) NOT NULL,
  PRIMARY KEY (`ID_LIKE`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `smf_activity_re_streams`
--

CREATE TABLE IF NOT EXISTS `smf_activity_re_streams` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `ID_STORY` int(11) NOT NULL,
  `ID_MEMBER` mediumint(8) NOT NULL,
  `likes` int(11) NOT NULL,
  `comments` int(11) NOT NULL,
  `time` int(11) NOT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `smf_activity_stream`
--

CREATE TABLE IF NOT EXISTS `smf_activity_stream` (
  `stream_id` int(11) NOT NULL AUTO_INCREMENT,
  `activity_id` int(11) unsigned NOT NULL,
  `ID_ATTACH` int(11) NOT NULL DEFAULT '0',
  `msg` text CHARACTER SET utf8 COLLATE utf8_spanish_ci NOT NULL,
  `thumbnail` text NOT NULL,
  `coords_thumbnail` text NOT NULL,
  `likes` int(11) NOT NULL DEFAULT '0',
  `comments` int(11) NOT NULL DEFAULT '0',
  `re_streams` int(11) NOT NULL DEFAULT '0',
  `re_streams_ids` varchar(955) NOT NULL,
  PRIMARY KEY (`stream_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `smf_amigables`
--

CREATE TABLE IF NOT EXISTS `smf_amigables` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `noamigable` varchar(255) COLLATE utf8_spanish_ci NOT NULL,
  `amigable` varchar(255) COLLATE utf8_spanish_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `smf_attachments`
--

CREATE TABLE IF NOT EXISTS `smf_attachments` (
  `ID_ATTACH` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `ID_THUMB` int(10) unsigned NOT NULL DEFAULT '0',
  `ID_MSG` int(10) unsigned NOT NULL DEFAULT '0',
  `ID_MEMBER` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `attachmentType` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `filename` tinytext NOT NULL,
  `size` int(10) unsigned NOT NULL DEFAULT '0',
  `downloads` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `width` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `height` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `file_hash` varchar(40) NOT NULL DEFAULT '',
  PRIMARY KEY (`ID_ATTACH`),
  UNIQUE KEY `ID_MEMBER` (`ID_MEMBER`,`ID_ATTACH`),
  KEY `ID_MSG` (`ID_MSG`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `smf_ban_groups`
--

CREATE TABLE IF NOT EXISTS `smf_ban_groups` (
  `ID_BAN_GROUP` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(20) NOT NULL DEFAULT '',
  `ban_time` int(10) unsigned NOT NULL DEFAULT '0',
  `expire_time` int(10) unsigned DEFAULT NULL,
  `cannot_access` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `cannot_register` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `cannot_post` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `cannot_login` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `reason` tinytext NOT NULL,
  `notes` mediumtext NOT NULL,
  PRIMARY KEY (`ID_BAN_GROUP`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `smf_ban_items`
--

CREATE TABLE IF NOT EXISTS `smf_ban_items` (
  `ID_BAN` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `ID_BAN_GROUP` smallint(5) unsigned NOT NULL DEFAULT '0',
  `ip_low1` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `ip_high1` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `ip_low2` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `ip_high2` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `ip_low3` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `ip_high3` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `ip_low4` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `ip_high4` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `hostname` tinytext NOT NULL,
  `email_address` tinytext NOT NULL,
  `ID_MEMBER` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `hits` mediumint(8) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`ID_BAN`),
  KEY `ID_BAN_GROUP` (`ID_BAN_GROUP`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `smf_bloques`
--

CREATE TABLE IF NOT EXISTS `smf_bloques` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `columna` int(11) NOT NULL,
  `ancho` int(11) NOT NULL,
  `tituloimg` text NOT NULL,
  `contcolor` text NOT NULL,
  `bordera` int(11) NOT NULL,
  `bordert` text NOT NULL,
  `borderc` text NOT NULL,
  `custom` int(11) NOT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `smf_bloquesf`
--

CREATE TABLE IF NOT EXISTS `smf_bloquesf` (
  `ID_BLOQUE` int(11) NOT NULL AUTO_INCREMENT,
  `id_columna` int(11) NOT NULL,
  `tibloque` text CHARACTER SET utf8 COLLATE utf8_spanish_ci NOT NULL,
  `cobloque` mediumtext,
  `conttipe` text NOT NULL,
  `filabloque` int(11) NOT NULL,
  `onbloque` int(11) NOT NULL,
  `rssbloque` text NOT NULL,
  `bdbloque` text NOT NULL,
  PRIMARY KEY (`ID_BLOQUE`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `smf_boards`
--

CREATE TABLE IF NOT EXISTS `smf_boards` (
  `ID_BOARD` smallint(5) unsigned NOT NULL AUTO_INCREMENT,
  `ID_CAT` tinyint(4) unsigned NOT NULL DEFAULT '0',
  `childLevel` tinyint(4) unsigned NOT NULL DEFAULT '0',
  `ID_PARENT` smallint(5) unsigned NOT NULL DEFAULT '0',
  `boardOrder` smallint(5) NOT NULL DEFAULT '0',
  `ID_LAST_MSG` int(10) unsigned NOT NULL DEFAULT '0',
  `ID_MSG_UPDATED` int(10) unsigned NOT NULL DEFAULT '0',
  `memberGroups` varchar(255) NOT NULL DEFAULT '-1,0',
  `name` tinytext NOT NULL,
  `description` mediumtext NOT NULL,
  `numTopics` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `numPosts` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `countPosts` tinyint(4) NOT NULL DEFAULT '0',
  `ID_THEME` tinyint(4) unsigned NOT NULL DEFAULT '0',
  `permission_mode` tinyint(4) unsigned NOT NULL DEFAULT '0',
  `override_theme` tinyint(4) unsigned NOT NULL DEFAULT '0',
  `countMoney` tinyint(1) unsigned NOT NULL DEFAULT '1',
  `thank_you_post_enable` tinyint(4) unsigned NOT NULL DEFAULT '1',
  PRIMARY KEY (`ID_BOARD`),
  UNIQUE KEY `categories` (`ID_CAT`,`ID_BOARD`),
  KEY `ID_PARENT` (`ID_PARENT`),
  KEY `ID_MSG_UPDATED` (`ID_MSG_UPDATED`),
  KEY `memberGroups` (`memberGroups`(48))
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=110 ;

--
-- Volcado de datos para la tabla `smf_boards`
--

INSERT INTO `smf_boards` (`ID_BOARD`, `ID_CAT`, `childLevel`, `ID_PARENT`, `boardOrder`, `ID_LAST_MSG`, `ID_MSG_UPDATED`, `memberGroups`, `name`, `description`, `numTopics`, `numPosts`, `countPosts`, `ID_THEME`, `permission_mode`, `override_theme`, `countMoney`, `thank_you_post_enable`) VALUES
(1, 1, 0, 0, 1, 0, 0, '-1,0,2,4,5,6,7', 'Animaciones', '', 0, 0, 0, 0, 0, 0, 1, 0),
(2, 1, 0, 0, 2, 0, 0, '-1,0,2,4,5,6,7,7', 'Anime / Manga / Otros', '', 0, 0, 0, 0, 0, 0, 1, 0),
(3, 1, 0, 0, 3, 0, 0, '-1,0,2,4,5,6,7,9,7', 'Cine y TV', '', 0, 0, 0, 0, 0, 0, 1, 0),
(4, 1, 0, 0, 4, 0, 0, '-1,0,2,4,5,6,7,9,10,7', 'Comic''s', '', 0, 0, 0, 0, 0, 0, 1, 0),
(5, 1, 0, 0, 5, 0, 0, '-1,0,2,4,5,6,7,9,10,11,7', 'Comunidad SP', '', 0, 0, 0, 0, 0, 0, 1, 0),
(6, 1, 0, 0, 6, 0, 0, '-1,0,2,4,5,6,7,9,10,11,12,7', 'Descargas', '', 0, 0, 0, 0, 0, 0, 1, 0),
(7, 1, 0, 0, 7, 0, 0, '-1,0,2,13,4,5,6,7,9,10,11,12,7', 'Enlaces', '', 0, 0, 0, 0, 0, 0, 1, 0),
(8, 1, 0, 0, 8, 0, 0, '-1,0,2,13,4,5,6,7,9,10,11,12,7', 'Emule / Torrents', '', 0, 0, 0, 0, 0, 0, 1, 0),
(9, 1, 0, 0, 9, 0, 0, '-1,0,2,13,4,5,6,7,8,9,10,11,12,7,8,8', 'Humor', '', 0, 0, 0, 0, 0, 0, 1, 0),
(10, 1, 0, 0, 10, 0, 0, '-1,0,2,13,4,5,6,7,8,9,10,11,12,7,8,8', 'Imágenes', '', 0, 0, 0, 0, 0, 0, 1, 0),
(11, 1, 0, 0, 11, 0, 0, '-1,0,2,13,4,5,6,7,8,9,10,11,12,7,8,8', 'Juegos', '', 0, 0, 0, 0, 0, 0, 1, 0),
(12, 1, 0, 0, 12, 0, 0, '-1,0,2,13,4,5,6,7,8,9,10,11,12,7,8,8', 'Libros', '', 0, 0, 0, 0, 0, 0, 1, 0),
(13, 1, 0, 0, 13, 0, 0, '-1,0,2,13,4,5,6,7,8,9,10,11,12,7,8,8', 'Linux', '', 0, 0, 0, 0, 0, 0, 1, 0),
(14, 1, 0, 0, 14, 0, 0, '-1,0,2,13,4,5,6,7,8,9,10,11,12,7,8,8', 'Música', '', 0, 0, 0, 0, 0, 0, 1, 0),
(15, 1, 0, 0, 15, 0, 0, '-1,0,2,13,4,5,6,7,8,9,10,11,12,7,8,8', 'Noticias', '', 0, 0, 0, 0, 0, 0, 1, 0),
(16, 1, 0, 0, 16, 0, 0, '-1,0,2,13,4,5,6,7,8,9,10,11,12,7,8,8', 'Off-topic', '', 0, 0, 0, 0, 0, 0, 1, 0),
(17, 1, 0, 0, 17, 0, 0, '-1,0,2,13,4,5,6,7,8,9,10,11,12,7,8,8', 'Peticiones / Soporte', '', 0, 0, 0, 0, 0, 0, 1, 0),
(18, 1, 0, 0, 18, 0, 0, '-1,0,2,7,4,5,6', 'Psp', '', 0, 0, 0, 0, 0, 0, 1, 0),
(19, 1, 0, 0, 19, 0, 0, '-1,0,2,13,4,5,6,7,8,9,10,11,12,7,8,8', 'Tips y Trucos', '', 0, 0, 0, 0, 0, 0, 1, 0),
(20, 1, 0, 0, 20, 0, 0, '-1,0,2,13,4,5,6,7,8,9,10,11,12,7,8,8', 'Tutoriales / Ayuda', '', 0, 0, 0, 0, 0, 0, 1, 0),
(21, 1, 0, 0, 21, 0, 0, '-1,0,2,13,4,5,6,7,8,9,10,11,12,7,8,8', 'Videos On-line', '', 0, 0, 0, 0, 0, 0, 1, 0),
(22, 1, 0, 0, 22, 0, 0, '-1,0,2,13,4,5,6,7,8,9,10,11,12,7,8,8', 'Windows', '', 0, 0, 0, 0, 0, 0, 1, 0);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `smf_board_permissions`
--

CREATE TABLE IF NOT EXISTS `smf_board_permissions` (
  `ID_GROUP` smallint(5) NOT NULL DEFAULT '0',
  `ID_BOARD` smallint(5) unsigned NOT NULL DEFAULT '0',
  `permission` varchar(30) NOT NULL DEFAULT '',
  `addDeny` tinyint(4) NOT NULL DEFAULT '1',
  PRIMARY KEY (`ID_GROUP`,`ID_BOARD`,`permission`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Volcado de datos para la tabla `smf_board_permissions`
--

INSERT INTO `smf_board_permissions` (`ID_GROUP`, `ID_BOARD`, `permission`, `addDeny`) VALUES
(3, 0, 'thank_you_post_post', 1),
(3, 0, 'mark_notify', 1),
(3, 0, 'mark_any_notify', 1),
(3, 0, 'poll_remove_own', 1),
(3, 0, 'poll_edit_own', 1),
(3, 0, 'poll_add_own', 1),
(3, 0, 'poll_post', 1),
(2, 0, 'thank_you_post_unlock_all', 1),
(3, 0, 'poll_vote', 1),
(3, 0, 'poll_view', 1),
(3, 0, 'report_any', 1),
(3, 0, 'modify_any', 1),
(3, 0, 'delete_any', 1),
(3, 0, 'post_reply_any', 1),
(-1, 0, 'thank_you_post_show', 1),
(3, 0, 'post_reply_own', 1),
(3, 0, 'remove_any', 1),
(3, 0, 'lock_any', 1),
(3, 0, 'lock_own', 1),
(3, 0, 'move_any', 1),
(3, 0, 'make_sticky', 1),
(3, 0, 'send_topic', 1),
(3, 0, 'split_any', 1),
(3, 0, 'merge_any', 1),
(3, 0, 'post_new', 1),
(3, 0, 'moderate_board', 1),
(2, 0, 'thank_you_post_lock_all_own', 1),
(3, 0, 'thank_you_post_show', 1),
(3, 0, 'thank_you_post_delete_own', 1),
(3, 0, 'thank_you_post_lock_own', 1),
(3, 0, 'thank_you_post_lock_all_own', 1),
(3, 0, 'thank_you_post_delete_mem_own', 1),
(2, 0, 'thank_you_post_lock_own', 1),
(2, 0, 'thank_you_post_delete_own', 1),
(2, 0, 'thank_you_post_show', 1),
(2, 0, 'report_any', 1),
(-1, 0, 'send_topic', 1),
(0, 0, 'thank_you_post_delete_own', 1),
(2, 0, 'thank_you_post_post', 1),
(3, 0, 'hide_post_own', 1),
(3, 0, 'hide_post_any', 1),
(3, 0, 'view_hidden_msg', 1),
(2, 0, 'view_hidden_msg', 1),
(3, 0, 'view_hidden_post', 1),
(0, 0, 'thank_you_post_show', 1),
(2, 0, 'view_hidden_post', 1),
(2, 0, 'hide_post_any', 1),
(0, 0, 'thank_you_post_post', 1),
(0, 0, 'report_any', 1),
(0, 0, 'view_hidden_msg', 1),
(0, 0, 'hide_post_any', 1),
(2, 0, 'hide_post_own', 1),
(2, 0, 'modify_any', 1),
(2, 0, 'modify_own', 1),
(2, 0, 'delete_any', 1),
(2, 0, 'delete_own', 1),
(7, 0, 'delete_replies', 1),
(7, 0, 'hide_post_any', 1),
(7, 0, 'hide_post_own', 1),
(7, 0, 'lock_own', 1),
(7, 0, 'modify_own', 1),
(7, 0, 'move_own', 1),
(7, 0, 'post_new', 1),
(7, 0, 'post_reply_any', 1),
(7, 0, 'remove_own', 1),
(7, 0, 'report_any', 1),
(7, 0, 'send_topic', 1),
(7, 0, 'thank_you_post_delete_mem_any', 1),
(7, 0, 'thank_you_post_delete_own', 1),
(7, 0, 'thank_you_post_lock_all_own', 1),
(7, 0, 'thank_you_post_lock_own', 1),
(7, 0, 'thank_you_post_post', 1),
(7, 0, 'thank_you_post_show', 1),
(7, 0, 'view_hidden_msg', 1),
(0, 0, 'hide_post_own', 1),
(0, 0, 'modify_own', 1),
(0, 0, 'delete_replies', 1),
(0, 0, 'post_reply_any', 1),
(0, 0, 'remove_own', 1),
(0, 0, 'lock_own', 1),
(2, 0, 'delete_replies', 1),
(2, 0, 'post_reply_any', 1),
(2, 0, 'remove_any', 1),
(2, 0, 'lock_any', 1),
(2, 0, 'move_any', 1),
(2, 0, 'make_sticky', 1),
(2, 0, 'send_topic', 1),
(2, 0, 'post_new', 1),
(2, 0, 'moderate_board', 1),
(2, 0, 'thank_you_post_delete_mem_own', 1),
(2, 0, 'thank_you_post_delete_mem_any', 1),
(0, 0, 'move_own', 1),
(0, 0, 'send_topic', 1),
(0, 0, 'post_new', 1),
(0, 0, 'thank_you_post_lock_own', 1),
(0, 0, 'thank_you_post_lock_all_own', 1),
(0, 0, 'thank_you_post_delete_mem_any', 1);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `smf_bookmarks`
--

CREATE TABLE IF NOT EXISTS `smf_bookmarks` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `ID_MEMBER` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `ID_TOPIC` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `time` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `ID_MEMBER` (`ID_MEMBER`,`ID_TOPIC`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `smf_buddies`
--

CREATE TABLE IF NOT EXISTS `smf_buddies` (
  `ID_MEMBER` mediumint(8) NOT NULL DEFAULT '0',
  `BUDDY_ID` mediumint(8) NOT NULL DEFAULT '0',
  `approved` smallint(1) NOT NULL DEFAULT '0',
  `position` tinyint(4) NOT NULL DEFAULT '0',
  `time_updated` int(11) NOT NULL DEFAULT '0',
  `requested` mediumint(8) NOT NULL DEFAULT '0'
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `smf_calendar`
--

CREATE TABLE IF NOT EXISTS `smf_calendar` (
  `ID_EVENT` smallint(5) unsigned NOT NULL AUTO_INCREMENT,
  `startDate` date NOT NULL DEFAULT '0001-01-01',
  `endDate` date NOT NULL DEFAULT '0001-01-01',
  `ID_BOARD` smallint(5) unsigned NOT NULL DEFAULT '0',
  `ID_TOPIC` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `title` varchar(48) NOT NULL DEFAULT '',
  `ID_MEMBER` mediumint(8) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`ID_EVENT`),
  KEY `startDate` (`startDate`),
  KEY `endDate` (`endDate`),
  KEY `topic` (`ID_TOPIC`,`ID_MEMBER`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `smf_calendar_holidays`
--

CREATE TABLE IF NOT EXISTS `smf_calendar_holidays` (
  `ID_HOLIDAY` smallint(5) unsigned NOT NULL AUTO_INCREMENT,
  `eventDate` date NOT NULL DEFAULT '0001-01-01',
  `title` varchar(30) NOT NULL DEFAULT '',
  PRIMARY KEY (`ID_HOLIDAY`),
  KEY `eventDate` (`eventDate`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `smf_categories`
--

CREATE TABLE IF NOT EXISTS `smf_categories` (
  `ID_CAT` tinyint(4) unsigned NOT NULL AUTO_INCREMENT,
  `catOrder` tinyint(4) NOT NULL DEFAULT '0',
  `name` tinytext NOT NULL,
  `canCollapse` tinyint(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`ID_CAT`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- Volcado de datos para la tabla `smf_categories`
--

INSERT INTO `smf_categories` (`ID_CAT`, `catOrder`, `name`, `canCollapse`) VALUES
(1, 0, 'Posts', 0);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `smf_collapsed_categories`
--

CREATE TABLE IF NOT EXISTS `smf_collapsed_categories` (
  `ID_CAT` tinyint(4) unsigned NOT NULL DEFAULT '0',
  `ID_MEMBER` mediumint(8) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`ID_CAT`,`ID_MEMBER`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `smf_comentarios`
--

CREATE TABLE IF NOT EXISTS `smf_comentarios` (
  `id_coment` int(11) NOT NULL AUTO_INCREMENT,
  `id_user` varchar(20) COLLATE utf8_spanish_ci DEFAULT NULL,
  `comentario` text CHARACTER SET utf8 COLLATE utf8_spanish2_ci,
  `id_post` varchar(20) COLLATE utf8_spanish_ci DEFAULT NULL,
  `fecha` text COLLATE utf8_spanish_ci NOT NULL,
  `id_cat` varchar(20) COLLATE utf8_spanish_ci NOT NULL DEFAULT '0',
  PRIMARY KEY (`id_coment`),
  FULLTEXT KEY `id_cat` (`id_cat`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `smf_comunidades`
--

CREATE TABLE IF NOT EXISTS `smf_comunidades` (
  `ID_COMUNIDAD` int(11) NOT NULL AUTO_INCREMENT,
  `titulo` tinytext COLLATE utf8_spanish_ci NOT NULL,
  `background` text CHARACTER SET latin1,
  `portada` text CHARACTER SET latin1,
  `descripcion` mediumtext COLLATE utf8_spanish_ci,
  `ID_BOARD` smallint(5) unsigned NOT NULL DEFAULT '0',
  `ID_BOARD2` smallint(5) unsigned NOT NULL DEFAULT '0',
  `ID_MEMBER_STARTED` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `ID_MEMBER_UPDATED` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `rango` tinyint(4) NOT NULL DEFAULT '1',
  `publicaciones` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `fecha` int(10) unsigned NOT NULL DEFAULT '0',
  `fecha_update` int(10) unsigned NOT NULL DEFAULT '0',
  `visitas` int(10) unsigned NOT NULL DEFAULT '0',
  `validacion` tinyint(4) NOT NULL DEFAULT '0',
  `miembros` int(10) unsigned NOT NULL DEFAULT '0',
  `temas` int(10) unsigned NOT NULL DEFAULT '0',
  `seguidores` int(10) unsigned NOT NULL DEFAULT '0',
  `privado` tinyint(4) NOT NULL DEFAULT '0',
  `sticky` tinyint(4) NOT NULL DEFAULT '0',
  `popularidad` int(10) NOT NULL DEFAULT '0',
  `borrador` int(2) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`ID_COMUNIDAD`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `smf_comunidades_categorias`
--

CREATE TABLE IF NOT EXISTS `smf_comunidades_categorias` (
  `ID_BOARD` smallint(5) unsigned NOT NULL AUTO_INCREMENT,
  `boardOrder` smallint(5) NOT NULL DEFAULT '0',
  `type` int(2) NOT NULL DEFAULT '0',
  `ID_LAST_CMD` int(10) unsigned NOT NULL DEFAULT '0',
  `memberGroups` varchar(255) NOT NULL DEFAULT '-1,0',
  `name` tinytext NOT NULL,
  `comunidades` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `temas` mediumint(8) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`ID_BOARD`),
  KEY `memberGroups` (`memberGroups`(48))
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `smf_comunidades_comentarios`
--

CREATE TABLE IF NOT EXISTS `smf_comunidades_comentarios` (
  `ID_C` int(11) NOT NULL AUTO_INCREMENT,
  `ID_COMUNIDAD` int(10) NOT NULL DEFAULT '0',
  `ID_TEMA` int(10) NOT NULL,
  `cuerpo` mediumtext COLLATE utf8_spanish_ci,
  `ID_MEMBER_STARTED` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `fecha` int(10) unsigned NOT NULL DEFAULT '0',
  `ID_MEMBER_UPDATED` mediumint(8) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`ID_C`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `smf_comunidades_likes`
--

CREATE TABLE IF NOT EXISTS `smf_comunidades_likes` (
  `id_like` int(11) NOT NULL DEFAULT '0',
  `ID_MEMBER` int(11) NOT NULL DEFAULT '0',
  `TYPE` int(11) NOT NULL DEFAULT '0',
  `fecha` int(10) NOT NULL DEFAULT '0'
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `smf_comunidades_miembros`
--

CREATE TABLE IF NOT EXISTS `smf_comunidades_miembros` (
  `ID` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `ID_COMUNIDAD` mediumint(8) unsigned NOT NULL,
  `ID_MIEMBRO` mediumint(8) unsigned NOT NULL,
  `ID_RANGO` mediumint(8) unsigned NOT NULL,
  `APROVED` mediumint(8) unsigned NOT NULL,
  `BAN` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `Razon` text NOT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `smf_comunidades_temas`
--

CREATE TABLE IF NOT EXISTS `smf_comunidades_temas` (
  `ID_TEMA` int(11) NOT NULL AUTO_INCREMENT,
  `titulo` tinytext COLLATE utf8_spanish_ci NOT NULL,
  `ID_COMUNIDAD` int(11) NOT NULL,
  `ID_BOARD` smallint(5) unsigned NOT NULL DEFAULT '0',
  `ID_BOARD2` smallint(5) unsigned NOT NULL DEFAULT '0',
  `cuerpo` mediumtext COLLATE utf8_spanish_ci,
  `ID_MEMBER_STARTED` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `ID_MEMBER_UPDATED` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `fecha` int(10) unsigned NOT NULL DEFAULT '0',
  `visitas` int(10) unsigned NOT NULL DEFAULT '0',
  `respuestas` int(10) unsigned NOT NULL DEFAULT '0',
  `cerrado` tinyint(4) NOT NULL DEFAULT '0',
  `sticky` tinyint(4) NOT NULL DEFAULT '0',
  `positivos` int(10) unsigned NOT NULL DEFAULT '0',
  `negativos` int(10) unsigned NOT NULL DEFAULT '0',
  `seguidores` int(10) unsigned NOT NULL DEFAULT '0',
  `favoritos` int(10) unsigned NOT NULL DEFAULT '0',
  `popularidad` int(10) unsigned NOT NULL DEFAULT '0',
  `borrador` int(2) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`ID_TEMA`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `smf_comunidades_tops`
--

CREATE TABLE IF NOT EXISTS `smf_comunidades_tops` (
  `dato` int(11) NOT NULL,
  `id_top` int(11) NOT NULL,
  `posicion` int(11) NOT NULL,
  `codigo` int(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `smf_denuncias`
--

CREATE TABLE IF NOT EXISTS `smf_denuncias` (
  `id_denuncia` int(10) NOT NULL AUTO_INCREMENT,
  `id` int(10) NOT NULL DEFAULT '0',
  `id_user` int(10) NOT NULL DEFAULT '0',
  `tipo` tinyint(4) DEFAULT NULL,
  `razon` text NOT NULL,
  `comentario` text NOT NULL,
  `fecha` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id_denuncia`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `smf_drafts`
--

CREATE TABLE IF NOT EXISTS `smf_drafts` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `titulo` text NOT NULL,
  `contenido` text NOT NULL,
  `fuente` text NOT NULL,
  `fijado` tinyint(1) NOT NULL,
  `sincom` tinyint(1) NOT NULL,
  `soloreg` tinyint(1) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `smf_followers`
--

CREATE TABLE IF NOT EXISTS `smf_followers` (
  `uid` mediumint(8) NOT NULL,
  `uif` mediumint(8) NOT NULL,
  `time` int(11) NOT NULL,
  `type` tinyint(2) NOT NULL,
  KEY `ID_MEMBER` (`uif`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `smf_imagenes`
--

CREATE TABLE IF NOT EXISTS `smf_imagenes` (
  `IDI` int(11) NOT NULL AUTO_INCREMENT,
  `ID_MEMBER` int(11) NOT NULL,
  `titulo` text COLLATE utf8_spanish_ci NOT NULL,
  `descripcion` text COLLATE utf8_spanish_ci NOT NULL,
  `url_img` text COLLATE utf8_spanish_ci NOT NULL,
  `previa` text COLLATE utf8_spanish_ci NOT NULL,
  `album` int(11) NOT NULL,
  `privacy` int(11) NOT NULL,
  `amigo` int(11) NOT NULL,
  `privado` int(11) NOT NULL,
  `publico` int(11) NOT NULL,
  `puntos` int(11) NOT NULL,
  `comentarios` int(11) NOT NULL,
  `fecha` int(11) NOT NULL,
  PRIMARY KEY (`IDI`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `smf_img_album`
--

CREATE TABLE IF NOT EXISTS `smf_img_album` (
  `IDA` int(11) NOT NULL AUTO_INCREMENT,
  `ID_MEMBER` int(11) NOT NULL,
  `nombre` text COLLATE utf8_spanish_ci NOT NULL,
  `cantimg` int(11) NOT NULL,
  `privacy` int(11) NOT NULL,
  `amigo` int(11) NOT NULL,
  `privado` int(11) NOT NULL,
  `publico` int(11) NOT NULL,
  `fecha` int(11) NOT NULL,
  PRIMARY KEY (`IDA`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci AUTO_INCREMENT=1 ;

--
-- Volcado de datos para la tabla `smf_img_album`
--

INSERT INTO `smf_img_album` (`IDA`, `ID_MEMBER`, `nombre`, `cantimg`, `privacy`, `amigo`, `privado`, `publico`, `fecha`) VALUES
(0, 0, 'default', 0, 0, 0, 0, 0, 0);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `smf_img_comentarios`
--

CREATE TABLE IF NOT EXISTS `smf_img_comentarios` (
  `IDC` int(11) NOT NULL AUTO_INCREMENT,
  `ID_MEMBER` int(11) NOT NULL,
  `IDI` int(11) NOT NULL,
  `comentario` text COLLATE utf8_spanish_ci NOT NULL,
  `fecha` int(11) NOT NULL,
  PRIMARY KEY (`IDC`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `smf_img_plog`
--

CREATE TABLE IF NOT EXISTS `smf_img_plog` (
  `IDPL` int(11) NOT NULL AUTO_INCREMENT,
  `IDI` int(11) NOT NULL,
  `ID_MEMBER` int(11) NOT NULL,
  `fecha` int(11) NOT NULL,
  `punto` text NOT NULL,
  PRIMARY KEY (`IDPL`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `smf_log_actions`
--

CREATE TABLE IF NOT EXISTS `smf_log_actions` (
  `ID_ACTION` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `logTime` int(10) unsigned NOT NULL DEFAULT '0',
  `ID_MEMBER` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `ip` char(16) NOT NULL DEFAULT '',
  `action` varchar(30) NOT NULL DEFAULT '',
  `extra` mediumtext NOT NULL,
  PRIMARY KEY (`ID_ACTION`),
  KEY `logTime` (`logTime`),
  KEY `ID_MEMBER` (`ID_MEMBER`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `smf_log_activity`
--

CREATE TABLE IF NOT EXISTS `smf_log_activity` (
  `date` date NOT NULL DEFAULT '0001-01-01',
  `hits` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `topics` smallint(5) unsigned NOT NULL DEFAULT '0',
  `posts` smallint(5) unsigned NOT NULL DEFAULT '0',
  `registers` smallint(5) unsigned NOT NULL DEFAULT '0',
  `mostOn` smallint(5) unsigned NOT NULL DEFAULT '0',
  `referrals` int(11) NOT NULL,
  `streams` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`date`),
  KEY `hits` (`hits`),
  KEY `mostOn` (`mostOn`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `smf_log_banned`
--

CREATE TABLE IF NOT EXISTS `smf_log_banned` (
  `ID_BAN_LOG` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `ID_MEMBER` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `ip` char(16) NOT NULL DEFAULT '',
  `email` tinytext NOT NULL,
  `logTime` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`ID_BAN_LOG`),
  KEY `logTime` (`logTime`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `smf_log_boards`
--

CREATE TABLE IF NOT EXISTS `smf_log_boards` (
  `ID_MEMBER` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `ID_BOARD` smallint(5) unsigned NOT NULL DEFAULT '0',
  `ID_MSG` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`ID_MEMBER`,`ID_BOARD`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `smf_log_errors`
--

CREATE TABLE IF NOT EXISTS `smf_log_errors` (
  `ID_ERROR` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `logTime` int(10) unsigned NOT NULL DEFAULT '0',
  `ID_MEMBER` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `ip` char(16) NOT NULL DEFAULT '',
  `url` mediumtext NOT NULL,
  `message` mediumtext NOT NULL,
  `session` char(32) NOT NULL DEFAULT '',
  PRIMARY KEY (`ID_ERROR`),
  KEY `logTime` (`logTime`),
  KEY `ID_MEMBER` (`ID_MEMBER`),
  KEY `ip` (`ip`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `smf_log_floodcontrol`
--

CREATE TABLE IF NOT EXISTS `smf_log_floodcontrol` (
  `ip` char(16) NOT NULL DEFAULT '',
  `logTime` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`ip`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `smf_log_karma`
--

CREATE TABLE IF NOT EXISTS `smf_log_karma` (
  `ID_TARGET` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `ID_EXECUTOR` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `logTime` int(10) unsigned NOT NULL DEFAULT '0',
  `action` tinyint(4) NOT NULL DEFAULT '0',
  PRIMARY KEY (`ID_TARGET`,`ID_EXECUTOR`),
  KEY `logTime` (`logTime`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `smf_log_mark_read`
--

CREATE TABLE IF NOT EXISTS `smf_log_mark_read` (
  `ID_MEMBER` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `ID_BOARD` smallint(5) unsigned NOT NULL DEFAULT '0',
  `ID_MSG` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`ID_MEMBER`,`ID_BOARD`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `smf_log_notify`
--

CREATE TABLE IF NOT EXISTS `smf_log_notify` (
  `ID_MEMBER` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `ID_TOPIC` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `ID_BOARD` smallint(5) unsigned NOT NULL DEFAULT '0',
  `sent` tinyint(1) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`ID_MEMBER`,`ID_TOPIC`,`ID_BOARD`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `smf_log_online`
--

CREATE TABLE IF NOT EXISTS `smf_log_online` (
  `session` varchar(32) NOT NULL DEFAULT '',
  `logTime` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `ID_MEMBER` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `ip` int(10) unsigned NOT NULL DEFAULT '0',
  `url` mediumtext NOT NULL,
  PRIMARY KEY (`session`),
  KEY `logTime` (`logTime`),
  KEY `ID_MEMBER` (`ID_MEMBER`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `smf_log_search_messages`
--

CREATE TABLE IF NOT EXISTS `smf_log_search_messages` (
  `ID_SEARCH` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `ID_MSG` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`ID_SEARCH`,`ID_MSG`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `smf_log_search_results`
--

CREATE TABLE IF NOT EXISTS `smf_log_search_results` (
  `ID_SEARCH` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `ID_TOPIC` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `ID_MSG` int(10) unsigned NOT NULL DEFAULT '0',
  `relevance` smallint(5) unsigned NOT NULL DEFAULT '0',
  `num_matches` smallint(5) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`ID_SEARCH`,`ID_TOPIC`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `smf_log_search_subjects`
--

CREATE TABLE IF NOT EXISTS `smf_log_search_subjects` (
  `word` varchar(20) NOT NULL DEFAULT '',
  `ID_TOPIC` mediumint(8) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`word`,`ID_TOPIC`),
  KEY `ID_TOPIC` (`ID_TOPIC`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `smf_log_search_topics`
--

CREATE TABLE IF NOT EXISTS `smf_log_search_topics` (
  `ID_SEARCH` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `ID_TOPIC` mediumint(9) NOT NULL DEFAULT '0',
  PRIMARY KEY (`ID_SEARCH`,`ID_TOPIC`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `smf_log_search_words`
--

CREATE TABLE IF NOT EXISTS `smf_log_search_words` (
  `ID_WORD` int(10) unsigned NOT NULL DEFAULT '0',
  `ID_MSG` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`ID_WORD`,`ID_MSG`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `smf_log_topics`
--

CREATE TABLE IF NOT EXISTS `smf_log_topics` (
  `ID_MEMBER` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `ID_TOPIC` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `ID_MSG` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`ID_MEMBER`,`ID_TOPIC`),
  KEY `ID_TOPIC` (`ID_TOPIC`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `smf_membergroups`
--

CREATE TABLE IF NOT EXISTS `smf_membergroups` (
  `ID_GROUP` smallint(5) unsigned NOT NULL AUTO_INCREMENT,
  `groupName` varchar(80) NOT NULL DEFAULT '',
  `onlineColor` varchar(20) NOT NULL DEFAULT '',
  `minPosts` mediumint(9) NOT NULL DEFAULT '-1',
  `maxMessages` smallint(5) unsigned NOT NULL DEFAULT '0',
  `stars` tinytext NOT NULL,
  `puntos` int(11) NOT NULL,
  PRIMARY KEY (`ID_GROUP`),
  KEY `minPosts` (`minPosts`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=8 ;

--
-- Volcado de datos para la tabla `smf_membergroups`
--

INSERT INTO `smf_membergroups` (`ID_GROUP`, `groupName`, `onlineColor`, `minPosts`, `maxMessages`, `stars`, `puntos`) VALUES
(1, 'Administrador', '#FF0000', -1, 0, '1#rangos/admin.gif', 35),
(2, 'Moderador', '#FFBF00', -1, 0, '1#rangos/moderador.gif', 20),
(3, 'Moderador de Seccion', '#13DD02', -1, 0, '1#rangos/moderador.gif', 15),
(4, 'Novato', '#B3B7B7', 0, 0, '1#rangos/leecher.gif', 0),
(5, 'New Full User', '#8B8E8E', 1, 0, '1#rangos/nfu.gif', 5),
(6, 'New Full User', '#B8C100', 150, 0, '1#rangos/user-complet.gif', 10),
(7, 'Miembro VIP', '', -1, 0, '1#rangos/VIP.gif', 20);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `smf_members`
--

CREATE TABLE IF NOT EXISTS `smf_members` (
  `ID_MEMBER` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `memberName` varchar(80) NOT NULL DEFAULT '',
  `dateRegistered` int(10) unsigned NOT NULL DEFAULT '0',
  `posts` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `topics` int(11) unsigned NOT NULL DEFAULT '0',
  `ID_GROUP` smallint(5) unsigned NOT NULL DEFAULT '0',
  `lngfile` tinytext NOT NULL,
  `lastLogin` int(10) unsigned NOT NULL DEFAULT '0',
  `realName` tinytext NOT NULL,
  `nombre` text NOT NULL,
  `comunidades` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `instantMessages` smallint(5) NOT NULL DEFAULT '0',
  `unreadMessages` smallint(5) NOT NULL DEFAULT '0',
  `buddy_list` mediumtext NOT NULL,
  `pm_ignore_list` tinytext NOT NULL,
  `messageLabels` mediumtext NOT NULL,
  `passwd` varchar(64) NOT NULL DEFAULT '',
  `emailAddress` tinytext NOT NULL,
  `personalText` tinytext NOT NULL,
  `gender` tinyint(4) unsigned NOT NULL DEFAULT '0',
  `birthdate` date NOT NULL DEFAULT '0001-01-01',
  `location` mediumint(8) NOT NULL DEFAULT '0',
  `hideEmail` tinyint(4) NOT NULL DEFAULT '0',
  `showOnline` tinyint(4) NOT NULL DEFAULT '1',
  `timeFormat` varchar(80) NOT NULL DEFAULT '',
  `signature` mediumtext NOT NULL,
  `timeOffset` float NOT NULL DEFAULT '0',
  `avatar` tinytext NOT NULL,
  `avatar_coords` text NOT NULL,
  `karmaBad` smallint(5) unsigned NOT NULL DEFAULT '0',
  `karmaGood` smallint(5) unsigned NOT NULL DEFAULT '0',
  `usertitle` tinytext NOT NULL,
  `memberIP` tinytext NOT NULL,
  `memberIP2` tinytext NOT NULL,
  `secretQuestion` tinytext NOT NULL,
  `secretAnswer` varchar(64) NOT NULL DEFAULT '',
  `ID_THEME` tinyint(4) unsigned NOT NULL DEFAULT '0',
  `is_activated` tinyint(3) unsigned NOT NULL DEFAULT '1',
  `validation_code` varchar(10) NOT NULL DEFAULT '',
  `ID_MSG_LAST_VISIT` int(10) unsigned NOT NULL DEFAULT '0',
  `additionalGroups` tinytext NOT NULL,
  `smileySet` varchar(48) NOT NULL DEFAULT '',
  `ID_POST_GROUP` smallint(5) unsigned NOT NULL DEFAULT '0',
  `totalTimeLoggedIn` int(10) unsigned NOT NULL DEFAULT '0',
  `passwordSalt` varchar(5) NOT NULL DEFAULT '',
  `money` int(11) unsigned NOT NULL DEFAULT '0',
  `moneyrankpp` int(11) NOT NULL,
  `moneyBank` decimal(9,2) unsigned NOT NULL DEFAULT '0.00',
  `recentpostBoards` text,
  `recentLastOnly` tinyint(4) DEFAULT NULL,
  `recentNrofPosts` tinyint(4) DEFAULT NULL,
  `comments` int(11) NOT NULL DEFAULT '0',
  `photos` int(11) NOT NULL DEFAULT '0',
  `notifications` mediumint(8) NOT NULL DEFAULT '0',
  `streams` int(11) NOT NULL DEFAULT '0',
  `re_streams` int(11) NOT NULL DEFAULT '0',
  `followers` int(11) NOT NULL DEFAULT '0',
  `following` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`ID_MEMBER`),
  KEY `memberName` (`memberName`(30)),
  KEY `dateRegistered` (`dateRegistered`),
  KEY `ID_GROUP` (`ID_GROUP`),
  KEY `birthdate` (`birthdate`),
  KEY `posts` (`posts`),
  KEY `lastLogin` (`lastLogin`),
  KEY `lngfile` (`lngfile`(30)),
  KEY `ID_POST_GROUP` (`ID_POST_GROUP`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `smf_members_info`
--

CREATE TABLE IF NOT EXISTS `smf_members_info` (
  `busca` text NOT NULL,
  `hobbies` text NOT NULL,
  `idiomas` text NOT NULL,
  `estudios` text NOT NULL,
  `trabajo` text NOT NULL,
  `habilidades` text NOT NULL,
  `intereses` text NOT NULL,
  `situacion` text NOT NULL,
  `vivecon` text NOT NULL,
  `ID_MEMBER` int(11) NOT NULL,
  `biografia` text NOT NULL,
  `web` text NOT NULL,
  `estado` text NOT NULL,
  PRIMARY KEY (`ID_MEMBER`),
  KEY `id_user` (`ID_MEMBER`),
  KEY `id_user_2` (`ID_MEMBER`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `smf_messages`
--

CREATE TABLE IF NOT EXISTS `smf_messages` (
  `ID_MSG` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `ID_TOPIC` mediumint(8) unsigned NOT NULL,
  `ID_BOARD` smallint(5) unsigned NOT NULL DEFAULT '0',
  `posterTime` int(10) unsigned NOT NULL DEFAULT '0',
  `ID_MEMBER` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `ID_MSG_MODIFIED` int(10) unsigned NOT NULL DEFAULT '0',
  `subject` tinytext CHARACTER SET utf8 COLLATE utf8_spanish_ci NOT NULL,
  `posterName` tinytext NOT NULL,
  `posterEmail` tinytext NOT NULL,
  `posterIP` tinytext NOT NULL,
  `smileysEnabled` tinyint(4) NOT NULL DEFAULT '1',
  `modifiedTime` int(10) unsigned NOT NULL DEFAULT '0',
  `modifiedName` tinytext NOT NULL,
  `body` mediumtext CHARACTER SET utf8 COLLATE utf8_spanish_ci,
  `icon` varchar(16) NOT NULL DEFAULT 'xx',
  `edit_reason` tinytext NOT NULL,
  `thank_you_post` tinyint(4) unsigned NOT NULL DEFAULT '0',
  `thank_you_post_counter` smallint(5) unsigned NOT NULL DEFAULT '0',
  `hiddenOption` tinyint(4) unsigned NOT NULL DEFAULT '0',
  `hiddenValue` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `fuente` text NOT NULL,
  PRIMARY KEY (`ID_MSG`),
  UNIQUE KEY `ID_BOARD` (`ID_BOARD`,`ID_MSG`),
  UNIQUE KEY `ID_MEMBER` (`ID_MEMBER`,`ID_MSG`),
  UNIQUE KEY `topic` (`ID_MSG`,`ID_TOPIC`),
  KEY `ipIndex` (`posterIP`(15),`ID_TOPIC`),
  KEY `participation` (`ID_MEMBER`,`ID_TOPIC`),
  KEY `showPosts` (`ID_MEMBER`,`ID_BOARD`),
  KEY `ID_TOPIC` (`ID_TOPIC`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `smf_message_icons`
--

CREATE TABLE IF NOT EXISTS `smf_message_icons` (
  `ID_ICON` smallint(5) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(80) NOT NULL DEFAULT '',
  `filename` varchar(80) NOT NULL DEFAULT '',
  `ID_BOARD` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `iconOrder` smallint(5) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`ID_ICON`),
  KEY `ID_BOARD` (`ID_BOARD`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `smf_moderators`
--

CREATE TABLE IF NOT EXISTS `smf_moderators` (
  `ID_BOARD` smallint(5) unsigned NOT NULL DEFAULT '0',
  `ID_MEMBER` mediumint(8) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`ID_BOARD`,`ID_MEMBER`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `smf_notifications`
--

CREATE TABLE IF NOT EXISTS `smf_notifications` (
  `ID_NOTIFICATION` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ID_MEMBER` int(11) unsigned NOT NULL,
  `ID_SUBJECT` int(11) unsigned NOT NULL DEFAULT '0',
  `ID_OBJECT` int(11) unsigned NOT NULL DEFAULT '0',
  `object_type` varchar(35) CHARACTER SET latin1 COLLATE latin1_general_ci NOT NULL,
  `type` varchar(45) NOT NULL,
  `parameters` text CHARACTER SET utf8 COLLATE utf8_spanish_ci NOT NULL,
  `is_read` int(11) NOT NULL,
  `time` int(11) NOT NULL,
  `timeForMark` int(11) NOT NULL,
  PRIMARY KEY (`ID_NOTIFICATION`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `smf_notifications_params`
--

CREATE TABLE IF NOT EXISTS `smf_notifications_params` (
  `ID_NOTIF` int(11) NOT NULL,
  `notifiers_id` varchar(955) NOT NULL DEFAULT '0',
  `sub_notifiers` varchar(955) NOT NULL DEFAULT '0',
  `object_id` varchar(955) NOT NULL DEFAULT '0',
  `notifiers_params` text CHARACTER SET utf8 COLLATE utf8_spanish_ci NOT NULL,
  `extra_params` text NOT NULL,
  `tmpl_minimal` text CHARACTER SET utf8 COLLATE utf8_spanish_ci NOT NULL,
  `tmpl_extended` text CHARACTER SET utf8 COLLATE utf8_spanish_ci NOT NULL,
  KEY `ID_NOTIF` (`ID_NOTIF`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `smf_package_servers`
--

CREATE TABLE IF NOT EXISTS `smf_package_servers` (
  `ID_SERVER` smallint(5) unsigned NOT NULL AUTO_INCREMENT,
  `name` tinytext NOT NULL,
  `url` tinytext NOT NULL,
  PRIMARY KEY (`ID_SERVER`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `smf_paises`
--

CREATE TABLE IF NOT EXISTS `smf_paises` (
  `ID_PAIS` int(11) NOT NULL AUTO_INCREMENT,
  `nombre` text NOT NULL,
  `img` text NOT NULL,
  `ID_MEMBER` int(11) NOT NULL,
  PRIMARY KEY (`ID_PAIS`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=245 ;

--
-- Volcado de datos para la tabla `smf_paises`
--

INSERT INTO `smf_paises` (`ID_PAIS`, `nombre`, `img`, `ID_MEMBER`) VALUES
(1, 'Afganistan', 'af', 1),
(2, 'Albania', 'al', 1),
(3, 'Alemania', 'de', 1),
(4, 'Argelia', 'dz', 1),
(5, 'Andorra', 'ad', 1),
(6, 'Angola', 'ao', 1),
(7, 'Anguila', 'ai', 1),
(8, 'Antigua y Barbuda', 'ag', 1),
(9, 'Antillas Neerlandesas', 'an', 1),
(10, 'Antartida', 'aq', 1),
(11, 'Arabia Saudita', 'sa', 1),
(12, 'Argentina', 'ar', 2),
(13, 'Armenia', 'am', 1),
(14, 'Aruba', 'aw', 1),
(15, 'Australia', 'au', 1),
(16, 'Austria', 'at', 1),
(17, 'Azerbaiyan', 'az', 1),
(18, 'Bahamas', 'bs', 1),
(19, 'Bahrein', 'bh', 1),
(20, 'Bangladesh', 'bd', 1),
(21, 'Barbados', 'bb', 1),
(22, 'Belice', 'bz', 1),
(23, 'Benin', 'bj', 1),
(24, 'Bermudas', 'bm', 1),
(25, 'Bielorrusia', 'by', 1),
(26, 'Bolivia', 'bo', 14),
(27, 'Bosnia y Herzegovina', 'ba', 1),
(28, 'Botswana', 'bw', 1),
(29, 'Brasil', 'br', 1),
(30, 'Brunei', 'bn', 1),
(31, 'Bulgaria', 'bg', 1),
(32, 'Burkina Faso', 'bf', 1),
(33, 'Burundi', 'bi', 1),
(34, 'Butan', 'bt', 1),
(35, 'Belgica', 'be', 1),
(36, 'Cabo Verde', 'cv', 1),
(37, 'Camboya', 'kh', 1),
(38, 'Camerun', 'cm', 1),
(39, 'Canada', 'ca', 1),
(40, 'Chad', 'td', 1),
(41, 'Chile', 'cl', 1),
(42, 'China', 'cn', 1),
(43, 'Chipre', 'cy', 1),
(44, 'Ciudad del Vaticano', 'va', 1),
(45, 'Colombia', 'co', 1),
(46, 'Comoras', 'km', 1),
(47, 'Corea del Norte', 'kp', 1),
(48, 'Corea del Sur', 'kr', 1),
(49, 'Costa Rica', 'cr', 1),
(50, 'Costa de Marfil', 'ci', 1),
(51, 'Croacia', 'hr', 1),
(52, 'Cuba', 'cu', 1),
(53, 'Dinamarca', 'dk', 1),
(54, 'Dominica', 'dm', 1),
(55, 'Ecuador', 'ec', 1),
(56, 'Egipto', 'eg', 1),
(57, 'El Salvador', 'sv', 1),
(58, 'Emiratos Arabes Unidos', 'ae', 1),
(59, 'Eritrea', 'er', 1),
(60, 'Eslovaquia', 'sk', 1),
(61, 'Eslovenia', 'si', 1),
(62, 'Espa&ntilde;a', 'es', 1),
(63, 'Estados Unidos', 'us', 1),
(64, 'Estonia', 'ee', 1),
(65, 'Etiopia', 'et', 1),
(66, 'Filipinas', 'ph', 1),
(67, 'Finlandia', 'fi', 1),
(68, 'Fiyi', 'fj', 1),
(69, 'Francia', 'fr', 1),
(70, 'Gabon', 'ga', 1),
(71, 'Gambia', 'gm', 1),
(72, 'Georgia', 'ge', 1),
(73, 'Ghana', 'gh', 1),
(74, 'Gibraltar', 'gi', 1),
(75, 'Granada', 'gd', 1),
(76, 'Grecia', 'gr', 1),
(77, 'Groenlandia', 'gl', 1),
(78, 'Guadalupe', 'gp', 1),
(79, 'Guam', 'gu', 1),
(80, 'Guatemala', 'gt', 1),
(81, 'Guayana Francesa', 'gf', 1),
(82, 'Guernsey', 'gg', 1),
(83, 'Guinea', 'gn', 1),
(84, 'Guinea Ecuatorial', 'gq', 1),
(85, 'Guinea-Bissau', 'gw', 1),
(86, 'Guyana', 'gy', 1),
(87, 'Haiti', 'ht', 1),
(88, 'Honduras', 'hn', 1),
(89, 'Hong Kong', 'hk', 1),
(90, 'Hungria', 'hu', 1),
(91, 'India', 'in', 1),
(92, 'Indonesia', 'id', 1),
(93, 'Iraq', 'iq', 1),
(94, 'Irlanda', 'ie', 1),
(95, 'Iran', 'ir', 1),
(96, 'Isla Bouvet', 'bv', 1),
(97, 'Isla de Man', 'im', 1),
(98, 'Isla de Navidad', 'cx', 1),
(99, 'Islandia', 'is', 1),
(100, 'Islas Caiman', 'ky', 1),
(101, 'Islas Cocos', 'cc', 1),
(102, 'Islas Cook', 'ck', 1),
(103, 'Islas Feroe', 'fo', 1),
(104, 'Islas Georgias del Sur y Sandwich del Sur', 'gs', 1),
(105, 'Islas Heard y McDonald', 'hm', 1),
(106, 'Islas Marianas del Norte', 'mp', 1),
(107, 'Islas Marshall', 'mh', 1),
(108, 'Islas Pitcairn', 'pn', 1),
(109, 'Islas Salomon', 'sb', 1),
(110, 'Islas Turcas y Caicos', 'tc', 1),
(111, 'Islas Virgenes Britanicas', 'vg', 1),
(112, 'Islas Virgenes Estadounidenses', 'vi', 1),
(113, 'Islas ultramarinas de Estados Unidos', 'um', 1),
(114, 'Israel', 'il', 1),
(115, 'Italia', 'it', 1),
(116, 'Jamaica', 'jm', 1),
(117, 'Japon', 'jp', 1),
(118, 'Jersey', 'je', 1),
(119, 'Jordania', 'jo', 1),
(120, 'Kazajistan', 'kz', 1),
(121, 'Kenia', 'ke', 1),
(122, 'Kirguistan', 'kg', 1),
(123, 'Kiribati', 'ki', 1),
(124, 'Kuwait', 'kw', 1),
(125, 'Laos', 'la', 1),
(126, 'Lesoto', 'ls', 1),
(127, 'Letonia', 'lv', 1),
(128, 'Liberia', 'lr', 1),
(129, 'Libia', 'ly', 1),
(130, 'Liechtenstein', 'li', 1),
(131, 'Lituania', 'lt', 1),
(132, 'Luxemburgo', 'lu', 1),
(133, 'Libano', 'lb', 1),
(134, 'Macao', 'mo', 1),
(135, 'Madagascar', 'mg', 1),
(136, 'Malasia', 'my', 1),
(137, 'Malaui', 'mw', 1),
(138, 'Maldivas', 'mv', 1),
(139, 'Malta', 'mt', 1),
(140, 'Mali', 'ml', 1),
(141, 'Marruecos', 'ma', 1),
(142, 'Martinica', 'mq', 1),
(143, 'Mauricio', 'mu', 1),
(144, 'Mauritania', 'mr', 1),
(145, 'Mayotte', 'yt', 1),
(146, 'Micronesia', 'fm', 1),
(147, 'Moldavia', 'md', 1),
(148, 'Mongolia', 'mn', 1),
(149, 'Montenegro', 'me', 1),
(150, 'Montserrat', 'ms', 1),
(151, 'Mozambique', 'mz', 1),
(152, 'Myanmar', 'mm', 1),
(153, 'Mexico', 'mx', 1),
(154, 'Monaco', 'mc', 1),
(155, 'Namibia', 'na', 1),
(156, 'Nauru', 'nr', 1),
(157, 'Nepal', 'np', 1),
(158, 'Nicaragua', 'ni', 1),
(159, 'Niger', 'ne', 1),
(160, 'Nigeria', 'ng', 1),
(161, 'Niue', 'nu', 1),
(162, 'Norfolk', 'nf', 1),
(163, 'Noruega', 'no', 1),
(164, 'Nueva Caledonia', 'nc', 1),
(165, 'Nueva Zelanda', 'nz', 1),
(166, 'Oman', 'om', 1),
(167, 'Pakistan', 'pk', 1),
(168, 'Palaos', 'pw', 1),
(169, 'Panama', 'pa', 1),
(170, 'Papua Nueva Guinea', 'pg', 1),
(171, 'Paraguay', 'py', 1),
(172, 'Paises Bajos', 'nl', 1),
(173, 'Peru', 'pe', 1),
(174, 'Polinesia Francesa', 'pf', 1),
(175, 'Polonia', 'pl', 1),
(176, 'Portugal', 'pt', 1),
(177, 'Puerto Rico', 'pr', 1),
(178, 'Qatar', 'qa', 1),
(179, 'Reino Unido', 'gb', 1),
(180, 'Republica Centroafricana', 'cf', 1),
(181, 'Republica Checa', 'cz', 1),
(182, 'Republica Democratica del Congo', 'cd', 1),
(183, 'Republica Dominicana', 'do', 1),
(184, 'Republica de Macedonia', 'mk', 1),
(185, 'Republica del Congo', 'cg', 1),
(186, 'Republica Arabe Saharaui Democratica', 'eh', 1),
(187, 'Reunion', 're', 1),
(188, 'Ruanda', 'rw', 1),
(189, 'Rumania', 'ro', 1),
(190, 'Rusia', 'ru', 1),
(191, 'Saint-Martin', 'mf', 1),
(192, 'Samoa', 'ws', 1),
(193, 'Samoa Americana', 'as', 1),
(194, 'San Bartolome', 'bl', 1),
(195, 'San Cristobal y Nieves', 'kn', 1),
(196, 'San Marino', 'sm', 1),
(197, 'San Pedro y Miquelon', 'pm', 1),
(198, 'San Vicente y las Granadinas', 'vc', 1),
(199, 'Santa Helena', 'sh', 1),
(200, 'Santa Lucia', 'lc', 1),
(201, 'Sao Tome y Principe', 'st', 1),
(202, 'Senegal', 'sn', 1),
(203, 'Serbia', 'rs', 1),
(204, 'Seychelles', 'sc', 1),
(205, 'Sierra Leona', 'sl', 1),
(206, 'Singapur', 'sg', 1),
(207, 'Siria', 'sy', 1),
(208, 'Somalia', 'so', 1),
(209, 'Sri Lanka', 'lk', 1),
(210, 'Suazilandia', 'sz', 1),
(211, 'Sudafrica', 'za', 1),
(212, 'Sudan', 'sd', 1),
(213, 'Suecia', 'se', 1),
(214, 'Suiza', 'ch', 1),
(215, 'Surinam', 'sr', 1),
(216, 'Svalbard y Jan Mayen', 'sj', 1),
(217, 'Tailandia', 'th', 1),
(218, 'Taiwan', 'tw', 1),
(219, 'Tanzania', 'tz', 1),
(220, 'Tayikistan', 'tj', 1),
(221, 'Territorio Britanico del Oceano Indico', 'io', 1),
(222, 'Territorios Australes Franceses', 'tf', 1),
(223, 'Territorios palestinos', 'ps', 1),
(224, 'Timor Oriental', 'tl', 1),
(225, 'Togo', 'tg', 1),
(226, 'Tokelau', 'tk', 1),
(227, 'Tonga', 'to', 1),
(228, 'Trinidad y Tobago', 'tt', 1),
(229, 'Turkmenistan', 'tm', 1),
(230, 'Turquia', 'tr', 1),
(231, 'Tuvalu', 'tv', 1),
(232, 'Tunez', 'tn', 1),
(233, 'Ucrania', 'ua', 1),
(234, 'Uganda', 'ug', 1),
(235, 'Uruguay', 'uy', 1),
(236, 'Uzbekistan', 'uz', 1),
(237, 'Vanuatu', 'vu', 1),
(238, 'Venezuela', 've', 1),
(239, 'Vietnam', 'vn', 1),
(240, 'Wallis y Futuna', 'wf', 1),
(241, 'Yemen', 'ye', 1),
(242, 'Yibuti', 'dj', 1),
(243, 'Zambia', 'zm', 1),
(244, 'Zimbabue', 'zw', 1);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `smf_permissions`
--

CREATE TABLE IF NOT EXISTS `smf_permissions` (
  `ID_GROUP` smallint(5) NOT NULL DEFAULT '0',
  `permission` varchar(30) NOT NULL DEFAULT '',
  `addDeny` tinyint(4) NOT NULL DEFAULT '1',
  PRIMARY KEY (`ID_GROUP`,`permission`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Volcado de datos para la tabla `smf_permissions`
--

INSERT INTO `smf_permissions` (`ID_GROUP`, `permission`, `addDeny`) VALUES
(1, 'shop_main', 1),
(1, 'shop_buy', 1),
(1, 'shop_invother', 1),
(1, 'shop_sendmoney', 1),
(1, 'shop_senditems', 1),
(1, 'shop_bank', 1),
(1, 'shop_trade', 1),
(3, 'shop_main', 1),
(3, 'shop_buy', 1),
(3, 'shop_invother', 1),
(3, 'shop_sendmoney', 1),
(3, 'shop_senditems', 1),
(3, 'shop_bank', 1),
(3, 'shop_trade', 1),
(7, 'search_posts', 1),
(2, 'search_posts', 1),
(0, 'smfgallery_view', 1),
(-1, 'who_view', 1),
(0, 'shop_sendmoney', 1),
(-1, 'view_stafflist', 1),
(0, 'smfgallery_add', 1),
(0, 'pm_send', 1),
(0, 'who_view', 1),
(0, 'view_stats', 1),
(7, 'profile_remote_avatar', 1),
(2, 'profile_title_own', 1),
(2, 'profile_extra_own', 1),
(2, 'profile_identity_own', 1),
(2, 'profile_view_any', 1),
(2, 'profile_view_own', 1),
(2, 'smfgallery_manage', 1),
(2, 'smfgallery_autoapprove', 1),
(2, 'smfgallery_report', 1),
(2, 'smfgallery_comment', 1),
(2, 'smfgallery_edit', 1),
(7, 'pm_read', 1),
(7, 'pm_send', 1),
(7, 'profile_extra_own', 1),
(7, 'profile_identity_own', 1),
(2, 'profile_remote_avatar', 1),
(7, 'profile_view_any', 1),
(7, 'profile_view_own', 1),
(0, 'search_posts', 1),
(7, 'shop_main', 1),
(7, 'shop_sendmoney', 1),
(7, 'smfgallery_add', 1),
(7, 'smfgallery_autoapprove', 1),
(7, 'smfgallery_comment', 1),
(7, 'smfgallery_delete', 1),
(7, 'smfgallery_edit', 1),
(7, 'smfgallery_report', 1),
(7, 'smfgallery_view', 1),
(7, 'view_stafflist', 1),
(7, 'view_stats', 1),
(0, 'shop_main', 1),
(0, 'view_stafflist', 1),
(0, 'pm_read', 1),
(2, 'smfgallery_delete', 1),
(2, 'smfgallery_add', 1),
(2, 'smfgallery_view', 1),
(2, 'shop_sendmoney', 1),
(2, 'shop_main', 1),
(2, 'pm_send', 1),
(2, 'pm_read', 1),
(2, 'manage_bans', 1),
(2, 'edit_news', 1),
(2, 'manage_boards', 1),
(2, 'view_stafflist', 1),
(-1, 'search_posts', 1),
(2, 'view_mlist', 1),
(2, 'view_stats', 1),
(0, 'pcomments_view', 1),
(0, 'pcomments_add', 1),
(0, 'pcomments_edit_own', 1),
(0, 'pcomments_delete_own', 1),
(0, 'pcomments_autocomment', 1),
(-1, 'smfgallery_view', 1),
(-1, 'profile_view_own', 1),
(-1, 'profile_view_any', 1),
(0, 'smfgallery_edit', 1),
(0, 'smfgallery_delete', 1),
(0, 'smfgallery_comment', 1),
(0, 'smfgallery_report', 1),
(0, 'smfgallery_autoapprove', 1),
(0, 'profile_view_own', 1),
(0, 'profile_view_any', 1),
(0, 'profile_identity_own', 1),
(0, 'profile_extra_own', 1),
(0, 'profile_title_own', 1),
(0, 'profile_remote_avatar', 1);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `smf_personal_messages`
--

CREATE TABLE IF NOT EXISTS `smf_personal_messages` (
  `ID_PM` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `ID_MEMBER_FROM` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `deletedBySender` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `fromName` tinytext NOT NULL,
  `msgtime` int(10) unsigned NOT NULL DEFAULT '0',
  `subject` tinytext NOT NULL,
  `body` mediumtext NOT NULL,
  PRIMARY KEY (`ID_PM`),
  KEY `ID_MEMBER` (`ID_MEMBER_FROM`,`deletedBySender`),
  KEY `msgtime` (`msgtime`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `smf_pm_recipients`
--

CREATE TABLE IF NOT EXISTS `smf_pm_recipients` (
  `ID_PM` int(10) unsigned NOT NULL DEFAULT '0',
  `ID_MEMBER` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `labels` varchar(60) NOT NULL DEFAULT '-1',
  `bcc` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `is_read` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `deleted` tinyint(3) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`ID_PM`,`ID_MEMBER`),
  UNIQUE KEY `ID_MEMBER` (`ID_MEMBER`,`deleted`,`ID_PM`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `smf_points_per_day`
--

CREATE TABLE IF NOT EXISTS `smf_points_per_day` (
  `ID_MEMBER` int(11) NOT NULL,
  `points` int(11) NOT NULL,
  PRIMARY KEY (`ID_MEMBER`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `smf_privacy`
--

CREATE TABLE IF NOT EXISTS `smf_privacy` (
  `ID_MEMBER` mediumint(8) NOT NULL,
  `stream_post` tinyint(1) NOT NULL DEFAULT '0',
  `stream_see_follows` tinyint(1) NOT NULL DEFAULT '0',
  `stream_allow_comments` tinyint(1) NOT NULL DEFAULT '1',
  `stream_see_likes` tinyint(1) NOT NULL DEFAULT '1',
  `profile_show_mail` tinyint(1) NOT NULL DEFAULT '0',
  `profile_show_info` tinyint(1) NOT NULL DEFAULT '0',
  `profile_show_followers` tinyint(1) NOT NULL DEFAULT '1',
  `profile_show_following` tinyint(1) NOT NULL DEFAULT '1',
  `profile_show_fotos` tinyint(1) NOT NULL DEFAULT '1',
  `followers_show_mail` tinyint(1) NOT NULL DEFAULT '0',
  `followers_show_info` tinyint(1) NOT NULL DEFAULT '0',
  `followers_show_followers` tinyint(1) NOT NULL DEFAULT '1',
  `followers_show_following` tinyint(1) NOT NULL DEFAULT '1',
  `followers_show_fotos` int(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`ID_MEMBER`),
  UNIQUE KEY `ID_MEMBER` (`ID_MEMBER`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `smf_puntos`
--

CREATE TABLE IF NOT EXISTS `smf_puntos` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_post` varchar(30) COLLATE utf8_spanish_ci DEFAULT NULL,
  `id_member` text COLLATE utf8_spanish_ci NOT NULL,
  `amount` varchar(30) COLLATE utf8_spanish_ci DEFAULT NULL,
  `time` int(11) NOT NULL,
  `date` date NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `smf_sessions`
--

CREATE TABLE IF NOT EXISTS `smf_sessions` (
  `session_id` varchar(32) NOT NULL DEFAULT '',
  `last_update` int(10) unsigned NOT NULL DEFAULT '0',
  `data` mediumtext NOT NULL,
  PRIMARY KEY (`session_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `smf_settings`
--

CREATE TABLE IF NOT EXISTS `smf_settings` (
  `variable` tinytext NOT NULL,
  `value` mediumtext NOT NULL,
  PRIMARY KEY (`variable`(30))
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Volcado de datos para la tabla `smf_settings`
--

INSERT INTO `smf_settings` (`variable`, `value`) VALUES
('smfVersion', '1.1.13'),
('news', 'Spirate v2.4 BETA'),
('enableReportPM', '1'),
('compactTopicPagesContiguous', '4'),
('compactTopicPagesEnable', '1'),
('enableStickyTopics', '1'),
('todayMod', '0'),
('karmaMode', '0'),
('karmaTimeRestrictAdmins', '1'),
('enablePreviousNext', '0'),
('pollMode', '0'),
('enableVBStyleLogin', '1'),
('enableCompressedOutput', '0'),
('karmaWaitTime', '0'),
('karmaMinPosts', '0'),
('karmaLabel', ''),
('karmaSmiteLabel', ''),
('karmaApplaudLabel', ''),
('attachmentSizeLimit', '0'),
('attachmentPostLimit', '0'),
('attachmentNumPerPostLimit', '1'),
('attachmentDirSizeLimit', '0'),
('attachmentUploadDir', ''),
('attachmentExtensions', 'gif,jpg,png,bmp'),
('attachmentCheckExtensions', '1'),
('attachmentShowImages', '0'),
('attachmentEnable', '0'),
('attachmentEncryptFilenames', '0'),
('attachmentThumbnails', '0'),
('attachmentThumbWidth', '0'),
('attachmentThumbHeight', '0'),
('censorIgnoreCase', '1'),
('mostOnline', '0'),
('mostOnlineToday', '0'),
('mostDate', '1209925058'),
('allow_disableAnnounce', '1'),
('trackStats', '1'),
('userLanguage', '0'),
('titlesEnable', '1'),
('topicSummaryPosts', '9999999'),
('enableErrorLogging', '0'),
('max_image_width', '800'),
('max_image_height', '0'),
('onlineEnable', '1'),
('cal_holidaycolor', '80'),
('cal_bdaycolor', '920AC4'),
('cal_eventcolor', '78907'),
('cal_enabled', '0'),
('cal_maxyear', '2010'),
('cal_minyear', '2004'),
('cal_daysaslink', '0'),
('cal_defaultboard', ''),
('cal_showeventsonindex', '0'),
('cal_showbdaysonindex', '0'),
('cal_showholidaysonindex', '0'),
('cal_showeventsoncalendar', '1'),
('cal_showbdaysoncalendar', '1'),
('cal_showholidaysoncalendar', '1'),
('cal_showweeknum', '0'),
('cal_maxspan', '7'),
('smtp_host', ''),
('smtp_port', '25'),
('smtp_username', ''),
('smtp_password', ''),
('mail_type', '0'),
('timeLoadPageEnable', '0'),
('totalTopics', '0'),
('totalMessages', '0'),
('simpleSearch', '1'),
('censor_vulgar', 'identi.li\nidenti.es'),
('censor_proper', '¡Ladrones!\n¡Ladrones!'),
('enablePostHTML', '0'),
('theme_allow', '0'),
('theme_default', '0'),
('theme_guests', '1'),
('enableEmbeddedFlash', '1'),
('xmlnews_enable', '1'),
('xmlnews_maxlen', '255'),
('hotTopicPosts', '20'),
('hotTopicVeryPosts', '50'),
('registration_method', '0'),
('send_validation_onChange', '1'),
('send_welcomeEmail', '0'),
('allow_editDisplayName', '0'),
('allow_hideOnline', '0'),
('allow_hideEmail', '1'),
('guest_hideContacts', '1'),
('spamWaitTime', '10'),
('pm_spam_settings', '5,0,0'),
('reserveWord', '1'),
('reserveCase', '1'),
('reserveUser', '1'),
('reserveName', '1'),
('reserveNames', 'Jesus'),
('autoLinkUrls', '1'),
('banLastUpdated', '1296068055'),
('smileys_dir', '{$boarddir}/Smileys'),
('smileys_url', '{$boardurl}/Smileys'),
('avatar_directory', ''),
('avatar_url', ''),
('avatar_max_height_external', '0'),
('avatar_max_width_external', '115'),
('avatar_action_too_large', 'option_html_resize'),
('avatar_max_height_upload', '0'),
('avatar_max_width_upload', '125'),
('avatar_resize_upload', '0'),
('avatar_download_png', '1'),
('failed_login_threshold', '5'),
('oldTopicDays', '0'),
('edit_wait_time', '5'),
('edit_disable_time', '0'),
('autoFixDatabase', '1'),
('allow_guestAccess', '1'),
('time_format', '%d de %B, %Y. %I:%M:%S %p'),
('number_format', '1234.00'),
('enableBBC', '1'),
('max_messageLength', '65536'),
('max_signatureLength', '400'),
('autoOptDatabase', '7'),
('autoOptMaxOnline', '0'),
('autoOptLastOpt', '1355940689'),
('defaultMaxMessages', '3'),
('defaultMaxTopics', '40'),
('defaultMaxMembers', '10'),
('enableParticipation', '0'),
('recycle_enable', '0'),
('recycle_board', '0'),
('maxMsgID', '49'),
('enableAllMessages', '0'),
('fixLongWords', '0'),
('knownThemes', '1,2'),
('who_enabled', '1'),
('time_offset', '0'),
('cookieTime', '3153600'),
('lastActive', '15'),
('smiley_sets_known', 'default,smiley-krystl-png-1_0'),
('smiley_sets_names', 'Default\nsmiley-krystl-png-1_0'),
('smiley_sets_default', 'default'),
('cal_days_for_index', '7'),
('requireAgreement', '1'),
('unapprovedMembers', '0'),
('default_personalText', ''),
('package_make_backups', ''),
('databaseSession_enable', '1'),
('databaseSession_loose', '1'),
('databaseSession_lifetime', '2880'),
('search_cache_size', '50'),
('search_results_per_page', '1'),
('search_weight_frequency', '30'),
('search_weight_age', '25'),
('search_weight_length', '20'),
('search_weight_subject', '15'),
('search_weight_first_message', '10'),
('search_max_results', '0'),
('permission_enable_deny', '0'),
('permission_enable_postgroups', '0'),
('permission_enable_by_board', '0'),
('localCookies', '1'),
('default_timezone', 'Etc/GMT-1'),
('memberlist_updated', '1356382900'),
('latestMember', '1'),
('totalMembers', '1'),
('latestRealName', ''),
('mostOnlineUpdated', '2008-08-07'),
('cal_today_updated', '20121222'),
('cal_today_holiday', 'a:0:{}'),
('gallery_max_height', '0'),
('cal_today_birthday', 'a:0:{}'),
('global_announcements_enable', '0'),
('global_announcements_sort_by', 'subject'),
('signature_settings', '1,400,0,0,0,359,235,0:strike,ed2k,email,ftp,flash,swf,hr,googlevid,html,size,sub,sup,shadow,time,table,ytplaylist,youtube,hide'),
('cpgDisable', '1'),
('cpgPrefix', ''),
('ajaxregEnabled', '0'),
('ajaxregFailureCSS', ''),
('cal_today_event', 'a:0:{}'),
('topbottomEnable', '0'),
('enableSpellChecking', '0'),
('hide_posUnhiddenText', '4'),
('hide_hiddentext', 'Mensaje oculto, Responde Al Tema.'),
('gallery_max_filesize', '26000000'),
('sbox_Visible', '1'),
('sbox_ModsRule', '1'),
('sbox_DoHistory', '1'),
('sbox_GuestVisible', '0'),
('sbox_GuestAllowed', '0'),
('minChar', '0'),
('shopDate', '18th January 2007'),
('shopVersion', '3.0'),
('enable_buddylist', '1'),
('modlog_enabled', '1'),
('queryless_urls', '0'),
('er_who', 'anyone'),
('search_pointer', '3'),
('messageIcons_enable', '1'),
('sbox_Height', '138'),
('smfstaff_showlastactive', ''),
('country_flag_ask', '3'),
('country_flag_required', '1'),
('country_flag_show', '1'),
('smiley_enable', '1'),
('sbox_RefreshTime', '10'),
('smfstaff_showdateregistered', ''),
('smfstaff_showcontactinfo', ''),
('smfstaff_showlocalmods', '1'),
('hide_autounhidegroups', '1,2,3,7,5,6'),
('seo4smf_board_topic', 'on'),
('thankYouPostDisableUnhide', '0'),
('thankYouPostThxUnhideAll', '1'),
('thankYouPostPreviewOrder', '0'),
('thankYouPostFullOrder', '2'),
('thankYouPostUnhidePost', '1'),
('thankYouPostPreviewHM', '900'),
('thankYouPostPreview', '1'),
('thankYouPostDisplayPage', '0'),
('thankYouPostColors', '1'),
('thankYouPostOnePerPost', '0'),
('seo4smf_utf8_language', ''),
('sbox_AllowBBC', '1'),
('sbox_UserLinksVisible', '1'),
('sbox_GuestBBC', '0'),
('sbox_NewShoutsBar', '0'),
('sbox_MaxLines', '50'),
('smfstaff_showavatar', ''),
('shopCurrencyPrefix', ''),
('shopBuild', '12'),
('shopCurrencySuffix', ' Puntos'),
('shopPointsPerTopic', '1'),
('shopPointsPerPost', '0'),
('shopInterest', '0'),
('shopBankEnabled', '0'),
('shopImageWidth', '0'),
('shopImageHeight', '0'),
('shopTradeEnabled', '0'),
('shopItemsPerPage', '0'),
('shopMinDeposit', '0'),
('shopMinWithdraw', '0'),
('shopRegAmount', '0'),
('shopPointsPerWord', '0'),
('shopPointsPerChar', '0'),
('shopPointsLimit', '0'),
('shopFeeWithdraw', '0'),
('shopFeeDeposit', '0'),
('package_server', 'smallpirate.com'),
('package_port', '21'),
('package_username', 'Spirate'),
('sbox_BlockRefresh', '1'),
('sbox_SmiliesVisible', '1'),
('sitemap_xml', '1'),
('sitemap_topic_count', '90000'),
('sitemap_collapsible', '1'),
('password_strength', '1'),
('disable_visual_verification', '4'),
('hitStats', '1'),
('pm_register_from', 'Staff'),
('pm_register_enable', '0'),
('pm_register_body', '&amp;#039;Bienvenido/a &amp;quot;&amp;lt;b&amp;gt;{$username}&amp;lt;/b&amp;gt;&amp;quot;. Esperamos que te pases de nuevo por aqui, hagas tus aportes y preguntas. Te invitamos a que disfrutes&lt;br /&gt;&lt;br /&gt;El equipo del foro&lt;br /&gt;{$boardname}.'),
('pm_register_subject', 'Bienvenido'),
('sbox_EnableSounds', '0'),
('sbox_FontFamily', 'Arial, Helvetica, sans-serif'),
('sbox_TextSize', 'x-small'),
('sbox_TextColor1', '#CC780A'),
('sbox_DarkThemes', ''),
('sbox_TextColor2', ''),
('coppaAge', '0'),
('search_match_words', '0'),
('search_index', 'custom'),
('search_custom_index_config', 'a:1:{s:14:"bytes_per_word";i:5;}'),
('minWordLen', '0'),
('hide_enableHTML', '0'),
('hide_useSpanTag', '0'),
('convert_urls', '1'),
('ajaxregSuccessCSS', ''),
('censorWholeWord', '1'),
('gallery_max_width', '0'),
('gallery_who_viewing', '0'),
('gallery_commentchoice', '0'),
('gallery_shop_picadd', '0'),
('gallery_shop_commentadd', '0'),
('gallery_set_showcode_bbc_image', '1'),
('gallery_set_showcode_directlink', '1'),
('gallery_set_showcode_htmllink', '1'),
('gallery_path', '{$boarddirl}/web/img/'),
('gallery_url', ''),
('global_character_set', 'UTF-8'),
('googletagged', '1'),
('allow_hiddenPost', '1'),
('show_hiddenMessage', '1'),
('max_hiddenValue', '500'),
('show_hiddenColor', 'red'),
('smftags_set_mintaglength', '3'),
('smftags_set_maxtaglength', '30'),
('smftags_set_maxtags', '10'),
('googletagged_together', '0'),
('avatar_download_external', '0'),
('global_announcements_sort_direction', 'ASC'),
('$key', '$value'),
('countChildPosts', '0'),
('search_stopwords', '101633002,227306032,310420379,387173358,606874276,665419812,710950976,740110935,760859284,780080978,807858898,918151391,943141432'),
('cache_enable', '1'),
('cache_memcached', ''),
('anuncio1', 'Publicidad Destacado'),
('publi', 'Publicidad'),
('cant_album', '10'),
('pag_recent', '5'),
('cant_img_recent', '20'),
('thumbnail', '1'),
('act_publi', '1'),
('anuncio2', 'publicidad en el buscador'),
('anuncio3', 'Perfil de usuario'),
('anuncio4', 'Publicidad Registro'),
('anuncio5', 'Publicidad Logo'),
('top_post_act', '1356389734'),
('ancho_del_logo', ''),
('anuncio6', 'Publicidad Favoritos'),
('enlaces', '<a target="_blank" href="http://Spirate.net">Spirate</a>,\r\n<a target="_blank" href="http://NutHost.com">NutHost</a>,\r\n<a target="_blank" href="http://TecnoBite.net">TecnoBite</a>\r\n\r\n'),
('meta_description', 'spirate, small, pirate, descargas, descarga, dvdrip, imagen, musica, juegos, espanol, pc, peliculas, msn, cookies, jdownloader'),
('meta_keywords', 'spirate, small, pirate, descargas, descarga, dvdrip, imagen, musica, juegos, espanol, pc, peliculas, msn, cookies, jdownloader'),
('meta_author', 'Small Pirate'),
('meta_copyright', '&copy; Copyright 2011'),
('hide_enableUnhiddenText', '0'),
('custom_avatar_enabled', '1'),
('custom_avatar_dir', ''),
('date_points', '20121225'),
('rand_seed', '1287618781'),
('0', 'smfVersion'),
('1', 'SMF 1.1.13'),
('denuncias_activar', '1'),
('cant_pun', '3'),
('gestorbloques', '0'),
('monitorcant', ''),
('monitorpubli', ''),
('por_puntos', '0'),
('por_posts', '1'),
('globalCookies', '1'),
('activar_el_disenador', '1'),
('activar_el_disenador_general', '0'),
('fondoweb_repeat', 'repeat-x'),
('cabeza_repeat', 'repeat-x'),
('interno_repeat', 'no-repeat'),
('elegir_tipo', 'bold'),
('elegir_letra', 'arial'),
('activar_el_disenador_menu', '0'),
('barra_tipo', 'normal'),
('barra_letra', 'Georgia'),
('activar_el_disenador_bloques', '0'),
('activar_el_disenador_display', '0'),
('coment_repeat', 'repeat'),
('url_cabeza', ''),
('amigables', '1'),
('color_titulos_box', '#9AC720'),
('color_infocabezal', '#DAE5EB'),
('alto_del_logo', '#A2D42D'),
('color_cabeza', '#83C326'),
('fondo_borde_azul', '#FF0F0F'),
('borde_azul', '#FF0000'),
('color_fondo_interno', '#FFFFFF'),
('borde_fondo_interno', '#CCCCCC'),
('color_texto', '#292929'),
('color_de_enlaces', '#2259AB'),
('color_de_enlaces_hover', '#3091FF'),
('infoc_border_left', '#B0CFDF'),
('infoc_border_top', '#B0CFDF'),
('infoc_border_right', '#B0CFDF'),
('infoc_border_bottom', '#B0CFDF'),
('color_coment', '#EBEBEB'),
('cc_border_left', '#8799A6'),
('cc_border_top', '#FFFFFF'),
('cc_border_right', '#8799A6'),
('cc_border_bottom', '#8799A6'),
('infoccolor_texto', '#718594'),
('ccolor_texto', '#454545'),
('color_barra', '#616161'),
('color_barra_back', '#C2C2C2'),
('color_barra_back_hover', '#FFF7F7'),
('color_barra_hover', '#FFF7F7'),
('barra_border_left', '#E3E3E3'),
('barra_border_right', '#999999'),
('color_text_barra', '#303030'),
('box_title_border_left', '#8EB81E'),
('barra_height', '15px'),
('barra_hover', ''),
('box_title_border_right', '#8EB81E'),
('barra_back', ''),
('box_title_border_top', '#8EB81E'),
('barra', ''),
('box_title_border_bottom', '#6F8F17'),
('text_titulos_box', '#1E68B3'),
('color_fondo_de_bloques', '#EBEBEB'),
('box_cuerpo_border_left', '#CCCCCC'),
('box_cuerpo_border_top', '#CCCCCC'),
('box_cuerpo_border_right', '#CCCCCC'),
('box_cuerpo_border_bottom', '#CCCCCC'),
('tamano_titulos_box', '13px'),
('url_infocabezal', 'http://sp.piribin.com/Themes/default/images/title.png'),
('url_coment', ''),
('banned_passwords', '12345, 111111, 11111111, 112233, 121212, 123123, 123456, 1234567, 12345678, 131313, 232323, 654321, 666666, 696969, 777777, 7777777, 8675309, 987654, aaaaaa, abc123, abc123, abcdef, abgrtyu, access, access14, action, albert, alexis, amanda, amateur, andrea, andrew, angela, angels, animal, anthony, apollo, apples, arsenal, arthur, asdfgh, asdfgh, ashley, asshole, august, austin, badboy, bailey, banana, barney, baseball, batman, beaver, beavis, bigcock, bigdaddy, bigdick, bigdog, bigtits, birdie, bitches, biteme, blazer, blonde, blondes, blowjob, blowme, bond007, bonnie, booboo, booger, boomer, boston, brandon, brandy, braves, brazil, bronco, broncos, bulldog, buster, butter, butthead, calvin, camaro, cameron, canada, captain, carlos, carter, casper, charles, charlie, cheese, chelsea, chester, chicago, chicken, cocacola, coffee, college, compaq, computer, cookie, cooper, corvette, cowboy, cowboys, crystal, cumming, cumshot, dakota, dallas, daniel, danielle, debbie, dennis, diablo, diamond, doctor, doggie, dolphin, dolphins, donald, dragon, dreams, driver, eagle1, eagles, edward, einstein, erotic, extreme, falcon, fender, ferrari, firebird, fishing, florida, flower, flyers, football, forever, freddy, freedom, fucked, fucker, fucking, fuckme, fuckyou, gandalf, gateway, gators, gemini, george, giants, ginger, golden, golfer, gordon, gregory, guitar, gunner, hammer, hannah, hardcore, harley, heather, helpme, hentai, hockey, hooters, horney, hotdog, hunter, hunting, iceman, iloveyou, internet, iwantu, jackie, jackson, jaguar, jasmine, jasper, jennifer, jeremy, jessica, johnny, johnson, jordan, joseph, joshua, junior, justin, killer, knight, ladies, lakers, lauren, leather, legend, letmein, letmein, little, london, lovers, maddog, madison, maggie, magnum, marine, marlboro, martin, marvin, master, matrix, matthew, maverick, maxwell, melissa, member, mercedes, merlin, michael, michelle, mickey, midnight, miller, mistress, monica, monkey, monkey, monster, morgan, mother, mountain, muffin, murphy, mustang, naked, nascar, nathan, naughty, ncc1701, newyork, nicholas, nicole, nipple, nipples, oliver, orange, packers, panther, panties, parker, password, password, password1, password12, password123, patrick, peaches, peanut, pepper, phantom, phoenix, player, please, pookie, porsche, prince, princess, private, purple, pussies, qazwsx, qwerty, qwertyui, rabbit, rachel, racing, raiders, rainbow, ranger, rangers, rebecca, redskins, redsox, redwings, richard, robert, rocket, rosebud, runner, rush2112, russia, samantha, sammy, samson, sandra, saturn, scooby, scooter, scorpio, scorpion, secret, sexsex, shadow, shannon, shaved, sierra, silver, skippy, slayer, smokey, snoopy, soccer, sophie, spanky, sparky, spider, squirt, srinivas, startrek, starwars, steelers, steven, sticky, stupid, success, suckit, summer, sunshine, superman, surfer, swimming, sydney, taylor, tennis, teresa, tester, testing, theman, thomas, thunder, thx1138, tiffany, tigers, tigger, tomcat, topgun, toyota, travis, trouble, trustno1, tucker, turtle, twitter, united, vagina, victor, victoria, viking, voodoo, voyager, walter, warrior, welcome, whatever, william, willie, wilson, winner, winston, winter, wizard, xavier, xxxxxx, xxxxxxxx, yamaha, yankee, yankees, yellow, zxcvbn, zxcvbnm, zzzzzz, ice la creyo, j0n4th4ntub3, kaissar se la come, rancio, jonathanredtube, alcapone, spirate, chocolate cake, kspr1, spirate, drago'),
('enable_fastRegister', '1'),
('message_after_register', 'Bienvenido {name} a {pagename},\r\ngracias por registrarte! da click en aceptar para loguearte.'),
('api_public_key_recaptcha', ''),
('limit_age', '0'),
('visual_verification', 'captcha'),
('api_private_key_recaptcha', ''),
('auto_login_regAjax', '1'),
('lastUpdateStreamAttachs', '1340622710'),
('totalComments', '0');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `smf_shop_categories`
--

CREATE TABLE IF NOT EXISTS `smf_shop_categories` (
  `id` smallint(5) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(50) NOT NULL,
  `count` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `smf_shop_inventory`
--

CREATE TABLE IF NOT EXISTS `smf_shop_inventory` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `ownerid` int(10) unsigned NOT NULL,
  `itemid` int(10) unsigned NOT NULL,
  `amtpaid` int(10) unsigned NOT NULL DEFAULT '0',
  `trading` tinyint(1) unsigned NOT NULL,
  `tradecost` int(10) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `smf_shop_items`
--

CREATE TABLE IF NOT EXISTS `smf_shop_items` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(50) NOT NULL DEFAULT '',
  `desc` mediumtext NOT NULL,
  `price` int(10) unsigned NOT NULL DEFAULT '0',
  `module` tinytext NOT NULL,
  `stock` smallint(6) NOT NULL DEFAULT '0',
  `info1` mediumtext NOT NULL,
  `info2` mediumtext NOT NULL,
  `info3` mediumtext NOT NULL,
  `info4` mediumtext NOT NULL,
  `input_needed` tinyint(3) unsigned NOT NULL DEFAULT '1',
  `can_use_item` tinyint(3) unsigned NOT NULL DEFAULT '1',
  `delete_after_use` tinyint(1) unsigned NOT NULL DEFAULT '1',
  `image` tinytext NOT NULL,
  `category` smallint(6) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `smf_smileys`
--

CREATE TABLE IF NOT EXISTS `smf_smileys` (
  `ID_SMILEY` smallint(5) unsigned NOT NULL AUTO_INCREMENT,
  `code` varchar(30) NOT NULL DEFAULT '',
  `filename` varchar(48) NOT NULL DEFAULT '',
  `description` varchar(80) NOT NULL DEFAULT '',
  `smileyRow` tinyint(4) unsigned NOT NULL DEFAULT '0',
  `smileyOrder` smallint(5) unsigned NOT NULL DEFAULT '0',
  `hidden` tinyint(4) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`ID_SMILEY`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `smf_stats`
--

CREATE TABLE IF NOT EXISTS `smf_stats` (
  `variable` tinytext NOT NULL,
  `total` mediumtext NOT NULL,
  PRIMARY KEY (`variable`(30))
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `smf_substream`
--

CREATE TABLE IF NOT EXISTS `smf_substream` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `ID_STREAM_COMMENT` mediumint(10) NOT NULL,
  `ID_MEMBER` mediumint(10) NOT NULL,
  `COMMENT` longtext CHARACTER SET utf8 NOT NULL,
  `DATE` varchar(75) CHARACTER SET utf8 NOT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `smf_themes`
--

CREATE TABLE IF NOT EXISTS `smf_themes` (
  `ID_MEMBER` mediumint(8) NOT NULL DEFAULT '0',
  `ID_THEME` tinyint(4) unsigned NOT NULL DEFAULT '1',
  `variable` tinytext NOT NULL,
  `value` mediumtext NOT NULL,
  PRIMARY KEY (`ID_THEME`,`ID_MEMBER`,`variable`(30)),
  KEY `ID_MEMBER` (`ID_MEMBER`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Volcado de datos para la tabla `smf_themes`
--

INSERT INTO `smf_themes` (`ID_MEMBER`, `ID_THEME`, `variable`, `value`) VALUES
(0, 1, 'name', 'Spirate Tema Predeterminado'),
(0, 1, 'theme_url', '{$boardurl}/Themes/default'),
(0, 1, 'images_url', '{$boardurl}/Themes/default/images'),
(0, 1, 'theme_dir', '{$boarddir}/Themes/default'),
(0, 1, 'show_bbc', '1'),
(0, 1, 'show_latest_member', '1'),
(0, 1, 'show_modify', '1'),
(0, 1, 'show_user_images', '1'),
(0, 1, 'show_blurb', '1'),
(0, 1, 'show_gender', '1'),
(0, 1, 'show_newsfader', '0'),
(0, 1, 'number_recent_posts', '10'),
(0, 1, 'show_member_bar', '1'),
(0, 1, 'linktree_link', '1'),
(0, 1, 'show_profile_buttons', '1'),
(0, 1, 'show_mark_read', '1'),
(0, 1, 'show_sp1_info', '1'),
(0, 1, 'linktree_inline', '0'),
(0, 1, 'show_board_desc', '1'),
(0, 1, 'newsfader_time', '5000'),
(0, 1, 'allow_no_censored', '0'),
(0, 1, 'additional_options_collapsable', '0'),
(0, 1, 'use_image_buttons', '1'),
(0, 1, 'enable_news', '0'),
(-1, 1, 'show_board_desc', '0'),
(-1, 1, 'show_children', '0'),
(-1, 1, 'show_no_avatars', '0'),
(-1, 1, 'show_no_signatures', '0'),
(-1, 1, 'show_no_censored', '0'),
(-1, 1, 'return_to_post', '0'),
(-1, 1, 'no_new_reply_warning', '0'),
(-1, 1, 'view_newest_first', '0'),
(-1, 1, 'view_newest_pm_first', '0'),
(-1, 1, 'popup_messages', '0'),
(-1, 1, 'copy_to_outbox', '0'),
(-1, 1, 'auto_notify', '0'),
(-1, 1, 'calendar_start_day', '1'),
(-1, 1, 'display_quick_reply', '2'),
(-1, 1, 'display_quick_mod', '1'),
(0, 1, 'header_logo_url', ''),
(0, 1, 'display_who_viewing', '0'),
(0, 1, 'smiley_sets_default', ''),
(0, 1, 'hide_post_group', '1');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `smf_topics`
--

CREATE TABLE IF NOT EXISTS `smf_topics` (
  `ID_TOPIC` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `isSticky` tinyint(4) NOT NULL DEFAULT '0',
  `ID_BOARD` smallint(5) unsigned NOT NULL DEFAULT '0',
  `ID_FIRST_MSG` int(10) unsigned NOT NULL DEFAULT '0',
  `ID_LAST_MSG` int(10) unsigned NOT NULL DEFAULT '0',
  `ID_MEMBER_STARTED` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `ID_MEMBER_UPDATED` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `numReplies` int(10) unsigned NOT NULL DEFAULT '0',
  `numViews` int(10) unsigned NOT NULL DEFAULT '0',
  `comments` int(10) unsigned NOT NULL DEFAULT '0',
  `bookmarks` int(10) unsigned NOT NULL DEFAULT '0',
  `locked` tinyint(4) NOT NULL DEFAULT '0',
  `puntos` int(15) NOT NULL DEFAULT '0',
  PRIMARY KEY (`ID_TOPIC`),
  UNIQUE KEY `lastMessage` (`ID_LAST_MSG`,`ID_BOARD`),
  UNIQUE KEY `firstMessage` (`ID_FIRST_MSG`,`ID_BOARD`),
  UNIQUE KEY `poll` (`ID_TOPIC`),
  KEY `isSticky` (`isSticky`),
  KEY `ID_BOARD` (`ID_BOARD`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `smf_tops`
--

CREATE TABLE IF NOT EXISTS `smf_tops` (
  `titulo` text NOT NULL,
  `dato` int(11) NOT NULL,
  `id_top` int(11) NOT NULL,
  `cantidad` int(11) NOT NULL,
  `posicion` int(11) NOT NULL,
  `codigo` int(11) NOT NULL,
  `fecha` text NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
