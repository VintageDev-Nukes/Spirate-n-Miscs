<?php

function header_stream(){
	global $context;
	
	
	
	$context['following_list'] = array(
		array('id' => 1, 'name' => 'jonathan', 'avatar' => 'http://localhost/cms/spirate2_4/Themes/default/images/avatar-4.png', 'type' => 'user'),
		array('id' => 2, 'name' => 'shake', 'avatar' => 'http://localhost/cms/spirate2_4/Themes/default/images/avatar-4.png', 'type' => 'user'),
		array('id' => 3, 'name' => 'rancitis', 'avatar' => 'http://localhost/cms/spirate2_4/Themes/default/images/avatar-4.png', 'type' => 'user'),
		array('id' => 4, 'name' => 'kawapanga', 'avatar' => 'http://localhost/cms/spirate2_4/Themes/default/images/avatar-4.png', 'type' => 'user'),
		array('id' => 5, 'name' => 'fivezone', 'avatar' => 'http://localhost/cms/spirate2_4/Themes/default/images/avatar-4.png', 'type' => 'user'),
		array('id' => 6, 'name' => 'uciel', 'avatar' => 'http://localhost/cms/spirate2_4/Themes/default/images/avatar-4.png', 'type' => 'user'),
		array('id' => 7, 'name' => '002', 'avatar' => 'http://localhost/cms/spirate2_4/Themes/default/images/avatar-4.png', 'type' => 'user'),
		array('id' => 8, 'name' => 'jesus', 'avatar' => 'http://localhost/cms/spirate2_4/Themes/default/images/avatar-4.png', 'type' => 'user'),
		array('id' => 9, 'name' => 'rancio', 'avatar' => 'http://localhost/cms/spirate2_4/Themes/default/images/avatar-4.png', 'type' => 'user'),
		array('id' => 10, 'name' => 'ran', 'avatar' => 'http://localhost/cms/spirate2_4/Themes/default/images/avatar-4.png', 'type' => 'user'),
		array('id' => 10, 'name' => 'ran', 'avatar' => 'http://localhost/cms/spirate2_4/Themes/default/images/avatar-4.png', 'type' => 'user'),
		array('id' => 10, 'name' => 'ran', 'avatar' => 'http://localhost/cms/spirate2_4/Themes/default/images/avatar-4.png', 'type' => 'user'),
		array('id' => 10, 'name' => 'ran', 'avatar' => 'http://localhost/cms/spirate2_4/Themes/default/images/avatar-4.png', 'type' => 'user'),
		array('id' => 10, 'name' => 'ran', 'avatar' => 'http://localhost/cms/spirate2_4/Themes/default/images/avatar-4.png', 'type' => 'user'),
		array('id' => 10, 'name' => 'ran', 'avatar' => 'http://localhost/cms/spirate2_4/Themes/default/images/avatar-4.png', 'type' => 'user'),
		array('id' => 10, 'name' => 'ran', 'avatar' => 'http://localhost/cms/spirate2_4/Themes/default/images/avatar-4.png', 'type' => 'user'),
		array('id' => 10, 'name' => 'ran', 'avatar' => 'http://localhost/cms/spirate2_4/Themes/default/images/avatar-4.png', 'type' => 'user'),
	);
	
	echo '
	<script type="text/javascript">
		global.stream = {
			follow_list : ' . (isset($context['following_list']) ? preg_replace('~(\}\,)~', "$1\n\t\t\t\t\t", json_encode($context['following_list'])) : '{}') .',
			privacy : ' .( $context['stream']['user']['privacy'] ?  $context['stream']['user']['privacy'] : 0 ). '
		}
	</script>';
	
}
function template_stream_above(){
	global $context, $settings, $scripturl, $boardurl, $modSettings, $txt, $mbname;
	
	/* set padding container to 0 */    
    echo '
	<style type="text/css">
      #main .globalcontent{
      padding: 0!important;
      min-height: 700px
      }
    </style>';
	
	header_stream();
	
	if( $context['user']['is_guest'] )
	{
	
		echo '<div class="col-left-stream">
			<div class="context">

		<div class="padding-20">
			<p>
				<h3 class="color-orange" style="font-weight: bold;">Interactua con los demas!</h3>
				<div class="color-dark-gray"><strong>'.$mbname.'</strong> te permite interactuar con los dem&aacute;s usuarios, compartir im&aacute;genes, videos, enlaces o simplemente compartir un estado.</div>
				<div style="margin-top: 10px"><input type="button" class="sp-button bluesky" value="Registrate!" rel="registro"> <span class="color-dark-gray">o... <a onclick="loginbox(\'show\');">logueate!</a></span></div>
			</p>
		</div>';
		
	echo '</div></div>';
		  
	}else{
	
	echo '<div class="menu-top-stream clearfix">';
        echo '<div class="menu-post">
                <ul class="attach-options">
                    <li attach="status" class="selected status"><a><i></i>'.$txt['status'].'</a></li>
                    <li attach="link" class="link"><a><i></i>'.$txt['link'].'</a></li>
                    <li attach="video" class="video"><a><i></i>'.$txt['video'].'</a></li>
                    <li attach="image" class="image"><a><i></i>'.$txt['image'].'</a></li>
                </ul>
            </div>';

            echo '<div class="stats">
                <ul>';				
                
                    echo '<li><strong>' . $context['stream']['user']['followers'] . '</strong><span>' . sprintf('%s', $context['stream']['user']['followers'] > 1 || $context['stream']['user']['followers'] == 0 ? 'Seguidores' : 'Seguidor') . '</span></li>
					<li><strong class="count-streams">' . $context['stream']['user']['streams'] . '</strong><span>' . sprintf('%s', $context['stream']['user']['streams'] > 1 ? 'Streams' : 'Stream') . '</span></li>';
					
          echo '</ul>
            </div>
        </div>';

    echo '<div class="col-left-stream">
        <div class="context">';

    
        echo '
    <div class="profile-data clearfix">
        <a class="thumbnail box-shadow-soft"><div class="square" href="#"><img src="'.$context['user']['avatar']['src'].'" class="avatar" style="'.$context['user']['avatar']['coords'][120]['style'].'"></div></a>
        <div class="options">
            <a href="#">'.$txt['edit_account'].'</a>
            <a href="#">'.$txt['edit_profile'].'</a>
        </div>
    </div>
    <a class="nick" href="'.$scripturl.'?action=profile&u='.$context['user']['id'].'">'.$context['user']['name'].'</a>
    <div class="nav">
        <ul>';		
		
        foreach($context['navigation'] as $tab)
            echo '<li', isset($tab['selected']) ? ' class="selected"' : '' ,'><a href="'.$tab['href'].'">'.$tab['text'].'</a></li>';
        echo '</ul>
    </div>';
        
    echo '</div>';

    echo '</div>';
    
	
	}
	
}

function template_main(){
    global $context, $settings, $scripturl, $mbname, $txt;
	
	echo '<div class="main-stream equal-height">';
	
	if( $context['user']['is_logged'] )
	{
	
		echo '<div class="context">';

			echo '
			<div class="post-area clearfix">		
				<div class="stream-input">
					<i class="top-dialog"></i>
					<textarea name="streamContent" class="stream-content with-placeholder rounded" style="height:auto" placeholder="'.$txt['placeholder_new_activity'].'"></textarea>
				</div>
				<div class="attach-post box-shadow-soft rounded hide">
					<strong class="add-txt">Ingresa un link</strong>
					<input type="text" class="attach-link-input">
					<input type="button" class="sp-button green" value="Adjuntar">
				</div>
				<div class="preview-story hide">
					<div id="templateAttachContent" class="streamAttachContext clearfix rounded"></div>
					<a class="removeAttach"></a>
				</div>
				
				<div class="footer-post-area clearfix rounded">				
					<div class="submit-btn clearfix">
						<div class="UIdrop click-to-open privacy inline">
							<span><a class="privacy tt-element" title="'.$context['stream']['privacy-post'][$context['stream']['user']['privacy']][1].'"><i></i></a></span>
							<div class="wrap-dropdown">
								<ul class="box-shadow clearfix" style="width: 180px">';
								
								foreach($context['stream']['privacy-post'] as $id => $privacy)
									echo '
									<li>' . vsprintf('<%s class="%s"%s privacy_id="'. $id .'" title="' . $privacy[1] . '">%s</%s>', $privacy[2] ? array('strong', 'selected', '', $privacy[0], 'strong') : array('a', 'tt-element', ' gravity="e"', $privacy[0], 'a')). '</li>';
									
								echo '
									<li class="extra-option">
										<div><input type="checkbox" name="disable_comments"', !$context['stream']['user']['allow_post_comments'] ? ' checked="checked"' : '' ,'> <i>Deshabilitar comentarios</i></div>
									</li>
								</ul>
							</div>
						</div>						
						<input type="button" class="sp-button bluesky" value="Compartir">
					</div>
				</div>	
	
		</div></div>';
	
	}
	
	
	echo '<div class="activities-main">
		<div class="filter-news clearfix">';
	
	if( $context['filter'] )
	{
	
	echo '
		<ul>';			
				foreach( $context['filter'] as $tab )
					echo '<li>', (isset($tab['selected']) ? '<strong>'. $tab['text'] .'</strong><i class="arrow_top"></i>' : '<a href="'. $tab['href'] .'" title="'. $tab['text'] .'">'. $tab['text'] .'</a>') ,'</li>
					';
			echo '
		</ul>';
	
	
	}else
		echo '
		<ul>
			<li>
				<strong>' . $context['navigation'][$context['stream']['nav_tab_selected']]['text'] . '</strong><i class="arrow_top"></i>
			</li>
		</ul>';
		
	echo '
	</div>';
	
	echo '
	<div class="container-stories" >
					
		<ul class="stream-stories"', $context['user']['is_guest'] ? ' style="border-top:none"' : '' ,'>';
		
		
		if(empty( $context['stream']['stories'] ) )
		{
			echo '<li class="story clearfix"><div class="error margin-5">no se encontro ninguna historia.</div></li>';
		}
		else
			foreach( $context['stream']['stories'] as $key_time => $story )
			{
			
				printActionByType($story, $story['story']['type'], $key_time);
			
			}
		
		echo '
		</ul>
	</div>';
	
	echo '</div>';

}

function template_stream_below(){
    global $context, $settings, $scripturl;
	
	echo '</div>';

	// Columna - Derecha
	
    echo '<div class="left" style="margin-left: 30px; width: 200px">';
	
	if($context['stream']['recommended_users'] && $context['user']['is_logged']){
	
	echo '
        <div class="minimal-box" style="width:100%">
            <div class="title"><strong class="color-orange size-15">Usuarios recomendados</strong></div>
            <div class="content">
                <ul class="follow-list">';				
				
				foreach($context['stream']['recommended_users'] as $member)
				
				echo '
                    <li class="clearfix">
						<div class="left">
							<a class="avatar-thumb s-32">
								<img class="avatar" src="' . $member['avatar']['src'] . '" style="' . $member['avatar']['coords'] . '">
							</a>
						</div>
						<div class="left action">
							<a href="' . $scripturl . '?action=profile&u=' . $member['id'] . '" title="' . $member['name'] . '">' . $member['name'] . '</a>
							<span class="data">' . $member['followers-txt'] . '</span>
						</div>
						<a title="Seguir usuario" class="tt-element follow" uid="' . $member['id'] . '"></a>
					</li>';
                    
                echo '
				</ul>
            </div>
        </div>';
		
		}
		if($context['user']['is_logged']){
		echo '
        <div class="minimal-box" style="width:100%">
            <div class="title"><strong>Usuarios seguidos online (<span class="color-', count($context['stream']['following-online']) > 0 ? 'green' : 'red' ,'"> ', count($context['stream']['following-online']) ,' </span>)</strong></div>
            <div class="content">
                <ul class="online-followings clearfix">';
				foreach( $context['stream']['following-online'] as $online )
					echo '
                    <li><a class="avatar-thumb s-32"><img class="avatar" src="'.$online['avatar']['src'].'" style="'.$online['avatar']['coords'].'"></a></li>';
					
				if( !$context['stream']['following-online'] )
					echo 'No se encontro usuarios online.';
				
                    echo '
                </ul>
            </div>
        </div>';}
		echo'
        <div class="minimal-box" style="width:100%">
            <div class="title"><strong class="size-15">Publicidad</strong></div>
            <div class="content">
                Aca va tu banner
            </div>
        </div>
        </div>';

	/* TEMPLATES AUXILIARES JAVASCRIPT ( $.tmpl ) */
    echo '
	<script id="story_tmpl_sub" type="text/x-jquery-tmpl">
		<li class="clearfix" id="cc_${id}">
			<a class="author-com">
				<img src="'.$context['user']['avatar']['src'].'" width="150" height="150">
			</a>
				<div class="inner-comment">
					<span class="author"><a href="'.$scripturl . '?action=profile&u='.$context['user']['id'].'">'.$context['user']['name'].'</a> coment&oacute;:</span>
						<span class="msg">${comentario}</span>
						<span class="time time-upd">Hace instantes - <span style="cursor:pointer;" id="${id}" class="deleteSub">Borrar</span></span>
				</div>
		</li>
	</script>
	
	<script id="story_tmpl_likes" type="text/x-jquery-tmpl">
		<li><a title="${membername}" href="'.$scripturl . '?action=profile&u=${iduser}"><img src="${avatar}"></a></li>

	</script>
	
	<script id="story_tmpl_sub_all" type="text/x-jquery-tmpl">
		<li class="clearfix" id="cc_${id}" style="background:rgba(0,0,0,0.03);">
			<a class="author-com">
				<img src="${avatar}" width="150" height="150">
			</a>
				<div class="inner-comment">
					<span class="author"><a href="'.$scripturl . '?action=profile&u=${iduser}">${name}</a> coment&oacute;:</span>
						<span class="msg">${comment}</span>
						<span class="time time-upd">${fecha} 
						{{if delete_item}}
						- <span style="cursor:pointer;" id="${id}" class="deleteSub">Borrar</span>
					{{/if}}
					</span>
				</div>
		</li>
	</script>
	
	<script id="story_tmpl_own" type="text/x-jquery-tmpl">
	<li class="story recentStoryElement clearfix">
			<div class="avatar">
				<a href="?clickStory" class="avatar-thumb"><img style="${avatar_coords}" src="${avatar_src}"></a>
			</div>
			<div class="story-context">
				
				<span class="story-user-info"><a class="nick" href="${member_href}">${member_name}</a> ${story_action} <a class="time-story" title="${story_date}">${story_time}</a>:</span>
				<div class="story-content">
					<span class="msg word-wrap"><div>{{html message}}</div></span>
					{{if attach_on}}
						<div class="streamAttachContext clearfix {{if attach_thumbnail}}thumbnailVisible{{/if}} ${story_type} rounded">
						</div>
					{{/if}}
				</div>
				
				<div class="outter-footer-story">
					<i class="arrow-footer"></i>
					<div class="footer-story rounded box-shadow-soft clearfix">
						<a class="outter-icon-story rounded-left"><i class="story-icon ${story_type}"></i></a>
						<ul class="stats">
							<li class="comments"><a class="clearfix">0</a></li>
							<li class="likes disabled"><a class="clearfix">0</a></li>
							<li class="re-streams disabled rounded-right"><a class="clearfix">0</a></li>
						</ul>
					</div>
				</div>
				
			</div>
		</li>
	</script>
	
    <script id="attachment_tmpl_link" type="text/x-jquery-tmpl">		
		<div class="attachThumbnail">
			<div class="thumbnails_list"><img src="${thumbnail}"></div>
			<div class="thumbnail-options">
				<span class="count"></span>
				<div class="paginate_thumbnails clearfix"></div>
				<span class="disable_thumbnail"><input type="checkbox" name="disable_thumbnail" /> Sin miniatura</span>
			</div>
		</div>
		<div class="attachText">
			<h3>${title}</h3>
			<div><a>${url}</a></div>
			<div><span>${description}</span></div>			
		</div>
		<!-- <i style="background: url(http://www.google.com/s2/favicons?domain=${domain})" class="favicon"></i> -->
    </script>
	
    <script id="attachment_tmpl_video" type="text/x-jquery-tmpl">
        <div class="thumbnail clearfix">
			<img src="${thumbnail}" width="180">
			<a class="play-icon"></a>
		</div>
		<div class="attachText clearfix">
			<a>${title}</a>
			<span>${description}</span>
		</div>
    </script>
	
	<script id="attachment_tmpl_swf" type="text/x-jquery-tmpl">
		<embed width="${width}" height="${height}" wmode="transparent" autoplay="false" allownetworking="internal" allowscriptaccess="never" allowfullscreen="true" type="application/x-shockwave-flash" quality="high" src="${src}" class="swf-untrusted">
	</script>
	
    <script id="attachment_tmpl_image" type="text/x-jquery-tmpl">
       <div class="thumbWrap"><img class="disabled-select" src="${src}" style="${style}"></div>	   
    </script>';

}
function printActionByType($data, $type, $key_time){
	global $context, $txt, $ID_MEMBER;
	
	switch( $type )
	{
		case 'error':
			echo '
			<li class="story error clearfix', $data['story']['class'] ? ' ' . $data['story']['class'] : '' ,'">
				' . $data['story']['body'] . '
			</li>';
			
			
		break;
		case 'status':
		case 'video':
		case 'video/swf':
		case 'image':
		case 'link':
		
		$footer_stats = array(
			'comments' => array(
				'count' => $data['story']['stats']['comments'],
				'no_show' => $data['story']['stats']['disabled']['comment'] === 'hide',
				'disabled' => false
			),
			'likes' => array(
				'count' => $data['story']['stats']['likes'],
				'no_show' => $data['story']['stats']['disabled']['like'] === 'hide',
				'disabled' => $data['story']['stats']['disabled']['like'] ? true : false
			),
			're-streams' => array(
				'count' => $data['story']['stats']['re_streams'],
				'no_show' => $data['story']['stats']['disabled']['re_stream'] === 'hide',
				'disabled' => $data['story']['stats']['disabled']['re_stream'] ? true : false
			)
		);
		
			
		echo '
		<li class="story clearfix', $data['story']['is_shared'] && !empty($data['story']['body']) ? ' re-stream' : '' ,'" story_id="' . ( $data['story']['is_shared'] ? $data['object']['stream']['id'] : $data['story']['id'] ) . '" id="storyi_'.$data['story']['id'].'">
			<div class="avatar">
				<a href="?clickStory" class="avatar-thumb"><img style="' . $data['member']['avatar']['coords'] . '" src="' . $data['member']['avatar']['src'] . '"></a>
			';
			
			if( $data['story']['is_shared'] && !$data['is_agrouped'] )
				echo '<div class="re-stream"><a href="" class="avatar-thumb s-32"><img style="'. $data['object']['member']['avatar']['coords'] . '" src="' . $data['object']['member']['avatar']['src'] . '"></a></div>';
			
			echo '
			</div>
			<div class="story-context">
			
				<span class="story-user-info">';
				
				echo'<a class="nick" href="' . $data['member']['href'] . '">' . $data['member']['name'] . '</a> ' . $data['story']['action'] . ' <a class="time-story" title="'.$data['story']['time']['date'].'">' . $data['story']['time']['text'] . '</a>:';
				if($data['member']['id'] != $ID_MEMBER && $context['user']['is_logged']){
					echo'<a style="float:right" onclick="denuncias.nueva('.$data['story']['id'].', 4)">Denunciar</a></span>';
				}
				
				if($data['member']['id'] == $ID_MEMBER){
					echo'<a style="float:right" onclick="stream_actions.delete_story('.$data['story']['id'].'); return false">Eliminar</a></span>';

				}
				echo'</span>

				<div class="story-content">
					<span class="msg word-wrap"><div>' . $data['story']['body'] . '</div></span>';
					if( $data['attach'] && $type != 'status' )
					{
						
						echo '
						<div class="streamAttachContext clearfix ' .( $data['attach']['thumbnail'] ? 'thumbnailVisible ' : '' ) . ( $data['attach']['params']['type'] ? $data['attach']['params']['type'] : $type) .' rounded">
						
							<!-- attach_story:'.$data['story']['id'].' -->
							';
							switch( $type ){
								
								case 'image':
								
									$set_min_height = ' style="';
									
									if ( $data['attach']['params']['minHeight'] )
										$set_min_height .= 'min-height: 350';
									else
										$set_min_height .= 'height: ' . $data['attach']['params']['height'];
									
									$set_min_height .= 'px;"';
									
									echo '<a' . $set_min_height . '><img style="'.$data['attach']['align'].'" src="'.$data['attach']['src'].'"></a>';
									
								break;
								
								case 'link':
								
								if( $data['attach']['thumbnail'] )
									echo '
									<div class="thumbnail clearfix">
										<img src="' . $data['attach']['thumbnail'] . '">
									</div>';
									
									echo '
									<div class="attachText clearfix">
										<h3>' . $data['attach']['params']['title'] . '</h3>
										<a>' . $data['attach']['params']['url'] . '</a>
										<span>' . $data['attach']['params']['description'] . '</span>										
									</div>
									<i class="favicon" style="background: url(' . $data['attach']['favicon'] . ')"></i>';
								
								break;
								
								case 'video':
								
								if( $data['attach']['thumbnail'] )
									echo '
									<div class="thumbnail clearfix">
										<img src="' . $data['attach']['thumbnail'] . '" width="180">
										<a class="play-icon"></a>
									</div>';
									
									echo '
									<div class="attachText clearfix">
										<a href="' . $data['attach']['url'] . '">' . $data['attach']['params']['title'] . '</a>
										<span>' . $data['attach']['params']['description'] . '</span>
									</div>';
								
								break;
								
								case 'video/swf':
									
									$scaled = getScaledCoords(372, 0, $data['attach']['params']['width'], $data['attach']['params']['height']);
									
									echo '
									<div class="swf-content" style="width: ' . $scaled[0] . 'px; height: ' . $scaled[1] .'px">
										<div class="hide hide-swf"><embed width="' . $scaled[0] . '" height="' . $scaled[1] .'" wmode="transparent" autoplay="false" allownetworking="internal" allowscriptaccess="never" allowfullscreen="true" type="application/x-shockwave-flash" quality="high" src="' . $data['attach']['url'] . '" class="swf-untrusted"></div>
										<a class="play-icon"></a>
									</div>';
									
								break;
							
							}
							echo '
						
						</div>';
						
					}
					echo '
				</div>
				
				<div class="outter-footer-story rounded-left">
					<i class="arrow-footer"></i>
					<div class="footer-story rounded box-shadow-soft clearfix">
						<a class="outter-icon-story  rounded-left"><i class="story-icon ' .( $data['story']['type'] == 'video/swf' ? 'video' : $data['story']['type'] ). '"></i></a>
						<ul class="stats">';
						$last_button = end(array_keys($footer_stats));
						
						foreach( $footer_stats as $key => $button )
						{
							if( $button['no_show'] )
								continue;
							if(empty($data['story']['is_shared'])){
							echo '
								<li class="' . $key . ( $button['disabled'] ? ' disabled' : '') . ($last_button == $key ? ' rounded-right' : '') . ($button['count'] > 0 ? ' filled' : '') . '"><a class="clearfix" id="comments_'.$data['story']['id'].'">' . $button['count'] . '</a></li>';						
						}
						}
							echo '
						</ul>';
				if(empty($data['story']['is_shared'])){
				
					if(!empty($data['story']['stats']['likes'])){
						echo'
						<div class="likes_content" id="likes_'.$data['story']['id'].'">
							',getLikes($data['story']['id']),'
						</div>';
					}
					
						if($context['user']['is_logged']){
							if($_COOKIE['text_'.$data['story']['id'].''] == 0 or $_COOKIE['text_'.$data['story']['id'].''] == ''){
						}
							
							else{
								echo'
								<script type="text/javascript">
										stream_actions.maketext('.$data['story']['id'].','.$_COOKIE['text_'.$data['story']['id'].''].');
									</script>
								
								';
							}
						}
					
					if($context['user']['is_logged'] or $data['story']['stats']['comments'] >= 1)	
					{echo'<div class="activity-users-actions">
												
							
						<div class="comments clearfix">
							<i class="header-arrow"></i>';
						if($data['story']['stats']['comments'] > 5){ 
							$restanPorVer = $data['story']['stats']['comments'] -5;
							echo'<span class="see-all" id="linkAll_'.$data['story']['id'].'" ><a onclick="stream_actions.seeAll(\''.$data['story']['id'].'\');">Ver los otros '.$restanPorVer.' comentarios</a></span>';}
						else{
						echo'<style>ul.comms{margin-top:0!important;} ul.comms li:first-child{border-top:none!important;margin-top:-3px;}</style>';
						}
						
						echo'<ul class="comms" id="comms_'.$data['story']['id'].'">';
							
							getsubsComments($data['story']['id']);		
							
						if(($mostrar = checkPriv($data['story']['id'])) == 1){
							echo'
							
								<li class="clearfix" id="addbox_'.$data['story']['id'].'">
									<a class="author-com"><img src="'.$context['user']['avatar']['src'].'"></a>
										<div class="inner-comment">
											<form  method="post" name="subcomment">
											<textarea id="sub_'.$data['story']['id'].'"onkeydown="stream_actions.comment(\''.$data['story']['id'].'\',event)" class="comment-form" tabindex="700" placeholder="Escribe un comentario..."></textarea>
											</form>
										</div>
									</li>
							';}
									
								echo'	
								</ul>
							</div>
						</div>';}}
					echo'	
					</div>
				</div>
				
			</div>
		</li>';
			
		break;
		case 'follow':
		
			echo '
		<li class="story short-activity clearfix">			
			<div class="story-context">
			
				<span class="story-user-info activity_action ' . $type . '"><i class="icon notifyIcon follow"></i> ' . $data['story']['action'] . ' ( <a class="time-story" title="' . $data['story']['time']['date'] . '">' . $data['story']['time']['text'] . '</a> ).</span>
				
				
			</div>
		</li>';
		
		break;
		case 'multi-follow':
		
			echo '
		<li class="story short-activity clearfix">			
			<div class="story-context">
			
				<span class="story-user-info activity_action ' . $type . '"><i class="icon notifyIcon follow"></i>' . $data['story']['action'] . '</span>
				<div class="avatars-stack">';
				
				$fade = false;
				
				if( count($data['members']) > 6 )
				{
				
					$fade = 1.00;
					$less_fade = $fade/(count($data['members'])+1);
				
				}
				
				foreach( $data['members'] as $member )
				{
					
					echo '
					<a href="'.$member['href'].'" class="avatar-thumb inline" title="'.$member['name'].'"><img src="' . $member['avatar']['src'] . '" style="' . $member['avatar']['coords'] . '"', $fade ? ' opacity="' . $fade . '"' : '' ,'></a>';
					
					if( $fade )					
						$fade = $fade - $less_fade;
				
				}

				echo '</div>
				
			</div>
		</li>';
		
		break;
		case 'signup':
			//...
		break;
		case 'avatar':
			//...
		break;
		case 'shared-story':
		
			echo 'hola';
		
		break;
	
	
	}
}
function template_view_stream(){
	
	header_stream();
	
	echo 'I\'m here.';
	
}
?>
