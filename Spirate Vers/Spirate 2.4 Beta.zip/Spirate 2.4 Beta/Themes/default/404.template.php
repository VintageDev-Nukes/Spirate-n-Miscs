
<?php
function template_main(){
echo '
	<div class="box-border-striped orange">
		<div class="stripes"></div>
			<div class="content">
				<div class="header"><h2>UPS! Error 404</h2></div>
					<div class="html-content">
						<div class="errormsg">Parece que la p&aacute;gina que buscas no existe...</div>
							<br />
					</div>
			</div>
	</div>

	';}

