<?php
function template_main(){}
function theme_show_buttons(){}
?>