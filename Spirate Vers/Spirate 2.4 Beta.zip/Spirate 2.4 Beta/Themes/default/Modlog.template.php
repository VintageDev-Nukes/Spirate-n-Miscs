<?php

function traduccion($valor){
	$valor = str_replace("topic", "Post", $valor);
	$valor = str_replace("message", "ID", $valor);
	$valor = str_replace("subject", "Titulo", $valor);
	$valor = str_replace("member", "Miembro", $valor);
	$valor = str_replace("causa", "<b style='color: #FF0000;'>Causa</b>", $valor);
	$valor = str_replace("board_from", "Estaba en", $valor);
	$valor = str_replace("board_to", "Movido a", $valor);
	
	return $valor;
}

function template_main(){
	global $context, $settings, $options, $scripturl, $txt, $modSettings;

echo '
<form action="',$scripturl,'?action=hist-mod" method="post" accept-charset="', $context['character_set'], '">
	<input type="hidden" name="order" value="', $context['order'], '" />
	<input type="hidden" name="dir" value="', $context['dir'], '" />
	<input type="hidden" name="start" value="', $context['start'], '" />
<div class="box_title" style="margin:10px 10px 0 10px;">
	Historial de Moderaci&oacute;n
</div><!-- /box_title -->
<div class="box_cuerpo" style="margin:0 10px 10px 10px;">
<style type="text/css">
.tablat:hover{background:#DBF1F5;-webkit-border-top-left-radius:10px;
  -webkit-border-top-right-radius:10px;
  -moz-border-radius-topleft:10px;
  -moz-border-radius-topright:10px;
  -webkit-border-bottom-left-radius:10px;
  -webkit-border-bottom-right-radius:10px;
  -moz-border-radius-bottomleft:10px;
  -moz-border-radius-bottomright:10px;
}
</style>

<table style="width:100%;">
	<tr> 
		<td style="width:470px;"><font size="3"><b>Post</b></td>
		<td style="width:70px;"><font size="3"><b><center>Acci&#243;n</center></b></td>
		<td style="width:130px;"><font size="3"><b><center>Moderador</center></b></td>
		<td style="width:130px;"><font size="3"><b><center>Causa</center></b></td>
	</tr>';

$eliminado= '<font style="color: #FF0000;">Eliminado</font>';
$editado='<font style="color: #00BA00;">Editado</font>';
$sticky='<font style="color: #B0DB3B;">Sticky</font>';
$cerrado='Cerrado';

	foreach ($context['entries'] as $entry)
	{
              $c=0; $titulo=''; $por=''; $causa=''; $pora= ''; $color='';
            
              if($entry['action']==$eliminado){
		foreach ($entry['extra'] as $key => $value)
                { $c= $c + 1;
                   if($c==2){$titulo=$value;}if($c==3){$por=$value;}if($c==4){$causa=$value;}
                   $pora= 'Por ';
                 //para darle color al fondo
               //$color='#FFD2D2';
               }}
               elseif($entry['action']==$editado){
		foreach ($entry['extra'] as $key => $value)
                { $c= $c + 1;
                   if($c==1){$titulo=$value;}if($c==3){$por=$value;}if($c==4){$causa=$value;}
                  $pora= 'Por ';
                  //para darle color al fondo
                 //$color='#DEFFAF';
                }}
                elseif($entry['action']==$cerrado){
		foreach ($entry['extra'] as $key => $value)
                { $c= $c + 1;
                   if($c==1){$titulo=$value;}
                  //para darle color al fondo
                 //$color='#FFF9EA';

                }}
                elseif($entry['action']==$sticky){
		foreach ($entry['extra'] as $key => $value)
                { $c= $c + 1;
                   if($c==1){$titulo=$value;}
                  //para darle color al fondo
                 //$color='#AFDEFF';

                }}
                elseif($entry['action']=='Comentario Editado'){
		foreach ($entry['extra'] as $key => $value)
                { $c= $c + 1;
                   if($c==1){$titulo=$value;}if($c==4){$causa=$value;}
                  //para darle color al fondo
                 //$color='#AFDEFF';

                }}
                else{
		foreach ($entry['extra'] as $key => $value)
                { $c= $c + 1;
                   if($c==2){$titulo=$value;}if($c==3){$por=$value;}if($c==4){$causa=$value;}
                   if($titulo==''){$titulo='-';}
                  //para darle color al fondo
                //$color='#EAEDFF';
              
               }}
             
             echo'<tr class="tablat"><td bgcolor="',$color,'" style="width:470px;border-bottom: 1px dashed #C1C1C1;padding:10px"><font size="1" color="#808080"><b>',$titulo,'</b><br>',$pora,'  ',$por,'</font>';
             echo'</td><td bgcolor="',$color,'" style="width:70px;border-bottom: 1px dashed #C1C1C1;padding:10px"><center>'. $entry['action'] .'</center></td>
             <td bgcolor="',$color,'" style="width:130px;border-bottom: 1px dashed #C1C1C1;padding:10px"><center>'. $entry['moderator']['link'] .'</center></td>';
             if($causa==''){$causa='-';}
             echo'<td bgcolor="',$color,'" style="width:130px;border-bottom: 1px dashed #C1C1C1;padding:10px"><center>'. $causa .'</center></td>
             </tr >';

		                                                       
	}


echo'
</table>
</div><!-- /box_cuerpo -->';
if($context['user']['is_admin'])
	echo'
	<div class="right">
		<input class="sp-button bluesky" type="submit" name="removeall" value="Mantenimiento..." />
	</div>';
echo'<input type="hidden" name="sc" value="', $context['session_id'], '" /></form>';
}

?>

