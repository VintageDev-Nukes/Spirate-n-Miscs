global = {};
global.onetime = [];
global.lang = [];
global.cache = {};

var clientPC = navigator.userAgent.toLowerCase(),
	clientVer = parseInt(navigator.appVersion),
	is_ie = ((clientPC.indexOf("msie") != -1) && (clientPC.indexOf("opera") == -1)),
	is_nav = ((clientPC.indexOf('mozilla')!=-1) && (clientPC.indexOf('spoofer')==-1) && (clientPC.indexOf('compatible') == -1) && (clientPC.indexOf('opera')==-1) && (clientPC.indexOf('webtv')==-1) && (clientPC.indexOf('hotjava')==-1)),
	is_win = ((clientPC.indexOf("win")!=-1) || (clientPC.indexOf("16bit") != -1)),
	is_mac = (clientPC.indexOf("mac")!=-1),
	is_moz = 0;

var lang = Array();

var mySettings_coms = {
    markupSet: [
        {name:lang['Negrita'], key:'B', openWith:'[b]', closeWith:'[/b]'},
        {name:lang['Cursiva'], key:'I', openWith:'[i]', closeWith:'[/i]'},
        {name:lang['Subrayado'], key:'U', openWith:'[u]', closeWith:'[/u]'},
        {separator:'-'},
        {   name:'Youtube',
            action: 'insertHtml',
            name: 'Insertar video de YouTube',
            beforeInsert: function (r) {
                var video = prompt(lang['ingrese el id de yt']);
                var regexpYT = /^http:\/\/((www|uk|fr|ie|it|jp|pl|es|nl|br|au|hk|mx|nz|de|ca)\.|)youtube\.com\/((watch|)\?v=|v\/|jp\.swf\?video_id=)([0-9A-Za-z-_]{11})(.*?)/i;
                if (video && video.match(regexpYT)) {
                    var YT_SWF = video.replace(regexpYT, 'http://www.youtube.com/v/$5');
                    r.replaceWith = '[youtube]' + YT_SWF + '[/youtube]\nlink: [url]' + YT_SWF + '[/url]\n';
                    
                } else {
                    sp_dialog.alert($txt['error'], "Video de Youtube no v&aacute;lido");
                }
            }
        }, 
        {
            action: 'insertHtml',
            name: 'Insertar archivo SWF',
            beforeInsert: function (r) {
                var selected = r.selection;
                
                if (selected.match(/(https?|ftp):\/\//)) {
                     r.replaceWith = '[swf=' + selected + ']\nlink: [url]' + selected + '[/url]\n';
                }
                else{

                    url = prompt('Ingrese la URL del archivo flash', 'http://');
                    if(url){
                    r.replaceWith = '[swf=' + url + ']\nlink: [url]' + url + '[/url]\n';
                    }
                    else{
                    r.replaceWith = '';
                    }

                }
            }
        },
        {
            action: 'insertHtml',
            name: 'Insertar Imagen',
            beforeInsert: function (r) {
                
               var selected = r.selection;
                
                if (selected.match(/(https?|ftp):\/\//)) {
                     r.replaceWith = '[img]' + selected + '[/img]';
                }
                else{

                    url = link = prompt('Ingrese la URL de la imagen', 'http://');
                    if(url){
                    r.replaceWith = '[img]' + url + '[/img]';
                    }
                    else{
                    r.replaceWith = '';
                    }

                }
            }
        },
        {
            action: 'createLink',
            name: 'Insertar Link',
            beforeInsert: function (r) {

                var selected = r.selection;
                
                if (selected.match(/(https?|ftp):\/\//)) {
                     r.replaceWith = '[url=' + selected + ']' + selected + '[/url]';
                }
                else{

                    url = link = prompt('Ingrese la URL', 'http://');
                    if(url){
                    r.replaceWith = '[url=' + url + ']' +  url + '[/url]';
                    }
                    else{
                    r.replaceWith = '';
                    }

                }
            }
        },
        {
            action: 'insertHtml',
            name: 'Citar',
            beforeInsert: function (r) {
                  var selected = r.selection;
                
                if(!empty(selected)){
                      r.replaceWith = '[quote]' + selected + '[/quote]';
                }
                else{

                    cita = link = prompt('Ingrese la Cita');
                    if(cita){
                    r.replaceWith = '[quote]' + cita + '[/quote]';
                    }
                    else{
                    r.replaceWith = '';
                    }

                }
            }
        },
    ]
};

var mySettings_comu = {
	markupSet: [
		{name:lang['Negrita'], key:'B', openWith:'[b]', closeWith:'[/b]'},
		{name:lang['Cursiva'], key:'I', openWith:'[i]', closeWith:'[/i]'},
		{name:lang['Subrayado'], key:'U', openWith:'[u]', closeWith:'[/u]'},
		{separator:'-'},
		{name:lang['Alinear a la izquierda'], key:'', openWith:'[align=left]', closeWith:'[/align]'},
		{name:lang['Centrar'], key:'', openWith:'[align=center]', closeWith:'[/align]'},
		{name:lang['Alinear a la derecha'], key:'', openWith:'[align=right]', closeWith:'[/align]'},
		{separator:'-'},
		{name:lang['Color'], dropMenu: [
			{name:lang['Rojo oscuro'], openWith:'[color=darkred]', closeWith:'[/color]'},
			{name:lang['Rojo'], openWith:'[color=red]', closeWith:'[/color]'},
			{name:lang['Naranja'], openWith:'[color=orange]', closeWith:'[/color]'},
			{name:lang['Marron'], openWith:'[color=brown]', closeWith:'[/color]'},
			{name:lang['Amarillo'], openWith:'[color=yellow]', closeWith:'[/color]'},
			{name:lang['Verde'], openWith:'[color=green]', closeWith:'[/color]'},
			{name:lang['Oliva'], openWith:'[color=olive]', closeWith:'[/color]'},
			{name:lang['Cyan'], openWith:'[color=cyan]', closeWith:'[/color]'},
			{name:lang['Azul'], openWith:'[color=blue]', closeWith:'[/color]'},
			{name:lang['Azul oscuro'], openWith:'[color=darkblue]', closeWith:'[/color]'},
			{name:lang['Indigo'], openWith:'[color=indigo]', closeWith:'[/color]'},
			{name:lang['Violeta'], openWith:'[color=violet]', closeWith:'[/color]'},
			{name:lang['Negro'], openWith:'[color=black]', closeWith:'[/color]'}
		]},
		{name:lang['Tamano'], dropMenu :[
			{name:lang['Pequena'], openWith:'[size=9]', closeWith:'[/size]'},
			{name:lang['Normal'], openWith:'[size=12]', closeWith:'[/size]'},
			{name:lang['Grande'], openWith:'[size=18]', closeWith:'[/size]'},
			{name:lang['Enorme'], openWith:'[size=24]', closeWith:'[/size]'}
		]},
		{name:lang['Fuente'], dropMenu :[
			{name:'Arial', openWith:'[font=Arial]', closeWith:'[/font]'},
			{name:'Courier New', openWith:'[font="Courier New"]', closeWith:'[/font]'},
			{name:'Georgia', openWith:'[font=Georgia]', closeWith:'[/font]'},
			{name:'Times New Roman', openWith:'[font="Times New Roman"]', closeWith:'[/font]'},
			{name:'Verdana', openWith:'[font=Verdana]', closeWith:'[/font]'},
			{name:'Trebuchet MS', openWith:'[font="Trebuchet MS"]', closeWith:'[/font]'},
			{name:'Lucida Sans', openWith:'[font="Lucida Sans"]', closeWith:'[/font]'},
			{name:'Comic Sans MS', openWith:'[font="Comic Sans MS"]', closeWith:'[/font]'}
		]},
		{separator:'-'},
		{name:lang['Insertar video de YouTube'], beforeInsert:function(h){markButtons.youtube(h);}},
		{name:lang['Insertar archivo SWF'], beforeInsert:function(h){markButtons.flash(h);}},
		{name:lang['Insertar Imagen'], beforeInsert:function(h){markButtons.image(h);}},
		{name:lang['Insertar Link'], beforeInsert:function(h){markButtons.link(h);}},
		{name:lang['Citar'], beforeInsert:function(h){markButtons.quote(h);}},
	]
};


function fix_design(){

         // fix .login-tab
        if($(window).width()==1024)
            $('.login-tab').css({
                'right' : '0px'
            });

        // fix ui-radio
        $('label.ui-radio.category').click(function(){
            $('label.ui-radio.category').removeClass('checked');
            $('input.ui-radio.category').removeAttr('checked');

            $(this).addClass('checked');
            $('input.ui-radio.category#' + $(this).attr('for')).attr('checked', 'checked');

        });
        $('label.ui-radio.sort').click(function(){
            $('label.ui-radio.sort').removeClass('checked');
            $('input.ui-radio.sort').removeAttr('checked');

            $(this).addClass('checked');
            $('input.ui-radio.sort#' + $(this).attr('for')).attr('checked', 'checked');

        });
        // fix ui-radio ( ie :yao ming: )
            if ( $.browser.msie ){
                $('label.ui-radio[for=categoria_0]').addClass('checked');
                $('label.ui-radio[for=order_1]').addClass('checked');

                $('ul#filter-category li label.ui-radio').each(function(){
                    $(this).click(function(){
                        $('ul#filter-category li label.ui-radio').removeClass('checked');
                        $('ul#filter-category li label.ui-radio').prev().removeAttr('checked');
                        $(this).addClass('checked');
                        $(this).prev().attr('checked', 'checked');
                    });
                });

                $('ul#filter-sort li label.ui-radio').each(function(){
                    $(this).click(function(){
                        $('ul#filter-sort li label.ui-radio').removeClass('checked');
                        $('ul#filter-sort li label.ui-radio').prev().removeAttr('checked');
                        $(this).addClass('checked');
                        $(this).prev().attr('checked', 'checked');
                    });
                });

            }
            
            if($('ul.paginator.moz-stack').length > 0)
                $('ul.paginator.moz-stack').css({
                    'right' : $('.wrap-paginator').width()/2 - $('ul.paginator.moz-stack')[0].offsetWidth/2 + 20
                });

            $('textarea[placeholder]').focus(function(){

                if($(this).val() == $(this).attr('placeholder'))
                    $(this).val('');

                $(this).removeClass('with-placeholder').blur(function(){
                    if(empty($(this).val()))
                    $(this).addClass('with-placeholder').val($(this).attr('placeholder'));
                });
            });

}

function effect_design(){

    $('.notify-globe').each(function(){
    $(this).hide();
    $(this).fadeIn('fast', function(){
        $(this).animate({'top' : '+=4px'}, 100, function(){
            $(this).animate({'top' : '-=4px'}, 100);
        });
    });
    });
    
// tipsy!
// gravity : nw | n | ne | w | e | sw | s | se
$('a.tt-element').tipsy({
        gravity: function(){
            return $(this).attr('gravity') ? $(this).attr('gravity') : 's';
        },
		live : true,
		opacity : 1
});

// tabs action{
    $('#menutabs li a').click(function(){
       menutabs(this);
    });
    // }

    // notify globe animation {
    
    // }

    // click out box notifications{
    $('.box-notifications').each(function(){
    var $this = this;
    var _parent = $(this).parent('li');

    $(this).parents().filter('body').bind('click', function(e){
            if(
                !$($this).parent('li').children('a').find('i').hasClass('loading')
                && !jQuery(e.target).closest(_parent).length
                && !jQuery(e.target).is('.box-notifications')){

                    $($this).hide();
                    $($this).parent('li').removeClass('selected');

            }

       }
      );

    $(this).parents().filter('body').keyup(function(e) {
            if (e.keyCode == 27 && $($this).css('display')=='block') {
                $($this).hide();
                $($this).parent('li').removeClass('selected');
            }   // esc
        });
    });
    // }

// fix box selection border
    $('.box-selection .context ul li.selected:first-child').parent().parent().css('border-top-color', 'transparent');
    $('.box-selection .context ul li.selected:last-child').parent().parent().css('border-bottom-color', 'transparent');

    $('.box-selection .context ul li').click(function(e){

    $('.box-selection ul li').removeClass('selected');
    $(this).addClass('selected')

                $('.box-selection .context').removePropertyStyle('border-bottom-color');
                $('.box-selection .context').removePropertyStyle('border-top-color');

            if($(this).is(':first-child')){
                $('.box-selection .context').css('border-top-color', 'transparent');
            }
            else if($(this).is(':last-child'))
                $('.box-selection .context').css('border-bottom-color', 'transparent');

            location.href = $(this).children('a').attr('href') ? $(this).children('a').attr('href') : '#';
            
        });


// autogrow
    $('textarea.autogrow').autoResize({
		animate : false,
		extraSpace : 'auto'
	});
	
	
	$('textarea._autogrow').autoResize({
		animate : false
	});
	
	// set opacity
	$('[opacity]').each(function(){
		
		$(this).css('opacity', $(this).attr('opacity'));
		
	});
	
	$('.UIdrop.click-to-open').click(function(e){
		
		var action = $(this).find('ul').css('display') == 'block' ? 'hide' : 'show',
			ul = $(this).find('ul');
			
		if( $(e.target).closest(ul).length )
			return;
		
		$(ul)[action]();
		
	}).bind("clickoutside", function(){
		$(this).find('ul').hide();
	});


}

function _init(){

    // corregimos los avatars con error
    global.cache['avatars'] = new Array();
    global.cache['avatars_src'] = {};
    
    $('img.avatar').each(function(){
        $(this).error(function(){
            $(this).attr('src', global.data.default_avatar).error(function(){
                $(this).attr('src', global.data.images_url + '/blank.gif'); // blank.gif is the last posibility.
            });
        });
        
    });
   
    $("a[rel=registro], input[rel=registro]").click(function(){
        sp_dialog.load();
        
        $.ajax({
           type : "GET",
           url  : global.data.scripturl + "?ajax&action=fast-register",
           success : function(data){
               data = data.substring(3);
               
               sp_dialog.endload();
               sp_dialog.options = {
                    title : 'Registro',
                    body : data,
                    beforeShow : function(){
                        sp_dialog.center();
                    }
                }
              sp_dialog.show('load');
               
            },
           error : function(){
               dialogbox.close();
               dialogbox.alert($txt['error_while_processing'], $txt['error']);
           }
       });       
    });


    // add more inputs.
    $('div.input-plus a').live('click', function(){

        if($('div.input-plus').length >= 10)
            return false;

        var a = $(this);
        var clone = $(this).parent().clone();
        $(clone).find('input').val('');
        $(this).parent().after(clone);
        $(a).addClass('hide');
        $.scrollTo('+=38'); // to bottom...

    });
	
   $('#markItUp').richedit({markItUpSettings: mySettings})
   
   $('#com_markitup').markItUp(mySettings_coms);
   
   // $('#markItUp').markItUp(mySettings_comu);
}



function count_list(){

var i = 0;
$('.count-list.list').each(function(){
    i++;
    if($(this).attr('count-list') == undefined)
        $(this).attr('count-list', i);
});

var count = new Array();
$('.data .list-element').each(function(){
if(typeof count[$(this).parent().attr('count-list')] == 'undefined')
    count[$(this).parent().attr('count-list')] = 1;
else
    count[$(this).parent().attr('count-list')]++;

    $(this).find('span.list-number').html(count[$(this).parent().attr('count-list')]);

});

}

function MM_jumpMenu(targ,selObj,restore){ 
    eval(targ + ".location=\'" + selObj.options[selObj.selectedIndex].value + "\'");
    if (restore)
        selObj.selectedIndex=0;
}

$(document).ready(function(){

    // init
    _init();
    // fix design
    fix_design();
    // effects in design
    effect_design();
    

});



/* Login action box */
function loginbox(action){
    
if(action){
switch(action){
    case 'close':
        $('#login-box').hide();
        $('.login-tab').removeClass('selected');
        $('.login-tab a').blur();
    break;
    case 'show':
        $('#login-box').show();
        $('.login-tab').addClass('selected');
        $('#login-box input.text:first').focus();
    break;

}
return;
}

        if($('.login-tab').hasClass('selected'))
            loginbox('close');
        else
            loginbox('show');

        if(global.onetime['loginbox'])
            return;
        else
            global.onetime['loginbox'] = true;
        


        $('body').bind('click', function(e){
            if(
                 $('.login-tab').hasClass('selected')
                 && !jQuery(e.target).is('#login-box')
                 && !jQuery(e.target).closest('#login-box').length
                 && !jQuery(e.target).is('.login-tab')
                 && !jQuery(e.target).closest('.login-tab').length
            )
                    return loginbox('close');
       }
      );

      
        $(document).keyup(function(e) {
            if (e.keyCode == 27) {
                return loginbox('close');
            }   // esc
        });
               
}
/* menu tabs */
function menutabs(a){

    $('#menutabs li').removeClass('selected');
    $(a).parent('li').addClass('selected');

}

function new_search(){
    $('.big-search .token').fadeOut(500, function(){
        var val = $(this).find('div').html();
    $('.big-search #q-input').removeAttr('disabled').attr('placeholder', $('.big-search #q-input').attr('ex-placeholder')).val(val).focus();
    $('.big-search .sp-button').animate({'opacity' : '1'}, 500 , function(){
        $(this).removeAttr('disabled');
        
    });
    });
}

var stopPropUIMENU = function(stop, a){
// evitar abrir una caja de notificaciones | mensajes | favoritos, si existe ajax de por medio. #ui-menu li a.menuicon[ajax] jQuery.browser.msie


    if(stop)
        $('a.menuicon[ajax]').each(function(){
            if($(a).attr('ajax') != $(this).attr('ajax')){
               global.cache['ui-menu a'][$(this).attr('ajax')] = $(this).attr('onclick');
               $(this).attr('onclick', 'return false;');
            }
        });
    else
        $('a.menuicon[ajax]').each(function(){
            $(this).attr('onclick', global.cache['ui-menu a'][$(this).attr('ajax')]);
        });
}

function mps(a){

    $('#mensajes-prvs').show();
    $(a).parent().addClass('active');


}


var notificaciones = {

    count : 0,

    open : function(a){
        
    var show = function(){
        $(a).parent().addClass('selected');
        $('#notificaciones').show();
    }
    var hide = function(){
        $(a).parent().removeClass('selected');
        $('#notificaciones').hide();
    }


    if($('#notificaciones').css('display') == 'block')
        hide();
    else if(global.cache['notificaciones']){
        $('#notificaciones').find('.body').html(global.cache['notificaciones']);
        show();
    }
   else
       show();

   if(global.onetime['notificaciones'])
       return;
   
    if($('#notificaciones .loading').size()==1)
        $('#notificaciones .loading').effect("pulsate", {times: 99}, 1000);

    $(a).children().addClass('loading').removeClass('monitor');
    
    global.onetime['notificaciones'] = true;
    $.ajax({
        type: 'POST',
        url: global.data.scripturl + '?action=ajax&do=notificaciones',
        success : function(e){
            
            global.cache['notificaciones'] = e;
            show();
            $('#notificaciones .loading').stop();
            $(a).children().removeClass('loading').addClass('monitor');
            $(a).parent().find('.notify-globe.notifications').animate({
                'top' : '-=10px'
            }, 100, function(){
                $(this).animate({'top' : '+=10px'}, 100, function(){
                    $(this).fadeOut('fast');
                })
            });
            $('#notificaciones').find('.body').html(e);
			$('#notificaciones li.recent').removeClass('recent').addClass('new');
            $('#notificaciones li.new').effect('highlight', {color:'#feffe8'}, 15000);
            //stopPropUIMENU();
            $('.hr-info span').fadeIn(function(){
                $(this).find('a').fadeIn();
            });
        },
        error : function(){
            sp_dialog.alert('Error', 'Hubo un error al solicitar lo procesado.');
            hide();
            $(a).children().removeClass('loading').addClass('monitor');
        }
    });
    },

    ballon : function(){

        if(notificaciones.count.toString().replace('+', '') > 0)
            $('.notify-globe.notifications a span').html(notificaciones.count);
        else
            return $('.notify-globe.notifications').hide();

        if($('.notify-globe.notifications a span').html().length == 2)
            $('.notify-globe.notifications').css('right', '-12px');
        else if($('.notify-globe.notifications a span').html().length == 3)
            $('.notify-globe.notifications').css('right', '-17px');

    },

    getLastUsers : function (id){

        dialog_();

    }

}

var errors = {
    
    retry : function(callback){
        dialogbox.show();
        dialogbox.html({
            'title' : $txt['error'],
            'body'  : $txt['error_while_processing']
        });
       
        var onclickEvent = '';
        
        if(typeof callback != 'function')
            onclickEvent = 'dialogbox.close(function(){' + callback.replace('|', '') + '},500)|dialogbox.close()';
        else if(typeof callback == 'function')
            var bindEvent = 'bindEvent_' + Math.random().toString().replace('.', '');

        dialogbox.buttons(typeof callback == 'function' ? $txt['buttons']['accept'] + ' ' : $txt['buttons']['retry'] + '|' + $txt['buttons']['cancel'], (typeof callback == 'function' ? 'bluesky ' + bindEvent : '') + '|red', onclickEvent);
        
        if(typeof callback == 'function')
        $('.' + bindEvent).click(function(){
            dialogbox.close(function(){
                callback();
            }, 500);
        })


    },

    error : function(){
        
        dialogbox.show();
        dialogbox.html({
            'title' : $txt['error'],
            'body'  : $txt['error_while_processing']
        });
        dialogbox.buttons($txt['buttons']['accept'], '',  'dialogbox.close()' );

    }
}

function info_help(){

    var help = $('#info').addClass("info");
    help.fadeIn();
    setTimeout(function(){help.fadeOut();},10000);
}

var profile = {
    stop_animation : false,
    prevent_ajax   : new Array(),
    prevent_delete : true,

    editbox : function(infoedit, iduser){

     var obj = $('#i' + infoedit).addClass("obj");
     var objb = $('#ib' + infoedit).addClass("objb");
     var edit =  $("#ie" + infoedit).addClass("edit");

                            var inf =  $('#in' + infoedit).addClass("infoe");
                            var info =  $('#in' + infoedit).val();
                            var act =  $('#i' + infoedit).val();

                             if(edit.css('display') == 'none'){

                                objb.html("Guardar");
                                obj.hide();
                                edit.show();
                            }
                            else{                            

                                $.ajax({
                                        type : 'POST',
                                        data : 'tipo='+ infoedit + '&data=' + info + '&iduser=' + iduser,
                                        url : global.data.scripturl + '?action=ajax&do=editbox',
                                        dataType: 'json',
                                        cache: false,
                                        async: true,
                                        success : function(data){
                                            if(data.status == 'error'){
                                                                    
                                                    return sp_dialog.alert($txt['error'], data.msg);
                                            }
                                            else{

                                                    edit.hide();
                                                    obj.html(info);
                                                    obj.show();
                                                    objb.html("Editar");
                                            }              
                                        },
                                        error : function(){
                                            return sp_dialog.alert($txt['error'], "Error al procesar lo solicitado.");
                                        },
                                    });   
                            }
                    
    },
    
    delete_activity : function(id, a, skip){
        
        if($('input[name=ev_prevent]').is(':checked'))
            this.prevent_delete = false;

        if(this.prevent_delete && !skip){
            $(a).attr('id', 'saveElement');
            dialogbox.show();
            dialogbox.html({
                'title' : $txt['confirm_action'],
                'body'  : $txt['ask::confirm_action'] + '<br /><br /><input type="checkbox" name="ev_prevent"> ' + $txt['dont_ask_me']
            });
            dialogbox.buttons( $txt['buttons']['accept'] + '|' + $txt['buttons']['cancel'], '|red', 'profile.delete_activity(' + id + ', $(\'#saveElement\'), true); dialogbox.close();|dialogbox.close()');
            return;
        }
        
        if(this.stop_animation)
            return;
        else
            this.stop_animation = true;
        
        var li = $(a).parent().is('.div-recent-feed') ? $(a).parent().parent() : $(a).parent();
        var li_date_time = $(li);
        
        do{
            li_date_time = $(li_date_time).prev('li');
            
        }while(!$(li_date_time).is('.data-time'));

        var normal_height = $(a).parent()[0].offsetHeight;
        
        // $.ajax({
        $(li).html('<div class="hideObj">' + $(li).html() + '</div>' + '<div class="maskwhite"></div>');
        
        $(li).children('.maskwhite').fadeIn(function(){

            setTimeout(function(){
                            if($('ul.activities-feed li').length==1)
                                $('ul.activities-feed li').slideUp(function(){$(this).remove()});
                            }, 1000);

            $(li).css({'padding' : '0', 'border' : 'none', 'height' : normal_height-1});
            $(li).animate({'height' : '0'}, 'fast', function(){
                $(this).remove();
                
                if($(li_date_time).next().is('.data-time') || !$(li_date_time).next().is('li') && !$('#feed').next().is('li.data-time'))
                        $(li_date_time).hide('fast', function(){
                            $(this).remove()
                        });
                
            profile.stop_animation = false;
            });
        });
        // }); ajax...
    },

    get_more_activites : function(){
        
        if(this.prevent_ajax['get_more_activities'])
            return;

        if(this.stop_animation)
            return;
        else
            this.stop_animation = true;
        
        $('#wrap-activities .mask-load').fadeIn();

        $.ajax({
            type : 'POST',
            url  : 'activities-feed.php',
            data : 'time=' + feed_time,
            dataType: 'json',
            success :  function(data){                                   
                   feed_time = data['feed_time'];

                   if(data['status']=='empty'){
                                $('.more-feeds').fadeOut();
                                profile.prevent_ajax['get_more_activities'] = true;
                                }
                                           
                   $(data['html']).each(function(k, item){
                        var li = $(item);
                        $(li).css({'display' : 'none', 'border-color' : 'transparent', 'background' : 'none'}).addClass('recent-feed');
                        $(li).html('<div class="hideObj div-recent-feed">' + $(li).html() + '</div><div class="maskwhite" style="display:block"></div>');
                        $(li).find('a.delete').click(function(){
                            profile.delete_activity($(li).attr('feed-id'), $(this));
                        });
                        
                        $('ul.activities-feed').append(li);
                        
                    });
                    $('#wrap-activities .mask-load').fadeOut(function(){
                        $('li.recent-feed').slideDown('slow', function(){
                            
                            if(!$(this).is('.data-time') && !$(this).is('.message-item')){
                                $(this).css('background', '#F3F3F3');
                            $(this).effect('highlight', {color:'#fdffca'}, 2000, function(){$(this).removeAttr('style')});
                            }

                            $(this).removeClass('recent-feed').find('.hideObj').removeClass('hideObj');
                            $(this).find('.maskwhite').fadeOut();
                        });
                    });

            },
            complete : function(){profile.stop_animation = false;},
            error : function(){
                $('#wrap-activities .mask-load').fadeOut();
                errors.retry('profile.get_more_activites()');
            }
        });
        

    }

}

var post = {
    pagePoints : 1,
    
    /* puntuar post */
    puntuar : function(points){

        var prev_html = $('#puntos-post').find('.puntos').html();
        var prev_html_tooltip = $('#puntos-post .nano-tooltips span.text').html();

        $('#puntos-post .nano-tooltips span.text').html($txt['loading']);

        $.ajax({
            type : 'post',
            url : global.data.scripturl + '?action=ajax&do=send_points',
            data : 'post=' + global.data.ID_POST + '&puntos=' + points,
            dataType: 'json',
            success : function(h){

                $('#puntos-post .descr').hide();

                if(h.status == 'error'){                    
                    $('#puntos-post').children('.nano-tooltips').removeClass('blue').addClass('red');
                    $('#puntos-post .nano-tooltips span.text').html($txt['error']);
                    $('#puntos-post').children('.nano-tooltips').animate({'top':'+=2px'}, 100, function(){$(this).animate({'top':'-=2px'}, 200)});
                    $('#puntos-post').addClass('red').find('.puntos').html(h.message);
                    return;
                }

                $('#puntos-post').children('.nano-tooltips').addClass('green').find('span.text').html('+ ' + h.points);
                $('#puntos-post').addClass('green').find('.puntos').html(h.message);
                $('#puntos-post').children('.nano-tooltips').animate({'top':'+=2px'}, 100, function(){$(this).animate({'top':'-=2px'}, 200)});

            }
        });

    },
    add_bookmark : function(){
        //...
        if(!global.onetime['add_bookmark'])
            global.onetime['add_bookmark'] = true;
        else
            return;

        $('a.add_bookmark i').addClass('load');

        $.ajax({
            type : 'POST',
            url : global.data.scripturl + '?action=ajax&do=add_bookmark',
            data : 'topic=' + global.data.ID_POST,
            dataType: 'json',
            success : function(h){
                $('a.add_bookmark i').removeClass('load');
                if(h.status == 'error')                   
                    return sp_dialog.alert($txt['error'], h.message);
                
                $('a.add_bookmark').addClass('green').find('span.txt').html(h.button_text);
            }
        });
        
    },
    new_comment : function(retry){

        if(!global.cache['new_comment'])
            global.cache['new_comment'] = {
                retry : false,
                wait : false,
                last_error : '',
                ready : false
            };
        
        if(!retry)
            data = {comment : encodeURIComponent($('textarea.comment').val()), ID_POST : global.data.ID_POST};
        else
            data = global.cache['new_comment']['retry'];

        if(!global.cache['new_comment']['retry'])
            global.cache['new_comment']['retry'] = data;

        if(global.cache['new_comment']['wait'])
            if(global.cache['new_comment']['wait'] > 0)
                return sp_dialog.alert($txt['error'], global.cache['new_comment']['last_error']);

        if(global.cache['new_comment']['ready'])
            return false;
        else
            global.cache['new_comment']['ready'] = true;

        var maskload = $('.new-comment .mask-load').fadeIn();
        $.ajax({
            type : 'POST',
            data : 'comentario=' + data.comment + '&post=' + data.ID_POST + '&show_comment=' + (last_page ? 0 : 1),
            url : global.data.scripturl + '?action=ajax&do=comentar',
            dataType: 'json',
            cache: false,
            async: true,
            success : function(data){
                if(data.status == 'error'){
                    
                    if(data.type == 'timeout'){ 
                        global.cache['new_comment']['wait'] = data.timeout;
                        post.checkTimeout();
                    } // suponiendo que el post se cerro en ese instante.
                    else if(data.type == 'locked' && $('.new-comment').length > 0)
                        $('.new-comment').slideUp(function(){
                            $(this).remove();
                        });
                        
                        global.cache['new_comment']['last_error'] = data.message;
                        return sp_dialog.alert($txt['error'], data.message);
                }

                $('textarea.comment').val('').focus().blur();
                
                if($('.no-comments').length > 0)
                    $('.no-comments').fadeOut();
                
                        var template = $(data.gotolast ? "#gotoLastPageTmpl" : "#newCommentTmpl").tmpl(data).appendTo("#comentarios");
                        $(template).slideDown('slow');

                        var scrollheight = 40;
                        if($(template).find('.UI-comment').length > 0)
                            scrollheight = $(template).find('.UI-comment')[0].offsetHeight;

                        $.scrollTo('+=' + scrollheight + 'px', 800);
            },
            error : function(){
                errors.retry('post.new_comment(true)');
            },
            complete : function(){
                global.cache['new_comment']['ready'] = false;
                $(maskload).fadeOut();
            }
        });
    },

    erase_com : function(numcom, postid){
        
        var cont = 0;
       
        sp_dialog.alert("Borrar Comentario", "Seguro que quieres borrar el comentario?")                            
                            sp_dialog.buttons([{
                    text: "Cancelar",
                    "class": 'left close-button-dialog',
                    click: function() {
                        sp_dialog.close();
                        cont = 0;
                        
                    }                    
                     },
                            {
                    text: "Aceptar",
                    "class": 'right close-button-dialog',
                    click: function() {
                        sp_dialog.close();
                        
                        
                        $.ajax({
            type : 'POST',
            data : 'comid=' + parseInt(numcom) + '&postid=' + parseInt(postid),
            url : global.data.scripturl + '?action=ajax&do=borrarcom',
            dataType: 'json',
            cache: false,
            async: true,
            success : function(data){
                if(data.status == 'error'){
                                        
                        return sp_dialog.alert($txt['error'], data.msg);
                }
                else{
                    $('#com_' + numcom).slideUp();
                }           
                    
            },

            error : function(){
                return sp_dialog.alert($txt['error'], "Error al procesar lo solicitado.");
            },
        });
                    },
                    
                        }                
                ]);
       
        
    },

    citar : function(idau){

      var div = document.getElementById("author_" + idau);
      var user = div.getAttribute("quote-author");
      var cita = div.getAttribute("quote-com");
      var text = ($('.comment').val() != '') ? $('.comment').val() + '\n' : '';
       text += '[quote=' + user + ']' + cita + '[/quote]\n';
       $('.comment').val(text);
         $('.comment').focus();
          
    },

    com_opt : function (id, mstatus){

       if(mstatus == 1){

            $('#opt_' + id).css("display","block");

         }

        else{

            $('#opt_' + id).css("display","none");

        }
    },


    checkTimeout : function(){

        if(global.cache['new_comment']['wait'] <= 0)
            return false;
        
        global.cache['new_comment']['wait']--;

        setTimeout(function(){
            post.checkTimeout();
        }, 1000);

    }



}

var denuncias = {

    nueva : function(id, tipo){

        var error_sol = 'Lamentamos que algo haya salido mal, intentalo de nuevo m&aacute;s tarde o <a href="' + global.data.scripturl + '?action=contactenos">Comunicate con el Administrador</a>';

       $.ajax({
        type : 'POST',
        url  : global.data.scripturl + "?action=ajax&do=den_form",
        data : 'id=' + parseInt(id) + '&tipo=' + parseInt(tipo),
           success : function(data){
               
               sp_dialog.endload();
               sp_dialog.options = {
                    title : 'Denunciar',
                    body : data,
                }
              sp_dialog.show();
              sp_dialog.buttons([{
                                text: "Cancelar",
                                "class": 'left close-button-dialog',
                                click: function() {
                                    sp_dialog.close();
                                    cont = 0;
                                    
                                }                    
                                 },
                                        {

                               
                                    text: "Aceptar",
                                "class": 'right close-button-dialog',
                                click: function() {
                                    var form = document.getElementById("denunciar-formul");
                                    var info = $("#denunciar-formul").serialize();
                                  if(form){
                                  
                                  $.ajax({
                                    type: 'POST',
                                    url: $("#denunciar-formul").attr("action"),
                                    data: info,
                                    dataType: 'json',
                                    success: function(data) {
                                        sp_dialog.close(); 
                                        if(data.status == 'error'){
                                        sp_dialog.alert("Error al denunciar", data.msg + "<br><br>" + error_sol);
                                        }
                                        else{
                                            sp_dialog.alert("Denunciar", data.msg);
                                        }

                                    },
                                    error : function(){
                                        sp_dialog.close();
                                        sp_dialog.alert($txt['error_while_processing'], $txt['error'] + "<br><br>" + error_sol);
                                    }
                                    }); 

                                    }
                                    else{sp_dialog.close();}

                                 }
                                     
                                 }]);
            },
           error : function(){
               sp_dialog.close();
               sp_dialog.alert($txt['error_while_processing'], $txt['error'] + "<br><br>" + error_sol);
           }
       });  



        },

    erase : function(id, tipo){

            switch(tipo){

                  case 1:

                  sp_dialog.alert("Borrar denuncias del post", "Seguro que quieres borrar todas las denuncias de este post.")
                  break;    

                  case 2:
                  
                  sp_dialog.alert("Borrar denuncias del usuario", "Seguro que quieres borrar todas las denuncias hacia este usuario.");
                  break;

                  case 3:

                  sp_dialog.alert("Borrar denuncias de la imagen", "Seguro que quieres borrar todas las denuncias de esta imagen.")
                  break;

                  case 4:

                  sp_dialog.alert("Borrar denuncias de la publicacion", "Seguro que quieres borrar todas las denuncias de esta publicacion.")
                  break;
            }

                                        sp_dialog.buttons([{
                                text: "Cancelar",
                                "class": 'left close-button-dialog',
                                click: function() {
                                    sp_dialog.close();
                                    cont = 0;
                                    
                                }                    
                                 },
                                        {
                                text: "Aceptar",
                                "class": 'right close-button-dialog',
                                click: function() {

                                         sp_dialog.close();
                                       
                                        $.ajax({
                                        type : 'POST',
                                        data : 'id=' + parseInt(id) + '&tipo=' + parseInt(tipo),
                                        url : global.data.scripturl + '?action=ajax&do=eraseden',
                                        dataType: 'json',
                                        cache: false,
                                        async: true,
                                        success : function(data){
                                            if(data.status == 'error'){
                                                    return sp_dialog.alert($txt['error'], data.msg);
                                            } 
                                            else{
                                                return sp_dialog.alert("Eliminar denuncias", data.msg);
                                            }
                                        },

                                        error : function(){
                                            return sp_dialog.alert($txt['error'], "Error al procesar lo solicitado.");
                                                 },
                                        });
                                      },
                                    }                
                                  ]);
                                  }


        }


global.cache['last_follow_u_action']  = 'none';
function follow_u(obj, user, section){
	
	var multi_follows_areas = new Array('stream');
	
	if( empty(user) )
		return false;
	
	if(global.cache['last_follow_u_action'] == 'follow' && $.inArray(section, multi_follows_areas) === -1)
		return false;
		
	if(!global.onetime['follow_u'])
            global.onetime['follow_u'] = true;
    else
        return;
	
	$.ajax({
		'type' : 'POST',
		'url' : global.data.scripturl + '?action=ajax&do=follow_u',
		'dataType' : 'json',
		'data' : 'uid=' + parseInt(user),
		success : function( h ){
			if(h.status == 'error')
				return errors.error(h.msg);
			
			global.cache['last_follow_u_action'] = 'follow';	
			global.onetime['follow_u'] = false;
			
			switch( section ){
			
			case 'profile':
			
				$( obj ).unbind('click').removeClass('green').addClass('red').val($txt['unfollow_u']).bind('click', function(){
					return unfollow_u(obj, user, section);
				});
			
			break;
			
			case 'stream':
				
				$(obj).parent().addClass('followed').find('a.follow').attr('title', $txt['unfollow_u']);
				
			break;
			
			}
			
		}
	});
		
}

function unfollow_u(obj, user, section){

	var multi_follows_areas = new Array('stream');
	
	if( empty(user) )
		return false;		
	
	if(global.cache['last_follow_u_action'] == 'unfollow' && $.inArray(section, multi_follows_areas) === -1)
		return false;
		
	if(!global.onetime['unfollow_u'])
            global.onetime['unfollow_u'] = true;
    else
        return;
	
	$.ajax({
		'type' : 'POST',
		'url' : global.data.scripturl + '?action=ajax&do=unfollow_u',
		'dataType' : 'json',
		'data' : 'uid=' + parseInt(user),
		success : function( h ){
			if(h.status == 'error')
				return errors.error(h.msg);
				
			global.cache['last_follow_u_action'] = 'unfollow';			
			global.onetime['unfollow_u'] = false;
			
			switch(section){
			
				case 'profile':
				
					$( obj ).unbind('click').removeClass('red').addClass('green').val($txt['follow_u']).bind('click', function(){
						return follow_u(obj, user, section);
					});
				
				break;
				
				case 'stream':
					
					$(obj).parent().removeClass('followed').find('a.follow').attr('title', $txt['follow_u']);
					
				break;
				
			}
		}
	});

}

var sp_dialog = {
    dialog : {},
    dialog_load : {},
    started : false,
    options : {},
    calls_open : [],

    show : function(action){

    var options = this.options;


        if(action == 'load' && this.started){
                    $('.ui-dialog').append('<div class="mask-load rounded load-dialog visible with-icon"></div>');
                    return;
        }

        if(this.started)
            return false;
        else
            this.started = true;

        if($('.ui-dialog').size() == 0)
        var dialog = $('<div id="dialog-context" class="hide"></div>').appendTo('body');
        this.dialog = dialog;

        var DialogClass = '';

        if(options.title)
            $(dialog).attr('title', options.title);
        else
            DialogClass += ' no-title ';

        if(options.noclose)
            DialogClass += ' no-close ';

        if(options.noclose && !options.title)
                DialogClass += ' hide-title ';

        
        $(dialog).dialog({modal: true, open: function(){

                if(options.beforeShow)
                    options.beforeShow();

                if(action == 'load')
                    $('.ui-dialog').append('<div class="mask-load rounded load-dialog visible with-icon"></div>');

                $('.ui-dialog .ui-dialog-titlebar-close').unbind('click').removeAttr('href');

                $('.ui-dialog .ui-dialog-titlebar-close').bind('click', function(){
                    sp_dialog.close();
                });

        }});

        if(!options.body)
            return this.destroy();

        $(dialog).html(options.body);

        
        $(dialog).dialog({
            dialogClass : DialogClass + (options.dialogClass ? options.dialogClass : ''),            
            resizable: false,
            autoOpen : false,
            draggable : false,
            width: options.width ? options.width : 350
        })

        if(options.fade){
            $(dialog).dialog("option", "show", "fade");
            $(dialog).dialog("option", "hide", "fade");
        }


        if(options.delay){
            setTimeout(function(){
                $(dialog).dialog("open");
            }, options.delay);
        }else
            $(dialog).dialog("open");

         


    },

    close : function(callback){

        if(!this.dialog)
            return;
        
        $(this.dialog).dialog("close");

        if(callback){
           setTimeout(function(){
                callback();
           }, 500);                
        }

        this.started = false;
        this.dialog = {};
        this.dialog_load = {};        
        this.destroy();
		this.dialog.options = {}
        
    },
    destroy : function(){

        if(!this.dialog)
            return;

        $('#dialog-context').remove();
        $('.ui-dialog').remove();  

    },
    load : function(){
        var loadTemplate = $('<div id="load-dialog"><div class="mask-load rounded visible with-icon"></div></div>');
        this.dialog_load = loadTemplate;
        
        $(loadTemplate).dialog({
            dialogClass : 'hide-title',
            modal : true,
            open : function(){
                $(this).css('min-height', '30px');
            }
        });

    },
    endload : function(callback, subload){
	
        if(subload){
            $('.load-dialog').fadeOut(function(){
                $(this).remove();

                if(callback)
                    callback();
            });
            return;
        }

        if(!this.dialog_load)
            return $('.mask-load').hide();

        $(this.dialog_load).dialog({
            close : function(){
                $(this).dialog("destroy");
                $('#load-dialog').remove();
                if(callback)
                    callback();
            }
        });
        $(this.dialog_load).dialog("close");
    },
    center : function(){
        if(!this.dialog)
            return;

        setTimeout(function(){
        $(this.dialog).dialog("option", "position", "center");

        if($('.ui-dialog ')[0].offsetHeight < $(window).height())
            $('.ui-dialog').css({'position' : 'fixed'});
        else
            $('.ui-dialog').css({'position' : 'absolute', 'top' : 100});
        }, 100);

        $(this.dialog).dialog("option", "position", "center");

        if($('.ui-dialog ')[0].offsetHeight < $(window).height())
            $('.ui-dialog').css({'position' : 'fixed'});
        else
            $('.ui-dialog').css({'position' : 'absolute', 'top' : 100});
    },
    buttons : function(buttons){

        if(!this.dialog)
            return;

        buttons = buttons || new Array();

        $(this.dialog).dialog({buttons: buttons});

    },
    alert : function(){

        if(arguments.length == 1 && typeof arguments[0] == 'object'){
            this.options.title = arguments[0].title ? arguments[0].title : false;
            this.options.body = arguments[0].body ? arguments[0].body : '';
        }else{
            this.options.title = arguments[0] ? arguments[0] : false;
            this.options.body = arguments[1] ? arguments[1] : ''
        }

        this.show();

        this.buttons([{
                    text: "Aceptar",
                    "class": 'right close-button-dialog',
                    click: function() {
                        sp_dialog.close();
                    }
                }]);
        
    }
}

/* Dialog box */

var dialogbox = {
    DOM : {'top' : 0, 'left' : 0},
    options : {'easyClose' : true},
    cache : {},
    started : false,


    show : function(options){

        if(this.started)
            return false;
        else
            this.started = true;

        var template = $('<div id="dialogbox" class="dialogbox ui-border-radius"><div class="content" id="dialogbox-content"><div class="body" id="body"></div></div></div>');

        $('body').prepend('<div class="overlay-dialog"></div>');

        if(!$('.dialogbox').size())
        $('body').prepend(template);

        if(this.options.easyClose){
            $(template).find('.content a.close').remove();
            $('.overlay-dialog').bind('click', function(){
                dialogbox.close();
            });
        }else{
            $('.overlay-dialog').unbind('click');
            $(template).find('.content').append('<a class="close visible" onclick="dialogbox.close()"></a>');
        }
            

        $(document).keyup(function(e) {
            if (e.keyCode == 27) 
                dialogbox.close();  // esc       
        });

        $(template).find('.content').prepend('<div class="title"'+ (this.options.loading ? ' style="display:none"' : '') +'></div>');

        
        $('.overlay-dialog').css({'width':$(document).width(),'height':$(document).height(),'display':'block'});

        if(jQuery.browser.msie)
		$('.dialogbox').css('position', 'absolute');

        $('.dialogbox').show();

        this.centerbox();

    },

    centerbox : function(){
        if($('#dialogbox')[0].offsetHeight > $(window).height())
		$('#dialogbox').css({'position':'absolute', 'top':20});
        else
        $('#dialogbox').css({
                             'top' : $(window).height()/2 - $('.dialogbox')[0].offsetHeight/2,
                             'left' : $(window).width()/2 - $('.dialogbox').width()/2
        });

        

        this.DOM.left = $(window).width()/2 - $('.dialogbox').width()/2;
        this.DOM.top = $(window).height()/2 - $('.dialogbox')[0].offsetHeight/2;

    },

    html : function(options){
        
        try{
        if(options.title){
            $('.dialogbox .content .title').show();
            $('.dialogbox .content .title').html(options.title);
        }else
            $('.dialogbox .content .title').hide();
    
        $('#dialogbox-content #body').html(options.body);

        // dialogbox.centerbox();
        }catch(e){
            alert('debug: ' + e);
        }
    },

    close : function(callback, delay){

        if(this.options.loading)
            return false;

        this.started = false;
        this.options = {'easyClose' : true};

            $('.loadialog').stop();
            $('.dialogbox').stop().fadeOut('fast', function(){$('.dialogbox').remove();});
            $('.overlay-dialog').css('display', 'none');
            $('.overlay-dialog').remove();


            if(callback)
                setTimeout(function(){
                callback();
                }, delay ? delay : 1000);
            
    },

    loading : function(){

        this.options.loading = true;
        this.show();

        $('a.close').hide();
        //$('.dialogbox .content .buttons').empty();
        $('.dialogbox .content .title').hide();
        $('.dialogbox .content .body').hide();
        $('.dialogbox .content .buttons').hide();

        if(!$('#loadialog').size())
            $('.dialogbox .content').append('<div class="loadialog" id="loadialog"><strong>' + $txt['loading'] + '</strong></div>');
        else
             $('#loadialog').show();

         this.centerbox();
        $('.loadialog strong').effect('pulsate', {times: 999}, 1000);


    },

    endloading : function(callback){
        
        $('.loadialog').stop();
        $('.dialogbox').hide();
        $('#loadialog').hide();

        $('#loadialog').hide();
        $('.loadialog').hide();
        $('.dialogbox').fadeIn('fast');

        $('.dialogbox .content .title').show();
        $('.dialogbox .content .body').show();
        $('.dialogbox .content .buttons').show();

        this.centerbox();

        this.options.loading = false;

        if(callback)
            callback();

    },

    buttons : function(val, class_, func){

        var x = val.split('|').length;
        var values = val.split('|');
        var classes = class_.split('|');
        var funcs = func.split('|');
        var buttons = '';

        $('.dialogbox .content .buttons').remove();
        $('.dialogbox .content').append('<div class="buttons" style="display:none"></div>');

        for(i=0;i<x;i++){
            buttons += '<input type="button" value="'+(values[i] ? values[i] : '')+'" class="sp-button ' + (classes[i] ? classes[i] : 'bluesky') + '" onclick="' + (funcs[i] ? funcs[i] : '') + '">';
        }

        $('.dialogbox .content .buttons').html(buttons);
        $('.dialogbox .content .buttons').show();

        this.centerbox(); // al agregar los botones aumenta el tama�o de la ventana modal :)
    },

    alerta : function(body, title){

    dialogbox.show();
    dialogbox.html({
        'title' : title ? title : null,
        'body' : body
    });
    dialogbox.buttons($txt['buttons']['accept'], 'bluesky', 'dialogbox.close()');

    }

}
// trim php.js
function trim(a,b){var c,d=0,e=0;a+="";if(!b){c=" \n\r\t\f            ​\u2028\u2029　"}else{b+="";c=b.replace(/([\[\]\(\)\.\?\/\*\{\}\+\$\^\:])/g,"$1")}d=a.length;for(e=0;e<d;e++){if(c.indexOf(a.charAt(e))===-1){a=a.substring(e);break}}d=a.length;for(e=d-1;e>=0;e--){if(c.indexOf(a.charAt(e))===-1){a=a.substring(0,e+1);break}}return c.indexOf(a.charAt(0))===-1?a:""};
// isset php.js
function isset(){var a=arguments,b=a.length,c=0,d;if(b===0){throw new Error("Empty isset")}while(c!==b){if(a[c]===d||a[c]===null){return false}c++}return true}
// rand php.js
function rand(a,b){var c=arguments.length;if(c===0){a=0;b=2147483647}else if(c===1){throw new Error("Warning: rand() expects exactly 2 parameters, 1 given")}return Math.floor(Math.random()*(b-a+1))+a}
/* htmlspecialchars_decode (php.js) 909.322 */
function htmlspecialchars_decode(a,b){var c=0,d=0,e=false;if(typeof b==="undefined"){b=2}a=a.toString().replace(/</g,"<").replace(/>/g,">");var f={ENT_NOQUOTES:0,ENT_HTML_QUOTE_SINGLE:1,ENT_HTML_QUOTE_DOUBLE:2,ENT_COMPAT:2,ENT_QUOTES:3,ENT_IGNORE:4};if(b===0){e=true}if(typeof b!=="number"){b=[].concat(b);for(d=0;d<b.length;d++){if(f[b[d]]===0){e=true}else if(f[b[d]]){c=c|f[b[d]]}}b=c}if(b&f.ENT_HTML_QUOTE_SINGLE){a=a.replace(/&#0*39;/g,"'")}if(!e){a=a.replace(/"/g,'"')}a=a.replace(/&/g,"&");return a}
function get_html_translation_table(d,e){var a={},f={},b=0,c="";c={};var h={},g={},i={};c[0]="HTML_SPECIALCHARS";c[1]="HTML_ENTITIES";h[0]="ENT_NOS";h[2]="ENT_COMPAT";h[3]="ENT_QUOTES";g=!isNaN(d)?c[d]:d?d.toUpperCase():"HTML_SPECIALCHARS";i=!isNaN(e)?h[e]:e?e.toUpperCase():"ENT_COMPAT";if(g!=="HTML_SPECIALCHARS"&&g!=="HTML_ENTITIES")throw new Error("Table: "+g+" not supported");a["38"]="&amp;";if(g==="HTML_ENTITIES"){a["160"]="&nbsp;";a["161"]="&iexcl;";a["162"]="&cent;";a["163"]="&pound;";a["164"]="&curren;";a["165"]="&yen;";a["166"]="&brvbar;";a["167"]="&sect;";a["168"]="&uml;";a["169"]="&copy;";a["170"]="&ordf;";a["171"]="&laquo;";a["172"]="&not;";a["173"]="&shy;";a["174"]="&reg;";a["175"]="&macr;";a["176"]="&deg;";a["177"]="&plusmn;";a["178"]="&sup2;";a["179"]="&sup3;";a["180"]="&acute;";a["181"]="&micro;";a["182"]="&para;";a["183"]="&middot;";a["184"]="&cedil;";a["185"]="&sup1;";a["186"]="&ordm;";a["187"]="&raquo;";a["188"]="&frac14;";a["189"]="&frac12;";a["190"]="&frac34;";a["191"]= "&iquest;";a["192"]="&Agrave;";a["193"]="&Aacute;";a["194"]="&Acirc;";a["195"]="&Atilde;";a["196"]="&Auml;";a["197"]="&Aring;";a["198"]="&AElig;";a["199"]="&Ccedil;";a["200"]="&Egrave;";a["201"]="&Eacute;";a["202"]="&Ecirc;";a["203"]="&Euml;";a["204"]="&Igrave;";a["205"]="&Iacute;";a["206"]="&Icirc;";a["207"]="&Iuml;";a["208"]="&ETH;";a["209"]="&Ntilde;";a["210"]="&Ograve;";a["211"]="&Oacute;";a["212"]="&Ocirc;";a["213"]="&Otilde;";a["214"]="&Ouml;";a["215"]="&times;";a["216"]="&Oslash;";a["217"]= "&Ugrave;";a["218"]="&Uacute;";a["219"]="&Ucirc;";a["220"]="&Uuml;";a["221"]="&Yacute;";a["222"]="&THORN;";a["223"]="&szlig;";a["224"]="&agrave;";a["225"]="&aacute;";a["226"]="&acirc;";a["227"]="&atilde;";a["228"]="&auml;";a["229"]="&aring;";a["230"]="&aelig;";a["231"]="&ccedil;";a["232"]="&egrave;";a["233"]="&eacute;";a["234"]="&ecirc;";a["235"]="&euml;";a["236"]="&igrave;";a["237"]="&iacute;";a["238"]="&icirc;";a["239"]="&iuml;";a["240"]="&eth;";a["241"]="&ntilde;";a["242"]="&ograve;";a["243"]= "&oacute;";a["244"]="&ocirc;";a["245"]="&otilde;";a["246"]="&ouml;";a["247"]="&divide;";a["248"]="&oslash;";a["249"]="&ugrave;";a["250"]="&uacute;";a["251"]="&ucirc;";a["252"]="&uuml;";a["253"]="&yacute;";a["254"]="&thorn;";a["255"]="&yuml;"}if(i!=="ENT_NOQUOTES")a["34"]="&quot;";if(i==="ENT_QUOTES")a["39"]="&#39;";a["60"]="&lt;";a["62"]="&gt;";for(b in a){c=String.fromCharCode(b);f[c]=a[b]}return f}function htmlspecialchars_decode(d,e){var a={},f="",b="",c="";b=d.toString();if(false===(a=this.get_html_translation_table("HTML_SPECIALCHARS",e)))return false;for(f in a){c=a[f];b=b.split(c).join(f)}return b=b.split("&#039;").join("'")};
// empty php.js
function empty(mixed_var){var key;if(mixed_var===""||mixed_var===0||mixed_var==="0"||mixed_var===null||mixed_var===false||typeof mixed_var==='undefined'){return true;}
if(typeof mixed_var=='object'){for(key in mixed_var){return false;}
return true;}
return false;}
// strpos php.js
function strpos(haystack,needle,offset){var i=(haystack+'').indexOf(needle,(offset||0));return i===-1?false:i;}
function implode (glue, pieces) {
    var i = '',
        retVal = '',
        tGlue = '';
    if (arguments.length === 1) {
        pieces = glue;
        glue = '';
    }
    if (typeof(pieces) === 'object') {
        if (Object.prototype.toString.call(pieces) === '[object Array]') {
            return pieces.join(glue);
        }
        for (i in pieces) {
            retVal += tGlue + pieces[i];
            tGlue = glue;
        }
        return retVal;
    }
    return pieces;
}
// sprintf php.js
function sprintf(){var regex=/%%|%(\d+\$)?([-+\'#0 ]*)(\*\d+\$|\*|\d+)?(\.(\*\d+\$|\*|\d+))?([scboxXuidfegEG])/g;var a=arguments,i=0,format=a[i++];var pad=function(str,len,chr,leftJustify){if(!chr){chr=' ';}
var padding=(str.length>=len)?'':Array(1+len-str.length>>>0).join(chr);return leftJustify?str+padding:padding+str;};var justify=function(value,prefix,leftJustify,minWidth,zeroPad,customPadChar){var diff=minWidth-value.length;if(diff>0){if(leftJustify||!zeroPad){value=pad(value,minWidth,customPadChar,leftJustify);}else{value=value.slice(0,prefix.length)+pad('',diff,'0',true)+value.slice(prefix.length);}}
return value;};var formatBaseX=function(value,base,prefix,leftJustify,minWidth,precision,zeroPad){var number=value>>>0;prefix=prefix&&number&&{'2':'0b','8':'0','16':'0x'}[base]||'';value=prefix+pad(number.toString(base),precision||0,'0',false);return justify(value,prefix,leftJustify,minWidth,zeroPad);};var formatString=function(value,leftJustify,minWidth,precision,zeroPad,customPadChar){if(precision!=null){value=value.slice(0,precision);}
return justify(value,'',leftJustify,minWidth,zeroPad,customPadChar);};var doFormat=function(substring,valueIndex,flags,minWidth,_,precision,type){var number;var prefix;var method;var textTransform;var value;if(substring=='%%'){return'%';}
var leftJustify=false,positivePrefix='',zeroPad=false,prefixBaseX=false,customPadChar=' ';var flagsl=flags.length;for(var j=0;flags&&j<flagsl;j++){switch(flags.charAt(j)){case' ':positivePrefix=' ';break;case'+':positivePrefix='+';break;case'-':leftJustify=true;break;case"'":customPadChar=flags.charAt(j+1);break;case'0':zeroPad=true;break;case'#':prefixBaseX=true;break;}}
if(!minWidth){minWidth=0;}else if(minWidth=='*'){minWidth=+a[i++];}else if(minWidth.charAt(0)=='*'){minWidth=+a[minWidth.slice(1,-1)];}else{minWidth=+minWidth;}
if(minWidth<0){minWidth=-minWidth;leftJustify=true;}
if(!isFinite(minWidth)){throw new Error('sprintf: (minimum-)width must be finite');}
if(!precision){precision='fFeE'.indexOf(type)>-1?6:(type=='d')?0:undefined;}else if(precision=='*'){precision=+a[i++];}else if(precision.charAt(0)=='*'){precision=+a[precision.slice(1,-1)];}else{precision=+precision;}
value=valueIndex?a[valueIndex.slice(0,-1)]:a[i++];switch(type){case's':return formatString(String(value),leftJustify,minWidth,precision,zeroPad,customPadChar);case'c':return formatString(String.fromCharCode(+value),leftJustify,minWidth,precision,zeroPad);case'b':return formatBaseX(value,2,prefixBaseX,leftJustify,minWidth,precision,zeroPad);case'o':return formatBaseX(value,8,prefixBaseX,leftJustify,minWidth,precision,zeroPad);case'x':return formatBaseX(value,16,prefixBaseX,leftJustify,minWidth,precision,zeroPad);case'X':return formatBaseX(value,16,prefixBaseX,leftJustify,minWidth,precision,zeroPad).toUpperCase();case'u':return formatBaseX(value,10,prefixBaseX,leftJustify,minWidth,precision,zeroPad);case'i':case'd':number=(+value)|0;prefix=number<0?'-':positivePrefix;value=prefix+pad(String(Math.abs(number)),precision,'0',false);return justify(value,prefix,leftJustify,minWidth,zeroPad);case'e':case'E':case'f':case'F':case'g':case'G':number=+value;prefix=number<0?'-':positivePrefix;method=['toExponential','toFixed','toPrecision']['efg'.indexOf(type.toLowerCase())];textTransform=['toString','toUpperCase']['eEfFgG'.indexOf(type)%2];value=prefix+Math.abs(number)[method](precision);return justify(value,prefix,leftJustify,minWidth,zeroPad)[textTransform]();default:return substring;}};return format.replace(regex,doFormat);}

/* $.tmpl Beta */
(function(a){var r=a.fn.domManip,d="_tmplitem",q=/^[^<]*(<[\w\W]+>)[^>]*$|\{\{\! /,b={},f={},e,p={key:0,data:{}},h=0,c=0,l=[];function g(e,d,g,i){var c={data:i||(d?d.data:{}),_wrap:d?d._wrap:null,tmpl:null,parent:d||null,nodes:[],calls:u,nest:w,wrap:x,html:v,update:t};e&&a.extend(c,e,{nodes:[],parent:d});if(g){c.tmpl=g;c._ctnt=c._ctnt||c.tmpl(a,c);c.key=++h;(l.length?f:b)[h]=c}return c}a.each({appendTo:"append",prependTo:"prepend",insertBefore:"before",insertAfter:"after",replaceAll:"replaceWith"},function(f,d){a.fn[f]=function(n){var g=[],i=a(n),k,h,m,l,j=this.length===1&&this[0].parentNode;e=b||{};if(j&&j.nodeType===11&&j.childNodes.length===1&&i.length===1){i[d](this[0]);g=this}else{for(h=0,m=i.length;h<m;h++){c=h;k=(h>0?this.clone(true):this).get();a.fn[d].apply(a(i[h]),k);g=g.concat(k)}c=0;g=this.pushStack(g,f,i.selector)}l=e;e=null;a.tmpl.complete(l);return g}});a.fn.extend({tmpl:function(d,c,b){return a.tmpl(this[0],d,c,b)},tmplItem:function(){return a.tmplItem(this[0])},template:function(b){return a.template(b,this[0])},domManip:function(d,l,j){if(d[0]&&d[0].nodeType){var f=a.makeArray(arguments),g=d.length,i=0,h;while(i<g&&!(h=a.data(d[i++],"tmplItem")));if(g>1)f[0]=[a.makeArray(d)];if(h&&c)f[2]=function(b){a.tmpl.afterManip(this,b,j)};r.apply(this,f)}else r.apply(this,arguments);c=0;!e&&a.tmpl.complete(b);return this}});a.extend({tmpl:function(d,h,e,c){var j,k=!c;if(k){c=p;d=a.template[d]||a.template(null,d);f={}}else if(!d){d=c.tmpl;b[c.key]=c;c.nodes=[];c.wrapped&&n(c,c.wrapped);return a(i(c,null,c.tmpl(a,c)))}if(!d)return[];if(typeof h==="function")h=h.call(c||{});e&&e.wrapped&&n(e,e.wrapped);j=a.isArray(h)?a.map(h,function(a){return a?g(e,c,d,a):null}):[g(e,c,d,h)];return k?a(i(c,null,j)):j},tmplItem:function(b){var c;if(b instanceof a)b=b[0];while(b&&b.nodeType===1&&!(c=a.data(b,"tmplItem"))&&(b=b.parentNode));return c||p},template:function(c,b){if(b){if(typeof b==="string")b=o(b);else if(b instanceof a)b=b[0]||{};if(b.nodeType)b=a.data(b,"tmpl")||a.data(b,"tmpl",o(b.innerHTML));return typeof c==="string"?(a.template[c]=b):b}return c?typeof c!=="string"?a.template(null,c):a.template[c]||a.template(null,q.test(c)?c:a(c)):null},encode:function(a){return(""+a).split("<").join("&lt;").split(">").join("&gt;").split('"').join("&#34;").split("'").join("&#39;")}});a.extend(a.tmpl,{tag:{tmpl:{_default:{$2:"null"},open:"if($notnull_1){_=_.concat($item.nest($1,$2));}"},wrap:{_default:{$2:"null"},open:"$item.calls(_,$1,$2);_=[];",close:"call=$item.calls();_=call._.concat($item.wrap(call,_));"},each:{_default:{$2:"$index, $value"},open:"if($notnull_1){$.each($1a,function($2){with(this){",close:"}});}"},"if":{open:"if(($notnull_1) && $1a){",close:"}"},"else":{_default:{$1:"true"},open:"}else if(($notnull_1) && $1a){"},html:{open:"if($notnull_1){_.push($1a);}"},"=":{_default:{$1:"$data"},open:"if($notnull_1){_.push($.encode($1a));}"},"!":{open:""}},complete:function(){b={}},afterManip:function(f,b,d){var e=b.nodeType===11?a.makeArray(b.childNodes):b.nodeType===1?[b]:[];d.call(f,b);m(e);c++}});function i(e,g,f){var b,c=f?a.map(f,function(a){return typeof a==="string"?e.key?a.replace(/(<\w+)(?=[\s>])(?![^>]*_tmplitem)([^>]*)/g,"$1 "+d+'="'+e.key+'" $2'):a:i(a,e,a._ctnt)}):e;if(g)return c;c=c.join("");c.replace(/^\s*([^<\s][^<]*)?(<[\w\W]+>)([^>]*[^>\s])?\s*$/,function(f,c,e,d){b=a(e).get();m(b);if(c)b=j(c).concat(b);if(d)b=b.concat(j(d))});return b?b:j(c)}function j(c){var b=document.createElement("div");b.innerHTML=c;return a.makeArray(b.childNodes)}function o(b){return new Function("jQuery","$item","var $=jQuery,call,_=[],$data=$item.data;with($data){_.push('"+a.trim(b).replace(/([\\'])/g,"\\$1").replace(/[\r\t\n]/g," ").replace(/\$\{([^\}]*)\}/g,"{{= $1}}").replace(/\{\{(\/?)(\w+|.)(?:\(((?:[^\}]|\}(?!\}))*?)?\))?(?:\s+(.*?)?)?(\(((?:[^\}]|\}(?!\}))*?)\))?\s*\}\}/g,function(m,l,j,d,b,c,e){var i=a.tmpl.tag[j],h,f,g;if(!i)throw"Template command not found: "+j;h=i._default||[];if(c&&!/\w$/.test(b)){b+=c;c=""}if(b){b=k(b);e=e?","+k(e)+")":c?")":"";f=c?b.indexOf(".")>-1?b+c:"("+b+").call($item"+e:b;g=c?f:"(typeof("+b+")==='function'?("+b+").call($item):("+b+"))"}else g=f=h.$1||"null";d=k(d);return"');"+i[l?"close":"open"].split("$notnull_1").join(b?"typeof("+b+")!=='undefined' && ("+b+")!=null":"true").split("$1a").join(g).split("$1").join(f).split("$2").join(d?d.replace(/\s*([^\(]+)\s*(\((.*?)\))?/g,function(d,c,b,a){a=a?","+a+")":b?")":"";return a?"("+c+").call($item"+a:d}):h.$2||"")+"_.push('"})+"');}return _;")}function n(c,b){c._wrap=i(c,true,a.isArray(b)?b:[q.test(b)?b:a(b).html()]).join("")}function k(a){return a?a.replace(/\\'/g,"'").replace(/\\\\/g,"\\"):null}function s(b){var a=document.createElement("div");a.appendChild(b.cloneNode(true));return a.innerHTML}function m(o){var n="_"+c,k,j,l={},e,p,i;for(e=0,p=o.length;e<p;e++){if((k=o[e]).nodeType!==1)continue;j=k.getElementsByTagName("*");for(i=j.length-1;i>=0;i--)m(j[i]);m(k)}function m(j){var p,i=j,k,e,m;if(m=j.getAttribute(d)){while(i.parentNode&&(i=i.parentNode).nodeType===1&&!(p=i.getAttribute(d)));if(p!==m){i=i.parentNode?i.nodeType===11?0:i.getAttribute(d)||0:0;if(!(e=b[m])){e=f[m];e=g(e,b[i]||f[i],null,true);e.key=++h;b[h]=e}c&&o(m)}j.removeAttribute(d)}else if(c&&(e=a.data(j,"tmplItem"))){o(e.key);b[e.key]=e;i=a.data(j.parentNode,"tmplItem");i=i?i.key:0}if(e){k=e;while(k&&k.key!=i){k.nodes.push(j);k=k.parent}delete e._ctnt;delete e._wrap;a.data(j,"tmplItem",e)}function o(a){a=a+n;e=l[a]=l[a]||g(e,b[e.parent.key+n]||e.parent,null,true)}}}function u(a,d,c,b){if(!a)return l.pop();l.push({_:a,tmpl:d,item:this,data:c,options:b})}function w(d,c,b){return a.tmpl(a.template(d),c,b,this)}function x(b,d){var c=b.options||{};c.wrapped=d;return a.tmpl(a.template(b.tmpl),b.data,c,b.item)}function v(d,c){var b=this._wrap;return a.map(a(a.isArray(b)?b.join(""):b).filter(d||"*"),function(a){return c?a.innerText||a.textContent:a.outerHTML||s(a)})}function t(){var b=this.nodes;a.tmpl(null,null,null,this).insertBefore(b[0]);a(b).remove()}})(jQuery)

/* preload images */
;(function($) {
	var imgList = [];
	$.extend({
		preload: function(imgArr, option) {
			var setting = $.extend({
				init: function(loaded, total) {},
				loaded: function(img, loaded, total) {},
				loaded_all: function(loaded, total) {},
				config : {'min_width' : false, 'min_height': false},
			}, option);
			
			var total = imgArr.length;
			var loaded = 0;
			var non_loaded = 0;
			var really_loaded = 0;
			var allowed_imgs = [];
			var count_i = 0;
			
			setting.init(0, total);
			
			for(var i in imgArr) {
			
				imgList.push(
					$("<img />")
					.attr("src", imgArr[i])
					.load(function() {
					
					count_i++;
					
					var no_pass = false;
					
					var clone = $(this).clone();

					$(clone)
					.css("position", "absolute")
					.css("left", -9999)
					.css("top", -9999);
					
					$(document.body).append(clone);
					
					var f = Math.min(100/$(clone)[0].offsetWidth, 100/$(clone)[0].offsetHeight, 1);
					var calc_width = Math.round(f*$(clone)[0].offsetWidth);
					var calc_height = Math.round(f*$(clone)[0].offsetHeight);
					
					if( setting.config.min_width )
						if ( calc_width < setting.config.min_width )
							no_pass = true;
					
					if(setting.config.min_height ){
					
						if( !no_pass )
							if(calc_height < setting.config.min_height)
								no_pass = true ;
								
					}
					
					$(clone).remove();
					
					if( no_pass ){
						non_loaded++;
						total--;
					}
					else{
					
					loaded++;
					really_loaded = (imgArr.length - non_loaded);
					allowed_imgs.push(this);					
					setting.loaded(this, loaded, total);
					
					}
					
					if ( count_i == imgArr.length ){
						
							if(loaded == total) {
							
								setting.loaded_all(loaded, total);
							
							}
					
					}
					
					})
				);
			}
			
			
		}
	});
})(jQuery);

;(function($) {
    $.fn.resize = function(options) {
 
        var settings = $.extend({
            scale: 1,
            maxWidth: null,
			maxHeight: null
        }, options);
 
        return this.each(function() {
			
			if(this.tagName.toLowerCase() != "img") {
				// Only images can be resized
				return $(this);
			} 

			var width = this.naturalWidth;
			var height = this.naturalHeight;
			if(!width || !height) {
				// Ooops you are an IE user, let's fix it.
				var img = document.createElement('img');
				img.src = this.src;
				
				width = img.width;
				height = img.height;
			}
			
			if(settings.scale != 1) {
				width = width*settings.scale;
				height = height*settings.scale;
			}
			
			var pWidth = 1;
			if(settings.maxWidth != null) {
				pWidth = width/settings.maxWidth;
			}
			var pHeight = 1;
			if(settings.maxHeight != null) {
				pHeight = height/settings.maxHeight;
			}
			var reduce = 1;
			
			if(pWidth < pHeight) {
				reduce = pHeight;
			} else {
				reduce = pWidth;
			}
			
			if(reduce < 1) {
				reduce = 1;
			}
			
			var newWidth = width/reduce;
			var newHeight = height/reduce;
			
			return $(this)
				.attr("width", newWidth)
				.attr("height", newHeight);
			
        });
    }
})(jQuery);


/**
 * This jQuery plugin displays pagination links inside the selected elements.
 *
 * @author Gabriel Birke (birke *at* d-scribe *dot* de)
 * @version 1.2
 * @param {int} maxentries Number of entries to paginate
 * @param {Object} opts Several options (see README for documentation)
 * @return {Object} jQuery Object
 */
jQuery.fn.pagination = function(maxentries, opts){
	opts = jQuery.extend({
		items_per_page:10,
		num_display_entries:10,
		current_page:0,
		num_edge_entries:0,
		link_to:"#",
		prev_text:"Prev",
		next_text:"Next",
		ellipse_text:"...",
		prev_show_always:true,
		next_show_always:true,
		callback:function(){return false;}
	},opts||{});
	
	return this.each(function() {
		/**
		 * Calculate the maximum number of pages
		 */
		function numPages() {
			return Math.ceil(maxentries/opts.items_per_page);
		}
		
		/**
		 * Calculate start and end point of pagination links depending on 
		 * current_page and num_display_entries.
		 * @return {Array}
		 */
		function getInterval()  {
			var ne_half = Math.ceil(opts.num_display_entries/2);
			var np = numPages();
			var upper_limit = np-opts.num_display_entries;
			var start = current_page>ne_half?Math.max(Math.min(current_page-ne_half, upper_limit), 0):0;
			var end = current_page>ne_half?Math.min(current_page+ne_half, np):Math.min(opts.num_display_entries, np);
			return [start,end];
		}
		
		/**
		 * This is the event handling function for the pagination links. 
		 * @param {int} page_id The new page number
		 */
		function pageSelected(page_id, evt){
			current_page = page_id;
			drawLinks();
			var continuePropagation = opts.callback(page_id, panel);
			if (!continuePropagation) {
				if (evt.stopPropagation) {
					evt.stopPropagation();
				}
				else {
					evt.cancelBubble = true;
				}
			}
			return continuePropagation;
		}
		
		/**
		 * This function inserts the pagination links into the container element
		 */
		function drawLinks() {
			panel.empty();
			var interval = getInterval();
			var np = numPages();
			// This helper function returns a handler function that calls pageSelected with the right page_id
			var getClickHandler = function(page_id) {
				return function(evt){ return pageSelected(page_id,evt); }
			}
			// Helper function for generating a single link (or a span tag if it's the current page)
			var appendItem = function(page_id, appendopts){
				page_id = page_id<0?0:(page_id<np?page_id:np-1); // Normalize page id to sane value
				appendopts = jQuery.extend({text:page_id+1, classes:""}, appendopts||{});
				if(page_id == current_page){
					var lnk = jQuery("<span class='current'>"+(appendopts.text)+"</span>");
				}
				else
				{
					var lnk = jQuery("<a>"+(appendopts.text)+"</a>")
						.bind("click", getClickHandler(page_id))
						.attr('href', opts.link_to.replace(/__id__/,page_id));
						
						
				}
				if(appendopts.classes){lnk.addClass(appendopts.classes);}
				panel.append(lnk);
			}
			// Generate "Previous"-Link
			if(opts.prev_text && (current_page > 0 || opts.prev_show_always)){
				appendItem(current_page-1,{text:opts.prev_text, classes:"prev"});
			}
			// Generate starting points
			if (interval[0] > 0 && opts.num_edge_entries > 0)
			{
				var end = Math.min(opts.num_edge_entries, interval[0]);
				for(var i=0; i<end; i++) {
					appendItem(i);
				}
				if(opts.num_edge_entries < interval[0] && opts.ellipse_text)
				{
					jQuery("<span>"+opts.ellipse_text+"</span>").appendTo(panel);
				}
			}
			// Generate interval links
			for(var i=interval[0]; i<interval[1]; i++) {
				appendItem(i);
			}
			// Generate ending points
			if (interval[1] < np && opts.num_edge_entries > 0)
			{
				if(np-opts.num_edge_entries > interval[1]&& opts.ellipse_text)
				{
					jQuery("<span>"+opts.ellipse_text+"</span>").appendTo(panel);
				}
				var begin = Math.max(np-opts.num_edge_entries, interval[1]);
				for(var i=begin; i<np; i++) {
					appendItem(i);
				}
				
			}
			// Generate "Next"-Link
			if(opts.next_text && (current_page < np-1 || opts.next_show_always)){
				appendItem(current_page+1,{text:opts.next_text, classes:"next"});
			}
		}
		
		// Extract current_page from options
		var current_page = opts.current_page;
		// Create a sane value for maxentries and items_per_page
		maxentries = (!maxentries || maxentries < 0)?1:maxentries;
		opts.items_per_page = (!opts.items_per_page || opts.items_per_page < 0)?1:opts.items_per_page;
		// Store DOM element for easy access from all inner functions
		var panel = jQuery(this);
		// Attach control functions to the DOM element 
		this.selectPage = function(page_id){ pageSelected(page_id);}
		this.prevPage = function(){ 
			if (current_page > 0) {
				pageSelected(current_page - 1);
				return true;
			}
			else {
				return false;
			}
		}
		this.nextPage = function(){ 
			if(current_page < numPages()-1) {
				pageSelected(current_page+1);
				return true;
			}
			else {
				return false;
			}
		}
		// When all initialisation is done, draw the links
		drawLinks();
        // call callback function
        opts.callback(current_page, this);
	});
};


// by j0n4th4ntub3
jQuery.fn.removePropertyStyle = function(property){
	return this.each(function(){

            if(!$(this).attr('style'))
                return false;

            var RegExpProperty = new RegExp( property + '(-(left|top|right|bottom)(-(color|width))?)?:[^;\"]+;?', 'i' );
            var newAttrSyle = $(this).attr('style').replace(RegExpProperty, '');

             return $(this).attr('style', newAttrSyle);

        });
}
$.fn.hasAttr = function(name){return this.attr(name) !== undefined;}

;(function(a){function c(c,d){this.$element=a(c);this.options=d;this.enabled=true;b(this.$element)}function b(a){if(a.attr("title")||typeof a.attr("original-title")!="string"){a.attr("original-title",a.attr("title")||"").removeAttr("title")}}c.prototype={show:function(){var b=this.getTitle();if(b&&this.enabled){var c=this.tip();c.find(".tipsy-inner")[this.options.html?"html":"text"](b);c[0].className="tipsy";c.remove().css({top:0,left:0,visibility:"hidden",display:"block"}).appendTo(document.body);var d=a.extend({},this.$element.offset(),{width:this.$element[0].offsetWidth,height:this.$element[0].offsetHeight});var e=c[0].offsetWidth,f=c[0].offsetHeight;var g=typeof this.options.gravity=="function"?this.options.gravity.call(this.$element[0]):this.options.gravity;var h;switch(g.charAt(0)){case"n":h={top:d.top+d.height+this.options.offset,left:d.left+d.width/2-e/2};break;case"s":h={top:d.top-f-this.options.offset,left:d.left+d.width/2-e/2};break;case"e":h={top:d.top+d.height/2-f/2,left:d.left-e-this.options.offset};break;case"w":h={top:d.top+d.height/2-f/2,left:d.left+d.width+this.options.offset};break}if(g.length==2){if(g.charAt(1)=="w"){h.left=d.left+d.width/2-15}else{h.left=d.left+d.width/2-e+15}}c.css(h).addClass("tipsy-"+g);if(this.options.fade){c.stop().css({opacity:0,display:"block",visibility:"visible"}).animate({opacity:this.options.opacity})}else{c.css({visibility:"visible",opacity:this.options.opacity})}}},hide:function(){if(this.options.fade){this.tip().stop().fadeOut(function(){a(this).remove()})}else{this.tip().remove()}},getTitle:function(){var a,c=this.$element,d=this.options;b(c);var a,d=this.options;if(typeof d.title=="string"){a=c.attr(d.title=="title"?"original-title":d.title)}else if(typeof d.title=="function"){a=d.title.call(c[0])}a=(""+a).replace(/(^\s*|\s*$)/,"");return a||d.fallback},tip:function(){if(!this.$tip){this.$tip=a('<div class="tipsy"></div>').html('<div class="tipsy-arrow"></div><div class="tipsy-inner"/></div>')}return this.$tip},validate:function(){if(!this.$element[0].parentNode){this.hide();this.$element=null;this.options=null}},enable:function(){this.enabled=true},disable:function(){this.enabled=false},toggleEnabled:function(){this.enabled=!this.enabled}};a.fn.tipsy=function(b){function f(){var a=d(this);a.hoverState="out";if(b.delayOut==0){a.hide()}else{setTimeout(function(){if(a.hoverState=="out")a.hide()},b.delayOut)}}function e(){var a=d(this);a.hoverState="in";if(b.delayIn==0){a.show()}else{setTimeout(function(){if(a.hoverState=="in")a.show()},b.delayIn)}}function d(d){var e=a.data(d,"tipsy");if(!e){e=new c(d,a.fn.tipsy.elementOptions(d,b));a.data(d,"tipsy",e)}return e}if(b===true){return this.data("tipsy")}else if(typeof b=="string"){return this.data("tipsy")[b]()}b=a.extend({},a.fn.tipsy.defaults,b);if(!b.live)this.each(function(){d(this)});if(b.trigger!="manual"){var g=b.live?"live":"bind",h=b.trigger=="hover"?"mouseenter":"focus",i=b.trigger=="hover"?"mouseleave":"blur";this[g](h,e)[g](i,f)}return this};a.fn.tipsy.defaults={delayIn:0,delayOut:0,fade:false,fallback:"",gravity:"n",html:false,live:false,offset:0,opacity:.8,title:"title",trigger:"hover"};a.fn.tipsy.elementOptions=function(b,c){return a.metadata?a.extend({},c,a(b).metadata()):c};a.fn.tipsy.autoNS=function(){return a(this).offset().top>a(document).scrollTop()+a(window).height()/2?"s":"n"};a.fn.tipsy.autoWE=function(){return a(this).offset().left>a(document).scrollLeft()+a(window).width()/2?"e":"w"}})(jQuery)

/**
 * jQuery.ScrollTo - Easy element scrolling using jQuery.
 * Copyright (c) 2007-2009 Ariel Flesler - aflesler(at)gmail(dot)com | http://flesler.blogspot.com
 */
;(function(d){var k=d.scrollTo=function(a,i,e){d(window).scrollTo(a,i,e)};k.defaults={axis:'xy',duration:parseFloat(d.fn.jquery)>=1.3?0:1};k.window=function(a){return d(window)._scrollable()};d.fn._scrollable=function(){return this.map(function(){var a=this,i=!a.nodeName||d.inArray(a.nodeName.toLowerCase(),['iframe','#document','html','body'])!=-1;if(!i)return a;var e=(a.contentWindow||a).document||a.ownerDocument||a;return d.browser.safari||e.compatMode=='BackCompat'?e.body:e.documentElement})};d.fn.scrollTo=function(n,j,b){if(typeof j=='object'){b=j;j=0}if(typeof b=='function')b={onAfter:b};if(n=='max')n=9e9;b=d.extend({},k.defaults,b);j=j||b.speed||b.duration;b.queue=b.queue&&b.axis.length>1;if(b.queue)j/=2;b.offset=p(b.offset);b.over=p(b.over);return this._scrollable().each(function(){var q=this,r=d(q),f=n,s,g={},u=r.is('html,body');switch(typeof f){case'number':case'string':if(/^([+-]=)?\d+(\.\d+)?(px|%)?$/.test(f)){f=p(f);break}f=d(f,this);case'object':if(f.is||f.style)s=(f=d(f)).offset()}d.each(b.axis.split(''),function(a,i){var e=i=='x'?'Left':'Top',h=e.toLowerCase(),c='scroll'+e,l=q[c],m=k.max(q,i);if(s){g[c]=s[h]+(u?0:l-r.offset()[h]);if(b.margin){g[c]-=parseInt(f.css('margin'+e))||0;g[c]-=parseInt(f.css('border'+e+'Width'))||0}g[c]+=b.offset[h]||0;if(b.over[h])g[c]+=f[i=='x'?'width':'height']()*b.over[h]}else{var o=f[h];g[c]=o.slice&&o.slice(-1)=='%'?parseFloat(o)/100*m:o}if(/^\d+$/.test(g[c]))g[c]=g[c]<=0?0:Math.min(g[c],m);if(!a&&b.queue){if(l!=g[c])t(b.onAfterFirst);delete g[c]}});t(b.onAfter);function t(a){r.animate(g,j,b.easing,a&&function(){a.call(this,n,b)})}}).end()};k.max=function(a,i){var e=i=='x'?'Width':'Height',h='scroll'+e;if(!d(a).is('html,body'))return a[h]-d(a)[e.toLowerCase()]();var c='client'+e,l=a.ownerDocument.documentElement,m=a.ownerDocument.body;return Math.max(l[h],m[h])-Math.min(l[c],m[c])};function p(a){return typeof a=='object'?a:{top:a,left:a}}})(jQuery)

/*
 * jQuery autoResize (textarea auto-resizer)
 * @copyright James Padolsey http://james.padolsey.com
 * @version 1.04
 */

;(function(a){a.fn.autoResize=function(b){var c=a.extend({onResize:function(){},animate:true,animateDuration:150,animateCallback:function(){},extraSpace:20,limit:1e3},b);this.filter("textarea").each(function(){var b=a(this).css({resize:"none","overflow-y":"hidden"}),d=b.height(),e=function(){var c=["height","width","lineHeight","textDecoration","letterSpacing"],d={};a.each(c,function(a,c){d[c]=b.css(c)});return b.clone().removeAttr("id").removeAttr("name").css({position:"absolute",top:0,left:-9999}).css(d).attr("tabIndex","-1").insertBefore(b)}(),f=null,g=function(){e.height(0).val(a(this).val()).scrollTop(1e4);var b=a(this)[0].offsetHeight-parseInt(a(this).css("height"));var g=Math.max(e.scrollTop(),d)+(c.extraSpace=="auto"?b:c.extraSpace),h=a(this).add(e);if(f===g){return}f=g;if(g>=c.limit){a(this).css("overflow-y","");return}c.onResize.call(this);var i=a(this)[0].offsetHeight>0;c.animate&&i?h.stop().animate({height:g},c.animateDuration,c.animateCallback):h.height(g)};b.unbind(".dynSiz").bind("keyup.dynSiz",g).bind("keydown.dynSiz",g).bind("change.dynSiz",g)});return this}})(jQuery)

/*
 * jQuery outside events - v1.1 - 3/16/2010
 * http://benalman.com/projects/jquery-outside-events-plugin/
 * 
 * Copyright (c) 2010 "Cowboy" Ben Alman
 * Dual licensed under the MIT and GPL licenses.
 * http://benalman.com/about/license/
 */
;(function($,c,b){$.map("click dblclick mousemove mousedown mouseup mouseover mouseout change select submit keydown keypress keyup".split(" "),function(d){a(d)});a("focusin","focus"+b);a("focusout","blur"+b);$.addOutsideEvent=a;function a(g,e){e=e||g+b;var d=$(),h=g+"."+e+"-special-event";$.event.special[e]={setup:function(){d=d.add(this);if(d.length===1){$(c).bind(h,f)}},teardown:function(){d=d.not(this);if(d.length===0){$(c).unbind(h)}},add:function(i){var j=i.handler;i.handler=function(l,k){l.target=k;j.apply(this,arguments)}}};function f(i){$(d).each(function(){var j=$(this);if(this!==i.target&&!j.has(i.target).length){j.triggerHandler(e,[i.target])}})}}})(jQuery,document,"outside");


/* markItUp 1.1.10 */
eval(function(p,a,c,k,e,d){e=function(c){return(c<a?'':e(parseInt(c/a)))+((c=c%a)>35?String.fromCharCode(c+29):c.toString(36))};if(!''.replace(/^/,String)){while(c--){d[e(c)]=k[c]||e(c)}k=[function(e){return d[e]}];e=function(){return'\\w+'};c=1};while(c--){if(k[c]){p=p.replace(new RegExp('\\b'+e(c)+'\\b','g'),k[c])}}return p}('(3($){$.2N.Z=3(X,28){p 6,u,A,I;u=A=I=d;6={D:\'\',1d:\'\',12:\'\',1x:\'\',1Y:l,2L:\'2M\',1r:\'~/3g/1H.27\',1m:\'\',2z:\'K\',1B:l,1G:\'\',1Z:\'\',23:{},26:{},25:{},1J:{},1n:[{}]};$.11(6,X,28);2(!6.12){$(\'3h\').1h(3(a,2l){1X=$(2l).1e(0).3i.1K(/(.*)3j\\.3f(\\.3e)?\\.3a$/);2(1X!==2p){6.12=1X[1]}})}7 L.1h(3(){p $$,c,18,16,o,F,Q,V,1g,1s,v,2B,O,1a;$$=$(L);c=L;18=[];1a=d;16=o=0;F=-1;6.1m=1j(6.1m);6.1r=1j(6.1r);3 1j(K,2i){2(2i){7 K.T(/("|\')~\\//g,"$1"+6.12)}7 K.T(/^~\\//,6.12)}3 2D(){D=\'\';1d=\'\';2(6.D){D=\'D="\'+6.D+\'"\'}f 2($$.1E("D")){D=\'D="Z\'+($$.1E("D").1o(0,1).3d())+($$.1E("D").1o(1))+\'"\'}2(6.1d){1d=\'R="\'+6.1d+\'"\'}$$.1I(\'<w \'+1d+\'></w>\');$$.1I(\'<w \'+D+\' R="Z"></w>\');$$.1I(\'<w R="3k"></w>\');$$.2b("2R");1g=$(\'<w R="3l"></w>\').2K($$);$(1P(6.1n)).24(1g);1s=$(\'<w R="3s"></w>\').1O($$);2(6.1B===l&&$.Y.3t!==l){1B=$(\'<w R="3u"></w>\').1O($$).1c("1R",3(e){p h=$$.2j(),y=e.2k,1C,1q;1C=3(e){$$.2d("2j",3r.3q(20,e.2k+h-y)+"3m");7 d};1q=3(e){$("27").1N("2h",1C).1N("2g",1q);7 d};$("27").1c("2h",1C).1c("2g",1q)});1s.2r(1B)}$$.2H(1V).3v(1V);$$.1c("21",3(e,X){2(X.1y!==d){1e()}2(c===$.Z.2c){14(X)}});$$.15(3(){$.Z.2c=L})}3 1P(1n){p C=$(\'<C></C>\'),i=0;$(\'B:2u > C\',C).2d(\'30\',\'k\');$.1h(1n,3(){p q=L,t=\'\',1D,B,j;1D=(q.17)?(q.1Q||\'\')+\' [32+\'+q.17+\']\':(q.1Q||\'\');17=(q.17)?\'2I="\'+q.17+\'"\':\'\';2(q.2e){B=$(\'<B R="36">\'+(q.2e||\'\')+\'</B>\').24(C)}f{i++;2w(j=18.8-1;j>=0;j--){t+=18[j]+"-"}B=$(\'<B R="2f 2f\'+t+(i)+\' \'+(q.34||\'\')+\'"><a 37="" \'+17+\' 1D="\'+1D+\'">\'+(q.1Q||\'\')+\'</a></B>\').1c("38",3(){7 d}).2v(3(){7 d}).1c("2Z",3(){$$.15()}).1R(3(){2(q.2t){3n(q.2t)()}2J(3(){14(q)},1);7 d}).2u(3(){$(\'> C\',L).3U();$(J).3w(\'2v\',3(){$(\'C C\',1g).2s()})},3(){$(\'> C\',L).2s()}).24(C);2(q.2n){18.3R(i);$(B).2b(\'3O\').2r(1P(q.2n))}}});18.3Q();7 C}3 2q(4){2(4){4=4.3X();4=4.T(/\\(\\!\\(([\\s\\S]*?)\\)\\!\\)/g,3(x,a){p b=a.1M(\'|!|\');2(I===l){7(b[1]!==2o)?b[1]:b[0]}f{7(b[1]===2o)?"":b[0]}});4=4.T(/\\[\\!\\[([\\s\\S]*?)\\]\\!\\]/g,3(x,a){p b=a.1M(\':!:\');2(1a===l){7 d}P=3Y(b[0],(b[1])?b[1]:\'\');2(P===2p){1a=l}7 P});7 4}7""}3 H(1i){2($.3M(1i)){1i=1i(V)}7 2q(1i)}3 1k(4){p E=H(Q.E);p 19=H(Q.19);p U=H(Q.U);p M=H(Q.M);2(U!==""){k=E+U+M}f 2(m===\'\'&&19!==\'\'){k=E+19+M}f{4=4||m;2(4.1K(/ $/)){k=E+4.T(/ $/,\'\')+M+\' \'}f{k=E+4+M}}7{k:k,E:E,U:U,19:19,M:M}}3 14(q){p z,j,n,i;V=Q=q;1e();$.11(V,{1u:"",12:6.12,c:c,m:(m||\'\'),o:o,u:u,A:A,I:I});H(6.1G);H(Q.1G);2(u===l&&A===l){H(Q.3B)}$.11(V,{1u:1});2(u===l&&A===l){W=m.1M(/\\r?\\n/);2w(j=0,n=W.8,i=0;i<n;i++){2($.3K(W[i])!==\'\'){$.11(V,{1u:++j,m:W[i]});W[i]=1k(W[i]).k}f{W[i]=""}}4={k:W.3I(\'\\n\')};G=o;z=4.k.8+(($.Y.1F)?n-1:0)}f 2(u===l){4=1k(m);G=o+4.E.8;z=4.k.8-4.E.8-4.M.8;z=z-(4.k.1K(/ $/)?1:0);z-=1v(4.k)}f 2(A===l){4=1k(m);G=o;z=4.k.8;z-=1v(4.k)}f{4=1k(m);G=o+4.k.8;z=0;G-=1v(4.k)}2((m===\'\'&&4.U===\'\')){F+=1T(4.k);G=o+4.E.8;z=4.k.8-4.E.8-4.M.8;F=$$.1f().1l(o,$$.1f().8).8;F-=1T($$.1f().1l(0,o))}$.11(V,{o:o,16:16});2(4.k!==m&&1a===d){2a(4.k);1L(G,z)}f{F=-1}1e();$.11(V,{1u:\'\',m:m});2(u===l&&A===l){H(Q.3L)}H(Q.1Z);H(6.1Z);2(v&&6.1Y){22()}A=I=u=1a=d}3 1T(4){2($.Y.1F){7 4.8-4.T(/\\n*/g,\'\').8}7 0}3 1v(4){2($.Y.2U){7 4.8-4.T(/\\r/g,\'\').8}7 0}3 2a(k){2(J.m){p 29=J.m.2x();29.1b=k}f{c.P=c.P.1l(0,o)+k+c.P.1l(o+m.8,c.P.8)}}3 1L(G,z){2(c.2m){2($.Y.1F&&$.Y.40>=9.5&&z==0){7 d}N=c.2m();N.3S(l);N.41(\'2Q\',G);N.3Z(\'2Q\',z);N.3V()}f 2(c.2P){c.2P(G,G+z)}c.1w=16;c.15()}3 1e(){c.15();16=c.1w;2(J.m){m=J.m;2($.Y.2U){p N=m.2x();p 1p=N.3y();1p.3z(c);1p.3E(\'3F\',N);p s=1p.1b.8-N.1b.8;o=s-(c.P.1o(0,s).8-c.P.1o(0,s).T(/\\r/g,\'\').8);m=N.1b}f{o=c.2O}}f{o=c.2O;m=c.P.1l(o,c.3H)}7 m}3 1H(){2(!v||v.3G){2(6.1x){v=2y.2W(\'\',\'1H\',6.1x);$(2y).3J(3(){v.1U()})}f{O=$(\'<2G R="3x"></2G>\');2(6.2L==\'2M\'){O.1O(1s)}f{O.2K(1g)}v=O[O.8-1].3D||3C[O.8-1]}}f 2(I===l){2(O){O.3N()}f{v.1U()}v=O=d}2(!6.1Y){22()}2(6.1x){v.15()}}3 22(){2E()}3 2E(){p 42;2(6.1m!==\'\'){$.2C({2F:\'3W\',2X:\'1b\',2V:d,2Y:6.1m,K:6.2z+\'=\'+3P($$.1f()),2T:3(K){1S(1j(K,1))}})}f{2(!2B){$.2C({2Y:6.1r,2X:\'1b\',2V:d,2T:3(K){1S(1j(K,1).T(/<!-- 3T -->/g,$$.1f()))}})}}7 d}3 1S(K){2(v.J){31{1W=v.J.2A.1w}33(e){1W=0}v.J.2W();v.J.35(K);v.J.1U();v.J.2A.1w=1W}}3 1V(e){A=e.A;I=e.I;u=(!(e.I&&e.u))?e.u:d;2(e.2F===\'2H\'){2(u===l){B=$("a[2I="+3p.3o(e.1z)+"]",1g).1A(\'B\');2(B.8!==0){u=d;2J(3(){B.39(\'1R\')},1);7 d}}2(e.1z===13||e.1z===10){2(u===l){u=d;14(6.25);7 6.25.1t}f 2(A===l){A=d;14(6.26);7 6.26.1t}f{14(6.23);7 6.23.1t}}2(e.1z===9){2(A==l||u==l||I==l){7 d}2(F!==-1){1e();F=$$.1f().8-F;1L(F,0);F=-1;7 d}f{14(6.1J);7 6.1J.1t}}}}2D()})};$.2N.3c=3(){7 L.1h(3(){p $$=$(L).1N().3b(\'2R\');$$.1A(\'w\').1A(\'w.Z\').1A(\'w\').U($$)})};$.Z=3(X){p 6={1y:d};$.11(6,X);2(6.1y){7 $(6.1y).1h(3(){$(L).15();$(L).2S(\'21\',[6])})}f{$(\'c\').2S(\'21\',[6])}}})(3A);',62,251,'||if|function|string||options|return|length||||textarea|false||else|||||block|true|selection||caretPosition|var|button||||ctrlKey|previewWindow|div|||len|shiftKey|li|ul|id|openWith|caretOffset|start|prepare|altKey|document|data|this|closeWith|range|iFrame|value|clicked|class||replace|replaceWith|hash|lines|settings|browser|markItUp||extend|root||markup|focus|scrollPosition|key|levels|placeHolder|abort|text|bind|nameSpace|get|val|header|each|action|localize|build|substring|previewParserPath|markupSet|substr|stored_range|mouseUp|previewTemplatePath|footer|keepDefault|line|fixIeBug|scrollTop|previewInWindow|target|keyCode|parent|resizeHandle|mouseMove|title|attr|opera|beforeInsert|preview|wrap|onTab|match|set|split|unbind|insertAfter|dropMenus|name|mousedown|writeInPreview|fixOperaBug|close|keyPressed|sp|miuScript|previewAutoRefresh|afterInsert||insertion|refreshPreview|onEnter|appendTo|onCtrlEnter|onShiftEnter|html|extraSettings|newSelection|insert|addClass|focused|css|separator|markItUpButton|mouseup|mousemove|inText|height|clientY|tag|createTextRange|dropMenu|undefined|null|magicMarkups|append|hide|call|hover|click|for|createRange|window|previewParserVar|documentElement|template|ajax|init|renderPreview|type|iframe|keydown|accesskey|setTimeout|insertBefore|previewPosition|after|fn|selectionStart|setSelectionRange|character|markItUpEditor|trigger|success|msie|global|open|dataType|url|focusin|display|try|Ctrl|catch|className|write|markItUpSeparator|href|contextmenu|triggerHandler|js|removeClass|markItUpRemove|toUpperCase|pack|markitup|templates|script|src|jquery|markItUpContainer|markItUpHeader|px|eval|fromCharCode|String|max|Math|markItUpFooter|safari|markItUpResizeHandle|keyup|one|markItUpPreviewFrame|duplicate|moveToElementText|jQuery|beforeMultiInsert|frame|contentWindow|setEndPoint|EndToEnd|closed|selectionEnd|join|unload|trim|afterMultiInsert|isFunction|remove|markItUpDropMenu|encodeURIComponent|pop|push|collapse|content|show|select|POST|toString|prompt|moveEnd|version|moveStart|phtml'.split('|'),0,{}))



/* Editor */
lang['Negrita'] = "Negrita";
lang['Cursiva'] = "Cursiva";
lang['Subrayado'] = "Subrayado";
lang['Alinear a la izquierda'] = "Alinear a la izquierda";
lang['Centrar'] = "Centrar";
lang['Alinear a la derecha'] = "Alinear a la derecha";
lang['Color'] = "Color";
lang['Rojo oscuro'] = "Rojo oscuro";
lang['Rojo'] = "Rojo";
lang['Naranja'] = "Naranja";
lang['Marron'] = "Marr&oacute;n";
lang['Amarillo'] = "Amarillo";
lang['Verde'] = "Verde";
lang['Oliva'] = "Oliva";
lang['Cyan'] = "Cyan";
lang['Azul'] = "Azul";
lang['Azul oscuro'] = "Azul oscuro";
lang['Indigo'] = "Indigo";
lang['Violeta'] = "Violeta";
lang['Negro'] = "Negro";
lang['Tamano'] = "Tama&ntilde;o";
lang['Miniatura'] = "Miniatura";
lang['Pequena'] = "Peque&ntilde;a";
lang['Normal'] = "Normal";
lang['Grande'] = "Grande";
lang['Enorme'] = "Enorme";
lang['Insertar video de YouTube'] = "Insertar video de YouTube";
lang['Insertar video de Google Video'] = "Insertar video de Google Video";
lang['Insertar archivo SWF'] = "Insertar archivo SWF";
lang['Insertar Imagen'] = "Insertar Imagen";
lang['Insertar Link'] = "Insertar Link";
lang['Insertar Emoticon'] = "Insertar Emoticon";
lang['Citar'] = "Citar";
lang['Ingrese la URL que desea postear'] = "Ingrese la URL que desea postear";
lang['Fuente'] = "Fuente";
lang['ingrese el id de yt'] = "Ingrese la URL de YouTube:\nEjemplo:\nhttp://www.youtube.com/watch?v=CACqDFLQIXI";
lang['ingrese el id de gv'] = "Ingrese el ID del video de Google:\n\nEjemplo:\nSi la URL de su video es:\nhttp://video.google.com/videoplay?docid=-5331378923498461236\nEl ID es: -5331378923498461236";
lang['ingrese el id de gv IE'] = "Ingrese el ID del video de Google:\nPor ejemplo: -5331378923498461236";
lang['ingrese la url de swf'] = "Ingrese la URL del archivo swf";
lang['ingrese la url de img'] = "Ingrese la URL de la imagen";
lang['ingrese la url de url'] = "Ingrese la URL que desea postear";
lang['ingrese el txt a citar'] = "Ingrese el texto a citar";
lang['ingrese solo el id de gv'] = "Ingrese solo el ID de GoogleVideo";
lang['Cambiar vista'] = "Cambiar vista";

/* Editor */
//Botones posts
// <richedit>
function strip_tags (input, allowed) {allowed = (((allowed || "") + "").toLowerCase().match(/<[a-z][a-z0-9]*>/g) || []).join('');var tags = /<\/?([a-z][a-z0-9]*)\b[^>]*>/gi,commentsAndPhpTags = /<!--[\s\S]*?-->|<\?(?:php)?[\s\S]*?\?>/gi;return input.replace(commentsAndPhpTags, '').replace(tags, function($0, $1){return allowed.indexOf('<' + $1.toLowerCase() + '>') > -1 ? $0 : '';});}

$.html2bbcode = function (data) {
	if (!data) {return '';}
	// smileys
	var smileys = {
		clipped: {
			'618:616:632': ':F',
			'596:594:610': '8|',
			'420:418:434': 'X(',
			'530:528:544': ':cool:',
			'442:440:456': ':cry:',
			'464:462:478': ':twisted:',
			'574:572:588': '^^',
			'486:484:500': ':|',
			'376:374:390': ':D',
			'552:550:566': ':oops:',
			'508:506:522': ':?',
			'398:396:412': ':(',
			'288:286:302': ':)',
			'354:352:368': ':P',
			'332:330:346': ':roll:',
			'310:308:324': ';)'
		},
		normal: {
			'idiot.gif': ':idiot:',
			'lpmqtp.gif': ':lpmqtp:',
			'8s.gif': ':8S:',
			'bang.gif': ':headbang:',
			'5.gif': ':]',
			'15.gif': ':blind:',
			'17.gif': ':buaa:',
			'hot.gif': ':hot:',
			'cold.gif': ':cold:',
			'globo.gif': ':globo:',
			'zombie.gif': ':zombie:',
			'pacman.gif': ':man:',
			'metal.gif': ':metal:',
			'mario.gif': ':mario:',
			'i.gif': ':info:',
			'exclamacion.gif': ':exc:',
			'pregunta.gif': ':q:',
			'wow.gif': ':WOW:',
			'lol.gif': ':LOL:',
			'no.gif': ':NO:',
			'ok.gif': ':OK:',
			'papel.gif': ':oo:',
			'rip.gif': ':RIP:',
			'koe.gif': ':alien:',
			'106.gif': ':trago:',
			'dolar.gif': ':money:',
			'culo.gif': ':culo:',
			'car.gif': ':auto:',
			'mobe.gif': ':lala:',
			'fantasma.gif': ':fantasma:',
			'getalife.gif': ':GET A LIFE:',
			'limoon.gif': ':limon:',
			'verde.gif': ':verde:',
			'sad2.gif': ':noo:',
			'cry.gif': ':crying:',
			'alabama.gif': ':alaba:',
			'shrug.gif': ':shrug:',
			'bobo.gif': ':bobo:',
			'buenpost.gif': ':buenpost:',
			'grin.gif': ':grin:',
			'love.gif': ':love:',
			'winky.gif': ':winky:',
			'love.gif': ':love:',
			'blaf.gif': ':blaf:',
			'unsure.gif': ':\\/',
			'nao.gif': ':NAO:',
			'postlegal.gif': ':postlegal:',
			'106.gif': ':drink:',
			'culo.gif': ':bunda:',
			'car.gif': ':carro:',
			'limoon.gif': ':limao:',
			'verde.gif': ':dolar:'
		}
	}
	// clean up spaces
	data = data.replace(/^\r\n\<br><br \\\/>/, '');
		
	data = data.replace(/<img src="http:\/\/[^/]+\/images\/space\.gif" style="vertical-align: middle; width: 15px; height: 15px;" hspace="3" vspace="2">/g, '');
	// replace clipped
	data = data.replace(
		/<span style="position: relative;"><img src="http:\/\/[^/]+\/images\/big2v5\.gif" style="position: absolute; top: -([0-9]+)px; clip: rect\(([0-9]+)px, 16px, ([0-9]+)px, 0px\);" hspace="3" vspace="2"><\/span>/g,
		function (m, _1, _2, _3) {
			var k = _1 + ':' + _2 + ':' + _3;
			if (smileys.clipped[k]) {
				return smileys.clipped[k]
			} else {
				return m;
			}
		}
	);
	// replace normal
	data = data.replace(
		/<img src="http:\/\/[^/]+\/images\/smiles\/([a-z0-9]+\.[a-z]+)">/g,
		function (m, _1) {
			if (smileys.normal[_1]) {
				return smileys.normal[_1];
			} else {
				return m;
			}
		}
	);
	// code
	data = data.replace(
		new RegExp('<(?:pre|code)>([^]*?)<\\\/(?:pre|code)>', 'g'),
		function (match, _1) {
			return '[code]' + strip_tags(_1, '<br><br/><br />') + '[/code]'
		}
	);
	/*
	// quotes
	data = data.replace(
		new RegExp('<blockquote><div class="cita"><strong>([^]*?)<\\\/strong> dijo:<\\\/div>', 'g'),
		'[quote=$1]'
	);
	do {
		original = data;
		data = data.replace(
			new RegExp('<div class="citacuerpo">(?:<p>)?([^]*?)(?:<\\\/p>)(?:<br \\\/>)+?<\\\/div><\\\/blockquote>', 'g'),
			function (m, _1) {
				if (_1.match(new RegExp('<div class="citacuerpo">(?:<p>)?([^]*?)(?:<\\\/p>)(?:<br \\\/>)+?<\\\/div><\\\/blockquote>'))) {
					return m;
				} else {
					return _1 + '[/quote]';
				}
			}
		);
	} while (original != data);
	*/
	var quote_regexp = /<blockquote.*><div.*class="cita"><strong>([^<]+)?<\/strong> dijo:<\/div><div.*class="citacuerpo">(?:<br(?:\s?\/>))*(.+)(?:<br(?:\s?\/>))*<\/div><\/blockquote>/gi;
	
	var data2 = data;
	do {
		original = data;
		data = data.replace(quote_regexp, function(all, author, message){
				var quote = '[quote';
					if(author)
						quote += '=' + author + ']' + message + '[/quote]';
					else
						quote += ']' + message + '[/quote]';
					return quote;
			}
		);
	} while (original != data);
	
	// swf
	if(data.match(/http:\/\/((?:www|uk|fr|ie|it|jp|pl|es|nl|br|au|hk|mx|nz|de|ca)\.|)youtube\.com\/(?:(?:watch|)\?v=|v\/|jp\.swf\?video_id=)([0-9A-Za-z-_]{11})(?:.*?)/i))
	data = data.replace(
		new RegExp('(?:<br \\\/>)?(?:<center>)?<embed.+?src="([^]*?)"(.*?)>(?:<\\\/embed>)?(?:<\\\/center>)?', 'g'),
		'[youtube]$1[/youtube]'
	);
	else
	data = data.replace(
		new RegExp('(?:<br>)?(?:<center>)?<embed src="([^]*?)"(.*?)>(?:<\\\/embed>)?(?:<\\\/center>)?', 'g'),
		'[swf=$1]'
	);
	// images
	data = data.replace(/<img\s[^<>]*?src=\"?([^<>]*?)\"?(\s[^<>]*)?\/?>/gi, '[img]$1[/img]');
	// strong
	data = data.replace(/<(strong|b)(\s[^<>]*)?>/gi, '[b]');
	data = data.replace(/<\/(strong|b)>/gi, '[/b]');
	// italic
	data = data.replace(/<(em|i)(\s[^<>]*)?>/gi, '[i]');
	data = data.replace(/<\/(em|i)>/gi, '[/i]');
	// underline
	data = data.replace(/<u(\s[^<>]*)?>/gi, '[u]');
	data = data.replace(/<\/u>/gi, '[/u]');
	// cleanup & pre processing
	data = data.replace(/<div><br(\s[^<>]*)?>/gi, '<div>');
	data = data.replace(/<br(\s[^<>]*)?>/gi, '\n');
	data = data.replace(/<p(\s[^<>]*)?>/gi, '');
	data = data.replace(/<\/p>/gi, '\n');
	data = data.replace(/<\/div>\s*<div([^<>]*)>/gi, '</span>\n<span$1>');
	data = data.replace(/<div([^<>]*)>/gi, '\n<span$1>');
	data = data.replace(/<\/div>/gi, '</span>\n');
	data = data.replace(/&nbsp;/gi, ' ');
	data = data.replace(/&quot;/gi, '\"');
	data = data.replace(/&amp;/gi, '&');
	var sc, sc2;
	do {
		sc = data;
		// font tag (eew!) color
		data = data.replace(/<font\s[^<>]*?color=\"?([^<>]*?)\"?(\s[^<>]*)?>([^<>]*?)<\/font>/gi, '[color=$1]$3[/color]');
		// ...and size
		data = data.replace(
			/<font\s[^<>]*?size=\"?([^<>]*?)\"?(\s[^<>]*)?>([^<>]*?)<\/font>/gi,
			function (m, _1, _2, _3) {
				return '[size=' + fontSize2px(_1) + ']' + _3 + '[/size]';
			}
		);
		// font tag cleanup
		if(sc == data) {
			data = data.replace(/<font[^<>]*>([^<>]*?)<\/font>/gi, '$1');
		}
		data = data.replace(/<a\s[^<>]*?href=\"?([^<>]*?)\"?(\s[^<>]*)?>([^<>]*?)<\/a>/gi, '[url=$1]$3[/url]');
		sc2 = data;
		data = data.replace(/<(span|blockquote|pre)\s[^<>]*?style=\"?font-weight: ?bold;?\"?\s*([^<]*?)<\/\1>/gi, '[b]<$1 style=$2</$1>[/b]');
		data = data.replace(/<(span|blockquote|pre)\s[^<>]*?style=\"?font-weight: ?normal;?\"?\s*([^<]*?)<\/\1>/gi, '<$1 style=$2</$1>');
		data = data.replace(/<(span|blockquote|pre)\s[^<>]*?style=\"?font-style: ?italic;?\"?\s*([^<]*?)<\/\1>/gi, '[i]<$1 style=$2</$1>[/i]');
		data = data.replace(/<(span|blockquote|pre)\s[^<>]*?style=\"?font-style: ?normal;?\"?\s*([^<]*?)<\/\1>/gi, '<$1 style=$2</$1>');
		data = data.replace(/<(span|blockquote|pre)\s[^<>]*?style=\"?text-decoration: ?underline;?\"?\s*([^<]*?)<\/\1>/gi, '[u]<$1 style=$2</$1>[/u]');
		data = data.replace(/<(span|blockquote|pre)\s[^<>]*?style=\"?text-decoration: ?none;?\"?\s*([^<]*?)<\/\1>/gi, '<$1 style=$2</$1>');
		data = data.replace(/<(span|blockquote|pre)\s[^<>]*?style=\"?color: ?([^<>]*?);\"?\s*([^<]*?)<\/\1>/gi, '[color=$2]<$1 style=$3</$1>[/color]');
		data = data.replace(/<(span|blockquote|pre)\s[^<>]*?style=\"?font-family: ?([^<>]*?);\"?\s*([^<]*?)<\/\1>/gi, '[font=$2]<$1 style=$3</$1>[/font]');
		// alignment
		data = data.replace(/<(span|blockquote|pre)\s[^<>]*?style=\"?text-align: ?([^<>]*?);\"?\s*([^<]*?)<\/\1>/gi, '[align=$2]<$1 style=$3</$1>[/align]');
		data = data.replace(
			/<(span|blockquote|pre)\s[^<>]*?style=\"?font-size: ?([^<>]*?);\"?\s*([^<]*?)<\/\1>/gi,
			function (m, _1, _2, _3) {
				return '[size=' + parseInt(_2) + ']<' + _1 + ' style=' + _3 + '</' + _1 + '>[/size]';
			}
		);
		data = data.replace(/<(blockquote|pre)\s[^<>]*?style=\"?\"? (class=|id=)([^<>]*)>([^<>]*?)<\/\1>/gi, '<$1 $2$3>$4</$1>');
		data = data.replace(/<span\s[^<>]*?style=\"?\"?>([^<>]*?)<\/span>/gi, '$1');
		if(sc2 == data) {
			data = data.replace(/<span[^<>]*>([^<>]*?)<\/span>/gi, '$1');
			sc2 = data;
		}
	} while(sc != data);
	data = data.replace(/<[^<>]*>/gi, '');
	data = data.replace(/&lt;/gi, '<');
	data = data.replace(/&gt;/gi, '>');
	// childs against parents
	/*do {
		sc = data;
		data = data.replace(/\[(b|i|u)\]\[quote([^\]]*)\]([\s\S]*?)\[\/quote\]\[\/\1\]/gi, '[quote$2][$1]$3[/$1][/quote]');
		data = data.replace(/\[color=([^\]]*)\]\[quote([^\]]*)\]([\s\S]*?)\[\/quote\]\[\/color\]/gi, '[quote$2][color=$1]$3[/color][/quote]');
		data = data.replace(/\[(b|i|u)\]\[code\]([\s\S]*?)\[\/code\]\[\/\1\]/gi, '[code][$1]$2[/$1][/code]');
		data = data.replace(/\[color=([^\]]*)\]\[code\]([\s\S]*?)\[\/code\]\[\/color\]/gi, '[code][color=$1]$2[/color][/code]');
	} while(sc != data);*/
	do {
		sc = data;
		data = data.replace(/\[b\]\[\/b\]/gi, '');
		data = data.replace(/\[i\]\[\/i\]/gi, '');
		data = data.replace(/\[u\]\[\/u\]/gi, '');
		data = data.replace(/\[quote[^\]]*\]\[\/quote\]/gi, '');
		data = data.replace(/\[code\]\[\/code\]/gi, '');
		data = data.replace(/\[url=([^\]]+)\]\[\/url\]/gi, '');
		data = data.replace(/\[img\]\[\/img\]/gi, '');
		data = data.replace(/\[color=([^\]]*)\]\[\/color\]/gi, '');
	} while (sc != data);
	return data;
}

function px2fontSize(px) {
	var size = 7;
	if (px < 11) {
		size = 1;
	} else if (px < 14) {
		size = 2;
	} else if (px < 17) {
		size = 3;
	} else if (px < 21) {
		size = 4;
	} else if (px < 28) {
		size = 5;
	} else if (px < 40) {
		size = 6;
	}
	return size;
}

function fontSize2px(size) {
	var sizes = [ 0, 10, 12, 16, 18, 24, 32, 48 ];
	if (sizes[size]) {
		return sizes[size];
	} else {
		return 0;
	}
}


var mySettings = {
	markupSet: [
		{
			action: 'bold',
			name: 'Negrita',
			key: 'B',
			openWith: '[b]',
			closeWith: '[/b]',
			beforeInsert: function (r) {
				$('#markItUp').get(0).tagInsert(r);
			}
		},
		{
			action: 'italic',
			name: 'Cursiva',
			key: 'I',
			openWith: '[i]',
			closeWith: '[/i]',
			beforeInsert: function (r) {
				$('#markItUp').get(0).tagInsert(r);
			}
		},
		{
			action: 'underline',
			name: 'Subrayado',
			key: 'U',
			openWith: '[u]',
			closeWith: '[/u]',
			beforeInsert: function (r) {
				$('#markItUp').get(0).tagInsert(r);
			}
		},
		{
			separator: '-'
		},
		{
			action: 'justifyLeft',
			name: 'Alinear a la izquierda',
			openWith: '[align=left]',
			closeWith: '[/align]',
			beforeInsert: function (r) {
				$('#markItUp').get(0).tagInsert(r);
			}
		},
		{
			action: 'justifyCenter',
			name: 'Alinear al centro',
			openWith: '[align=center]',
			closeWith: '[/align]',
			beforeInsert: function (r) {
				$('#markItUp').get(0).tagInsert(r);
			}
		},
		{
			action: 'justifyRight',
			name: 'Alinear a la derecha',
			openWith: '[align=right]',
			closeWith: '[/align]',
			beforeInsert: function (r) {
				$('#markItUp').get(0).tagInsert(r);
			}
		},
		{
			separator: '-'
		},
		{
			name: 'Color',
			dropMenu: [
				{
					action: 'foreColor',
					name: 'Rojo oscuro',
					openWith: '[color=darkred]',
					closeWith: '[/color]',
					beforeInsert: function (r) {
						$('#markItUp').get(0).tagInsert(r, 'darkred');
					}
				},
				{
					action: 'foreColor',
					name: 'Rojo',
					openWith: '[color=red]',
					closeWith: '[/color]',
					beforeInsert: function (r) {
						$('#markItUp').get(0).tagInsert(r, 'red');
					}
				},
				{
					action: 'foreColor',
					name: 'Naranja',
					openWith: '[color=orange]',
					closeWith: '[/color]',
					beforeInsert: function (r) {
						$('#markItUp').get(0).tagInsert(r, 'orange');
					}
				},
				{
					action: 'foreColor',
					name: 'Marron',
					openWith: '[color=brown]',
					closeWith: '[/color]',
					beforeInsert: function (r) {
						$('#markItUp').get(0).tagInsert(r, 'brown');
					}
				},
				{
					action: 'foreColor',
					name: 'Amarillo',
					openWith: '[color=yellow]',
					closeWith: '[/color]',
					beforeInsert: function (r) {
						$('#markItUp').get(0).tagInsert(r, 'yellow');
					}
				},
				{
					action: 'foreColor',
					name: 'Verde',
					openWith: '[color=green]',
					closeWith: '[/color]',
					beforeInsert: function (r) {
						$('#markItUp').get(0).tagInsert(r, 'green');
					}
				},
				{
					action: 'foreColor',
					name: 'Oliva',
					openWith: '[color=olive]',
					closeWith: '[/color]',
					beforeInsert: function (r) {
						$('#markItUp').get(0).tagInsert(r, 'olive');
					}
				},
				{
					action: 'foreColor',
					name: 'Cyan',
					openWith: '[color=cyan]',
					closeWith: '[/color]',
					beforeInsert: function (r) {
						$('#markItUp').get(0).tagInsert(r, 'cyan');
					}
				},
				{
					action: 'foreColor',
					name: 'Azul',
					openWith: '[color=blue]',
					closeWith: '[/color]',
					beforeInsert: function (r) {
						$('#markItUp').get(0).tagInsert(r, 'blue');
					}
				},
				{
					action: 'foreColor',
					name: 'Azul oscuro',
					openWith: '[color=darkblue]',
					closeWith: '[/color]',
					beforeInsert: function (r) {
						$('#markItUp').get(0).tagInsert(r, 'darkblue');
					}
				},
				{
					action: 'foreColor',
					name: '&Iacute;ndigo',
					openWith: '[color=indigo]',
					closeWith: '[/color]',
					beforeInsert: function (r) {
						$('#markItUp').get(0).tagInsert(r, 'indigo');
					}
				},
				{
					action: 'foreColor',
					name: 'Violeta',
					openWith: '[color=violet]',
					closeWith: '[/color]',
					beforeInsert: function (r) {
						$('#markItUp').get(0).tagInsert(r, 'violet');
					}
				},
				{
					action: 'foreColor',
					name: 'Negro',
					openWith: '[color=black]',
					closeWith: '[/color]',
					beforeInsert: function (r) {
						$('#markItUp').get(0).tagInsert(r, 'black');
					}
				}
			]
		},
				{
			name: 'Fuente',
			dropMenu: [
				{
					action: 'fontSize',
					name: 'Pequeña',
					openWith: '[size=9]',
					closeWith: '[/size]',
					beforeInsert: function (r) {
						$('#markItUp').get(0).tagInsert(r, px2fontSize(9));
					}
				},
				{
					action: 'fontSize',
					name: 'Normal',
					openWith: '[size=12]',
					closeWith: '[/size]',
					beforeInsert: function (r) {
						$('#markItUp').get(0).tagInsert(r, px2fontSize(12));
					}
				},
				{
					action: 'fontSize',
					name: 'Grande',
					openWith: '[size=18]',
					closeWith: '[/size]',
					beforeInsert: function (r) {
						$('#markItUp').get(0).tagInsert(r, px2fontSize(18));
					}
				},
				{
					action: 'fontSize',
					name: 'Enorme',
					openWith: '[size=24]',
					closeWith: '[/size]',
					beforeInsert: function (r) {
						$('#markItUp').get(0).tagInsert(r, px2fontSize(24));
					}
				}
			]
		},
		{
			name: 'Fuente',
			dropMenu: [
				{
					action: 'fontName',
					name: 'Arial',
					openWith: '[font=Arial]',
					closeWith: '[/font]',
					beforeInsert: function (r) {
						$('#markItUp').get(0).tagInsert(r, 'Arial');
					}
				},
				{
					action: 'fontName',
					name: 'Courier New',
					openWith: '[font=Courier New]',
					closeWith: '[/font]',
					beforeInsert: function (r) {
						$('#markItUp').get(0).tagInsert(r, 'Courier New');
					}
				},
				{
					action: 'fontName',
					name: 'Georgia',
					openWith: '[font=Georgia]',
					closeWith: '[/font]',
					beforeInsert: function (r) {
						$('#markItUp').get(0).tagInsert(r, 'Georgia');
					}
				},
				{
					action: 'fontName',
					name: 'Times New Roman',
					openWith: '[font=Times New Roman]',
					closeWith: '[/font]',
					beforeInsert: function (r) {
						$('#markItUp').get(0).tagInsert(r, 'Times New Roman');
					}
				},
				{
					action: 'fontName',
					name: 'Verdana',
					openWith: '[font=Verdana]',
					closeWith: '[/font]',
					beforeInsert: function (r) {
						$('#markItUp').get(0).tagInsert(r, 'Verdana');
					}
				},
				{
					action: 'fontName',
					name: 'Trebuchet MS',
					openWith: '[font=Trebuchet MS]',
					closeWith: '[/font]',
					beforeInsert: function (r) {
						$('#markItUp').get(0).tagInsert(r, 'Trebuchet MS');
					}
				},
				{
					action: 'fontName',
					name: 'Lucida Sans',
					openWith: '[font=Lucida Sans]',
					closeWith: '[/font]',
					beforeInsert: function (r) {
						$('#markItUp').get(0).tagInsert(r, 'Lucida Sans');
					}
				},
				{
					action: 'fontName',
					name: 'Comic Sans',
					openWith: '[font=Comic Sans]',
					closeWith: '[/font]',
					beforeInsert: function (r) {
						$('#markItUp').get(0).tagInsert(r, 'Comic Sans');
					}
				}
			]
		},
		{
			separator: '-'
		},
		{
			action: 'insertHtml',
			name: 'Insertar video de YouTube',
			beforeInsert: function (r) {
				var video = prompt(lang['ingrese el id de yt']);
				var regexpYT = /^http:\/\/((www|uk|fr|ie|it|jp|pl|es|nl|br|au|hk|mx|nz|de|ca)\.|)youtube\.com\/((watch|)\?v=|v\/|jp\.swf\?video_id=)([0-9A-Za-z-_]{11})(.*?)/i;
				if (video && video.match(regexpYT)) {
					var YT_SWF = video.replace(regexpYT, 'http://www.youtube.com/v/$5');
					var embed = '<embed height="315" width="540" allowfullscreen="true" allowscriptaccess="always" type="application/x-shockwave-flash" src="' + YT_SWF + '?version=3&amp;hl=es_ES"></embed>';
					r.replaceWith = '[youtube]' + YT_SWF + '[/youtube]\nlink: [url]' + YT_SWF + '[/url]\n';
					$('#markItUp').get(0).tagInsert(r, '<center>'
														+ embed +
														'</center><div>Enlace: <a rel="nofollow" target="_blank" href="' + video + '">' + video + '</a></div>');
					$('#markItUp').get(0).refreshSwf();
					setTimeout(function(){
					$('#markItUp').get(0).refreshSwf();
					}, 1500);
				} else {
					r.replaceWith = '';
				}
			}
		},
		{
			action: 'insertHtml',
			name: 'Insertar archivo SWF',
			beforeInsert: function (r) {
				var selection = r.selection || $('#markItUp').get(0).selected().text, movie = '';
				r.replaceWith = '';
				if (selection.substr(0, 7) == 'http://') {
					movie = selection;
				} else {
					movie = prompt('Ingrese la URL', 'http://');
				}
				if (movie) {
					r.replaceWith = '[swf=' + movie + ']\nlink: [url]' + movie + '[/url]\n';
					$('#markItUp').get(0).tagInsert(r, '<br /><center><embed src="' + movie + '" quality=high width="425" height="350" TYPE="application/x-shockwave-flash" AllowNetworking="internal" AllowScriptAccess="never" autoplay="false" wmode="transparent"></embed></center><br /><br />link: <a rel="nofollow" target="_blank" href="' + movie + '">' + movie + '</a>');
					$('#markItUp').get(0).refreshSwf();
				} else {
					r.replaceWith = '';
				}
			}
		},
		{
			action: 'insertHtml',
			name: 'Insertar Imagen',
			beforeInsert: function (r) {
				var selection = r.selection || $('#markItUp').get(0).selected().text, img = '';
				r.replaceWith = '';
				if (selection.substr(0, 7) == 'http://') {
					img = selection;
				} else {
					img = prompt('Ingrese la URL', 'http://');
				}
				if (img) {
					r.replaceWith = '[img=' + img + ']';
					$('#markItUp').get(0).tagInsert(r, '<img class="imagen" border="0" src="' + img + '" onresizestart="return false" />');
				} else {
					r.replaceWith = '';
				}
			}
		},
		{
			action: 'createLink',
			name: 'Insertar Link',
			beforeInsert: function (r) {
				var selection = r.selection || $('#markItUp').get(0).selected().text, link = '', innerText = '';
				r.replaceWith = '';r.action = 'createLink';
				if (selection.match(/(https?|ftp):\/\//)) {
					innerText = selection;
				} else {
					link = prompt('Ingrese la URL', 'http://');
					if (link) {
						innerText = link;
					}
				}
				if (link && innerText) {
					r.replaceWith = '[url=' + link + ']' + innerText + '[/url]';
					if ($('#markItUp').get(0).selected().text) {
						$('#markItUp').get(0).tagInsert(r, link);
					} else {
						r.action = 'insertHtml';
						$('#markItUp').get(0).tagInsert(r, '<a href="' + link + '">' + innerText + '</a>');
					}
				}
			}
		},
		{
			action: 'insertHtml',
			name: 'Citar',
			beforeInsert: function (r) {
				var selection = r.selection || $('#markItUp').get(0).selected().text, quote = '';
				r.replaceWith = '';
				if (selection){
					quote = selection;
				} else {
					quote = prompt('Ingrese el texto a citar');
				}
				if (quote) {
					r.replaceWith = '[quote]' + quote + '[/quote]';
					$('#markItUp').get(0).tagInsert(r, '<blockquote><div class="cita"><strong></strong> dijo:</div><div class="citacuerpo">' + quote + '</div></blockquote>');
				}
			}
		}
	]
};


$.fn.richedit = function(opts) {

	return this.each(function () {

		this.tagInsert = function (object, param) {
			if (this.view == 'html') {
				if (!param) {
					param = null;
				}
				if (!object.original) {
					object.original = [ object.replaceWith, object.openWith, object.closeWith ];
				}
				object.replaceWith = '';
				object.openWith = '';
				object.closeWith = '';
				this.exec(object.action, param);
			} else {
				if (object.original) {
					object.replaceWith = object.original[0];
					object.openWith = object.original[1];
					object.closeWith = object.original[2];
					delete object.original;
				}
			}
		}

		this.editor = $('<iframe border="0"></iframe>')[0];
		this.markItUp = $(this).markItUp(opts.markItUpSettings);

		this.refreshSwf = function () {
			if (this.editor.contentWindow.document.designMode) { 
				var doc = this.editor.contentWindow.document, attr;
				doc.designMode = 'off';
				$(this.editor).contents().find('embed').each(function(){
					attr = $(this).attr('src');
					$(this).attr('src', attr);
				});
				setTimeout(function(){
					doc.designMode = 'on';
				}, 250);
			}
		}

		this.view = null;
		this.viewSource = function (init) {
			if (!init) {
				$(this).val($.html2bbcode($(this.editor.contentWindow.document.body).html()));
			}
			$(this).removeClass('hide').next().show();
			$(this.editor).addClass('hide');
			$('.markItUpButton15').addClass('selected');
			this.view = 'source';
		}
		this.viewHtml = function () {
			var parsedContent = '';
			if ($.trim($(this).val())) {
				$.ajax({
					type: 'post',
					url: global.data.scripturl + '?action=ajax&do=bbc2html',
					data: 'body=' + encodeURIComponent($(this).val()),
                                        dataType: 'json',
					async: false,
					success: function (r) {
						parsedContent = r.data;
                                        }
				});
			}
			this.editor.contentWindow.document.open();
			this.editor.contentWindow.document.write('<html><head><link type="text/css" href="' + global.data.theme_url + '/wysiwyg.css?v=0.1" rel="stylesheet" /></head><body class="post-contenido" style="overflow: auto !important; margin-top: 0px !important">' + parsedContent + '</body></html>');
			this.editor.contentWindow.document.close();
			$('#markItUp').get(0).refreshSwf();
			if (this.editor.contentWindow.document.designMode) {
				this.editor.contentWindow.document.designMode = 'on';
			}
			this.editor.contentWindow.document.execCommand('enableObjectResizing', false, false);
			$(this).addClass('hide').next().hide();
			$(this.editor).removeClass('hide');
			$('.markItUpButton15').removeClass('selected');
			this.view = 'html';
			setTimeout(function(){
			$('#markItUp').get(0).refreshSwf();
			}, 1000);
		}
		this.switchView = function () {
			if (this.view == 'html') {
				this.viewSource();
			} else {
				this.viewHtml();
			}

                        $(this.editor).css('height', $('#markItUp')[0].offsetHeight-2);

		}

		this.setFocus = function () {
			if (this.view == 'html') {
				$(this.editor).focus();
			} else {
				$(this).focus();
			}
		}

		this.selected = function () {
			var r = {start: 0, end: 0, text: ''}, objDocument, objWindow, object;
			if (this.view == 'html') {
				object = this.editor;
				objDocument = object.contentWindow;
				objWindow = object.contentWindow;
			} else {
				object = this;
				objDocument = document;
				objWindow = window;
			}
			if (this.view == 'source' && object.selectionStart) {
				r.start = object.selectionStart;
				r.end = object.selectionEnd;
				r.text = $(object).val().substr(r.start, r.end - r.start);
			} else {
				var tmp;
				if (objWindow.getSelection) {
					tmp = objWindow.getSelection().getRangeAt(0);
				} else if (objDocument.getSelection) {
					tmp = objDocument.getSelection().getRangeAt(0);
				} else if (objDocument.selection) {
					tmp = objDocument.selection.createRange();
				}
				if (tmp) {
					r.start = tmp.startOffset;
					r.end = tmp.endOffset;
					r.text = tmp.toString();
				}
			}
			return r;
		}

		this.exec = function (action, param) {
			this.setFocus();
			if (!param) {
				param = null;
			}
			this.editor.contentWindow.document.execCommand(action, false, param);
		}

		this.execPrompt = function (action, caption, text) {
			var param = this.selected().text;
			if (!param) {
				param = prompt(caption, text);
			}
			if (param) {
				return this.exec(action, param);
			}
		}

		var properties = [ 'style', 'class' ], property;
		for (property in properties) {
			$(this.editor).attr(properties[property], $(this).attr(properties[property]));
		}
		$(this.editor).removeClass('required'); // fast fix

		$(this.editor).insertBefore(this);
		if (!is_ie && false) {
			this.viewHtml();
		} else {
			this.viewSource(true); // ie is currently not supported, sorry :_(
		}

	});

}

// </richedit>


if (!$.browser.msie) {
	var wysiwygObj = {
		name: lang['Cambiar vista'],
		beforeInsert: function (r) {
			$('#markItUp').get(0).switchView();
		}
	};
	mySettings.markupSet.push(wysiwygObj);
}

jQuery.expr[':'].regex = function(elem, index, match) {
    var matchParams = match[3].split(','),
        validLabels = /^(data|css):/,
        attr = {
            method: matchParams[0].match(validLabels) ?
                        matchParams[0].split(':')[0] : 'attr',
            property: matchParams.shift().replace(validLabels,'')
        },
        regexFlags = 'ig',
        regex = new RegExp(matchParams.join('').replace(/^\s+|\s+$/g,''), regexFlags);
    return regex.test(jQuery(elem)[attr.method](attr.property));
}

// ...

