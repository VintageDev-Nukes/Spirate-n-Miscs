<?php
// Spirate Script - Version 2.4
if (!defined('SPIRATE'))
	die('Hacking attempt...');

function template_buscador_above(){

    global $context, $settings, $txt, $scripturl, $modSettings, $boardurl, $func;

// set .content padding to 0px
echo '<style type="text/css">
    #main .globalcontent{
    padding:0;
    }
    </style>';

echo '<div class="clearfix">';
echo '<div class="sub-header blue clearfix" style="padding-top:30px; position: relative">';
echo nanotip($context['search_errors']['invalid_search_string'] ? $context['search_errors']['messages'][0] : '&iquest;Que deseas buscar?', $context['search_errors']['invalid_search_string'] ? 'red' : 'blue' . ' left', array(
    'position' => 'absolute',
    'left' => 17,
    'top' => 10
));
echo '<form name="buscador" method="GET" action="'.$scripturl.'">
<div class="big-search rounded-3 left"><input type="text" name="action&#61;search2&amp;search" ', empty($context['search_params']['search']) ? 'placeholder="Ingresa el termino a buscar" ' : 'disabled="disabled" ex-placeholder="Que deseas buscar?" ' ,'class="search-input rounded-3" id="q-input">
<input type="submit" value="' , $txt['mods_cat_search'] , '" class="sp-button bluesky', !empty($context['search_params']['search']) ? ' disabled" disabled="disabled"' : '"' ,'>
', !empty($context['search_params']['search']) ? '<div class="token"><div>'.$func['substr']($context['search_params']['search'], 0, 80) . ( $func['strlen']($context['search_params']['search']) > 80 ? '...' : '' ).'</div><a onclick="new_search();"></a></div>' : '' ,'
</div>

<div class="nano-tooltips clearfix green left" style="position: absolute; right:170px; top:10px"><span class="izq"></span><span class="text">Busqueda por usuario</span><span class="der"></span></div>
<div class="big-search rounded-3 left" style="width: 250px"><input type="text" name="autor" placeholder="Algun autor en especial?" class="search-input rounded-3"  style="width: 227px; padding-right:10px">
</div>

</div>';

echo '<div class="globalcontent2 left clearfix" style="width:660px">';

if(empty($context['search_params']['search']))
echo '<div class="info relative clearfix"><img src="'.$context['user']['avatar']['src'].'" width="50" class="left"><div class="left" style="margin-left: 10px">Ingresa algo para comenzar tu busqueda.</div><i class="arrow"></i></div>';
else if(empty($context['topics'])){

echo '<div class="error relative clearfix"><img src="'.$context['user']['avatar']['src'].'" width="50" class="left">
<div class="left" style="margin-left: 10px"><b>' , $txt['search_no_results'], '</b><br />
<i>', $txt['search_for_dummies'],'</i><br/>
', $txt['use_the_right_words'],'<br/>
', $txt['use_another_words'],'<br/>
', $txt['use_common_words'],'<br/>
', $txt['use_less_words'],'</span><br /></div></div>';

}

    
}
function template_buscador_below(){
    global $context, $settings, $txt, $scripturl, $modSettings, $boardurl;
    
 echo '</div>';

    echo '<div class="searchColumn-r-opt equal-height clearfix">
    <strong class="title">Filtrar por Categoria</strong>
    <div class="cont-option">
    <ul id="filter-category">';
    echo '<li><input type="radio" name="categoria" id="categoria_0" class="ui-radio" checked="checked" value="0"><label class="ui-radio category" for="categoria_0"></label> <span>Todas las categorias</span></li>';
    
    foreach ($context['boards'] as $board)
    echo '<li><input type="radio" name="categoria" id="categoria_', $board['id'], '" ', $board['selected'] ? ' checked="checked"' : '' ,' class="ui-radio" value="', $board['id'], '"><label class="ui-radio', $board['selected'] ? ' checked' : '' ,' category" for="categoria_', $board['id'], '"></label> <span>', $board['name'], '</span></li>';
    echo '</ul>
    </div>
    <strong class="title">Orden de los resultados</strong>
    <div class="cont-option">
    <ul id="filter-sort">';
    $sort = array(
        $txt['relevancia'] => array('order_1', '0qdesc'),
        $txt['reciente'] => array('order_2', '1qdesc'),
        $txt['antiguo'] => array('order_3', '1qasc')
        );

    foreach($sort as $k => $v)
        echo '<li><input type="radio" name="sort" id="'.$v[0].'" class="ui-radio sort"', ($_GET['sort'] == $v[1] || !isset($_GET['sort']) && $v[0] == 'order_1') ? ' checked="checked"' : '' ,' value="'.$v[1].'"><label class="ui-radio sort ', ($_GET['sort'] == $v[1] || !isset($_GET['sort']) && $v[0] == 'order_1') ? ' checked' : '' ,'" for="'.$v[0].'"></label> <span>' , $k , '</span></li>';

    echo '</ul>
    </div>';

    echo '<strong class="title">Publicidad</strong>
      <div class="cont-option" style="text-align:center; overflow: hidden">
      ', get_advertise(2) ,'
      </div>';

    echo '</div></div></form>';


   

}

function template_main(){
    global $context;

    //...

}

function template_results(){
	global $context, $settings, $options, $txt, $scripturl;

echo'<h2 class="title">' , $txt['resultado'] , '</h2>
<div class="results">';

while ($topic = $context['get_topics']()){
echo '<div class="wrap-result">
      <div class="result">
      <div class="result-item">
      <i class="icon-result"><img src="', $settings['images_url'] ,'/post/icono_', $topic['board']['id'], '.gif" title="', $topic['board']['name'], '"></i>
      <div class="data">
      <span class="result-title"><a href="">' , $topic['first_post']['link'] , '</a></span>
      <span class="result-information">
      <img src="'.$settings['images_url'].'/date_serach_result_inf.png" style="margin:0 4px -4px 0">' , $txt['creado'] , ' <strong>' , $topic['first_post']['fecha'] , '</strong>
      <img src="'.$settings['images_url'].'/coin_serach_result_inf.png" style="margin:0 2px -3px 5px"> <strong>' , $topic['first_post']['puntos'] , '</strong> ' , $txt['puntos'] , '
      <img src="'.$settings['images_url'].'/ballon_serach_result_inf.png" style="margin:0 2px -4px 5px"> <strong>', $topic['first_post']['comentarios'] ,'</strong> comentarios
      <img src="'.$settings['images_url'].'/user_serach_result_inf.png" style="margin:0 2px -4px 5px"> Autor: <strong><a>' , $topic['first_post']['name'] , '</a></strong>
      </span></div></div></div></div>';
}

echo'</div>';


if ($context['page_index'])
echo '<div>' . $context['page_index'] . '</div>';


}

?>