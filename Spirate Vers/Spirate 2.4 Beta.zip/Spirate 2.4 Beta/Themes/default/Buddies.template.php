<?php

// Version: 0.8.5 Buddies

// This file is a part of Ultimate Profile mod

// Author: Jovan Turanjanin





function template_buddy_center()

{

	global $context, $settings, $options, $scripturl, $modSettings, $txt;



	echo '<div class="box_title"><img src="', $settings['images_url'], '/icons/profile_sm.gif" alt="" align="top" />&nbsp;'.$txt['Buddies_center'].'</div>          <div class="box_cuerpo"><center>

			<table width="85%" cellspacing="0">
			<tr class="catbg3" style="font-weight:bold;">
				<td width="20%">', $txt[68], '</td>
				<td>', $txt['online8'], '</td>
				<td>', $txt[69], '</td>
				<td align="center">', $txt[513], '</td>
				<td align="center">', $txt[603], '</td>
				<td align="center">', $txt[604], '</td>
				<td align="center">', $txt['MSN'], '</td>
				<td width="20px;"></td>
				<td width="20px;"></td>
				<td></td>
			</tr>';



	// Sin Amigos :)
	if (empty($context['buddies']))
		echo'<tr class="windowbg">
				<td colspan="10" align="center"><b>',$txt['Buddies_none'],'</b></td>
			</tr>';

	//Mostramos los Amigos
	$alternate = false;
	$j = count ($context['buddies']) - 1; $i = 0;
	$first = true; $last = false;

	foreach ($context['buddies'] as $buddy)
	{
		$i++;
		echo '<tr class="', $alternate ? 'windowbg' : 'windowbg2', '">

				<td>', $buddy['link'], '</td>
				<td align="center"><a href="', $buddy['online']['href'], '"><img src="', $buddy['online']['image_href'], '" alt="', $buddy['online']['label'], '" title="', $buddy['online']['label'], '" /></a></td>
				<td align="center">', ($buddy['hide_email'] ? '' : '<a href="mailto:' . $buddy['email'] . '"><img src="' . $settings['images_url'] . '/email_sm.gif" alt="' . $txt[69] . '" title="' . $txt[69] . ' ' . $buddy['name'] . '" /></a>'), '</td>
				<td align="center">', $buddy['icq']['link'], '</td>				<td align="center">', $buddy['aim']['link'], '</td>				<td align="center">', $buddy['yim']['link'], '</td>				<td align="center">', $buddy['msn']['link'], '</td>				<td align="center">';

				if (!$first)				echo '<a href="', $scripturl, '?action=buddies;sa=order;u=', $buddy['id'], ';dir=up;sesc=' . $context['session_id'] . '"><img src="', $settings['images_url'], '/arriba.png" alt="',$txt['Buddies_move_up'],'" title="',$txt['Buddies_move_up'],'" /></a>';
				else
				echo '&nbsp;';

		echo '</td>
				<td align="center">';
				if (!$last)
				echo '<a href="', $scripturl, '?action=buddies;sa=order;u=', $buddy['id'], ';dir=down;sesc=' . $context['session_id'] . '"><img src="', $settings['images_url'], '/abajo.png" alt="',$txt['Buddies_move_down'],'" title="',$txt['Buddies_move_down'],'" /></a>';
				else
				echo '&nbsp;';
		echo '</td>
				<td align="center"><a href="', $scripturl, '?action=buddies;sa=remove;u=', $buddy['id'], ';sesc=' . $context['session_id'] . '"><img src="', $settings['images_url'], '/icons/delete.gif" alt="',$txt['Buddies_del'],'" title="',$txt['Buddies_del'],'" /></a></td>
			</tr>';
		$alternate = !$alternate;
		$first = false;
		if ($i == $j)		$last = true;
	}
	echo '</table></center></div>';

	

	if (isset ($context['unapproved'])) {
		echo '<div class="box_title" style="margin-top:5px;">&nbsp;<img src="', $settings['images_url'], '/icons/profile_sm.gif" alt="" align="top" />&nbsp;',$txt['Buddies_not_aproved'],'</div>              <div class="box_cuerpo"><center>

			<table width="85%">            <tr class="catbg3" style="font-weight:bold;">				<td width="20%">', $txt[68], '</td>				<td>', $txt['online8'], '</td>				<td>', $txt[69], '</td>				<td align="center">', $txt[513], '</td>				<td align="center">', $txt[603], '</td>				<td align="center">', $txt[604], '</td>				<td align="center">', $txt['MSN'], '</td>				<td></td>				<td></td>
			</tr>';

	// Amigos para Aprobar
	$alternate = false;
	foreach ($context['unapproved'] as $buddy)
	{
		echo '<tr class="', $alternate ? 'windowbg' : 'windowbg2', '">				<td>', $buddy['link'], '</td>				<td align="center"><a href="', $buddy['online']['href'], '"><img src="', $buddy['online']['image_href'], '" alt="', $buddy['online']['label'], '" title="', $buddy['online']['label'], '" /></a></td>				<td align="center">', ($buddy['hide_email'] ? '' : '<a href="mailto:' . $buddy['email'] . '"><img src="' . $settings['images_url'] . '/email_sm.gif" alt="' . $txt[69] . '" title="' . $txt[69] . ' ' . $buddy['name'] . '" /></a>'), '</td>				<td align="center">', $buddy['icq']['link'], '</td>				<td align="center">', $buddy['aim']['link'], '</td>				<td align="center">', $buddy['yim']['link'], '</td>				<td align="center">', $buddy['msn']['link'], '</td>				<td align="center"><a href="', $scripturl, '?action=buddies;sa=approve;u=', $buddy['id'], ';sesc=' . $context['session_id'] . '"><b style="color:red">',$txt['Buddies_aprove'],'</b></a></td>				<td align="center"><a href="', $scripturl, '?action=buddies;sa=remove;u=', $buddy['id'], ';sesc=' . $context['session_id'] . '"><img src="', $settings['images_url'], '/icons/delete.gif" alt="',$txt['Buddies_del'],'" title="',$txt['Buddies_del'],'" /></a></td>			</tr>';
		$alternate = !$alternate;

	}

	echo '</table></center></div>';

	}

	if (isset ($context['pending'])) {

		echo '<div class="box_title" style="margin-top:5px;">&nbsp;<img src="', $settings['images_url'], '/icons/profile_sm.gif" alt="" align="top" />&nbsp;',$txt['Buddies_pend'],'</div>              <div class="box_cuerpo"><center>			  <table width="85%">
			<tr class="catbg3" style="font-weight:bold;">				<td width="20%">', $txt[68], '</td>				<td>', $txt['online8'], '</td>				<td>', $txt[69], '</td>				<td align="center">', $txt[513], '</td>				<td align="center">', $txt[603], '</td>				<td align="center">', $txt[604], '</td>				<td align="center">', $txt['MSN'], '</td>				<td></td>			</tr>';

	// Amigos en espera de Aprobacion	$alternate = false;		foreach ($context['pending'] as $buddy)	{		echo '<tr class="', $alternate ? 'windowbg' : 'windowbg2', '">				<td>', $buddy['link'], '</td>				<td align="center"><a href="', $buddy['online']['href'], '"><img src="', $buddy['online']['image_href'], '" alt="', $buddy['online']['label'], '" title="', $buddy['online']['label'], '" /></a></td>				<td align="center">', ($buddy['hide_email'] ? '' : '<a href="mailto:' . $buddy['email'] . '"><img src="' . $settings['images_url'] . '/email_sm.gif" alt="' . $txt[69] . '" title="' . $txt[69] . ' ' . $buddy['name'] . '" /></a>'), '</td>				<td align="center">', $buddy['icq']['link'], '</td>				<td align="center">', $buddy['aim']['link'], '</td>				<td align="center">', $buddy['yim']['link'], '</td>				<td align="center">', $buddy['msn']['link'], '</td>				<td align="center"><a href="', $scripturl, '?action=buddies;sa=remove;u=', $buddy['id'], ';sesc=' . $context['session_id'] . '"><img src="', $settings['images_url'], '/icons/delete.gif" alt="',$txt['Buddies_del'],'" title="',$txt['Buddies_del'],'" /></a></td>			</tr>';
		$alternate = !$alternate;	}



	echo '</table></center></div>';

	}

}
?>