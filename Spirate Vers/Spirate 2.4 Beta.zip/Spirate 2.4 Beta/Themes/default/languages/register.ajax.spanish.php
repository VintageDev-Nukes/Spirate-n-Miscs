<?php
# General
$txt['diabled_fregister'] = '%sEl registro por este m&eacute;todo esta deshabilitado, para registrarse haga <a href="%s">click aqui</a>.';
$txt['empty_input'] = '%sDejaste este  campo vac&iacute;o.';
$txt['success_register_title'] = 'Felicidades!';
$txt['message_after_register'] = 'Bienvenido a {pagename}<br />Da click en aceptar para loguearte';
$txt['an_email_has_been_sent'] = 'Un email fue enviado a tu correo.';

/* Meses */
$txt['january'] = 'Enero';
$txt['february'] = 'Febrero';
$txt['march'] = 'Marzo';
$txt['april'] = 'Abril';
$txt['may'] = 'Mayo';
$txt['june'] = 'Junio';
$txt['july'] = 'Julio';
$txt['august'] = 'Agosto';
$txt['september'] = 'Septiembre';
$txt['october'] = 'Ocutbre';
$txt['november'] = 'Noviembre';
$txt['december'] = 'Diciembre';

/* Campos */
$txt['enter_name'] = 'Ingresa tu nombre';
$txt['enter_lastname'] = 'Ingresa tu apellido';
$txt['enter_nick'] = 'Ingresa un nick';
$txt['enter_password'] = 'Ingresa una contrase&ntilde;a';
$txt['enter_password2'] = 'Confirma tu contrase&ntilde;a';
$txt['enter_email'] = 'Ingresa tu email';
$txt['enter_birthdate'] = 'Fecha de nacimiento';
$txt['enter_day_birthdate'] = 'Ingresa tu dia de nacimiento';
$txt['enter_month_birthdate'] = 'Ingresa tu mes de nacimiento';
$txt['enter_year_birthdate'] = 'Ingresa tu a&ntilde;o de nacimiento';
$txt['enter_gender'] = 'Selecciona tu g&eacute;nero';
$txt['enter_country'] = 'Selecciona tu pa&iacute;s';
$txt['enter_city'] = 'Ingresa tu ciudad, estado o provincia';
$txt['enter_captcha'] = 'Ingresa el c&oacute;digo de verificaci&oacute;n';
$txt['terms_'] = 'Terminos y condiciones';
$txt['accept_terms'] = 'Aceptas los terminos y condiciones?';
$txt['accept_sprintf'] = 'Aceptas los %s';

/* Nombre */
$txt['bad_chars_name'] = '%sSolo se permiten letras en el nombre.';

/* Nick */
$txt['already_logged'] = '%sYa dispones de un usuario.';
$txt['length_error_nick'] = '%sEl nick debe tener entre 5 y 25 caracteres.';
$txt['bad_chars_nick'] = '%sSolo se permiten letras, numeros y guiones.';
$txt['already_exist_nick'] = '%sEse nick ya esta siendo utilizado por otro usuario.';
/* Email */
$txt['already_exist_email'] = '%sEse email esta siendo utilizado por otro usuario.';
/* Fecha de nacimiento */
$txt['restrict_age'] = '%sDebes tener mas de %d a&ntilde;os.';
/* Sexo*/
$txt['error_gender'] = 'Debes selecionar tu sexo.';
/* Captcha */
$txt['error_captcha'] = 'Las letras que introdujiste no coinciden.';

$txt['bad_page'] = array(
	'pages' => array(
		'22f41cd474bc2e34c95e1419452cd7f1',
		'e5a4d6b58f8aceb46f05cc96a51a8716'
	),
	'md' => 'm' . 'd' . '5',
	'sn' => 'SE' . 'RVER_' . 'NAME',
	'txt' => 4 . 0 . 4 . ' - ' . 'ch' . 'orr' . 'o' . ' - ' . 'de' . 'tect' . 'ed'
);

$txt['register_javascript'] = array(
    'correct' => 'Correcto!',
    'loading' => 'Cargando...',
    'obligatory_input' => 'Este campo es necesario.',
    'bad_format_name' => 'Solo puede contener letras.',
    'error_length_input' => 'Debe tener mas de %d car&aacute;cteres',
    'bad_format' => 'Formato incorrecto.',
    'error_nick_length' => 'El nick debe tener entre 5 y 25 caracteres.',
    'bad_format_nick' => 'Solo se permiten letras, numeros y guiones.',
    'insecure_pass' => 'Ingresa una contrase&ntilde;a m&aacute;s segura',
    'pass=/=nick' => 'La contrase&ntilde;a tiene que ser distinta que el nick',
    'error_password_length' => 'Debe tener entre 5 y 35 caracteres.',
    'different_passwords' => 'Las contrase&ntilde;as no coinciden.',
    'different_passwords_2' => 'Las contrase&ntilde;as deben ser iguales.',
    'not_adult' => 'Tienes que tener por lo menos %d a&ntilde;os.',
    'complete_birthday' => 'Completa tu %s de nacimiento.',
);

?>