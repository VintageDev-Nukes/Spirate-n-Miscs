<?php

//Profile Comments

$txt['pcomments_notify_pm_subject'] = 'You have a new comment on your profile!';
$txt['pcomments_notify_pm_body']  = "You have a new comment on your profile!\nComment posted by: %poster\n\nYour Profile: ";

$txt['pcomments_only_logued'] = '<center><span style="color: red;" class="size11"><b>Only logued users can comment</b></span></center>';

$txt['pcomments_subcoment'] = 'commented on your publication in a';
$txt['pcomments_profile'] = 'Profile';
$txt['pcomments_subject'] = 'Notification: Subcomment.';
$txt['pcomments_delete'] = 'Subcomment Deleted';

?>