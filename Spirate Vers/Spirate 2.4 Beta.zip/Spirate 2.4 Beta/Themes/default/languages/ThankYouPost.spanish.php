<?php
$txt['NMidTopicSet'] = 'La identificaci�n del mensaje o tema no fue hecha!';
$txt['allready_postet_thx'] = 'Ya has dado las Gracias a este post';
$txt['WMidTopicSet'] = 'Tema equivocado o Identificaci�n de Mensaje incorrecta!';
$txt['Thxtomyself'] = 'No puedes darte las gracias a ti mismo!';
$txt['thxislocked'] = 'Gracias est� cerrado, por lo tanto no puedes dar agradecimientos';
$txt['thxislockednor'] = 'No tienes permisos para cambiar el estado de Cerrado de Gracias';
$txt['notathankyoupost'] = 'Este no es un post que incluya Gracias !';
$txt['thxdeletenor'] = 'No tienes permisos para borrar los Agradecimientos en este post !';
$txt['thxdeletenormem'] = 'No tienes permisos para borrar este miembro de los Agradecimientos!';
$txt['remove_thank_you_post_mem'] = 'Borra a este miembro de los Agradecimientos';
$txt['thxidnotfound'] = 'La identificaci�n de este Gracias no ha sido encontrada!';
?>
