<?php

$txt['puntospr'] = 'Points per membergroup';
$txt['puntospr_points'] = 'Points';
$txt['puntospr_range'] = 'Membergroups';

?>