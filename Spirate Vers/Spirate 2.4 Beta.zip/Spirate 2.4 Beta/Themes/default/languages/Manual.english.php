<?php

// Version: 1.1; Manual



/* Everything in this file is for the Simple Machines help manual

   If you are looking at translating this into another language please

   visit the Simple Machines website for tools to assist! */

// Entries for template: index.

$txt['manual_index_visit_simple_machines'] = 'Visit Simple Machines!';



// Entries for template: smf.

$txt['manual_smf_user_help'] = 'Spirate User Help';



// Entries for template: index.

$txt['manual_index_intro'] = 'Introduction';

$txt['manual_index_register'] = 'Registering';

$txt['manual_index_login'] = 'Logging In';

$txt['manual_index_profile'] = 'Profile';

$txt['manual_index_posting'] = 'Posting';

$txt['manual_index_pm'] = 'Personal Message';

$txt['manual_index_search'] = 'Searching';

$txt['manual_index_you_have_arrived_part1'] = 'So you\'ve arrived at this ';

$txt['manual_index_you_have_arrived_link_site0'] = 'Simple Machines Forum';

$txt['manual_index_you_have_arrived_part2'] = ' (SMF)! Perhaps you\'ve been looking at the ';

$txt['manual_index_you_have_arrived_link_site0_board'] = 'board index';

$txt['manual_index_you_have_arrived_part3'] = ' or a screen telling you that you need to register before you can read it and you\'re wondering what to do next?';

$txt['manual_index_guest_permit_read_part1'] = 'Well, some forums permit guests to read and post, some permit guests to read only and some are restricted to registered members. We\'d recommend ';

$txt['manual_index_guest_permit_read_link_registering'] = 'registering';

$txt['manual_index_guest_permit_read_part2'] = ' at any forum that you see yourself using regularly because many of the most useful features will only become available to you when you do so. Since SMF, however, is such a flexible system that few forums are likely to be identical, we will start by describing four key areas that we\'d normally expect to be there for you:';

$txt['manual_index_main_menu'] = 'The Main Menu';

$txt['manual_index_suppossing_guest'] = 'Supposing you\'ve arrived here as a guest (or have registered but are currently logged out), the main menu (which appears on every page) should normally comprise five or six buttons (or text links):';

$txt['manual_index_home_desc_part1'] = '<strong>Home</strong>, which takes you back to the ';

$txt['manual_index_home_desc_link_board'] = 'board index';

$txt['manual_index_home_desc_part2'] = '.';

$txt['manual_index_help_desc'] = '<strong>Help</strong>, which brings you to this guide.';

$txt['manual_index_search_desc_part1'] = '<strong>Search</strong>, which allows you to ';

$txt['manual_index_search_desc_link_searching'] = 'search';

$txt['manual_index_search_desc_part2'] = ' the forums for whatever you\'re looking for.';

$txt['manual_index_calendar_desc_part1'] = '<strong>Calendar</strong>, which links to the forum ';

$txt['manual_index_calendar_desc_link_posting_calendar'] = 'calendar';

$txt['manual_index_calendar_desc_part2'] = ' (if enabled).';

$txt['manual_index_login_desc_part1'] = '<strong>Login</strong>, which allows you to ';

$txt['manual_index_login_desc_link_loginout'] = 'login';

$txt['manual_index_login_desc_part2'] = ' if already registered.';

$txt['manual_index_register_desc_part1'] = '<strong>Register</strong>, which allows you to ';

$txt['manual_index_register_desc_link_registering'] = 'register';

$txt['manual_index_register_desc_part2'] = ' (or sometimes apply for registration) when you wish to do so.';

$txt['manual_index_once_registered'] = 'Once you\'ve registered and logged in, however, the main menu should look a little different:';

$txt['manual_index_home_reg'] = '<strong>Home</strong> (as before).';

$txt['manual_index_help_reg'] = '<strong>Help</strong> (as before).';

$txt['manual_index_search_reg'] = '<strong>Search</strong> (as before).';

$txt['manual_index_profile_reg_part1'] = '<strong>Profile</strong>, which allows you to make changes to your ';

$txt['manual_index_profile_reg_link_profile'] = 'profile';

$txt['manual_index_profile_reg_part2'] = ' settings.';

$txt['manual_index_calendar_reg'] = '<strong>Calendar</strong> (as before).';

$txt['manual_index_logout_reg_part1'] = '<strong>Logout</strong>, which allows you to ';

$txt['manual_index_logout_reg_link_loginout_logout'] = 'logout';

$txt['manual_index_logout_reg_part2'] = ' again if desired.';

$txt['manual_index_forum_admins_note_presentation'] = 'Forum administrators should also note the presence of an additional <strong>Admin</strong> button.';

$txt['manual_index_sec_board_index'] = 'The Board Index';

$txt['manual_index_sec_board_index_def'] = 'While the board index (forum home page) is packed with all kinds of information and links, the core of the interface (at least in the SMF default theme) normally looks something like this:';

$txt['manual_index_forum_name'] = 'Forum Name';

$txt['manual_index_cat_name'] = 'Category Name';

$txt['manual_index_board_name'] = 'Board Name';

$txt['manual_index_board_desc'] = 'Board Description';

$txt['manual_index_topics_posts'] = 'Number of topics and posts in this board';

$txt['manual_index_date_time'] = 'Date, time, subject and author of last post';

$txt['manual_index_new_posts'] = 'New Posts';

$txt['manual_index_no_new'] = 'No New Posts';

$txt['manual_index_mark_read'] = 'Mark ALL messages as read';

$txt['manual_index_f_name'] = 'The <strong>forum name</strong> links back to the top of the board index.';

$txt['manual_index_cat'] = 'If the <strong>category</strong> is collapsible (shown by the little arrow symbol), clicking the category name collapses or expands the category as appropriate.';

$txt['manual_index_b_name_part1'] = 'The <strong>board name</strong> links to the ';

$txt['manual_index_b_name_link_message'] = 'message index';

$txt['manual_index_b_name_part2'] = ' for that board.';

$txt['manual_index_b_desc'] = 'The <strong>board description</strong> describes the board\'s content, and may also include links to child boards and/or specify the board\'s moderator(s).';

$txt['manual_index_n_no_n_posts'] = 'The <strong>New Posts</strong> and <strong>No New Posts</strong> icons in the leftmost column show registered members whether there have been any new posts to the board since they last read it.';

$txt['manual_index_m_read'] = 'The <strong>Mark as Read</strong> button enables registered members to mark all posts in the entire forum as \'read\'.';

$txt['manual_index_sec_msg_index'] = 'The Message Index';

$txt['manual_index_sec_msg_index_def'] = 'Like the board index, the message index interface is quite straightforward when reduced to its essential components:';

$txt['manual_index_pages'] = 'Pages';

$txt['manual_index_mark_read_this_board'] = 'Mark Topics as Read for this Board';

$txt['manual_index_ru_sure_notify'] = 'Are you sure you wish to enable notification of new topics for this board?';

$txt['manual_index_notify'] = 'Notify of Replies';

$txt['manual_index_start_new'] = 'Start new topic';

$txt['manual_index_new_poll'] = 'Post New Poll';

$txt['manual_index_subject'] = 'Subject';

$txt['manual_index_started_by'] = 'Started by';

$txt['manual_index_replies'] = 'Replies';

$txt['manual_index_views'] = 'Views';

$txt['manual_index_last_post'] = 'Last post';

$txt['manual_index_topic_subject'] = 'Topic Subject';

$txt['manual_index_new'] = 'New';

$txt['manual_index_topic_starter'] = 'Topic Starter';

$txt['manual_index_last_poster'] = 'Date, time and author of last post';

$txt['manual_index_normal_post'] = 'Topic you have posted in';

$txt['manual_index_normal_topic'] = 'Normal Topic';

$txt['manual_index_hot_post'] = 'Hot Topic (More than 15 replies)';

$txt['manual_index_very_hot_post'] = 'Very Hot Topic (More than 25 replies)';

$txt['manual_index_locked'] = 'Locked Topic';

$txt['manual_index_sticky'] = 'Sticky Topic';

$txt['manual_index_poll'] = 'Poll';

$txt['manual_index_jump_to'] = 'Jump to';

$txt['manual_index_destination'] = 'Please select a destination';

$txt['manual_index_another_board'] = 'Another Board';

$txt['manual_index_go'] = 'go';

$txt['manual_index_nav_tree'] = 'Some forums show the <strong>navigation tree</strong> at the top in a space-saving horizontal mode.';

$txt['manual_index_page_number'] = 'The <strong>page numbers</strong> link to further pages of the board, and may be accompanied by <strong>Go Up</strong> and <strong>Go Down</strong> buttons linking to the top and bottom of the current page.';

$txt['manual_index_mark_read_button'] = 'The <strong>Mark as Read</strong> button enables registered members to mark all posts in this board as \'read\'.';

$txt['manual_index_notify_button'] = 'The <strong>Notify</strong> button enables registered members to subscribe to email notification of replies to topics in this board.';

$txt['manual_index_new_topic_poll_button_part1'] = 'The <strong>New Topic</strong> and <strong>New Poll</strong> buttons are for starting new topics and polls, as described in the ';

$txt['manual_index_new_topic_poll_button_link_posting'] = 'posting help';

$txt['manual_index_new_topic_poll_button_part2'] = '.';

$txt['manual_index_subject_replies_etc'] = 'The <strong>Subject</strong>, <strong>Started by</strong>, <strong>Replies</strong>, <strong>Views</strong> and <strong>Last post</strong> links enable you to sort the columns by these parameters (with <strong>Last post</strong> also toggling between descending and ascending order as indicated by the little arrow).';

$txt['manual_index_topic_icons'] = 'The <strong>topic icons</strong> in the leftmost column are explained by the key below.';

$txt['manual_index_post_icons'] = 'The <strong>post icons</strong> in the next column are sometimes used to draw attention to the mood or purpose of the topic.';

$txt['manual_index_topic_subject_links_part1'] = 'The <strong>topic subject</strong> links to the start of the ';

$txt['manual_index_topic_subject_links_link_topic'] = 'topic';

$txt['manual_index_topic_subject_links_part2'] = ', with extra links for subsequent pages and <strong>new</strong> buttons to take registered members straight to their first unread post of the topic.';

$txt['manual_index_where_topic_part1'] = 'Where the <strong>topic</strong> has been started or last replied to by a registered member, their names link to their respective ';

$txt['manual_index_where_topic_link_profile'] = 'profiles';

$txt['manual_index_where_topic_part2'] = '.';

$txt['manual_index_jump_to_menu'] = 'The <strong>Jump to</strong> menu provides a convenient quick method of navigating the forum.';

$txt['manual_index_sec_topic'] = 'The Topic';

$txt['manual_index_ref_thread'] = 'Sometimes referred to as <strong>threads</strong>, <strong>topics</strong> are where you find the actual messages:';

$txt['manual_index_reply'] = 'Reply';

$txt['manual_index_ru_sure_enable_notify'] = 'Are you sure you wish to enable notification of new replies for this topic?';

$txt['manual_index_mark_unread'] = 'Mark unread';

$txt['manual_index_send_topic'] = 'Send this topic';

$txt['manual_index_print'] = 'Print';

$txt['manual_index_author'] = 'Author';

$txt['manual_index_topic'] = 'Topic';

$txt['manual_index_read_x_times'] = 'Read x times';

$txt['manual_index_view_author_profile'] = 'View the profile of Author';

$txt['manual_index_member_group'] = 'Member Group';

$txt['manual_index_post_group'] = 'Post Group';

$txt['manual_index_post_count'] = 'Post Count';

$txt['manual_index_post_date_time'] = 'Date and Time of Post';

$txt['manual_index_reply_quote'] = 'Reply with quote';

$txt['manual_index_topic_text'] = 'Here is the text of the message, which is ultimately what we\'re all here for!';

$txt['manual_index_smiley'] = 'Smiley';

$txt['manual_index_report_to_mod'] = 'Report to moderator';

$txt['manual_index_logged'] = 'Logged';

$txt['manual_index_view_profile'] = 'View Profile';

$txt['manual_index_email'] = 'Email';

$txt['manual_index_personal_msg'] = 'Personal Message (Offline)';

$txt['manual_index_navigation_tree'] = 'Some forums show the <strong>navigation tree</strong> at the top in a space-saving horizontal mode.';

$txt['manual_index_prev_next'] = 'Some forums may also be configured with <strong>previous</strong> and <strong>next</strong> topic links.';

$txt['manual_index_page_no_link'] = 'The <strong>page numbers</strong> link to further pages of the topic, and may be accompanied by <strong>Go Up</strong> and <strong>Go Down</strong> buttons linking to the top and bottom of the current page.';

$txt['manual_index_reply_button_part1'] = 'The <strong>Reply</strong> button enables you to ';

$txt['manual_index_reply_button_link_posting_reply'] = 'reply';

$txt['manual_index_reply_button_part2'] = ' to the topic.';

$txt['manual_index_notify_button_enables'] = 'The <strong>Notify</strong> button enables registered members to subscribe to email notification of replies to the topic.';

$txt['manual_index_mark_unread_button'] = 'The <strong>Mark Unread</strong> button enables registered members to mark the topic as \'unread\', which means that it will still be listed as new and can be effectively \'saved for later\'. Note that this button changes to <strong>Add Poll</strong> in the bottom button set for users with permission to add polls to existing topics.';

$txt['manual_index_send_topic_button'] = 'The <strong>Send Topic</strong> button enables registered members to send a link to the topic by email.';

$txt['manual_index_print_button'] = 'The <strong>Print</strong> button creates a simplified, printer-friendly rendering of the page.';

$txt['manual_index_author_name_link_part1'] = 'The <strong>author name</strong> links to the author\'s ';

$txt['manual_index_author_name_link_link_profile'] = 'profile';

$txt['manual_index_author_details'] = 'The <strong>author details</strong> in the lefthand column may be accompanied by further personal information.';

$txt['manual_index_topic_subject_links_start'] = 'The <strong>topic subject</strong> links back to the start of the topic.';

$txt['manual_index_quote_button_part1'] = 'The <strong>Quote</strong> button enables you to ';

$txt['manual_index_quote_button_link_posting_quote'] = 'quote';

$txt['manual_index_quote_button_part2'] = ' the post.';

$txt['manual_index_modify_delete_part1'] = 'Further <strong>Modify</strong> and <strong>Delete</strong> options are normally provided to enable registered members to ';

$txt['manual_index_modify_delete_link_posting_modify'] = 'edit';

$txt['manual_index_modify_delete_part2'] = ' their own posts.';

$txt['manual_index_report_to_moderator'] = '<strong>Report to moderator</strong> enables you to report abusive or wrongly-placed posts to the forum staff.';

$txt['manual_index_logged_IP'] = '<strong>Logged</strong> indicates that the IP of the author has been logged. The actual IP is only available to board administrators';

$txt['manual_index_jump_to_menu_provides'] = 'The <strong>Jump to</strong> menu provides a convenient quick method of navigating the forum.';



// Entries for template: loginout.

$txt['manual_loginout_complete_reg_part1'] = 'Once you have completed the ';

$txt['manual_loginout_complete_reg_link_registering'] = 'registration';

$txt['manual_loginout_complete_reg_part2'] = ' process, you will be able to login to the site for the first time. After that, you can choose whether to stay logged in indefinitely or logout at the end of your visit.';

$txt['manual_loginout_sec_login'] = 'Logging In';

$txt['manual_loginout_login_desc'] = 'So you might be newly registered or you might simply have been logged out from a previous visit, but there\'s normally a choice between the login screen and the quick login in either case.';

$txt['manual_loginout_login_screen'] = 'The Login Screen';

$txt['manual_loginout_login_screen_desc_part1'] = 'Since this screen (accessed from the <strong>Login</strong> option of the ';

$txt['manual_loginout_login_screen_desc_link_index_main'] = 'main menu';

$txt['manual_loginout_login_screen_desc_part2'] = ') is not only where you\'ll normally be taken on completing registration but also the first thing you\'ll see in any \'members only\' forum, we will describe it first:';

$txt['manual_loginout_login'] = 'Login';

$txt['manual_loginout_username'] = 'Username';

$txt['manual_loginout_password'] = 'Password';

$txt['manual_loginout_how_long'] = 'Minutes to stay logged in';

$txt['manual_loginout_always'] = 'Always stay logged in';

$txt['manual_loginout_forgot'] = 'Forgot your password';

$txt['manual_loginout_login_screen_explanation'] = 'While the <strong>Username</strong> and <strong>Password</strong> fields should be self-explanatory, <strong>Minutes to stay logged in</strong> simply means the number of minutes the cookie that keeps you logged in will last before expiring and requiring you to login again. So it\'s not advisable to enter a long time here if you share a computer and are likely to forget to logout, but you might prefer to check <strong>Always stay logged in</strong> if no-one else has access to your computer.';

$txt['manual_loginout_sub_quick_login'] = 'The Quick Login';

$txt['manual_loginout_although_many_forums_part1'] = 'Although many forums also have a quick login box to allow you to login direct from any screen, its position on the page may vary considerably from forum to forum. In the SMF default theme, for example, it\'s in the collapsable section at the top, whereas it\'s more likely to be at the bottom in themes based on the older YaBB SE forum. If you can\'t see it and it hasn\'t simply been collapsed, it\'s either not enabled at all (in which case you should still be able to access the login screen from the ';

$txt['manual_loginout_although_many_forums_link_index_main'] = 'main menu';

$txt['manual_loginout_although_many_forums_part2'] = ') or you\'re already logged in (in which case the main menu should include a <strong>Logout</strong> rather than <strong>Login</strong> link!).';

$txt['manual_loginout_hour'] = '1 Hour';

$txt['manual_loginout_day'] = '1 Day';

$txt['manual_loginout_week'] = '1 Week';

$txt['manual_loginout_mo'] = '1 Month';

$txt['manual_loginout_forever'] = 'Forever';

$txt['manual_loginout_login_all'] = 'Login with username, password and session length';

$txt['manual_loginout_use_quick_login'] = 'To use the quick login box, enter your username and password, select your session length from the drop-down menu and click <strong>Login</strong>. Please note that <strong>Forever</strong>, like <strong>Always stay logged in</strong>, simply means that the computer should remember you until you next choose to logout, and not that you actually need to be online all of that time!';

$txt['manual_loginout_logout'] = 'Logging Out';

$txt['manual_loginout_logout_desc_part1'] = 'When you have finished browsing the forum, you may decide to logout. Perhaps you share a workstation with someone else, in which case leaving yourself logged in would not be a good idea. So select the <strong>Logout</strong> option from the ';

$txt['manual_loginout_logout_desc_link_index_main'] = 'main menu';

$txt['manual_loginout_logout_desc_part2'] = ' and the forum should log you out, turning you into an instant guest, clearing your name from the list of users online and safeguarding your forum identity until you choose to login again.';

$txt['manual_loginout_sec_reminder'] = 'Password Reminder';

$txt['manual_loginout_reminder_desc_part1'] = 'If you\'re trying to login to the forum but have forgetten or lost your password, you can retrieve it with the lost password tool by following the <strong>Forgot your password?</strong> link from the ';

$txt['manual_loginout_reminder_desc_link_screen'] = 'login';

$txt['manual_loginout_reminder_desc_part2'] = ' screen.';

$txt['manual_loginout_password_reminder'] = 'Password reminder';

$txt['manual_loginout_username_email'] = 'Username/email';

$txt['manual_loginout_send'] = 'Send';

$txt['manual_loginout_by_user'] = 'by User';

$txt['manual_loginout_by_email'] = 'by Email';

$txt['manual_loginout_ask_q'] = 'Ask me my question';

$txt['manual_loginout_q_explanation'] = 'You can\'t retrieve your password, but you can set a new one by following a link sent to you by email.  You also have the option of setting a new password by answering your secret question.';

$txt['manual_loginout_reminder_explanation'] = 'You can enter either your username or your email address so long as you check the appropriate option, then click the <strong>Send</strong> button to send yourself an email containing a link to reset your password. It\'s also possible to avoid the email altogether if you\'ve set yourself a secret question and answer in your profile, but please beware of questions that anyone could answer or guess (like \'what is the first color of the rainbow?\', which would be a very bad choice)!';



// Entries for template: pm.

$txt['manual_pm_community'] = 'SMF is about community and communication. And there are many ways to communicate, such as posting to the boards, personal messaging, email, ICQ, AIM and YIM. But SMF\'s own personal message system, as available to registered members in most forums, is sometimes a more suitable option than any of these.';

$txt['manual_pm_sec_pm'] = 'Personal Messaging';

$txt['manual_pm_pm_desc'] = 'Description';

$txt['manual_pm_pm_desc_1'] = 'While email is a good way to correspond directly with members, it also has several drawbacks for forum purposes: you must open your email application to write and send the message, the recipient must open his/her email application and check his/her mail, your message will be mixed in with all the other mail and it can sometimes take several minutes to an hour for mail to reach the recipient.';

$txt['manual_pm_pm_desc_2'] = 'As an alternative to email, SMF offers a faster, more private method. Personal messaging on the boards provides instantaneous delivery to the recipient\'s private mailbox. The mail is sent and received entirely through SMF, so neither you nor the recipient have to open another program or leave SMF. Personal messaging also offers both the sender and the recipient greater privacy because no-one\'s real email address is revealed. Personal messages show only the handle and name of both parties.';

$txt['manual_pm_pm_desc_3'] = 'If a recipient isn\'t online, personal messages wait in the member\'s PM box until the next time he/she logs in and reads and/or deletes them. SMF Personal Messages is a self-contained, highly private email system.';

$txt['manual_pm_reading'] = 'Reading Your Messages';

$txt['manual_pm_reading_desc_part1'] = 'To read your personal messages, you need to be ';

$txt['manual_pm_reading_desc_link_loginout'] = 'logged in';

$txt['manual_pm_reading_desc_part2'] = ', then follow the link that says something like \'Hey, [username], you have ';

$txt['manual_pm_reading_desc_link_loginout_interface'] = 'x messages';

$txt['manual_pm_reading_desc_part3'] = ', x are new\'.';

$txt['manual_pm_sec_pm2'] = 'The PM Interface';

$txt['manual_pm_pm_desc2_part1'] = 'The PM interface is similar in operation to that of the ';

$txt['manual_pm_pm_desc2_link_index_message'] = 'message index';

$txt['manual_pm_pm_desc2_part2'] = '. While we are showing the inbox interface here, the outbox works in much the same way:';

$txt['manual_pm_forum_name'] = 'Forum Name';

$txt['manual_pm_personal_msgs'] = 'Personal Messages';

$txt['manual_pm_inbox'] = 'Inbox';

$txt['manual_pm_delete'] = 'Delete all messages in your Inbox';

$txt['manual_pm_outbox'] = 'Outbox';

$txt['manual_pm_new_msg'] = 'New Message';

$txt['manual_pm_check_new_msgs'] = 'Check for new messages';

$txt['manual_pm_date'] = 'Date';

$txt['manual_pm_subject2'] = 'Subject';

$txt['manual_pm_from'] = 'From';

$txt['manual_pm_date_and_time'] = 'Date and time of message';

$txt['manual_pm_another_member'] = 'Another Member';

$txt['manual_pm_subject'] = 'Message Subject';

$txt['manual_pm_delete_selected'] = 'Delete Selected';

$txt['manual_pm_pages'] = 'Pages';

$txt['manual_pm_nav_tree'] = 'Some forums show the <strong>navigation tree</strong> at the top in a space-saving horizontal mode.';

$txt['manual_pm_delete_button'] = 'The main <strong>Delete</strong> button deletes all messages in your inbox (or outbox if open). Note that the checkbox and lower <strong>Delete</strong> button also allow you to delete selected messages, with the top checkbox selecting all.';

$txt['manual_pm_outbox_button'] = 'The <strong>Outbox</strong> button toggles to your outbox, where it obviously becomes an <strong>Inbox</strong> button.';

$txt['manual_pm_new_msg2_part1'] = 'The <strong>New Message</strong> button enables you to start a new message, which is similar to ';

$txt['manual_pm_new_msg2_link_posting_newtopic'] = 'starting a new topic';

$txt['manual_pm_new_msg2_part2'] = ' but adds \'To:\' and \'Bcc:\' (blind carbon copy) fields and the option to save to your outbox.';

$txt['manual_pm_reload'] = 'The <strong>Reload</strong> button checks for new messages by refreshing the page.';

$txt['manual_pm_sort_by'] = 'The <strong>Date</strong>, <strong>Subject</strong>, and <strong>From</strong> links enable you to sort the columns by these parameters (with <strong>Date</strong> also toggling between descending and ascending order as indicated by the little arrow).';

$txt['manual_pm_main_subject'] = 'The main subject title links to the start of the message, which will be further down the same page.';

$txt['manual_pm_page_nos'] = 'The page numbers link to further pages of messages as applicable.';

$txt['manual_pm_start_reply'] = 'Starting or Replying to a Message';

$txt['manual_pm_how_to_start_reply_part1'] = 'There are actually several different ways to start a new personal message, but all require you to be ';

$txt['manual_pm_how_to_start_reply_link_loginout'] = 'logged in';

$txt['manual_pm_how_to_start_reply_part2'] = ':';

$txt['manual_pm_msg_link_part1'] = 'You can follow the link that says something like \'Hey, [username], you have ';

$txt['manual_pm_msg_link_link_interface'] = 'x messages';

$txt['manual_pm_msg_link_part2'] = ', x are new\', then click the <strong>New Message</strong> button in your inbox.';

$txt['manual_pm_click_name_part1'] = 'You can click another member\'s name, followed by <strong>Send this member a personal message</strong> from his/her ';

$txt['manual_pm_click_name_link_profile_info-all'] = 'profile';

$txt['manual_pm_click_name_part2'] = ' summary screen.';

$txt['manual_pm_click_im_icon'] = 'You can start a new message direct by clicking the <strong>IM on/offline</strong> icon from the user info accompanying all of his/her posts.';

$txt['manual_pm_click_pm_icon_part1'] = 'You can start a new message direct by clicking the <strong>PM on/offline</strong> icon from the <strong>Current Status</strong> in his/her ';

$txt['manual_pm_click_pm_icon_link_profile_info-all'] = 'profile';

$txt['manual_pm_click_pm_icon_part2'] = ' summary screen. (This icon/link is often duplicated in the user info described above.)';

$txt['manual_pm_reply_msg_part1'] = 'Replying to a message is very similar to ';

$txt['manual_pm_reply_msg_link_posting_reply'] = 'replying to a topic';

$txt['manual_pm_reply_msg_part2'] = '.';

$txt['manual_pm_messages'] = 'Messages';



// Entries for template: posting.

$txt['manual_posting_forum_about_part1'] = 'Since posting messages is basically what forums are all about, we will spend some time looking at the various options and techniques available. Those who are familiar with forum software, HTML or bulletin board code in general may prefer to skip straight to the ';

$txt['manual_posting_forum_about_link_bbcref'] = 'Bulletin Board Code';

$txt['manual_posting_forum_about_part2'] = ' and ';

$txt['manual_posting_forum_about_link_bbcref_smileysref'] = 'Smileys';

$txt['manual_posting_forum_about_part3'] = ' references.';

$txt['manual_posting_please_note'] = '<strong>Please note that, because an SMF forum may be customized extensively by its administrator(s), the presence of a feature in this documentation does not necessarily mean that it will be available to all users in all forums.</strong>';

$txt['manual_posting_sec_posting_basics'] = 'Posting Basics';

$txt['manual_posting_starting_topic'] = 'Starting a New Topic';

$txt['manual_posting_starting_topic_desc_part1'] = 'Browse to the board where you wish to post and click the <strong>New Topic</strong> button (positioned by default at both the top and the bottom of the board, as shown in the ';

$txt['manual_posting_starting_topic_desc_link_index_message'] = 'User Help Introduction';

$txt['manual_posting_starting_topic_desc_part2'] = '), which should take you to the <strong>Start new topic</strong> screen. While this presents a number of options, the two most important are the <strong>Subject</strong> field and main <strong>Message</strong> field (not labeled as such, but obvious by its size). So enter your subject and start to type (or paste) your message into the main text area, noting that a message missing either a subject or a body will not be accepted for posting until it has both. If you\'re happy with your plain text message, you can then post it by clicking the <strong>Post</strong> button and/or preview it first by clicking the <strong>Preview</strong> button, but there are many further ';

$txt['manual_posting_starting_topic_desc_link_index_message_standard'] = 'options';

$txt['manual_posting_starting_topic_desc_part3'] = ' available to make things that little bit more interesting.';

$txt['manual_posting_forum_name'] = 'Forum Name';

$txt['manual_posting_cat_name'] = 'Category Name';

$txt['manual_posting_board_name'] = 'Board Name';

$txt['manual_posting_start_topic'] = 'Start new topic';

$txt['manual_posting_std_options'] = 'Standard Options';

$txt['manual_posting_add_options'] = 'Additional Options';

$txt['manual_posting_omit_clarity'] = 'omitted for clarity and demonstrated below.';

$txt['manual_posting_subject'] = 'Subject';

$txt['manual_posting_shortcuts'] = 'shortcuts: hit alt+s to submit/post or alt+p to preview';

$txt['manual_posting_posts'] = 'Post';

$txt['manual_posting_preview'] = 'Preview';

$txt['manual_posting_nav_tree'] = 'Some forums show the <strong>navigation tree</strong> at the top in a space-saving horizontal mode.';

$txt['manual_posting_spell_check'] = 'Some forums may be configured to offer an additional <strong>Spell Check</strong> button alongside the <strong>Post</strong> and <strong>Preview</strong> options.';

$txt['manual_posting_start_poll'] = 'Starting a New Poll';

$txt['manual_posting_poll_desc_part1'] = 'A poll is basically a topic with an added question and voting options, started by clicking <strong>New Poll</strong> instead of <strong>New Topic</strong> ';

$txt['manual_posting_poll_desc_link_newtopic'] = 'as described above';

$txt['manual_posting_poll_desc_part2'] = '. To post a poll it is necessary to fill out the <strong>Question</strong> field and at least two of the <strong>Option</strong> fields in addition to the <strong>Subject</strong> and <strong>Message</strong> fields required by a standard topic. Further options to configure how many choices the user may vote for, how long the poll should run, whether users can change their votes and what conditions must be fulfilled for the results to be displayed should be self-explanatory.';

$txt['manual_posting_poll_options'] = 'To offer more than five choices in a poll, simply click <strong>Add Option</strong> as many times as necessary.';

$txt['manual_posting_poll_note'] = 'Note that it may also be possible for some users in some forums to add a poll to an existing topic.';

$txt['manual_posting_post_event'] = 'Posting an Event to the Calendar';

$txt['manual_posting_event_desc_part1'] = 'Where this option has been configured (it\'s not standard \'out of the box\'), you can post an event by selecting <strong>Calendar</strong> from the ';

$txt['manual_posting_event_desc_link_index_main'] = 'main menu';

$txt['manual_posting_event_desc_part2'] = ' followed by <strong>Post Event</strong> from the calendar screen. What you see now is a <strong>Start new topic</strong> screen with supplementary fields for the event title, date and target board, which simply add your event to the calendar and create a link back to your post in that board.';

$txt['manual_posting_replying'] = 'Replying to a Topic or Poll';

$txt['manual_posting_replying_desc_part1'] = 'Replying to a topic or poll is basically the same as ';

$txt['manual_posting_replying_desc_link_newtopic'] = 'starting a new topic';

$txt['manual_posting_replying_desc_part2'] = ', but it\'s not necessary to enter anything in the <strong>Subject</strong> field unless you wish to change what\'s already there. To vote in a poll, you simply have to select your chosen option(s) and click <strong>Submit Vote</strong>.';

$txt['manual_posting_quick_reply_part1'] = 'If \'Quick Reply\' has been enabled, a simple reply field will also appear after the post(s) on a page, but you\'ll have to type your ';

$txt['manual_posting_quick_reply_link_bbc'] = 'Bulletin Board Code';

$txt['manual_posting_quick_reply_part2'] = ' and ';

$txt['manual_posting_quick_reply_link_bbc_smileys'] = 'Smileys';

$txt['manual_posting_quick_reply_part3'] = ' manually if you choose to use it.';

$txt['manual_posting_quote_post'] = 'Quoting a Post';

$txt['manual_posting_quote_desc'] = 'To reply to a post by quoting it, you can either click the <strong>Quote</strong> button for the relevant post and add your own message to the quoted text or click the <strong>Reply</strong> button followed by <strong>Insert Quote</strong> from the relevant post in the \'Topic Summary\' below, but note that:';

$txt['manual_posting_quote_both_part1'] = 'Both these options add a link to the original post showing the name of the poster and the date and time of the post, whereas the ';

$txt['manual_posting_quote_both_link_bbc'] = 'Bulletin Board Code';

$txt['manual_posting_quote_both_part2'] = ' <strong>quote</strong> tag simply quotes the relevant post without this additional information.';

$txt['manual_posting_quote_independant_part1'] = 'You can also retain or add the \'author\' attribute independently of the full <strong>Quote</strong> function, as demonstrated in the ';

$txt['manual_posting_quote_independant_link_bbcref'] = 'SMF Bulletin Board Code Reference';

$txt['manual_posting_quote_independant_part2'] = ' below.';

$txt['manual_posting_modify_delete'] = 'Modifying or Deleting a Post';

$txt['manual_posting_modify_desc'] = 'To modify a post, click the <strong>Modify</strong> button and make your changes. Note that most forums are likely to be configured to show the date and time of the last edit, but the administrator(s) may also allow a short period to elapse before this happens.';

$txt['manual_posting_delete_desc'] = 'To delete a post, click the <strong>Delete</strong> button followed by <strong>OK</strong> from the <strong>Remove this message?</strong> box that appears. Some forums may also allow you to remove topics or polls that you start, but the buttons for these are usually at the bottom of the page.';

$txt['manual_posting_sec_posting_options'] = 'Standard Posting Options';

$txt['manual_posting_msg_icon'] = 'Message icon';

$txt['manual_posting_standard_icon'] = 'Standard';

$txt['manual_posting_thumb_up_icon'] = 'Thumb Up';

$txt['manual_posting_thumb_down_icon'] = 'Thumb Down';

$txt['manual_posting_exc_pt_icon'] = 'Exclamation point';

$txt['manual_posting_q_mark_icon'] = 'Question mark';

$txt['manual_posting_lamp_icon'] = 'Lamp';

$txt['manual_posting_smiley_icon'] = 'Smiley';

$txt['manual_posting_angry_icon'] = 'Angry';

$txt['manual_posting_cheesy_icon'] = 'Cheesy';

$txt['manual_posting_grin_icon'] = 'Grin';

$txt['manual_posting_sad_icon'] = 'Sad';

$txt['manual_posting_wink_icon'] = 'Wink';

$txt['manual_posting_bold_example'] = 'Bold';

$txt['manual_posting_italicize_example'] = 'Italicized';

$txt['manual_posting_underline_example'] = 'Underline';

$txt['manual_posting_strike_example'] = 'Strikethrough';

$txt['manual_posting_glow_example'] = 'Glow';

$txt['manual_posting_shadow_example'] = 'Shadow';

$txt['manual_posting_move_example'] = 'Marquee';

$txt['manual_posting_pre_example'] = 'Preformatted Text';

$txt['manual_posting_left_example'] = 'Left Align';

$txt['manual_posting_center_example'] = 'Centered';

$txt['manual_posting_right_example'] = 'Right Align';

$txt['manual_posting_hr_example'] = 'Horizontal Rule';

$txt['manual_posting_size_example'] = 'Font Size';

$txt['manual_posting_face_example'] = 'Font Face';

$txt['manual_posting_flash_example'] = 'Insert Flash';

$txt['manual_posting_img_example'] = 'Insert Image';

$txt['manual_posting_url_example'] = 'Insert Hyperlink';

$txt['manual_posting_email_example'] = 'Insert Email';

$txt['manual_posting_ftp_example'] = 'Insert FTP Link';

$txt['manual_posting_table_example'] = 'Insert Table';

$txt['manual_posting_tr_example'] = 'Insert Table Row';

$txt['manual_posting_td_example'] = 'Insert Table Column';

$txt['manual_posting_sup_example'] = 'Superscript';

$txt['manual_posting_sub_example'] = 'Subscript';

$txt['manual_posting_tele_example'] = 'Teletype';

$txt['manual_posting_code_example'] = 'Insert Code';

$txt['manual_posting_quote_example'] = 'Insert Quote';

$txt['manual_posting_list_example'] = 'Insert List';

$txt['manual_posting_Change_Color'] = 'Change Color';

$txt['manual_posting_color_black'] = 'Black';

$txt['manual_posting_color_red'] = 'Red';

$txt['manual_posting_color_yellow'] = 'Yellow';

$txt['manual_posting_color_pink'] = 'Pink';

$txt['manual_posting_color_green'] = 'Green';

$txt['manual_posting_color_orange'] = 'Orange';

$txt['manual_posting_color_purple'] = 'Purple';

$txt['manual_posting_color_blue'] = 'Blue';

$txt['manual_posting_color_beige'] = 'Beige';

$txt['manual_posting_color_brown'] = 'Brown';

$txt['manual_posting_color_teal'] = 'Teal';

$txt['manual_posting_color_navy'] = 'Navy';

$txt['manual_posting_color_maroon'] = 'Maroon';

$txt['manual_posting_color_lime'] = 'Lime Green';

$txt['manual_posting_smiley_code'] = 'Smiley';

$txt['manual_posting_wink_code'] = 'Wink';

$txt['manual_posting_cheesy_code'] = 'Cheesy';

$txt['manual_posting_grin_code'] = 'Grin';

$txt['manual_posting_angry_code'] = 'Angry';

$txt['manual_posting_sad_code'] = 'Sad';

$txt['manual_posting_shocked_code'] = 'Shocked';

$txt['manual_posting_cool_code'] = 'Cool';

$txt['manual_posting_huh_code'] = 'Huh';

$txt['manual_posting_rolleyes_code'] = 'Roll Eyes';

$txt['manual_posting_tongue_code'] = 'Tongue';

$txt['manual_posting_embarrassed_code'] = 'Embarrassed';

$txt['manual_posting_lipsrsealed_code'] = 'Lips Sealed';

$txt['manual_posting_undecided_code'] = 'Undecided';

$txt['manual_posting_kiss_code'] = 'Kiss';

$txt['manual_posting_cry_code'] = 'Cry';

$txt['manual_posting_sub_message_icon'] = 'Message Icon';

$txt['manual_posting_msg_icon_dropdown'] = 'This drop-down menu allows you to change the default icon for the subject line to something matching the mood or purpose of your post.';

$txt['manual_posting_sub_bbc'] = 'Bulletin Board Code';

$txt['manual_posting_bbc_desc'] = 'Bulletin Board Code (or BBC) is the essential tool for formatting and changing the appearance of your post. While it affects the plain text in much the same way as the formatting tools in any word processor, the main <strong>Message</strong> field does not behave in a WYSIWYG manner, so you should preview your message if you need to see what it will look like when posted.';

$txt['manual_posting_bbc_ref_part1'] = 'A complete ';

$txt['manual_posting_bbc_ref_link_bbcref'] = 'SMF Bulletin Board Code Reference';

$txt['manual_posting_bbc_ref_part2'] = ' is provided below.';

$txt['manual_posting_sub_smileys'] = 'Smileys';

$txt['manual_posting_smiley_desc_part1'] = 'While smileys can be viewed as purely whimsical in nature, they can also play a valuable role in clarifying the written word in much the same way as vocal inflections and/or facial expressions clarify the spoken word. Like most forum software, SMF provides a standard range of smiley images which can be added to posts by clicking the relevant icons or typing the relevant codes. A ';

$txt['manual_posting_smiley_desc_link_nosmileys'] = 'don\'t use smileys';

$txt['manual_posting_smiley_desc_part2'] = ' option is naturally also provided for those occasions when you don\'t want typed character combinations that would normally be displayed as smileys to be converted to the expected images!';

$txt['manual_posting_smiley_ref_part1'] = 'A complete ';

$txt['manual_posting_smiley_ref_link_smileysref'] = 'SMF Smileys Reference';

$txt['manual_posting_smiley_ref_part2'] = ' is provided below.';

$txt['manual_posting_sec_tags'] = 'Tags and Nesting (for beginners)';

$txt['manual_posting_tags_desc_part1'] = 'Before listing the available ';

$txt['manual_posting_tags_desc_link_bbcref'] = 'BBC buttons';

$txt['manual_posting_tags_desc_part2'] = ' and their purposes, let\'s see how they work by imagining that we want to post some text in bold type. While we can start by clicking the <strong>B</strong> (Bold) button and typing our text between the tags it produces, it\'s often more practical to type the text first, highlight it and then click the button. So typing \'text\', highlighting it and clicking the \'B\' button should produce \'[b]text[/b]\', which renders as <b>text</b> when posted or previewed. (NB This doesn\'t work in Opera, which inserts the tags at the end of the post.) Subsequently highlighting \'[b]text[/b]\' and clicking the <strong>I</strong> (Italicized) button will produce \'[i][b]text[/b][/i]\', which not only renders as <i><b>text</b></i> when posted or previewed but also introduces the concept of nesting, which means that each new set of tags in a case like this should be seen as a new \'box\' containing both the original text <em>and</em> any tags already applied to it.';

$txt['manual_posting_note_tags'] = 'Note that the BBC tags can also be typed and edited direct instead of clicking the buttons.';

$txt['manual_posting_sec_additional_options'] = 'Additional Options';

$txt['manual_posting_sec_additional_options_desc'] = 'The following options may appear by default in some forums but be contained within an expanding/collapsing panel (try clicking the link with the arrow below!) in others:';

$txt['manual_posting_notify'] = 'Notify me of replies.';

$txt['manual_posting_return'] = 'Return to this topic.';

$txt['manual_posting_no_smiley'] = 'Don\'t use smileys.';

$txt['manual_posting_attach'] = 'Attach';

$txt['manual_posting_allowed_types'] = 'Allowed file types: txt, jpg, gif, pdf, mpg, png';

$txt['manual_posting_max_size'] = 'Maximum attachment size allowed: 128 KB';

$txt['manual_posting_sub_notify'] = 'Notify me of replies';

$txt['manual_posting_notify_desc'] = 'Check this to subscribe to email notification for the topic.';

$txt['manual_posting_sub_return'] = 'Return to this topic';

$txt['manual_posting_return_desc'] = 'Check this to return to the topic (instead of the message index) after posting (NB you can also set this behavior as a preference in your profile).';

$txt['manual_posting_sub_no_smiley'] = 'Don\'t use smileys';

$txt['manual_posting_no_smiley_desc_part1'] = 'Check this to prevent certain ';

$txt['manual_posting_no_smiley_desc_link_smileysref'] = 'character combinations';

$txt['manual_posting_no_smiley_desc_part2'] = ' in your post from being parsed and rendered as smileys.';

$txt['manual_posting_sub_attach'] = 'Attachments';

$txt['manual_posting_attach_desc_part1'] = 'If enabled, this feature allows you to attach files to your posts in much the same way as most email clients, so you simply have to browse to the relevant file(s) on your computer before clicking <strong>Post</strong>. You can delete your attachment(s) or add more by ';

$txt['manual_posting_attach_desc_link_modify'] = 'modifying your post';

$txt['manual_posting_attach_desc_part2'] = ', but please note that:';

$txt['manual_posting_attach_desc2'] = 'The permitted file types and sizes are set by the forum administrator(s).';

$txt['manual_posting_most_forums_attach'] = 'Although most forums are likely be configured to display attached images as part of the post, it\'s not possible to <em>preview</em> attachments so you should always browse to and attach your files just before you finally <em>post</em> your message.';

$txt['manual_posting_sec_references'] = 'References';

$txt['manual_posting_sub_SMF_bbc'] = 'SMF Bulletin Board Code';

$txt['manual_posting_sub_smf_bbc_desc'] = 'The buttons shown belong to the SMF default theme and may differ from forum to forum.';

$txt['manual_posting_header_name'] = 'Tag Name';

$txt['manual_posting_header_button'] = 'Button';

$txt['manual_posting_header_code'] = 'Code';

$txt['manual_posting_header_output'] = 'Output';

$txt['manual_posting_header_comments'] = 'Comments';

$txt['manual_posting_bbc_bold'] = 'Bold';

$txt['manual_posting_bold_code'] = '[b]bold[/b]';

$txt['manual_posting_bold_output'] = 'bold';

$txt['manual_posting_bold_comment'] = '*';

$txt['manual_posting_bbc_italic'] = 'Italicized';

$txt['manual_posting_italic_code'] = '[i]italicized[/i]';

$txt['manual_posting_italic_output'] = 'italicized';

$txt['manual_posting_italic_comment'] = '*';

$txt['manual_posting_bbc_underline'] = 'Underline';

$txt['manual_posting_underline_code'] = '[u]underline[/u]';

$txt['manual_posting_underline_output'] = 'underline';

$txt['manual_posting_underline_comment'] = '*';

$txt['manual_posting_bbc_strike'] = 'Strikethrough';

$txt['manual_posting_strike_code'] = '[s]strikethrough[/s]';

$txt['manual_posting_strike_output'] = 'strikethrough';

$txt['manual_posting_strike_comment'] = '*';

$txt['manual_posting_bbc_glow'] = 'Glow';

$txt['manual_posting_glow_code'] = '[glow=red,2,50]glow[/glow]';

$txt['manual_posting_glow_output'] = 'glow';

$txt['manual_posting_glow_comment'] = 'The three attributes (eg red, 2, 50) in the \'glow\' tag are color, strength and width respectively.';

$txt['manual_posting_bbc_shadow'] = 'Shadow';

$txt['manual_posting_shadow_code'] = '[shadow=red,left]<br />shadow<br />[/shadow]';

$txt['manual_posting_shadow_output'] = 'shadow';

$txt['manual_posting_shadow_comment'] = 'The two attributes (eg red, left) in the \'shadow\' tag are color and direction respectively.';

$txt['manual_posting_bbc_move'] = 'Marquee';

$txt['manual_posting_move_code'] = '[move]move[/move]';

$txt['manual_posting_move_output'] = 'move';

$txt['manual_posting_move_comment'] = 'Not valid XHTML, but can also be used for images!';

$txt['manual_posting_bbc_pre'] = 'Preformatted Text';

$txt['manual_posting_pre_comment'] = 'Preserves critical text formatting, rendered in a monospace font.';

$txt['manual_posting_bbc_left'] = 'Left Align';

$txt['manual_posting_left_code'] = '[left]left align[/left]';

$txt['manual_posting_left_output'] = 'left align';

$txt['manual_posting_left_comment'] = '*';

$txt['manual_posting_bbc_centered'] = 'Centered';

$txt['manual_posting_centered_code'] = '[center]centered[/center]';

$txt['manual_posting_centered_output'] = 'centered';

$txt['manual_posting_centered_comment'] = '*';

$txt['manual_posting_bbc_right'] = 'Right Align';

$txt['manual_posting_right_code'] = '[right]right align[/right]';

$txt['manual_posting_right_output'] = 'right align';

$txt['manual_posting_right_comment'] = '*';

$txt['manual_posting_bbc_rtl'] = 'Right-to-Left';

$txt['manual_posting_rtl_code'] = '[rtl]right to left![/rtl]';

$txt['manual_posting_rtl_output'] = 'right to left!';

$txt['manual_posting_rtl_comment'] = 'Typical usage would be to post Arabic or Hebrew in an English document.';

$txt['manual_posting_bbc_ltr'] = 'Left-to-Right';

$txt['manual_posting_ltr_code'] = '[ltr]left to right![/ltr]';

$txt['manual_posting_ltr_output'] = 'left to right!';

$txt['manual_posting_ltr_comment'] = 'Typical usage would be to post English in an Arabic or Hebrew document.';

$txt['manual_posting_bbc_hr'] = 'Horizontal Rule';

$txt['manual_posting_hr_code'] = '[hr]';

$txt['manual_posting_hr_comment'] = '*';

$txt['manual_posting_bbc_size'] = 'Font Size';

$txt['manual_posting_size_code'] = '[size=10pt]font size[/size]';

$txt['manual_posting_size_output'] = 'font size';

$txt['manual_posting_size_comment'] = '*';

$txt['manual_posting_bbc_font'] = 'Font Face';

$txt['manual_posting_font_code'] = '[font=Verdana]font face[/font]';

$txt['manual_posting_font_output'] = 'font face';

$txt['manual_posting_font_comment'] = 'Only fonts installed on the user\'s computer will be displayed, so use with caution!';

$txt['manual_posting_bbc_color'] = 'Font Color';

$txt['manual_posting_color_code'] = '[color=Red]red[/color]';

$txt['manual_posting_color_output'] = 'red';

$txt['manual_posting_color_comment'] = 'Select the color from the drop-down.';

$txt['manual_posting_bbc_flash'] = 'Insert Flash';

$txt['manual_posting_flash_code'] = '[flash=200,200]<br />http://somesite/somefile.swf<br />[/flash]';

$txt['manual_posting_flash_output'] = 'http://somesite/somefile.swf';

$txt['manual_posting_flash_comment'] = 'Please note that, if embedded Flash has been disabled by the forum administrator(s), the Flash file will appear as a straight hyperlink as shown here. The two attributes in the \'flash\' tag (where relevant) are width and height respectively.';

$txt['manual_posting_bbc_img'] = 'Insert Image';

$txt['manual_posting_img_top_code'] = '[img]<br />http://somesite/image.gif<br />[/img]';

$txt['manual_posting_img_top_comment'] = 'Type the width and height attributes to resize the image.';

$txt['manual_posting_img_bottom_code'] = '[img width=48 height=48]<br />http://somesite/image.gif<br />[/img]';

$txt['manual_posting_bbc_url'] = 'Insert Hyperlink';

$txt['manual_posting_url_code'] = '[url]http://somesite/[/url]';

$txt['manual_posting_url_output'] = 'http://somesite/';

$txt['manual_posting_url_comment'] = 'NB the \'url\' tag opens in a new window, but you can type \'iurl\' tags to open in the same window.';

$txt['manual_posting_url_bottom_code'] = '[url=http://somesite/]<br />descriptive link<br />[/url]';

$txt['manual_posting_url_bottom_output'] = 'descriptive link';

$txt['manual_posting_bbc_email'] = 'Insert Email';

$txt['manual_posting_email_code'] = '[email]<br />someone@somesite<br />[/email]';

$txt['manual_posting_email_output'] = 'someone@somesite';

$txt['manual_posting_email_comment'] = '*';

$txt['manual_posting_bbc_ftp'] = 'Insert FTP Link';

$txt['manual_posting_ftp_code'] = '[ftp]<br />ftp://somesite/somefile<br />[/ftp]';

$txt['manual_posting_ftp_output'] = 'ftp://somesite/somefile';

$txt['manual_posting_ftp_comment'] = '*';

$txt['manual_posting_ftp_bottom_code'] = '[ftp=ftp://somesite/somefile]<br />descriptive link<br />[/ftp]';

$txt['manual_posting_ftp_bottom_output'] = 'descriptive link';

$txt['manual_posting_bbc_table'] = 'Insert Table';

$txt['manual_posting_table_code'] = '[table][/table]';

$txt['manual_posting_table_comment'] = 'No meaningful output from the \'table\' tags alone.';

$txt['manual_posting_bbc_row'] = 'Insert Table Row';

$txt['manual_posting_row_code'] = '[table][tr][/tr][/table]';

$txt['manual_posting_row_comment'] = 'No meaningful output from the \'table\' and \'tr\' tags alone.';

$txt['manual_posting_bbc_column'] = 'Insert Table Column';

$txt['manual_posting_column_code'] = '[table][tr][td]<br />content<br />[/td][/tr][/table]';

$txt['manual_posting_column_output'] = 'content';

$txt['manual_posting_column_comment'] = 'Note the correct nesting of the tags, so the \'table\' tags contain the \'tr\' tags, which each contain an equal number of \'td\' tags!';

$txt['manual_posting_column_bottom_code'] = '[table][tr][td]SMF[/td]<br />[td]Bulletin[/td][/tr]<br />[tr][td]Board[/td]<br />[td]Code[/td][/tr][/table]';

$txt['manual_posting_bbc_sup'] = 'Superscript';

$txt['manual_posting_sup_code'] = '[sup]superscript[/sup]';

$txt['manual_posting_sup_output'] = 'superscript';

$txt['manual_posting_sup_comment'] = '*';

$txt['manual_posting_bbc_sub'] = 'Subscript';

$txt['manual_posting_sub_code'] = '[sub]subscript[/sub]';

$txt['manual_posting_sub_output'] = 'subscript';

$txt['manual_posting_sub_comment'] = '*';

$txt['manual_posting_bbc_tt'] = 'Teletype';

$txt['manual_posting_tt_code'] = '[tt]teletype[/tt]';

$txt['manual_posting_tt_output'] = 'teletype';

$txt['manual_posting_tt_comment'] = 'Monospace font.';

$txt['manual_posting_bbc_code'] = 'Insert Code';

$txt['manual_posting_code_code'] = '[code]&lt;?php phpinfo(); ?&gt;[/code]';

$txt['manual_posting_code_comment'] = 'Always use to preserve formatting of code and avoid parsing as BBC and/or smileys!';

$txt['manual_posting_bbc_quote'] = 'Insert Quote';

$txt['manual_posting_quote_code'] = '[quote]quote[/quote]';

$txt['manual_posting_quote_output'] = 'quote';

$txt['manual_posting_quote_comment'] = 'Note the optional \'author\' attribute.';

$txt['manual_posting_quote_buttom_code'] = '[quote author=author]quote[/quote]';

$txt['manual_posting_quote_buttom_output'] = 'quote';

$txt['manual_posting_bbc_list'] = 'Insert List';

$txt['manual_posting_list_code'] = '[list]<br />[li]SMF[/li]<br />[li]YaBB SE[/li]<br />[/list]';

$txt['manual_posting_list_output'] = '<ul><li>SMF</li><li>YaBB SE</li></ul>';

$txt['manual_posting_list_comment'] = 'While you can add as many items as you wish, each item must be contained by the correct opening and closing tags. You can also style your list item bullets with special opening tags and no closing tags, but this option doesn\'t currently output valid XHTML.';

$txt['manual_posting_list_buttom_code'] = '[list]<br />[o]circle<br />[O]circle<br />[0]circle<br />[*]disc<br />[@]disc<br />[+]square<br />[x]square<br />[#]square<br />[/list]';

$txt['manual_posting_list_buttom_output'] = '<ul><li type="circle">circle<br /><li type="circle">circle<br /><li type="circle">circle<br /><li type="disc">disc<br /><li type="disc">disc<br /><li type="square">square<br /><li type="square">square<br /><li type="square">square<br /></ul>';

$txt['manual_posting_bbc_abbr'] = 'Abbreviation';

$txt['manual_posting_abbr_code'] = '[abbr=exemlpi gratia]eg[/abbr]';

$txt['manual_posting_abbr_output'] = 'eg';

$txt['manual_posting_abbr_comment'] = 'Displays the full expression for the abbreviation on mouseover.';

$txt['manual_posting_bbc_acro'] = 'Acronym';

$txt['manual_posting_acro_code'] = '[acronym=Simple Machines Forum]SMF[/acronym]';

$txt['manual_posting_acro_output'] = 'SMF';

$txt['manual_posting_acro_comment'] = 'Displays the full expression for the acronym on mouseover.';

$txt['manual_posting_sub_help_smileys'] = 'SMF Smileys';

$txt['manual_posting_smileys_help_desc'] = 'The smileys shown here are the standard set from the SMF default theme and may differ from forum to forum.';

$txt['manual_posting_smileys_help_name'] = 'Name';

$txt['manual_posting_smileys_help_img'] = 'Image (click to insert)';

$txt['manual_posting_smileys_help_code'] = 'Code (type to insert)';

$txt['manual_posting_smiley_help_name'] = 'Smiley';

$txt['manual_posting_wink_help_name'] = 'Wink';

$txt['manual_posting_cheesy_help_name'] = 'Cheesy';

$txt['manual_posting_grin_help_name'] = 'Grin';

$txt['manual_posting_angry_help_name'] = 'Angry';

$txt['manual_posting_sad_help_name'] = 'Sad';

$txt['manual_posting_shocked_help_name'] = 'Shocked';

$txt['manual_posting_cool_help_name'] = 'Cool';

$txt['manual_posting_huh_help_name'] = 'Huh';

$txt['manual_posting_rolleyes_help_name'] = 'Roll Eyes';

$txt['manual_posting_tongue_help_name'] = 'Tongue';

$txt['manual_posting_embarrassed_help_name'] = 'Embarrassed';

$txt['manual_posting_lipsrsealed_help_name'] = 'Lips Sealed';

$txt['manual_posting_undecided_help_name'] = 'Undecided';

$txt['manual_posting_kiss_help_name'] = 'Kiss';

$txt['manual_posting_cry_help_name'] = 'Cry';

$txt['manual_posting_smiley_parse'] = 'Please note that not all of the smiley codes will be correctly parsed and converted to images unless their opening spaces are present.';



// Entries for template: profile.

$txt['manual_profile_profile_screen'] = 'The profile screen in the default theme normally consists of a single main pane, with an additional menu to the left to lead you through the editing options for your own profile. Please note that, because an SMF forum may be customized extensively by its administrator(s), the features and user permissions described here are typical rather than definitive.';

$txt['manual_profile_edit_profile_part1'] = 'To edit your own profile, start by selecting <strong>Profile</strong> from the ';

$txt['manual_profile_edit_profile_link_index_main'] = 'main menu';

$txt['manual_profile_edit_profile_part2'] = ' or clicking your own username. You can also view (but not edit) other members\' profiles by clicking on their names.';

$txt['manual_profile_available_to_all'] = 'Information Normally Available to all Members';

$txt['manual_profile_profile_info'] = 'Profile Info';

$txt['manual_profile_username'] = 'Username';

$txt['manual_profile_login_name'] = 'Member\'s login name';

$txt['manual_profile_pic_text'] = 'Picture/Text';

$txt['manual_profile_name'] = 'Name';

$txt['manual_profile_screen_name'] = 'Member\'s screen name';

$txt['manual_profile_posts'] = 'Posts';

$txt['manual_profile_member_posts'] = 'Member\'s number of posts';

$txt['manual_profile_position'] = 'Position';

$txt['manual_profile_membergroup'] = 'Member\'s member group or post group';

$txt['manual_profile_date_reg'] = 'Date Registered';

$txt['manual_profile_date_time_reg'] = 'Date and time of registration';

$txt['manual_profile_last_active'] = 'Last Active';

$txt['manual_profile_date_time_active'] = 'Date and time last active';

$txt['manual_profile_email'] = 'Email';

$txt['manual_profile_email_user'] = 'member@their.address';

$txt['manual_profile_website'] = 'Website';

$txt['manual_profile_status'] = 'Current Status';

$txt['manual_profile_pm'] = 'Personal Message';

$txt['manual_profile_online'] = 'Online';

$txt['manual_profile_gender'] = 'Gender';

$txt['manual_profile_age'] = 'Age';

$txt['manual_profile_n_a'] = 'N/A';

$txt['manual_profile_location'] = 'Location';

$txt['manual_profile_local_time'] = 'Local Time';

$txt['manual_profile_current_date_time'] = 'Current date and time in member\'s time zone';

$txt['manual_profile_language'] = 'Language';

$txt['manual_profile_sig'] = 'Signature';

$txt['manual_profile_other_info'] = 'Additional Information';

$txt['manual_profile_send_pm'] = 'Send this member a personal message.';

$txt['manual_profile_show_member_posts'] = 'Show the last posts of this person.';

$txt['manual_profile_show_member_stats'] = 'Show general statistics for this member.';

$txt['manual_profile_summary_part1'] = 'This <strong>Summary</strong> screen is not only there to tell you about others, but also the first screen that you see when ';

$txt['manual_profile_summary_link_owners'] = 'editing your own profile';

$txt['manual_profile_summary_part2'] = '.';

$txt['manual_profile_hide_email'] = 'Members may choose to hide their <strong>email address</strong> and/or <strong>online status</strong>.';

$txt['manual_profile_empty_part1'] = 'The fields left empty here are not filled in by default, so you should ';

$txt['manual_profile_empty_link_owners'] = 'edit your profile';

$txt['manual_profile_empty_part2'] = ' if you wish to display this information.';

$txt['manual_profile_send_member_pm_part1'] = 'You can send the profile owner a ';

$txt['manual_profile_send_member_pm_link_pm'] = 'Personal Message';

$txt['manual_profile_send_member_pm_part2'] = ' by clicking the <strong>Current Status</strong> <strong>On/Offline Icon</strong> or following the link from <strong>Additional Information</strong> below.';

$txt['manual_profile_show_last_posts'] = '<strong>Show the last posts of this person</strong> links to a complete paginated listing of the member\'s posts.';

$txt['manual_profile_show_member_stats2'] = '<strong>Show general statistics for this member</strong> links to a screen of statistics about the member\'s time online and posting activity.';

$txt['manual_profile_sec_normal'] = 'Settings Normally Available to Profile Owners';

$txt['manual_profile_normal_desc'] = 'While the <strong>Summary</strong> screen is the same as the one shown above and the <strong>Show Posts</strong> and <strong>Show Stats</strong> links are effectively duplicates, profile owners are also provided with the tools to customize their own profiles:';

$txt['manual_profile_modify_profile'] = 'Modify Profile';

$txt['manual_profile_account_related'] = '<strong>Account Related Settings</strong> enables you to make changes to your <strong>display name</strong> (your <strong>login</strong> or <strong>username</strong> can only be changed by an administrator), preferred <strong>language</strong> (if the forum administrators have installed alternative language packs), <strong>email</strong> and <strong>password</strong> settings.';

$txt['manual_profile_forum_profile_info'] = '<strong>Forum Profile Information</strong> enables you to enter optional personal details such as <strong>gender</strong>, <strong>birthdate</strong>, <strong>location</strong>, <strong>website</strong> and <strong>instant messenger</strong> contact information. It\'s also where you go to enter your own <strong>personal text</strong> and <strong>signature</strong> and select an <strong>avatar</strong> (personal picture) from a list (if provided by the forum administrators) or link to one of your own on the web.';

$txt['manual_profile_look_layout'] = '<strong>Look and Layout Preferences</strong> enables you to select your preferred <strong>theme</strong> (forum skin), time zone and format and other personal choices for <strong>layout settings</strong>. Note that the currently selected option in the menu pane is highlighted in bold type:';

$txt['manual_profile_profile_info2'] = 'Profile Info';

$txt['manual_profile_summary2'] = 'Summary';

$txt['manual_profile_show_stats'] = 'Show Stats';

$txt['manual_profile_show_posts'] = 'Show Posts';

$txt['manual_profile_modify_own_profile'] = 'Modify Profile';

$txt['manual_profile_edit_profile1'] = 'Edit Profile';

$txt['manual_profile_acct_settings'] = 'Account Related Settings';

$txt['manual_profile_forum_profile'] = 'Forum Profile Information';

$txt['manual_profile_look_and_layout'] = 'Look and Layout Preferences';

$txt['manual_profile_notify_email'] = 'Notifications and Email';

$txt['manual_profile_pm_options1'] = 'Personal Message Options';

$txt['manual_profile_actions'] = 'Actions';

$txt['manual_profile_delete_account'] = 'Delete this account';

$txt['manual_profile_look_layout_explanation'] = 'This section allows you to customize the look and layout of the forum.';

$txt['manual_profile_current_theme'] = 'Current Theme';

$txt['manual_profile_board_default'] = 'Forum or Board Default';

$txt['manual_profile_change'] = 'change';

$txt['manual_profile_time_format'] = 'Time Format';

$txt['manual_profile_help'] = 'Help';

$txt['manual_profile_caption_date'] = 'The format here will be used to show dates throughout this forum.';

$txt['manual_profile_date_option_select'] = 'Forum Default';

$txt['manual_profile_date_option_1'] = 'Month Day, Year, HH:MM:SS a/pm';

$txt['manual_profile_date_option_2'] = 'Month Day, Year, HH:MM:SS (army time.)';

$txt['manual_profile_date_option_3'] = 'YYYY-MM-DD, HH:MM:SS';

$txt['manual_profile_date_option_4'] = 'DD Month YYYY, HH:MM:SS';

$txt['manual_profile_date_option_5'] = 'DD-MM-YYYY, HH:MM:SS';

$txt['manual_profile_time_offset'] = 'Time Offset';

$txt['manual_profile_offset_hours'] = 'Number of hours to +/- to make displayed time equal to your local time.';

$txt['manual_profile_forum_time'] = 'Current forum time should be displayed here.';

$txt['manual_profile_board_descriptions'] = 'Show board descriptions inside boards.';

$txt['manual_profile_show_child'] = 'Show child boards on every page inside boards, not just the first.';

$txt['manual_profile_no_ava'] = 'Don\'t show other user\'s avatars.';

$txt['manual_profile_no_sig'] = 'Don\'t show other user\'s signatures.';

$txt['manual_profile_return_to_topic'] = 'Return to topics after posting by default.';

$txt['manual_profile_recent_posts'] = 'Show most recent posts at the top.';

$txt['manual_profile_recent_pms'] = 'Show most recent personal messages at top.';

$txt['manual_profile_quick_reply'] = 'Use quick reply on topic display';

$txt['manual_profile_not_at_all'] = 'don\'t show at all';

$txt['manual_profile_off_default'] = 'show, off by default';

$txt['manual_profile_on_default'] = 'show, on by default';

$txt['manual_profile_quick_mod'] = 'Show quick-moderation on message index as';

$txt['manual_profile_no_quick_mod'] = 'don\'t show';

$txt['manual_profile_check_quick_mod'] = 'checkboxes';

$txt['manual_profile_icon_quick_mod'] = 'icons';

$txt['manual_profile_first_day_week'] = 'First day of the week on the calendar:';

$txt['manual_profile_sun'] = 'Sunday';

$txt['manual_profile_mon'] = 'Monday';

$txt['manual_profile_change_profile'] = 'Change profile';

$txt['manual_profile_notify_email_prefs'] = '<strong>Notifications and Email</strong> enables you to select personal preferences for <strong>notifications</strong> (emails about new topics/replies) and lists any notifications that you have set up.';

$txt['manual_profile_pm_options_part1'] = '<strong>Personal Message Options</strong> enables you to set up an <strong>ignore list</strong> (blacklist) for ';

$txt['manual_profile_pm_options_link_pm'] = 'Personal Messages';

$txt['manual_profile_pm_options_part2'] = ', to request <strong>notification</strong> of new PMs by email and to <strong>save copies</strong> of your outgoing PMs by default.';

$txt['manual_profile_sub_actions'] = 'Actions';

$txt['manual_profile_confirm_delete_acct'] = '<strong>Delete this account</strong> does exactly what it says! Yes, there\'s a <strong>confirmation screen</strong>, but it really does <strong>delete your own account</strong>, so be careful...';

$txt['manual_profile_sec_settings'] = 'Settings Normally Restricted to Admins';

$txt['manual_profile_settings_desc'] = 'As well as being able to view/edit any of the details above from other members\' profiles, some further options are normally visible to (and executable by) admins only:';

$txt['manual_profile_track_user'] = 'Track User';

$txt['manual_profile_track_ip'] = 'Track IP';

$txt['manual_profile_show_permissions'] = 'Show Permissions';

$txt['manual_profile_ban_user'] = 'Ban this user';

$txt['manual_profile_sub_profile_info'] = 'Profile Info';

$txt['manual_profile_sub_track_user'] = '<strong>Track User</strong> provides a list of <strong>IP numbers</strong> used by the member, other members who might be in the same <strong>IP range</strong> and <strong>error messages</strong> generated/experienced by the member.';

$txt['manual_profile_sub_track_ip'] = '<strong>Track IP</strong> provides tools for tracking <strong>members</strong>, <strong>messages</strong> and <strong>errors</strong> from any specified <strong>IP range</strong>.';

$txt['manual_profile_sub_show_permissions'] = '<strong>Show Permissions</strong> lists the <strong>board permissions</strong> that have been granted to the member and who gave them.';

$txt['manual_profile_sub_modify_profile'] = 'Modify Profile';

$txt['manual_profile_sub_acct_settings'] = '<strong>Account Related Settings</strong> is basically the same screen as shown to profile owners, but with the additional option to assign members to <strong>member groups</strong>.';

$txt['manual_profile_sub_forum_profile_info'] = '<strong>Forum Profile Information</strong> is basically the same screen as shown to profile owners, but with the additional option to specify <strong>custom titles</strong> for members.';

$txt['manual_profile_sub_actions2'] = 'Actions';

$txt['manual_profile_sub_ban_user'] = '<strong>Ban this user</strong> provides tools for <strong>banning</strong> users, configuring the <strong>level</strong> of the ban and maintaining a <strong>ban list</strong> noting the details of any bans in force.';

$txt['manual_profile_sub_delete_acct'] = '<strong>Delete this account</strong> is similar to the screen of the same name available to all members, but the <strong>confirmation question</strong> is different when it\'s not your own account that\'s about to be deleted.';



// Entries for template: registering.

$txt['manual_registering_you_have_arrived_part1'] = 'When you have set up your SMF forum, or wish to join another SMF forum, you should register a username. This will enable you to maintain a consistent identity while posting and keep track of what you\'ve read, no matter where you\'re working from or what computer you\'re using. You\'ll be able to fill out a personal ';

$txt['manual_registering_you_have_arrived_link_profile'] = 'profile';

$txt['manual_registering_you_have_arrived_part2'] = ' and use the built-in ';

$txt['manual_registering_you_have_arrived_link_profile_pm'] = 'personal message system';

$txt['manual_registering_you_have_arrived_part3'] = '. You\'ll be able to subscribe to email notifications, monitor your forum activity and more.';

$txt['manual_registering_sec_register'] = 'How to Register';

$txt['manual_registering_register_desc'] = 'Assuming you\'ve arrived at the forum as a guest and wish to register, you should be looking at one of these two things:';

$txt['manual_registering_select_register_part1'] = 'Any page of the forum, in which you case you should select <strong>Register</strong> from the ';

$txt['manual_registering_select_register_link_index_main'] = 'main menu';

$txt['manual_registering_select_register_part2'] = '.';

$txt['manual_registering_login_Scr_part1'] = 'A login screen headed by a warning about access being restricted to registered members, in which case you should either use the registration link provided or select <strong>Register</strong> from the ';

$txt['manual_registering_login_Scr_link_index_main'] = 'main menu';

$txt['manual_registering_login_Scr_part2'] = '.';

$txt['manual_registering_warning'] = 'Warning!';

$txt['manual_registering_warning_desc_1'] = 'Only registered members are allowed to access this section.';

$txt['manual_registering_warning_desc_2'] = 'Please login below or ';

$txt['manual_registering_warning_desc_3'] = 'register an account';

$txt['manual_registering_warning_desc_4'] = ' with Forum Name.';

$txt['manual_registering_sec_reg_screen'] = 'The Registration Screen';

$txt['manual_registering_required_info'] = 'Register - Required Information';

$txt['manual_registering_choose_username'] = 'Choose username';

$txt['manual_registering_caption_username'] = 'Used only for identification by SMF.';

$txt['manual_registering_email'] = 'Email';

$txt['manual_registering_caption_email'] = 'This must be a valid email address.';

$txt['manual_registering_hide_email'] = 'Hide email address from public?';

$txt['manual_registering_choose_pass'] = 'Choose password';

$txt['manual_registering_verify_pass'] = 'Verify password';

$txt['manual_registering_agreement'] = 'This is where the registration agreement should be if there is one!';

$txt['manual_registering_agree'] = 'I Agree';

$txt['manual_registering_register'] = 'Register';

$txt['manual_registering_reg_screen_requirements_part1'] = 'When you arrive at the registration screen, you will need to enter a <strong>username</strong>, <strong>email address</strong> and <strong>password</strong>, and may be offered the option of hiding your email address. Since most forums also require you to agree to their terms of use before your registration is accepted, you will normally have to read the agreement and check <strong>I Agree</strong> before continuing. What happens next depends on how the forum is configured, but, if the next thing you see is a ';

$txt['manual_registering_reg_screen_requirements_link_loginout_screen'] = 'login screen';

$txt['manual_registering_reg_screen_requirements_part2'] = ' headed by a message inviting you to proceed, that\'s it, you\'re through and you can proceed to login! If not, there are two further possibilities:';

$txt['manual_registering_email_activate'] = 'If registration has been configured to require email activation, the next screen will tell you so and you should receive an immediate email with instructions about how to proceed. But there\'s also a useful link (\'Did you miss your activation email?\') in the <strong>User Info</strong> box in case you miss this email or mistype your email address.';

$txt['manual_registering_admin_approve'] = 'If registration has been configured to require approval from a forum administrator, the next screen will tell you so and you should receive both an acknowledgement by email and another email later to inform you whether or not your application has been approved.';



// Entries for template: searching.

$txt['manual_searching_you_have_arrived'] = 'While SMF naturally incorporates a powerful search engine, knowing how to use it is not surprisingly the key to returning successful results!';

$txt['manual_searching_sec_search'] = 'Starting a Search';

$txt['manual_searching_search_desc_part1'] = 'Assuming the forum is running the SMF default theme (or a derivative of it), there should be both a simple <strong>Search</strong> field (partnered by an <strong>Advanced search</strong> text link) in the collapsible top section and a <strong>Search</strong> option in the ';

$txt['manual_searching_search_desc_link_index_main'] = 'main menu';

$txt['manual_searching_search_desc_part2'] = '. If not, the main menu <strong>Search</strong> option should still lead straight to the advanced search screen.';

$txt['manual_searching_sec_syntax'] = 'Syntax';

$txt['manual_searching_syntax_desc'] = 'While you can just type (and search for) any combination of characters, you should consider using quotes<!-- and/or wildcards --> to make your search really work for you:';

$txt['manual_searching_sub_quotes'] = 'Quote Marks';

$txt['manual_searching_quotes_desc'] = 'To put this in a nutshell, searching for <strong>simple machines forum</strong> will return any or all of these three words, but enclosing the search string in <em>double</em> quote marks (ie <strong>"simple machines forum"</strong>) will return only the entire phrase.';

$txt['manual_searching_sec_simple_adv'] = 'Simple or Advanced?';

$txt['manual_searching_sub_simple'] = 'Simple Search';

$txt['manual_searching_simple_desc'] = 'To use the simple search (if enabled), the basic syntax outlined above is all you really need to know. But you might also like to know that this tool searches the entire forum for any or all of what you specify that\'s been posted during the last 9999 days (which is more than 27 years)! So, to take more control of your search, you should use the advanced search feature.';

$txt['manual_searching_sub_adv'] = 'Advanced Search';

$txt['manual_searching_adv_desc'] = 'Although the advanced search screen might initially seem a little intimidating if a forum has many boards and child boards, it\'s surprisingly straightforward when reduced to its basic components:';

$txt['manual_searching_forum_name'] = 'Forum Name';

$txt['manual_searching_search'] = 'Search';

$txt['manual_searching_search_param'] = 'Set Search Parameters';

$txt['manual_searching_search_for'] = 'Search for';

$txt['manual_searching_match_all'] = 'Match all words';

$txt['manual_searching_match_any'] = 'Match any words';

$txt['manual_searching_by_user'] = 'by user';

$txt['manual_searching_options'] = 'Options';

$txt['manual_searching_msg_age'] = 'Message age';

$txt['manual_searching_show_results'] = 'Show results as messages';

$txt['manual_searching_subject_only'] = 'Topic subjects only';

$txt['manual_searching_between'] = 'Between ';

$txt['manual_searching_and'] = ' and ';

$txt['manual_searching_days'] = ' days';

$txt['manual_searching_search_order'] = 'Search order';

$txt['manual_searching_relevant_first'] = 'Most relevant results first';

$txt['manual_searching_big_first'] = 'Largest topics first';

$txt['manual_searching_small_first'] = 'Smallest topics first';

$txt['manual_searching_recent_first'] = 'Most recent topics first';

$txt['manual_searching_oldest_first'] = 'Oldest topics first';

$txt['manual_searching_choose'] = 'Choose a board to search in, or search all';

$txt['manual_searching_cat'] = 'Category name';

$txt['manual_searching_board_name'] = 'Board Name';

$txt['manual_searching_another_board'] = 'Another Board';

$txt['manual_searching_check_all'] = 'Check all';

$txt['manual_searching_nav_tree'] = 'Some forums show the <strong>navigation tree</strong> at the top in a space-saving horizontal mode.';

$txt['manual_searching_three_options_part1'] = 'Despite initial appearances, there are really <em>three</em> options for how to search, with <strong>Match all words</strong> and <strong>Match any words</strong> being available from the drop-down, and <strong>"Match as phrase"</strong><!-- and <strong>*wildcards</strong> --> still being available as ';

$txt['manual_searching_three_options_link_syntax'] = 'described';

$txt['manual_searching_three_options_part2'] = ' above.';

$txt['manual_searching_wildcard'] = 'The default * in the <strong>by user</strong> field is essentially a wildcard matching any poster. Please note that, while you can replace this with any <em>single</em> username for a more specific search, it\'s not currently possible to search for posts by multiple users except as that single wildcard.';

$txt['manual_searching_results_as_messages'] = '<strong>Show results as messages</strong> returns the full message containing the search string (with a reply option) instead of the usual linked excerpt, but will naturally result in much larger results pages which might be significant if you are searching for a popular word or phrase.';

$txt['manual_searching_message_age'] = '<strong>Message age</strong> sets the minimum and maximum ages of posts to search.';

$txt['manual_searching_which_board'] = '<strong>Choose a board to search in</strong> provides you with another tool to narrow the scope of the search, with the default being \'all\' (the whole forum or, more properly, all the boards to which you have read access).';

$txt['manual_searching_search_button'] = 'The <strong>Search</strong> button not surprisingly sets the whole thing in motion, but hitting \'Enter\' direct from any of the search fields is sometimes more convenient.';

$txt['Recomendar'] = 'Recomend';

$txt['Recomendar_amigos'] = ' To Your Friends';

$txt['Recomendar_amigos2'] = 'Up To Six Persons';

$txt['1'] = '1 - ';

$txt['2'] = '2 - ';

$txt['3'] = '3 - ';

$txt['4'] = '4 - ';

$txt['5'] = '5 - ';

$txt['6'] = '6 - ';

$txt['Asunto'] = 'Subject';

$txt['Mensaje'] = 'Message';

$txt['Te_recomiendo'] = 'I Would Recommend';

$txt['Mensaje_mail'] = 'Hello! I Recommend You To See This';

$txt['catpcha'] = 'Code Of The Image';

$txt['refresh_image'] = 'Refresh Image';

$txt['greets'] = 'Greets!';

$txt['terminos_condiciones_title'] = 'Terms And Conditions.';





$txt['terminos_condiciones_message'] = '<i>The Access And The Use Of This Site Is With The knowledge Of The Terms And Conditions,That Establish:</i> <br><br>

<b>1.</b> This Site reserves the right to admision/ or permanence of users in this forum.

<br>

<b>2.</b>This site is not responsible for any technical problems that might generate some file or downloaded software on the forum.

<br>

<b>3.</b> This site is not responsible for the misuse of the files are provided and Software, Music, Books, Etc.

<br>

<b>4.</b> The Access To This Web Is Free And Without Age Restriction.

<br>

<b>5.</b> Once Registered You Have To Follow The <a href="' . $scripturl . '?action=protocolo" target="_blank">Protocol</a>.

<br>

<br>

<center>&copy; 2011. All Rights Reserved. Prohibited Partial Or Complete Reproduction.</center>';



$txt['contacto_title'] = 'Contact Form.';

$txt['contacto_Email'] = 'E-mail:';

$txt['contacto_Asunto'] = 'Subject:';

$txt['contacto_Comentarios'] = 'Comments:';

$txt['contacto_imagen_code'] = 'Image Code:';

$txt['contacto_ip_save'] = '- Your IP (';
$txt['contacto_ip_saveb'] = ') Will Be Saved,Just For Security Reasons.';

$txt['contacto_wrong_code'] = 'Wrong Code.';



$txt['enlazanos'] = 'Share Us.';


$txt['Protocolo'] = 'Protocol';

$txt['Introduccion'] = 'Introduction';

$txt['Mensaje_1'] = 'this is an entertainment site for english users in which users share information about various topics (links, images, news, videos, etc..) through posts. <br> <br> this site was created with the idea to answer questions and discuss such topics as a web. <br> moderators are in charge of filtering, removing or editing the information shared in this way, we prevent the contents from becoming a large amount of "nothing" and always maintain the highest possible quality. there are rules which underpin the management philosophy called a protocol and is detailed below. ';

$txt['Caracteristicas'] = 'Features to post';

$txt['Mensaje_Protocolo'] = '<p>* Subject without caps (this indicates that you are shouting).</p>

<p>*That the font size is adequate (there may be exceptions in key words).</p>

<p>* Be as descriptive or as clear as possible, at the time of posting, to avoid misunderstandings , or comment or post being removed. </ p>

<p> * Posting on the right category. </p>

<p> * See if the links work properly. </p>

<p>* Do not reveal personal information about y rself or others such as e-mail, msn, full name, phones, etc ... This web does not take the trouble of publishing such content.) </p>

<br />

<p> <b> + Posts are removed: </b> </p>

<p> * If it is considered spam </p>

* If it  is repost <p>. </p>

<p> *  If it contains a vulgar vocabulary. </p>

<p> * If it refers to the violation of human rights. </ p>

<p>* If it has dead links.</p>

<p>* If you publish content without licence (demo).</p>

<p> * that contains pornographic material (images, videos, links, etc). </p>

<br/>

<p> <b> + are modified post containing: </b> </p>

<p> * that does not comply with the characteristics to post. </p>

<p> * title with opinions. </p>

<p> * containing spelling mistakes. </p>

<p> * post with more than 1000 comments (comments are closed). </p>

<br/>

<p> <b> + are removed comments containing: </b> </p>

<p> * all caps or abuse using caps. </ p>

<p> * that the user was the first to comment his post. </p>

<p> * name calling, insults, etc. (to another user or in general). </p>

<p> * comments racist. </p>

<p> * very large fonts or with the clear effect of attention. </p>

<p> * spam. </p>

<br/>

<p> <b> + are eliminated or suspended users: </b> </p>

<p> * users that are used to be the first to comment(in his gallery). </ p>

<p> * racist comments . </p>

* users who post <p> pornographic material or material morvan </p>

<br />

<p> <b> + are modified to the user: </b> </p>

<p> * when you have a firm with spam. </p>

<p> * when you have personal message spam. </p>

<p> * when you have an avatar with pornographic content. </p>

<p> * when the avatar url does not work. </p>

<br/>

<p> <b> + eliminate or modify the images in the gallery that contains: </b> </p>

<p> * spam (image with a site url) </p>

<p> * pictures with pornography. </p>

* images <p> morbid. </p>

<br/>

<p> <b> + comments are deleted in the gallery that contains: </b> </p>

<p> * spam </p>

<p> * name calling, insults, descrimination, etc. (to another user or in general). </p>

<p> * very large fonts or with the clear effect of attention. </p>

<p> * all caps or abuse of them. </p>

<p> * that the user is the first to discuss his image. </p>';



$txt['pais_title'] = 'Countries Administration';
$txt['pais_name'] = 'Name';
$txt['pais_name_img'] = 'Image Name';
$txt['pais_edit'] = 'Edit';
$txt['pais_delete'] = 'Delete';
$txt['pais_no_name'] = 'Please enter the name.';
$txt['pais_no_img'] = 'Please enter the image name.';
$txt['pais_thec'] = 'The country';
$txt['pais_wasc'] = 'was created.';
$txt['pais_waser'] = 'was erased.';
$txt['pais_wased'] = 'was edited.';
$txt['pais_ae_country'] = 'Edit/Add Countries';
$txt['pais_select_edit'] = '<font size="2" color="#0F69C5"><b>Choose a country to edit</b></font>';
$txt['pais_select'] = 'Select a Country';
$txt['pais_country'] = 'Country';
$txt['pais_add'] = '<font size="2" color="#0F69C5"><b>Add Country</b></font>';
$txt['pais_img_help'] = '<font size="1">(The images are stored in ../default/images/icons/banderas/)</font>';
$txt['pais_create'] = 'Create';

?>