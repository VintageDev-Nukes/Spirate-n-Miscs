<?php

$txt['bloque'] = 'Gestor de Bloques';
$txt['bloque_descripcion'] = 'Desde este gestor de bloques podras administrar los bloques del inicio de tu web, <b>hecho por 002</b>';
$txt['ver_colum'] = 'Bloques en Columnas';


$txt['ancho_disponible'] = 'Ancho Disponible en el inicio: ';
$txt['numero_columnas'] = 'Numero de Columnas: ';
$txt['ancho_sobrepasado'] = 'Est&#225;s sobrepasando el ancho.';

$txt['ancho_columna'] = 'Ancho de la columna:
<div class="smalltext">(Ancho en pixeles, ej: 365)</div>';

$txt['custom_desing'] = 'Usar Dise&#241;o customizado?:';

$txt['img_back'] = 'Im&#225;gen de Fondo del titulo:
<div class="smalltext">(URL de la imagen que se repetira horizontalmente)</div>';

$txt['content'] = '<b>Para el Contenido:</b>';
$txt['content_color'] = 'Color de Fondo del Contenido: <div class="smalltext">(Codigo de color html, ej: <b>#FFFFFF</b>)</div>';
$txt['borderw'] = 'Ancho del Borde:<div class="smalltext">(Recomendado 1)</div> ';
$txt['border_tipe'] = 'Tipo del Borde: ';
$txt['border_color'] = 'Color del Borde:<div class="smalltext">(Codigo de color html, ej: <b>#FFFFFF</b>)</div>';

?>