<?php

$txt['mod_log'] = 'Historial de Moderaci&oacute;n';
$txt['maintenance'] = 'Mantenimiento...';
$txt['edited_post'] = '<font style="color: #00BA00;">Editado</font>';
$txt['member_deleted'] = '<font style="color: #FF0000;">Miembro eliminado</font>';
$txt['cause'] = '<b style="color: #FF0000;">Causa</b>';
$txt['mod_closed'] = 'Cerrado';
$txt['mod_stick'] = 'Sticky';
$txt['mod_moved'] = 'Movido';
$txt['mod_deleted'] = '<font style="color: #FF0000;">Eliminado</font>';
$txt['mod_removed'] = '<font style="color: #FF9114;">Comentario Eliminado</font>';
$txt['mod_baned'] = 'Baneado';
$txt['mod_news'] = 'Nuevo';
$txt['mod_perfil'] = 'Perfil';
$txt['mod_unk'] = 'aaaa';
?>