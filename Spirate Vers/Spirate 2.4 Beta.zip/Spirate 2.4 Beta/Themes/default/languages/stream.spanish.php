<?php

$txt['status'] = 'Estado';
$txt['link'] = 'Enlace';
$txt['video'] = 'Video';
$txt['image'] = 'Im&aacute;gen';
$txt['edit_account'] = 'Editar Cuenta';
$txt['edit_profile'] = 'Editar Perfil';
$txt['privacy'] = 'Privacidad';
$txt['placeholder_new_activity'] = 'Comparte un estado, im&aacute;gen, enlace o video con los dem&aacute;s';
$txt['stream_empty_members'] = 'No encontramos ninguna historia reciente, prueba seguir a otros usuarios o agrega un amigo a tu lista.';
$txt['stream_empty_stories'] = 'No se encontro ninguna historia.';


?>