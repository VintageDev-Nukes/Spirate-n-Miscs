<?php
$txt['jslang'] = array();
$txt['jslang']['doh'] = 'Oops';
$txt['jslang']['loading'] = 'Cargando...';
$txt['jslang']['error'] = 'Error';
$txt['jslang']['error_while_processing'] = 'Ocurrio un error al solicitar lo procesado.';
$txt['jslang']['confirm_action'] = 'Confirmar acci&oacute;n';
$txt['jslang']['ask::confirm_action'] = 'Estas seguro de querer realizar esta acci&oacute;n?';
$txt['jslang']['dont_ask_me'] = 'No volver a preguntarme.';
$txt['jslang']['buttons'] = array(
                                'accept' => 'Aceptar',
                                'cancel' => 'Cancelar',
                                'retry' => 'Reintentar'
                            );
$txt['jslang']['reason_elimination'] = 'Es necesaria la causa de la eliminaci&oacute;n.';
$txt['jslang']['unfollow_u'] = 'Dejar de seguir';
$txt['jslang']['follow_u'] = 'Seguir usuario';

?>