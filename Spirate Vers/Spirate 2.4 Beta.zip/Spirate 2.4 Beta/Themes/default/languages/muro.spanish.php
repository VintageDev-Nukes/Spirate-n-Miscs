<?php

//Muro de Commentarios

$txt['pcomments_notify_pm_subject'] = 'Notificacion: Comentaron tu Muro!';
$txt['pcomments_notify_pm_body']  = "Tienes un nuevo comentario en tu Muro!\nComentado por: %poster\n\nIr al Perfil: ";

$txt['pcomments_only_logued'] = '<center><span style="color: red;" class="size11"><b>Solo usuarios registrados pueden comentar</b></span></center>';

$txt['pcomments_subcoment'] = 'ha comentado tu publicacion en un';
$txt['pcomments_profile'] = 'Perfil';
$txt['pcomments_subject'] = 'Notificacion: Subcomentario.';
$txt['pcomments_delete'] = 'Subcomentario Borrado';


?>