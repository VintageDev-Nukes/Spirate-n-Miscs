<?php
$txt['post_already_added_to_favorites'] = 'This post is already in your bookmarks!';
$txt['added_to_favorites'] = 'Added to your bookmarks';
$txt['my_favorites'] = 'My Bookmarks';
$txt['no_favorites'] = 'You have not selected any favorite post';
$txt['selected_favorites'] = 'Bookmark/s selected/s:';
$txt['favorites_ads'] = 'Ads';
?>