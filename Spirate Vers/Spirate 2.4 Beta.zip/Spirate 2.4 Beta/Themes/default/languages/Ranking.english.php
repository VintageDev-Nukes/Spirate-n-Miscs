<?php
// Ranking 2.0 by 002adrproducciones 2010

$txt['rankinguser'] = 'User Rank';
$txt['rank_act'] = 'Rank! Updated Succesfully<br>Users updated:';
$txt['rank_noactivo'] = 'you have not enabled the ranking, therefore the rank will not be visible, not even in the posts, or profile,enable it for a better use.<br><br>A tip from 002 xD';
$txt['copy'] = '<font size="1">Ranking System v2.0 By <a href="http://www.bitenet.com.ar/" target="_blank">002adrproducciones</a></font>';
$txt['rank_back'] = 'Go Home';
$txt['actualizar'] = 'Update Rank';
$txt['user'] = 'User';
$txt['score'] = 'Score';
$txt['r'] = 'R!';

?>