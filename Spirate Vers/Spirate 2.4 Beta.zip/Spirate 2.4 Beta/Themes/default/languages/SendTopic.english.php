<?php
$txt['send_post'] = 'Send Post';
$txt['email_amigo'] = 'Your Friends E-Mail';
$txt['Asunto'] = 'Subject';
$txt['Mensaje'] = 'Message';
$txt['Mensaje_mail'] = 'Hello! I Would Like To Recommend You This Topic!';
$txt['Value_recomendar'] = 'Recomend Post';
$txt['send_no_friend'] = 'You Have Not Entered The E-Mail.';
$txt['send_no_mess'] = 'You Have Not Written The Message';
$txt['send_from'] = 'This Message Was Sent From';
$txt['send_link'] = 'Link: ';
?>