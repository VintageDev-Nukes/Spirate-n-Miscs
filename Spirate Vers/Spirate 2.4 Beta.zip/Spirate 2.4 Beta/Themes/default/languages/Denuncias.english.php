<?php
//report!!
$txt['comment_denunciation'] = 'You have to write the reason of your report.';
$txt['select_post'] = 'You have not selected any post';
$txt['denounce_post'] = 'Report post';
$txt['denounce_login'] = 'Sorry, to make a report you must be logged.';
$txt['principal_page'] = 'Go home';
$txt['denounce_to_post'] = 'Report the post:';
$txt['created_by'] = 'Created by:';
$txt['denounce_reason'] = 'Reason:';
$txt['denounce_repost'] = 'Re-post';
$txt['denounce_spam'] = 'Spam';
$txt['denounce_links'] = 'Dead links';
$txt['denounce_disrespectful'] = 'Racist or rude';
$txt['denounce_personal_information'] = 'Includes personal information';
$txt['denounce_mayus'] = 'Title in caps';
$txt['denounce_porn'] = 'Includes pornography';
$txt['denounce_gore'] = 'Includes gore content';
$txt['denounce_fount'] = 'Wrong font';
$txt['denounce_poor'] = 'Post too poor';
$txt['denounce_pass'] = 'No password for the files';
$txt['denounce_protocol'] = 'Out of the protocol';
$txt['denounce_other'] = 'Another reason (specify)';
$txt['denounce_explanation'] = 'Explanation:';
$txt['repost_link'] = 'If it�s re-post you have to give the original link.';
$txt['denounce_envoy'] = 'Report sent';
$txt['denounce_envoy2'] = 'Your report has been sent.';
$txt['denounce_titulo'] = "Report post";

?>