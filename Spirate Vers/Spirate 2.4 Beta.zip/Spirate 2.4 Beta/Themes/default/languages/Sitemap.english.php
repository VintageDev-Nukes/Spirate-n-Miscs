<?php
$txt['general'] = 'General';
$txt['searcher'] = 'Search';
$txt['chat'] = 'Chat';
$txt['contact'] = 'Contact';
$txt['share_us'] = 'Share Us';
$txt['protocol'] = 'Protocol';
$txt['widget'] = 'Widget';
$txt['TOS'] = 'Terms and Conditions';
$txt['top'] = 'Top';
$txt['categories'] = 'Categories';
$txt['topic'] = 'Post';
$txt['rss'] = 'RSS';
$txt['lasts_topics'] = 'Latest topics';
$txt['lasts_posts'] = ' Latest comments';$txt['points_users'] = 'Top Points Users';$txt['posts_users'] = 'Tops Posts Users';$txt['new_users'] = 'New Users';
?>