﻿<?php

//Varios
$txt['monitor_title'] = 'User monitor';
$txt['last_moves'] = 'Latest movements';
$txt['profile_of'] = 'View profile of:';
$txt['no_moves'] = 'No new movements';
$txt['fil_moves'] = 'Filter by:';
$txt['no_fil'] = 'Dont filter';
$txt['help'] = 'Help:';
$txt['help_background'] = '<b>Yellow Background:</b><br>means that the notification was made today.';
$txt['help_lineblue'] = '<b>Blue line to the left:</b><br>means that the notification has not been seen.';
$txt['publicity'] = 'Ads';
$txt['private_function'] = 'This function is private, you have to be registered!.';
$txt['cant'] = 'You can not do this';
$txt['delete_finish'] = 'Completely emptied, thanks for working with';
$txt['delete_notifi'] = 'Notifications empty';

//Notificaiones
$txt['not_comment'] ='Comments';
$txt['not_point'] ='Points';
$txt['not_fav'] ='Bookmarks';
$txt['not_comment_img'] ='Comments (Picture)';
$txt['not_point_img'] ='Points (Picture)';
$txt['not_comment_profile'] ='Comments (Wall)';
$txt['not_subcomment_profile'] ='Subcomments (Wall)';
$txt['not_friend'] ='Friend requests';
$txt['not_users'] ='Users';


//Complementos a las Notificaciones
$txt['quehizo_1'] = 'Replied your';
$txt['quehizo_2-1'] = 'Gave';//Left
$txt['quehizo_2-2'] = 'points to your';
$txt['quehizo_3'] = 'bookmarked your';
$txt['quehizo_4'] = 'replied your';
$txt['quehizo_5-1'] = 'Gave';//Left
$txt['quehizo_5-2'] = 'points to your';
$txt['quehizo_6'] = 'made a publication to your';
$txt['quehizo_7'] = 'replied your';
$txt['quehizo_8'] = 'wants to be your';
$txt['quehizo_9'] = 'accepted you as a';

$txt['quehizo_8_title'] = 'Enter to accept or reject it';

//Mas complementos
$txt['post'] = 'Post';
$txt['image'] = 'Picture';
$txt['wall'] = 'Wall';
$txt['publication'] = 'Topic';//ACA
$txt['friend'] = 'Friend';

//funcion Howlong
$txt['rec_since'] = 'Since';
$txt['rec_seconds'] = 'seconds';
$txt['rec_minute'] = 'minute';
$txt['rec_minutes'] = 'minutes';
$txt['rec_hour'] = 'hour';
$txt['rec_hours'] = 'hours';
$txt['rec_day'] = 'day';
$txt['rec_days'] = 'days';
$txt['rec_month'] = 'month';
$txt['rec_months'] = 'months';
$txt['rec_year'] = 'year';
$txt['rec_years'] = 'years';


//Administracion
$txt['admin_monitor_title'] = 'Manage monitor';
$txt['admin_monitor_descripcion'] = 'Here you can manage the monitor';
$txt['admin_edit'] = 'Edit Monitor';
$txt['admin_monitorpubli'] = 'Ads block: ';
$txt['admin_monitorcant'] = 'Number of notificatios to show: ';
?>