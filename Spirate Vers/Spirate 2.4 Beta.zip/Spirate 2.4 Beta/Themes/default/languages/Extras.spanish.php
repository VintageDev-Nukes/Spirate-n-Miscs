<?php
$txt['announcement_added'] = 'Informaci&oacute;n editada con &eacute;xito';
$txt['announcement_mistake'] = 'Error al editar la informaci&oacute;n';
$txt['add_extra'] = 'Configurar Extras';
$txt['add_ads'] = 'Editar publicidad:';
$txt['ads_explanation'] = 'Los anuncios NO pueden ser los mismos (cuidado con las dimensiones).';
$txt['ads1'] = '(1) Bloque Destacados: [rectangular]';
$txt['ads2'] = '(2) Publicidad en el Buscador: [vertical]';
$txt['ads3'] = '(3) Perfil de Usuario: [horizontal]';
$txt['ads4'] = '(4) Registro: [rectangular]';
$txt['ads5'] = '(5) Al lado del logo: [horizontal]';
$txt['ads6'] = '(6) Favoritos: [vertical]';
$txt['sitelinks'] = 'Editar enlaces:';
$txt['save_ads'] = 'Guardar Cambios';
$txt['error_for_idiots_like_you'] = 'Error al cargar la plantilla "eres_tonto"';
$txt['extras_title'] = 'Publicidad';
?>