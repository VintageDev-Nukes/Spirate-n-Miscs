<?php

$txt['puntospr'] = 'Puntos por Rangos';
$txt['puntospr_points'] = 'Puntos';
$txt['puntospr_range'] = 'Rangos';

?>