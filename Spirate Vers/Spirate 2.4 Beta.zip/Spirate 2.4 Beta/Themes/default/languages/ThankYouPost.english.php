<?php
$txt['NMidTopicSet'] = 'The Topic Could Not Be Identified!';
$txt['allready_postet_thx'] = 'You Have Already Thanked This Topic';
$txt['WMidTopicSet'] = 'Wrong Topic Or Could Not Be Identified';
$txt['Thxtomyself'] = 'You Can�t Thank Yourself!';
$txt['thxislocked'] = 'Thanks Is Closed,So You Can�t Thank Anymore!';
$txt['thxislockednor'] = 'Sorry You Can�t Open The Option,The Thank Option Is Closed';
$txt['notathankyoupost'] = 'This Post Does Not Have The Thank Option !';
$txt['thxdeletenor'] = 'You Are Not Allowed To Remove The Thanks Of This Topic !';
$txt['thxdeletenormem'] = 'You Can�t Delete This Member From The List!';
$txt['remove_thank_you_post_mem'] = 'Remove This Member From The Thanked';
$txt['thxidnotfound'] = 'The Identification Of The Thanks Could Not Be Found!';
?>
