﻿<?php

//Varios
$txt['monitor_title'] = 'Monitor de Usuario';
$txt['last_moves'] = '&Uacute;ltimos Movimientos';
$txt['profile_of'] = 'Ver perfil de:';
$txt['no_moves'] = 'No ten&eacute;s movimientos nuevos';
$txt['fil_moves'] = 'Filtrar por:';
$txt['no_fil'] = 'No filtrar';
$txt['help'] = 'Ayuda:';
$txt['help_background'] = '<b>Fondo de color amarillo:</b><br>indica que la notificaci&oacute;n se hizo hoy.';
$txt['help_lineblue'] = '<b>Linea azul a la derecha:</b><br>indica que la notificacion no fu&eacute; vista.';
$txt['publicity'] = 'Publicidad';
$txt['private_function'] = 'Esta funci&oacute;n es solo para usuarios registrados.';
$txt['cant'] = 'No podes hacer eso';
$txt['delete_finish'] = 'Vaciado Completado, gracias por colaborar con';
$txt['delete_notifi'] = 'Vaciar Notificaciones';

//Notificaiones
$txt['not_comment'] ='Comentarios';
$txt['not_point'] ='Puntos';
$txt['not_fav'] ='Favoritos';
$txt['not_comment_img'] ='Comentarios (Imagen)';
$txt['not_point_img'] ='Puntos (Imagen)';
$txt['not_comment_profile'] ='Comentarios (Muro)';
$txt['not_subcomment_profile'] ='Subcomentario (Muro)';
$txt['not_friend'] ='Peticion de Amigos';
$txt['not_users'] ='Usuarios';


//Complementos a las Notificaciones
$txt['quehizo_1'] = 'coment&oacute; tu';
$txt['quehizo_2-1'] = 'dej&oacute;';
$txt['quehizo_2-2'] = 'puntos a tu';
$txt['quehizo_3'] = 'agrego a favoritos tu';
$txt['quehizo_4'] = 'coment&oacute; tu';
$txt['quehizo_5-1'] = 'dej&oacute;';
$txt['quehizo_5-2'] = 'puntos a tu';
$txt['quehizo_6'] = 'hizo una publicaci&oacute;n en tu';
$txt['quehizo_7'] = 'coment&oacute; tu';
$txt['quehizo_8'] = 'quiere ser tu';
$txt['quehizo_9'] = 'te ha aceptado como';

$txt['quehizo_8_title'] = 'Entra para Aceptarlo o Rechazarlo';

//Mas complementos
$txt['post'] = 'Post';
$txt['image'] = 'Im&aacute;gen';
$txt['wall'] = 'Muro';
$txt['publication'] = 'Publicaci&oacute;n';
$txt['friend'] = 'Amigo';

//funcion Howlong
$txt['rec_since'] = 'Hace';
$txt['rec_seconds'] = 'segundos';
$txt['rec_minute'] = 'minuto';
$txt['rec_minutes'] = 'minutos';
$txt['rec_hour'] = 'hora';
$txt['rec_hours'] = 'horas';
$txt['rec_day'] = 'd&iacute;a';
$txt['rec_days'] = 'd&iacute;as';
$txt['rec_month'] = 'mes';
$txt['rec_months'] = 'meses';
$txt['rec_year'] = 'año';
$txt['rec_years'] = 'años';


//Administracion
$txt['admin_monitor_title'] = 'Administrar Monitor';
$txt['admin_monitor_descripcion'] = 'Aqu&iacute; podr&aacute;s gestionar tu Monitor de Usuario';
$txt['admin_edit'] = 'Editar Monitor';
$txt['admin_monitorpubli'] = 'Bloque Publicidad: ';
$txt['admin_monitorcant'] = 'Cantidad de notificaciones a mostrar: ';
?>