<?php

$txt['bloque'] = 'Block manager';
$txt['bloque_descripcion'] = 'From this block manager, you can manage all your blocks from the main page, <b>Developed by 002</b>';
$txt['ver_colum'] = 'Blocks in column';


$txt['ancho_disponible'] = 'Available width: ';
$txt['numero_columnas'] = 'Number of columns: ';
$txt['ancho_sobrepasado'] = 'the width exceeds.';

$txt['ancho_columna'] = 'Column width:
<div class="smalltext">(Width in pixels, ej: 365)</div>';

$txt['custom_desing'] = 'Use custom design?:';

$txt['img_back'] = 'Titles background image:
<div class="smalltext">(URL of the image that will be repeated horizontally)</div>';

$txt['content'] = '<b>For the content:</b>';
$txt['content_color'] = 'Background color: <div class="smalltext">(color code html, ej: <b>#FFFFFF</b>)</div>';
$txt['borderw'] = 'Border width:<div class="smalltext">(Recommended 1)</div> ';
$txt['border_tipe'] = 'Type of border: ';
$txt['border_color'] = 'Border color:<div class="smalltext">(Codigo de color html, ej: <b>#FFFFFF</b>)</div>';

?>