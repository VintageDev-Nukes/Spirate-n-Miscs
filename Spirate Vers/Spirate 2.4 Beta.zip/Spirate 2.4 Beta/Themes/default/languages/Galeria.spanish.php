<?php 


 //Administracion
 $txt['admin_title'] = 'Administraci&oacute;n de la Galeria';
 $txt['admin_gal_descripcion'] = 'Aqu&iacute; encontraras las opciones utilizadas para la Galeria de Im&aacute;genes, <b>hecho por 002</b>';

 $txt['cant_album'] = 'Cantidad de Albums que puede crear un Usuario: <div class="smalltext" style="color:#888888">(cero para deshabilitarlo.)</div>';
 $txt['pag_recent'] = 'Cantidad de Paginas a Mostrar: <div class="smalltext" style="color:#888888">(cantidad de n&uacute;meros de p&aacute;gina.)</div>';
 $txt['cant_img_recent'] = 'Cantidad de Im&aacute;genes a Mostrar';
 $txt['thumbnail'] = 'Activar Thumbnails <div class="smalltext" style="color:#888888">(Las Thumbnails se guardar&aacute;n en tu servidor.)</div>';
 $txt['act_publi'] = 'Activar Publicidad: ';
 $txt['publi'] = 'Publicidad: ';

?>