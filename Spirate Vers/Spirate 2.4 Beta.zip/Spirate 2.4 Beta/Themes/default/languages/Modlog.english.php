<?php

$txt['mod_log'] = 'Mod log';
$txt['maintenance'] = 'Maintenance...';
$txt['edited_post'] = '<font style="color: #00ba00;">Edited</font>';
$txt['member_deleted'] = '<font style="color: #ff0000;">Member deleted</font>';
$txt['cause'] = '<b style="color: #ff0000;">Cause</b>';
$txt['mod_closed'] = 'Closed';
$txt['mod_stick'] = 'Sticky';
$txt['mod_moved'] = 'Moved';
$txt['mod_deleted'] = '<font style="color: #ff0000;">Deleted</font>';
$txt['mod_removed'] = '<font style="color: #ff9114;">Comment removed</font>';
$txt['mod_baned'] = 'Baned';
$txt['mod_news'] = 'New';
$txt['mod_perfil'] = 'Profile';
$txt['mod_unk'] = 'aaaa';
?>