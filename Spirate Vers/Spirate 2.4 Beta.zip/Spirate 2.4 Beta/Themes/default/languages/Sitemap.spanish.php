<?php
$txt['general'] = 'General';
$txt['searcher'] = 'Buscador';
$txt['chat'] = 'Chat';
$txt['contact'] = 'Contacto';
$txt['share_us'] = 'Enlazanos';
$txt['protocol'] = 'Protocolo';
$txt['widget'] = 'Widget';
$txt['TOS'] = 'T&eacute;rminos y condiciones';
$txt['top'] = 'Top';
$txt['categories'] = 'Categor&iacute;as';
$txt['topic'] = 'Post';
$txt['rss'] = 'RSS';
$txt['lasts_topics'] = '&Uacute;ltimos posts';
$txt['lasts_posts'] = '&Uacute;ltimos comentarios';

$txt['points_users'] = 'Usuarios con Mas Puntos';
$txt['posts_users'] = 'Usuarios con Mas Posts';
$txt['new_users'] = 'Nuevos Usuarios';

?>