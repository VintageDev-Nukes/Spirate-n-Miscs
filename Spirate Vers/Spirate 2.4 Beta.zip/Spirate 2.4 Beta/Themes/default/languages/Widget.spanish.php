<?php
//widget.english.php
$txt['should_be_integer'] = 'Debes ingresar un valor num&eacute;rico en el campo cantidad de posts listados';
$txt['should_input_something'] = 'Debes ingresar un valor num&eacute;rico en el campo cantidad de posts listados';
$txt['maximun_listed_topics'] = 'La cantidad m&acute;xima de posts listados es';
$txt['title'] = 'Widget';
$txt['how_to_implement'] = 'Integra los &uacute;ltimos posts en tu Web y estate siempre actualizado.<br />

      En s&oacute;lo un segundos podr&aacute;s tener un listado que estar&aacute; siempre 
      actualizado con los &uacute;ltimos posts publicados.<br />
      Puedes personalizar el listado para que se adapte al estilo de tu sitio, cambiando su tama&ntilde;o, color, cantidad de posts a listar y hasta filtrado por categor&iacute;as.<br /><br />

      <b>Como implementarlo:</b><br />
      <b>1.</b> Personal&iacute;zalo a tu gusto. Elige la categor&iacute;a, cantidad de posts, tama&ntilde;o y el color.<br />

      <b>2.</b> Copia el c&oacute;digo generado y p&eacute;galo en tu p&aacute;gina.<br />
      <b>3.</b> Listo. Ya puedes disfrutar de nuestro Widget<br />';
$txt['customization'] = 'Personalizaci&oacute;n';
$txt['code'] = 'C&oacute;digo';
$txt['example'] = 'Ejemplo';
$txt['category'] = 'Categor&iacute;a';
$txt['all'] = 'Todas';
$txt['how_much'] = 'Cantidad';
$txt['size'] = 'Tama&ntilde;o';
$txt['color'] = 'Color';
$txt['red'] = 'Rojo';
$txt['yellow'] = 'Amarillo';
$txt['grey'] = 'Gris';
$txt['pink'] = 'Rosa';
$txt['violet'] = 'Violeta';
$txt['green'] = 'Verde';
$txt['lightblue'] = 'Turquesa';
?>