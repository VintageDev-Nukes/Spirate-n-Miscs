<?php
$txt['Buddies_again'] = 'Este usuario ya es amigo tuyo.';
$txt['Buddies_added'] = '&iexcl;Has agregado a este usuario como amigo!';
$txt['Buddies_youself'] = '&iexcl;No puedes agregarte a ti mismo como amigo!';
$txt['Buddies_center'] = 'Centro de Amigos';
$txt['Buddies_permission_short'] = '%s quiere ser tu amigo';
$txt['Buddies_permission_long'] = '%s quiere ser tu amigo. [url=%s]Click aqui[/url] para ir al Centro de Amigos y Aceptarlo o Rechazarlo.';
$txt['Buddies_none'] = 'No Tienes Ning&uacute;n Amigo En tu Lista';
$txt['Buddies_del'] = 'Eliminar amigo';
$txt['Buddies_move_up'] = 'Mover amigo arriba';
$txt['Buddies_move_down'] = 'Mover amigo abajo';
$txt['Buddies_not_aproved'] = 'Amigos no aprobados';
$txt['Buddies_aprove'] = 'Aprobar amigo';
$txt['Buddies_pend'] = 'Amigos Pendientes';
?>