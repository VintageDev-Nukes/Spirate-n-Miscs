<?php

$txt['comment_denunciation'] = 'Es necesario que agreges una aclaraci\xf3n o comentario sobre tu denuncia.';
$txt['select_post'] = 'Tu no has seleccionado ningun post para denunciar';
$txt['denounce_post'] = 'Denunciar Post';
$txt['denounce_login'] = 'Disculpe, para denunciar un post debe autentificarte.';
$txt['principal_page'] = 'Ir a la P&aacute;gina principal';
$txt['denounce_to_post'] = 'Denunciar el post:';
$txt['created_by'] = 'Creado por:';
$txt['denounce_reason'] = 'Raz&oacute;n de la denuncia:';
$txt['denounce_repost'] = 'Re-post';
$txt['denounce_spam'] = 'Se hace Spam';
$txt['denounce_links'] = 'Tiene enlaces muertos';
$txt['denounce_disrespectful'] = 'Es Racista o irrespetuoso';
$txt['denounce_personal_information'] = 'Contiene informaci&oacute;n personal';
$txt['denounce_mayus'] = 'El Titulo esta en may&uacute;scula';
$txt['denounce_porn'] = 'Contiene Pornografia';
$txt['denounce_gore'] = 'Es Gore o asqueroso';
$txt['denounce_fount'] = 'Est&aacute; mal la fuente';
$txt['denounce_poor'] = 'Post demasiado pobre';
$txt['denounce_pass'] = 'No se encuentra el Pass';
$txt['denounce_protocol'] = 'No cumple con el protocolo';
$txt['denounce_other'] = 'Otra raz&oacute;n (especificar)';
$txt['denounce_explanation'] = 'Aclaraci&oacute;n y comentarios:';
$txt['repost_link'] = 'En el caso de ser Re-post se debe indicar el enlace del post original.';
$txt['denounce_envoy'] = 'Denuncia enviada';
$txt['denounce_envoy2'] = 'Tu denuncia ha sido enviada correctamente.';
$txt['denounce_titulo'] = "Denunciar Post";

?>