<?php
// Spirate Script - Version 2.4
function template_init()
{	global $context, $settings, $txt;
	$settings['doctype'] = 'xhtml';
	$settings['theme_version'] = '2.4';
        $settings['theme'] = array(
            'name' => 'Small pirate',
            'version' => '2.4',
            'author' => 'spirate staff' // :)
            );
}

function template_main_above(){
global $context, $settings, $boardurl, $scripturl, $txt, $modSettings, $db_prefix, $boarddir, $no_avatar, $ID_MEMBER, $mbname;

echo '<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<!-- Small Pirate - Social Community Script - www.spirate.net V2.4 -->
<html debug="true">
    <head>
	<meta http-equiv="X-UA-Compatible" content="chrome=1" />
	<meta http-equiv="Content-Type" content="text/html; charset=' , $context['character_set'] , '" />
	<meta name="description" content="' , $context['page_description'] , '" />
	<meta name="robots" content="all" />
	<meta name="keywords" content="all" />
	<meta name="revisit-after" content="1 days" />
	<title>'.$mbname.' - ' , $context['page_title'] , '</title>
	<link rel="shortcut icon" href="', $settings['images_url'] ,'/favicon.ico" type="image/x-icon">
	<link rel="alternate" type="application/atom+xml" title="', $txt['last_posts'] ,'" href="/web/rss/rss-ultimos-post.php" />
	<link rel="alternate" type="application/atom+xml" title="', $txt['last_comments'] ,'" href="/web/rss/rss-comment.php" />
        <!-- Estilos del Theme -->
        <link rel="stylesheet" type="text/css" href="'.$settings['theme_url'].'/bluesp-estilos.css', $_SERVER['HTTP_HOST'] == 'localhost' ? '?upd=' . time() : '?v=0.1' ,'"/>
        <!--[if IE]>
            <link rel="stylesheet" type="text/css" href="'.$settings['theme_url'].'/bluesp-ie.css', $_SERVER['HTTP_HOST'] == 'localhost' ? '?upd=' . time() : '' ,'"/>
        <![endif]-->
        <!-- Lenguajes para el javascript -->
        <script src="'.$scripturl.'?action=jslang" type="text/javascript"></script>
        <!-- Librerias javascript -->
        <script src="'.$settings['theme_url'].'/jquery.min.js" type="text/javascript"></script>
        <script src="'.$settings['theme_url'].'/jquery-ui.min.js" type="text/javascript"></script>
        <!-- javascript -->
        <script type="text/javascript" src="'.$settings['theme_url'].'/sp-functions.js"></script>
        <script type="text/javascript" src="'.$settings['theme_url'].'/bluesp-script.js', $_SERVER['HTTP_HOST'] == 'localhost' ? '?upd=' . time() : '?v=0.1' ,'"></script>
		' . implode("\n\t", $context['html_headers']) . '';
	
	if($context['user']['is_guest'])
	
        echo '<!-- css :: Fast register -->
            <link rel="stylesheet" type="text/css" href="'.$settings['theme_url'].'/register.ajax.css', $_SERVER['HTTP_HOST'] == 'localhost' ? '?upd=' . time() : '' ,'"/>';
		
        echo spVarsJs(array(
            // variables simples. ( solo para definir integros, decimales, arrays, cadenas y booleanos )
            // ejemplos: 'variable' => 1, 'foo' => 'jon', 'fruit' => array(1,2,3,4,5)
            // RETURN: var variable = 1, var foo = 'jon', var fruit = [1,2,3,4,5]
			// [ejemplo] = 1 | return => ejemplo = 1; // remove "var"
			
            '[notificaciones.count]' => (int) $context['user']['count::notifications'],
        ), array(		
            // object global.data 
            // ejemplos: 'foo' => 'spirate', 'linux' => true, 'dias' => array('lunes', 'martes', 'miercoles')
            // RETURN: global.data{ foo : 'spirate', linux : true, dias : ['lunes', 'martes', 'miercoles'] }
			
            'default_avatar' => $no_avatar,
            'ID_POST' => (isset($_GET['topic']) && !empty($_GET['topic']) ? $_GET['topic'] : 0),
            'ID_IMG' => (isset($_GET['imagen']) && !empty($_GET['imagen']) ? $_GET['imagen'] : 0),
			'images_url' => $settings['images_url']
        ), array(
            // when DOM is ready
			
            $context['user']['is_logged'] ? 'notificaciones.ballon();' : null
        ));
		
echo '
	</head>
<body>
<noscript>',$txt['no_java_explorer'],'</noscript>
		<!-- #header -->
		<div id="header">
            <div class="container clearfix">
            <div class="left"><a id="logo" href="'.$scripturl.'"><img src="';if($settings['header_logo_url']==''){echo''.$settings['images_url'].'/logo-beta.png';}else{echo $settings['header_logo_url'] ; } echo'" title="'.$context['forum_name'].'" alt="'.$context['forum_name'].'" /></a></div>
            <!-- <div class="banner">Publicidad</div> -->
            <div id="search">
            <div class="ui-search clearfix"><div class="left"></div>
            <form name="buscador" method="GET" action="'.$scripturl.'">
            <input name="action&#61;search2&amp;search" type="text" class="text" name="q" placeholder="Buscar..." /><input type="submit" class="button"></div>
            </form>
            </div>

            </div>
        </div>
		<!-- / #header -->
        <!-- Menu de navegacion -->
	    ',sp_nav(),'

        <!-- main content -->
        <div id="main"', $context['no_show_menus'] ? 'class="no_show_menus"' : '' ,'>
        
        <!-- barra -->
        ',sp_news(),'
            
        <!-- contenido -->
        <div class="globalcontent clearfix">';
        

}

//Navegacion principal
function sp_nav(){
	global $context, $scripturl, $txt, $db_prefix, $func, $no_avatar;

$ttipChatUsers = ($total_online = getUsersFromChat()) ? nanotip('<span id="n_users_chat">' . $total_online . '</span> online', 'left', array('position' => 'absolute', 'width' => 300, 'top' => $context['browser']['is_ie'] ? -14 : -5, 'left' => 25)) : '';


	echo'

<div id="navigation">
<div class="container">';

/**
 * @tabs[
 *       all    : pestañas a vista de todos los usuarios logueados y visitantes.
 *       on     : pestañas a vista de usuarios logueados solamente.
 *       off    : pestañas a vista de usuarios visitantes solamente.
 *       admin  : pestañas a vista de administradores solamente.
 *       ]
 *
 * ¡IMPORTANTE! : recuerda usar '. $var .' y no usar ', $var ,' ( puntos => SI, COMAS => no )
 *
 * sintaxis: 'ideas' => '<li{selected}><a href="'.$scripturl.'?action=ideas" title="ideas para tu web"><i></i></a></li>'
 * --------
 * 
 * seleccionando pestaña con varias acciones (?action=)
 * 
 * 'foo|jhon|fruits' => '<li{selected}><a href="'.$scripturl.'?action=jhon" title="probando..."><i></i></a></li>'
 * --------
 *
 * seleccionando pestaña con una subaccion en especial
 * 
 * "accion" : ?action=
 * "subaccion" : &sa= o &loquesea=
 * "adonde" : valor de la subaccion
 * 
 * 'accion&[subaccion]=adonde' => '<li{selected}><a href="'.$scripturl.'?action=debug" title="probando..."><i></i></a></li>'
 * 
 */

// La pestania administracion debe estar seleccionada con estas acciones:
$adminAreas = array(
                    'admin',
                    'news',
                    'denuncias',
                    'paises',
                    'designtheme',
                    'desingtheme',
                    'puntospr',
                    'bloques',
                    'adminmonitor',
                    'adminamigables',
                    'featuresettings',
                    'serversettings',
                    'theme',
                    'extras',
                    'packages',
                    'manageboards',
                    'postsettings',
                    'managesearch',
                    'smileys',
                    'manageattachments',
                    'viewmembers',
                    'membergroups',
                    'permissions',
                    'regcenter',
                    'ban',
                    'maintain',
                    'viewError',
                    
                    'shop_general',
                    'shop_inventory',
                    'shop_usergroup'
                    );


$tabs = array(
    'all' => array(
        'stream' => array(
                          'html' => '<li{selected}><a href="'.$scripturl.'?action=stream" title="Actividades recientes"><i></i></a>'.($_GET['action']!='stream' ? '<div style="width: 100px; z-index: 99999; right: -85px; top: 1px;" class="bubble-notify absolute right"><span class="arrow"></span><span class="data"><i>new</i></span><span class="right"></span></div>' : '' ).'</li>',
                          'class' => 'stream'
                  ),
        'home|search|search2|post|post2|hist-mod' => '<li{selected}><a href="'.$scripturl.'" title="posts">Posts</a></li>',
        'TOPs' => '<li{selected}><a href="'.$scripturl.'?action=TOPs" title="'.$txt['tops'].'">'.$txt['tops'].'</a></li>',
        'rz&[m]=chat' => '<li{selected} style="position:relative"><a href="'.$scripturl.'?action=rz&m=chat" title="'.$txt['chat'].'">'.$txt['chat'].'</a>'.$ttipChatUsers.'</li>',
        'galeria' => '<li{selected}><a href="'.$scripturl.'?action=galeria" title="Galeria">Galeria</a></li>',
    ),
    'on' => array(
        
        // ...
    ),
    'off' => array(
        'registrarse' => '<li{selected}><a rel="registro">Registrate!</a>'.nanotip('Gratis!', 'left', array('position' => 'absolute', 'top' => -5, 'left' => 45, 'width' => 300)).'</li>',
        // ...
    ),
    'admin' => array(
        implode('|', $adminAreas) => '<li{selected}><a href="'.$scripturl.'?action=admin" title="'.$txt['admin_boton_index'].'">'.$txt['admin_boton_index'].'</a></li>'
        // ...
    )

);

$menutabs = array_merge($tabs['all'], $tabs[$context['user']['is_logged'] ? 'on' : 'off']);

// tabs para administrador/moderador
if($context['allow_admin'])
    $menutabs += $tabs['admin'];


$action = !isset($_GET['action']) || empty($_GET['action']) || (isset($_GET['topic']) && !isset($_GET['msg'])) ? 'home' : $_GET['action'];

if($context['no_show_menus']){
    if(!$context['create_default_tabs'])
        $menutabs = array('default_tab' => '<li{selected}><a href="', $context['default_tab_in_no_menu'] ,'">', $context['default_tab_in_no_menu'][1] ,'</a></li>');
    else
        $menutabs = array('default_tab' => '<li{selected}><a href="', $context['create_default_tabs'][0] ,'">', $context['create_default_tabs'][1] ,'</a></li>');
}


echo '<ul id="menutabs" class="clearfix smallfont">';

foreach($menutabs as $k => $tab)
    if(!is_array($tab)){
        if(preg_match('~([^\|]+)\|~', $k, $match)){
            echo (in_array($action, explode('|', $k)) ? str_replace('{selected}', ' class="selected"', $tab) : str_ireplace('{selected}', '', $tab));
        }
        else if(preg_match('~([^&]+)&\[([^=]+)\]=([^&]+)~', $k, $match)){
            list(, $_action, $sa, $saKey) = $match;
            echo ($_action == $action && $_GET[$sa] == $saKey ? str_replace('{selected}', ' class="selected"', $tab) : str_ireplace('{selected}', '', $tab));
        }
        else
            echo ($action == $k ? str_replace('{selected}', ' class="selected"', $tab) : str_replace('{selected}', '', $tab));
    }
    else{
        $classes = ' class="' . ($action == $k ? 'selected ' : '') . $tab['class'] . '"';
        echo ($tab_ = str_replace('{selected}', $classes, $tab['html']));
     }

echo '</ul><!-- /#menutabs -->';

if(!$context['no_show_menus']){
$mps = (int) $context['user']['unread_messages'];

$RightOptions = array(
    
    'on' => '<div id="ui-menu"><ul class="clearfix">
                    <li class="'. ($action == 'monitor' ? ' selected' : '') .'">
                    <div class="notify-globe notifications" style="top: -6px; right: -7px;"><a><span></span></a></div>
                    <a ajax="notificaciones" title="'.$txt['monitor'].'" onclick="notificaciones.open(this)" class="menuicon"><i class="monitor"></i></a>
                    <div class="box-notifications" id="notificaciones">
					<h3 class="title">Notificaciones</h3>
					<div class="body clearfix">
					<div class="loading">Cargando...</div>
					</div>
					<div class="hr-info clear"><span class="hide"><a class="tt-element hide" title="notificaciones anteriores" gravity="se">5+</a><i></i></span></div>
					<div class="see-more"><a href="'.$scripturl.'?action=monitor">Ver m&aacute;s notificaciones</a></div>
					</div></li>
                    <li'. ($action == 'pm' ? ' class="selected"' : '') .'>
                    '.(!empty($mps) ? '<div class="notify-globe" style="top: -6px; right: -7px;"><a><span>'.$mps.'</span></a></div>' : '').'
                    <a ajax="mensajes" href="'.$scripturl.'?action=pm" title="'.$txt['pm'].'" class="menuicon"><i class="mp"></i></a>
                    <!--<div class="box-notifications" id="mensajes-prvs"><h3 class="title">Mensajes Privados</h3><div class="body"><div class="loading">Sin mensajes...</div></div></div>--></li>
                    <li'. ($action == 'favoritos' ? ' class="selected"' : '' ) .'><a href="'.$scripturl.'?action=favoritos" title="'.$txt['my_favourites'].'" class="menuicon"><i class="favoritos"></i></a></li>                    
                    <li'. ($action == 'profile' && @$_GET['sa'] == 'cuenta' ? ' class="selected"' : '') .'><a href="'.$scripturl.'?action=profile&sa=cuenta" title="'.$txt['my_account'].'" class="menuicon"><i class="cuenta"></i></a></li>
                    <li'. ($action == 'profile' && @$_GET['sa'] != 'cuenta' ? ' class="selected"' : '') .'><a href="'.$scripturl.'?action=profile" title="'.$txt['my_profile'].'" class="menuicon username"><i class="avatar_thumbnail s22"><img src="'.( $context['user']['avatar']['src'] ? $context['user']['avatar']['src'] : $no_avatar ).'" class="rounded avatar" style="'.$context['user']['avatar']['coords'][22]['style'].'"></i> '.$func['substr']($context['user']['name'], 0, 12).'</a></li>
                    <li'. ($action == 'hist-mod' ? ' class="selected"' : '') .'><a href="'.$scripturl.'?action=hist-mod" title="'.$txt['hist_mod'].'" class="menuicon"><i class="hist-mod"></i></a></li>
                    <li><a onclick="logout(); return false;" href="'.$scripturl.'?action=logout&sesc='.$context['session_id'].'" title="'.$txt['exit'].'" class="menuicon close"><i class="close"></i></a></li>
                </ul></div>',
    
    'off' => '<div class="login-tab"><a href="javascript:loginbox()" title="iniciar sesi&oacute;n">Iniciar sesi&oacute;n</a>
                    <div id="login-box">
                    <div class="cuerpo">
                    <form action="'.$scripturl. '?action=login2" method="post" accept-charset="ISO-8859-1" name="frmLogin" id="frmLogin" onsubmit="hashLoginPassword(this, \'' . $context['session_id'] . '\');">
                    <label for="nick">Usuario</label>
                    <input type="text" class="text" name="user" />
                    <label for="password">Password</label>
                    <input type="password" class="text" name="passwrd" />
                    <input type="submit" class="sp-button bluesky" value="Aceptar" style="width:217px">
                    </form>
                    <hr>
                    <a href="'. $scripturl. '?action=reminder">Olvidaste tu password?</a><br />
                    <a onclick="loginbox();" rel="registro">No tienes usuario?</a>
                    </div>

                    </div>
               </div>'
);

/* Borradores */
//<li'. ($action == 'borradores' ? ' class="selected"' : '') .'><a href="'.$scripturl.'?action=borradores" title="Ver tus borradores" class="menuicon"><i class="borradores"></i></a></li>

// motramos las opciones del usuario, si esta logueado, caso contrario, el login box.
echo $RightOptions[$context['user']['is_logged'] ? 'on' : 'off'];
}

		echo'</div><!-- /container -->
                           </div><!-- /navigation -->';

}

//Footer de la web
function template_main_below(){
	global $context, $scripturl, $txt;

	echo '</div></div>
            <!-- footer -->';
        
        if(!$context['no_show_menus']){
            echo '<div id="footer"><div class="padding-10">
                    <div class="left"><a title="'.$txt['termns'].'" href="'.$scripturl.'?action=terminos">'.$txt['termns'].'</a> -
                                                                    <a title="'.$txt['protocol'].'" href="'.$scripturl.'?action=protocolo">'.$txt['protocol'].'</a> -
                                                                    <a title="'.$txt['contact'].'" href="'.$scripturl.'?action=contactenos">'.$txt['contact'].'</a> -
                                                                    <a title="'.$txt['link_us'].'" href="'.$scripturl.'?action=enlazanos">'.$txt['link_us'].'</a> -
                                                                    <a title="'.$txt['widget'].'" href="'.$scripturl.'?action=widget">'.$txt['widget'].'</a>
                    </div>
                    <div class="right">', theme_copyright() ,'</div>
                    <div class="clear"></div>
            </div></div>';
        }
        else
            echo '<div class="container" style="text-align:center;margin-top: 15px">', theme_copyright() ,'</div>';

      echo '<div class="container" style="text-align:center"><br />Tiempo de carga: <strong>'.$context['load_time'].'</strong> segundos</div>';
echo '</body>
</html>';

}

//Barra noticias y submenu
function sp_news(){
	global $context, $settings, $scripturl;

if($context['no_show_menus'])
    return false;

$action = isset($_GET['action']) ? $_GET['action'] : false;

if(!$action || isset($_GET['topic']))
    $action = 'posts';

$sub_tabs = array(
    'post|posts|hist-mod' => array(
        array(
            'txt' => 'Inicio',
            'href' => $scripturl,
            'title' => 'Inicio',
            'who' => 'all'
            ),
	    array(
            'txt' => 'Ingresar',
            'href' => $scripturl . '?action=login',
            'title' => 'Ingresar',
            'who' => 'off'
        ),
        array(
            'txt' => '<img src="'.$settings['images_url'].'/add.png"> Agregar Post',
            'href' => $scripturl . '?action=post',
            'title' => 'Agregar post',
            'who' => 'on'
        ),       

    )
);

if(!empty($context['sub_tabs']))
    $sub_tabs = array_merge($sub_tabs, $context['sub_tabs']);

echo '<div class="info-bar">';
echo '<div id="sub-menutabs" class="clearfix">';


if(!empty($action)){

    $auxst = $sub_tabs;
    foreach($auxst as $subkey => $k){
	   if(in_array($action, explode('|', $subkey)))
	    $action = $subkey;
	}
    foreach($sub_tabs[$action] as $tab => $subtab){

	
        if($subtab['who']=='all' || empty($subtab['who']))
         echo '<a '. ('http://'.$_SERVER['HTTP_HOST'].$_SERVER['REQUEST_URI']== $subtab['href'] ? 'class="select"' : '') .' href="' . $subtab['href'] . '" title="'.$subtab['title'].'">' . $subtab['txt']. '</a>';
        elseif($subtab['who']=='on' && $context['user']['is_logged'])
         echo'<a '. ('http://'.$_SERVER['HTTP_HOST'].$_SERVER['REQUEST_URI']== $subtab['href'] ? 'class="select"' : '') .' href="' . $subtab['href'] . '" title="'.$subtab['title'].'">' . $subtab['txt']. '</a>';
        elseif($subtab['who']=='off' && !$context['user']['is_logged'])
         echo '<a '. ('http://'.$_SERVER['HTTP_HOST'].$_SERVER['REQUEST_URI']== $subtab['href'] ? 'class="select"' : '') .' href="' . $subtab['href'] . '" title="'.$subtab['title'].'">' . $subtab['txt']. '</a>';
        elseif($subtab['who']=='admin' && $context['allow_admin'])
         echo '<a '. ('http://'.$_SERVER['HTTP_HOST'].$_SERVER['REQUEST_URI']== $subtab['href'] ? 'class="select"' : '') .' href="' . $subtab['href'] . '" title="'.$subtab['title'].'">' . $subtab['txt']. '</a>';

                                                   }
					}

echo '</div>';

echo'<span id="smfFadeScroller" style="margin-left:15px;">', $context['news_lines'][0] , '</span>

	<script type="text/javascript"><!-- // --><![CDATA[
		// The fading delay (in ms.)
		var smfFadeDelay = ', empty($settings['newsfader_time']) ? 3000 : $settings['newsfader_time'], ';
		// Fade from... what text color? To which background color?
		var smfFadeFrom = {"r": 0, "g": 0, "b": 0}, smfFadeTo = {"r": 255, "g": 255, "b": 255};
		// Surround each item with... anything special?
		var smfFadeBefore = "", smfFadeAfter = "";

		var foreColor, backEl, backColor;

		if (typeof(document.getElementById(\'smfFadeScroller\').currentStyle) != "undefined")
		{
			foreColor = document.getElementById(\'smfFadeScroller\').currentStyle.color.match(/#([\da-f][\da-f])([\da-f][\da-f])([\da-f][\da-f])/);
			smfFadeFrom = {"r": parseInt(foreColor[1]), "g": parseInt(foreColor[2]), "b": parseInt(foreColor[3])};

			backEl = document.getElementById(\'smfFadeScroller\');
			while (backEl.currentStyle.backgroundColor == "transparent" && typeof(backEl.parentNode) != "undefined")
				backEl = backEl.parentNode;

			backColor = backEl.currentStyle.backgroundColor.match(/#([\da-f][\da-f])([\da-f][\da-f])([\da-f][\da-f])/);
			smfFadeTo = {"r": eval("0x" + backColor[1]), "g": eval("0x" + backColor[2]), "b": eval("0x" + backColor[3])};
		}
		else if (typeof(window.opera) == "undefined" && typeof(document.defaultView) != "undefined")
		{
			foreColor = document.defaultView.getComputedStyle(document.getElementById(\'smfFadeScroller\'), null).color.match(/rgb\((\d+), (\d+), (\d+)\)/);
			smfFadeFrom = {"r": parseInt(foreColor[1]), "g": parseInt(foreColor[2]), "b": parseInt(foreColor[3])};

			backEl = document.getElementById(\'smfFadeScroller\');
			while (document.defaultView.getComputedStyle(backEl, null).backgroundColor == "transparent" && typeof(backEl.parentNode) != "undefined" && typeof(backEl.parentNode.tagName) != "undefined")
				backEl = backEl.parentNode;

			backColor = document.defaultView.getComputedStyle(backEl, null).backgroundColor.match(/rgb\((\d+), (\d+), (\d+)\)/);
			smfFadeTo = {"r": parseInt(backColor[1]), "g": parseInt(backColor[2]), "b": parseInt(backColor[3])};
		}

		// List all the lines of the news for display.
		var smfFadeContent = new Array(
			"', implode('",
			"', $context['fader_news_lines']), '"
		);
	// ]]></script>';

echo'<script type="text/javascript" src="', $settings['default_theme_url'], '/fader.js"></script>';
echo '</div>';
}

function spVarsJs($vars = array(), $globalVars = array(), $ready_data = array()){
    global $context, $modsettings, $scripturl, $boardurl, $settings, $ID_MEMBER;

    $prepareVal = create_function(
            '$var, $simplevar = false',
            '$type = gettype($var);
                switch($type){
                    case \'integer\':
                    case \'double\':
                        return $var;
                    case \'boolean\':
                        return $var ? \'true\' : \'false\';
                    break;
                    case \'string\':
                        return "\'" . $var . "\'";
                    break;
                    case \'array\':
                        $object = json_encode($var);
                        
                        if(empty($var))
                            return \'{}\';
                        
                        $matches = array(
                                        \'~null:([^,]+,|[^\}\]]+)~\',
                                        \'~,?"([a-z0-9\$_]+)":([^,]+,|[^\}]+)~i\',
                                        \'~^\{~\', \'~\}$~\',
                                        );
                        $replaces = array("", "\t\t\t$1 : $2\n", "{\n", "\t\t\t}");

                        $object = preg_replace($matches, $replaces, $object);

                        return $object;
                    break;
                }
            '
            );

    $globalData = array(
            'scripturl' => $scripturl,
            'boardurl' => $boardurl,
            'images_url' => $settings['images_url'],
            'theme_url' => $settings['theme_url']
    );

    $simpleVars = array(
        'section' => isset($_GET['action']) ? $_GET['action'] : (isset($_GET['topic']) ? 'post' : '')
    );

    // procesar variables simples
        if(!empty($vars))
            foreach($vars as $k => $v)
                $simpleVars[$k] = $v;
        
    // procesar variables para global.data
        if(!empty($globalVars))
            foreach($globalVars as $k => $v)
                $globalData[$k] = $v;

    $js = "\n\t" . '<script type="text/javascript">' . "\n";

    foreach($simpleVars as $var => $val){
       if($var == '{ignore}')
           continue;
       
        $js .= (substr($var, 0, 1) != '[' ? "\tvar " . $var : "\t" . str_replace(array('[', ']'), '', $var)) . ' = ' . (is_null($val) ? 'null' : $prepareVal($val)) . ";\n";
    }

    // next... global.data!
    $js .= "\n\t" . 'global.data = {' . "\n";

    $global_data = ''; // check null values.
    foreach($globalData as $var => $val){
       if($var == '{ignore}')
           continue;
       
        $global_data[] =  "\t\t" . $var . ' : ' .(is_null($val) ? 'null' : $prepareVal($val));
    }
    foreach($global_data as $parsed)
        $js .= $parsed . (end($global_data) == $parsed ? "\n" : ",\n");

    $js .= "\t};";

    // ok, now start the functions when document is ready
    $rd = '';
    foreach($ready_data as $d)
        if(!empty($d))
            $rd .= $d . "\n";

    if(!empty($rd)){
        $js .= "\n\t$(document).ready(function(){\n\t\t";
        $js .= $rd;
        $js .= "\t});";
    }

    $js .= "\n\t</script>\n";

    return $js;
}

/** getUsersFromChat
 *
 * Obtenemos la cantidad de usuarios en la seccion chat cada n tiempo.
 *
 * @author j0n4th4ntub3
 * @param int $seconds tiempo para volver a consultar la cantidad de usuarios en el chat.
 * @return int|bool
 */
function getUsersFromChat($seconds = 60){
    global $context, $db_prefix, $ID_MEMBER;
	
	$enabled = true; // cambiar a true si se desea activar
	
	if( !$enabled )
		return false;

    $regexp = '^a:3:\{s:[0-9]+:"[^"]+";(s:2:"rz";s:1:"m";s:4:"chat";)[^\}]+}'; // ?action=rz&m=chat || ?variable=rz&m=chat
    // $regexp = '^a:2:\{s:[0-9]+:"[^"]+";(s:4:"chat";)[^\}]+}'; // ?action=chat

    if(empty($ID_MEMBER))
        return false;

    if($context['in_chat'])
        return false;

    $reloadtime = (time() - $seconds);

    if($_SESSION['TEMP_USERS_ONLINE_TIME']  < $reloadtime){

        $membersInChat = array();
        $request = db_query("SELECT ID_MEMBER
                             FROM {$db_prefix}log_online
                             WHERE ID_MEMBER > 0  AND ID_MEMBER != $ID_MEMBER
                             AND url REGEXP '$regexp'", __FILE__, __LINE__);
        while($row = mysql_fetch_assoc($request))
            $membersInChat[] = $row['ID_MEMBER'];
        mysql_free_result($request);

        $total = count($membersInChat);

        $_SESSION['TEMP_USERS_ONLINE_TIME'] = time();
        $_SESSION['TEMP_USERS_ONLINE'] = $total;

        return $total;
    }else if(isset($_SESSION['TEMP_USERS_ONLINE']))
        return $_SESSION['TEMP_USERS_ONLINE'];
    else
        return false;

}
// define mini tooltip function!
function nanotip($text, $classes, $style = array()){
    // construct style attribute
    $styleAttr = '';
    if(is_array($style))
        foreach($style as $k => $v)
            $styleAttr .= ($k . ':' . (is_numeric($v) ? $v . 'px' : $v ) . (end($style) == $v ? '' : '; '));
    else
        $styleAttr = $style;

    // contruct class attribute
    $classAttr = (!is_array($classes) ? empty($classes) ? '' : $classes : implode(' ', $classes));

    // return a Tooltip!
        return '<div class="nano-tooltips clearfix '.$classAttr.'"'.(!empty($styleAttr) ? ' style="' . $styleAttr . '"' : '') . '><span class="izq"></span><span class="text">'.$text.'</span><span class="der"></span></div>';
}
function template_button_strip(){}
function theme_linktree2(){}
function theme_linktree3(){}
function theme_newestlink(){}
function theme_linktree(){}

?>