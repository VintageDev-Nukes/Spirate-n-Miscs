<?php
// Spirate Script - Version 2.4
header("Content-Type: text/html;charset=utf-8");
function template_manual_above(){}
function template_manual_below(){}
function template_intro(){}

// Agregar imagen
function template_enviari(){
	global $context, $txt, $modSettings, $db_prefix, $modSettings;
 
        $filename = $_POST['filename'];

         if(!getimagesize($filename))
        {fatal_error("No existe una imagen en esa URL", false);}

	$filename = mysql_real_escape_string($_POST['filename']);
	$description = mysql_real_escape_string($_POST['description']);
	$title = mysql_real_escape_string($_POST['title']);
	$date = mysql_real_escape_string($_POST['date']);
	$user = mysql_real_escape_string($context['user']['name']);
	$ID_MEMBER = (int) $context['user']['id'];
	$points = $modSettings['gallery_shop_picadd'];
	$allowcomments = $_POST['allowcomments'];

	db_query("INSERT INTO {$db_prefix}gallery_pic
	(ID_CAT,filename,title,description,ID_MEMBER,date,allowcomments)
	VALUES ('1', '$filename', '$title', '$description', '$ID_MEMBER', '$date', '$allowcomments')", __FILE__, __LINE__);
	Header("Location: $scripturl?action=imagenes&usuario=$user");
		
	if(isset($modSettings['shopVersion'])){
		db_query("UPDATE {$db_prefix}members
		SET money = money + '$points'
		WHERE ID_MEMBER = '$ID_MEMBER'
		LIMIT 1", __FILE__, __LINE__);
	}
}

// Editar imagen
function template_editari(){
	global $context, $txt, $modSettings, $db_prefix;
	
	$filename = mysql_real_escape_string($_POST['filename']);
	$description = mysql_real_escape_string($_POST['description']);
	$title = mysql_real_escape_string($_POST['title']);
	$user = mysql_real_escape_string($context['user']['name']);
	$allowcomments = mysql_real_escape_string($_POST['allowcomments']);
	$id = (int) $_POST['id'];
	
	db_query("
		UPDATE {$db_prefix}gallery_pic
		SET filename='$filename', title='$title', description='$description' 
		WHERE ID_PICTURE = '$id'", __FILE__, __LINE__);

	Header("Location: $scripturl?action=imagenes&usuario=$user");
}

// Agregaste un post
function template_postagregado(){
	global $txt, $db_prefix, $scripturl;
	
	$id = (int) $_GET['idpost'];
	
	$request = db_query("
	SELECT ID_TOPIC, subject
	FROM {$db_prefix}messages
	WHERE ID_TOPIC = '$id'
	ORDER BY subject ASC
	LIMIT 1", __FILE__, __LINE__);
	$context['post1'] = array();
	while ($row = mysql_fetch_assoc($request))
		$context['post1'][] = array(
		'subject' => $row['subject'],
	);
	mysql_free_result($request);

echo'<style type="text/css">
        #main .globalcontent{
        min-height: 500px;
        }
     </style>
	<div id="errorBox">
		<div class="box_title">',$txt['acc_congrats'],'</div>
		<div class="box_cuerpo"><center>
			<br />
			'.$txt['acc_your_post'].' "<b>'; foreach ($context['post1'] AS $npost)echo''.$npost['subject'].'';
			echo'</b>" '.$txt['added_post'].'<br />
			<br />
			<input class="sp-button bluesky" type="submit" title="'.$txt['acc_go_home'].'" value="'.$txt['principal_page'].'" onclick="location.href=\''.$scripturl.'\'" />
			<input class="sp-button green" type="submit" title="'.$txt['view_post'].'" value="'.$txt['view_post'].'" onclick="location.href=\''.$scripturl.'?topic='.$id.'\'" />
			<br /></center>
		</div>
	</div>
';
}

// Edistaste un post
function template_posteditado(){
	global $txt, $db_prefix, $scripturl;

	$id = (int) $_GET['idpost'];
	
	$request = db_query("
	SELECT ID_TOPIC, subject
	FROM {$db_prefix}messages
	WHERE ID_TOPIC = '$id'
	ORDER BY subject ASC
	LIMIT 1", __FILE__, __LINE__);
    
	$context['post1'] = array();
	while ($row = mysql_fetch_assoc($request))
		$context['post1'][] = array(
		'subject' => $row['subject'],
		);
	mysql_free_result($request);

	echo'
	<div id="errorBox">
		<div class="box_title">',$txt['acc_congrats'],'</div>
		<div class="box_cuerpo"><center>
			<br />
			',$txt['acc_your_post'],' "<b>'; foreach ($context['post1'] AS $npost)echo''.$npost['subject'].'';
			echo'</b>" ',$txt['edited_post'],'<br />
			<br />
			<input class="sp-button bluesky no-shadow" type="submit" title="',$txt['acc_go_home'],'" value="',$txt['principal_page'],'" onclick="location.href=\'',$scripturl,'\'" /> 
			<input class="sp-button green no-shadow" type="submit" title="',$txt['view_post'],'" value="',$txt['view_post'],'" onclick="location.href=\'',$scripturl,'?topic='.$id.'\'" />
			<br /></center>
		</div>
	</div>
	';
}

function template_comentar(){
	global $context, $txt, $modSettings, $db_prefix;
	
	$ID_TOPIC = (int) $_POST['ID_TOPIC'];
	$ID_BOARD = (int) $_POST['ID_BOARD'];
	$ID_MEMBER = (int) $context['user']['id'];
	$comentarios = mysql_real_escape_string(utf8_decode($_POST['cuerpo_comment']));
	$fecha = time();
	
	db_query("INSERT INTO {$db_prefix}comentarios
	(id_post,id_cat,id_user,comentario,fecha)
	VALUES ('$ID_TOPIC', '$ID_BOARD', '$ID_MEMBER','$comentario','$fecha')", __FILE__, __LINE__);
	Header("Location: $scripturl?topic=$ID_TOPIC");
}

function template_eliminarc(){
	global $context, $txt, $modSettings, $db_prefix;
	
	$topic = (int) $_POST['topic'];
	$userid =  $context['user']['id'];
	$memberid = (int) $_POST['memberid'];
	Header("Location: $scripturl?topic=$topic");
	if($userid = $memberid){
		if(!empty($_POST['campos'])) {
			$aLista=array_keys($_POST['campos']);
			db_query("DELETE FROM {$db_prefix}comentarios WHERE id_coment IN (".implode(',',$aLista).")", __FILE__, __LINE__);
		}
	}

	//Fijemonos que sea mayor a 0
            $request = db_query("SELECT comments
                                FROM ({$db_prefix}topics)
                                WHERE ID_TOPIC = $topic", __FILE__, __LINE__);
            list($totalComments) = mysql_fetch_row($request);
            mysql_free_result($request);


            $cant_com = $totalComments;
    $aLista=array_keys($_POST['campos']);
	$count = count($_POST['campos']);

	//Si no es 0 le resta 1 comentario    
        if($cant_com != 0){


         db_query("UPDATE {$db_prefix}topics
                               SET comments = comments - $count
                          WHERE ID_TOPIC = $topic",__FILE__,__LINE__);   

		//Actualizamos cantidad total de comentarios		  
		updateStats('comment',false);
        }
}

function template_endenuncias(){
	global $context, $txt, $db_prefix;
	


	$ID_TOPIC2 = (int) $_POST['ID_TOPIC'];
	$ID_MEMBER2 = (int) $_POST['ID_MEMBER'];
	$comentario = htmlentities($_POST['comentario'], ENT_QUOTES, 'UTF-8');
	$razon = htmlentities($_POST['razon'], ENT_QUOTES, 'UTF-8');


	$errorr = db_query("
	SELECT *
	FROM {$db_prefix}denuncias
	WHERE id_user = '$ID_MEMBER2'
	AND	id_post = $ID_TOPIC2
	LIMIT 1", __FILE__, __LINE__);
	$yadio = mysql_num_rows($errorr) != 0 ? true : false;
	mysql_free_result($errorr);
	
	if($yadio){
		fatal_error($txt['already_denounced'], false);
	}
	
	db_query("INSERT INTO {$db_prefix}denuncias
	(id_post,id_user,razon,comentario)
	VALUES ('$ID_TOPIC2','$ID_MEMBER2','$razon','$comentario')", __FILE__, __LINE__);
	Header("Location: $scripturl?action=denunciar&page=enviada");
}

function template_eldenuncias(){
	global $context, $txt, $db_prefix;
	

	if(!empty($_POST['campos']) && $context['allow_admin']){
		$aLista=array_keys($_POST['campos']);
		db_query("DELETE FROM {$db_prefix}denuncias WHERE id_denuncia IN (".implode(',',$aLista).")", __FILE__, __LINE__);
	}
        else
        {
        fatal_error("Mmm, fuira pichichu fuira", false);
        }

	Header("Location: $scripturl?action=rz;m=denuncias");
}

function template_denuncias(){
	global $context, $settings, $db_prefix, $txt, $scripturl, $modSettings;



	function razon($valor){
        global $txt;
	$valor = str_replace("12", $txt['acc_val12'], $valor);
	$valor = str_replace("11", $txt['acc_val11'], $valor);
	$valor = str_replace("10", $txt['acc_val10'], $valor);
	$valor = str_replace("0", $txt['acc_val0'], $valor);
	$valor = str_replace("1", $txt['acc_val1'], $valor);
	$valor = str_replace("2", $txt['acc_val2'], $valor);
	$valor = str_replace("3", $txt['acc_val3'], $valor);
	$valor = str_replace("4", $txt['acc_val4'], $valor);
	$valor = str_replace("5", $txt['acc_val5'], $valor);
	$valor = str_replace("6", $txt['acc_val6'], $valor);
	$valor = str_replace("7", $txt['acc_val7'], $valor);
	$valor = str_replace("8", $txt['acc_val8'], $valor);
	$valor = str_replace("9", $txt['acc_val9'], $valor);
	return $valor;
	}

$request = mysql_query("
SELECT *
FROM {$db_prefix}denuncias");
$context['denunciasss'] = mysql_num_rows($request);	
	if ($context['allow_admin']) {
	$cantidad=1;
	echo'<div class="box_title">',$txt['acc_denuncia'],'</div>
	<div class="box_cuerpo">
		<table width="100%" cellpadding="3" cellspacing="0" class="windowbg" border="0">	
			<tr>
				<td>
					<form action="'.$scripturl.'?action=rz;m=eldenuncias" method="post" accept-charset="', $context['character_set'], '" name="eldenuncias" id="eldenuncias">
					<p align="right">
						<span class="size10">',$txt['acc_denuncia_sel'],'</span> <input class="button" type="submit" value="',$txt['acc_elim'],'">
					</p>';
	
if($context['denunciasss']){

echo'<table width="100%" cellspacing="0">
<tr>
    <td>&nbsp;</td>
    <td><b>Post Denunciado</b></td>
    <td><b>Por</b></td>
    <td><b>Razon/comentario</b></td>
</tr>
';

$request = mysql_query("
SELECT *
FROM ({$db_prefix}denuncias AS den, {$db_prefix}members AS m, {$db_prefix}messages AS me)
WHERE den.id_user = m.ID_MEMBER
AND me.ID_TOPIC = den.id_post
ORDER BY den.id_post ASC
");
$c=0;$ant =0;
while ($den1 = mysql_fetch_assoc($request)){
$c++;

$comentario = htmlspecialchars($den1['comentario']);
$comentario = censorText($den1['comentario']);

$border='style="border-top:2px dashed #061570;"';

if($ant==$den1['id_post']){
$border='style="border-top:1px dashed #CECECE;"';
$den1['subject'] = '';
}

echo'<tr>
     <td ',$border,'>#',$c,' <input type="checkbox" name="campos['.$den1['id_denuncia'].']"></td>
     <td ',$border,'><a href="?topic='.$den1['id_post'].'" title="'.$den1['subject'].'">'.$den1['subject'].'</a></td>
     <td ',$border,'><a href="',$scripturl,'?action=profile;u='.$den1['ID_MEMBER'].'" title="'.$den1['realName'].'">'.$den1['realName'].'</a></td>
     <td ',$border,'><font color="red">'.razon($den1['razon']).'</font><br>
     <font size="1" color="#5A5A5A">Comentario: '.str_replace("\n", "<br />",$den1['comentario']).'</font></td> 
     </tr>';

$ant = $den1['id_post'];
/*
echo'<b>',$txt['user_police'],'</b> <a href="',$scripturl,'?action=profile;u='.$den1['ID_MEMBER'].'" title="'.$den1['realName'].'">'.$den1['realName'].'</a><br />
<b>Post Denunciado:</b> <a href="?topic='.$den1['id_post'].'" title="'.$den1['id_post'].'">'.$den1['id_post'].'</a><br />
<b>Raz&oacute;n:</b> <font color="red">'.razon($den1['razon']).'</font><br />
<b>Comentario:</b> '.str_replace("\n", "<br />",$den1['comentario']).'<br />
<b>Seleccionar:</b> <input type="checkbox" name="campos['.$den1['id_denuncia'].']"><br /><br /><hr>';
*/
				}
	mysql_free_result($request);

echo'</table>';

}else echo'<p align="center">',$txt['no_denounced'],'</p>';
echo'	</form></td>
		</tr></table>';}
		else echo''.Header("Location: $scripturl").'';

	echo'</div>';
}

function template_chat(){
	global $chatid, $txt,$context;

echo'<style type="text/css">

#main .globalcontent{
    padding:0 !important;
}
</style>
<div class="new-post-content left clearfix">
	<div class="box-border-striped">
		<div class="stripes"></div>
			<div class="content">
				<div class="header">
					<h3>Chat de ',$context['forum_name'],'</h3>
					<hr />
				</div>
			
					<object width="600" height="400" id="obj_1313400741484"><param name="movie" value="http://'. $chatid .'.chatango.com/group"/><param name="AllowScriptAccess" VALUE="always"/><param name="AllowNetworking" VALUE="all"/><param name="AllowFullScreen" VALUE="true"/><param name="flashvars" value="cid=1313400741484&b=100&c=666666&d=666666&g=333333&j=333333&k=666666&l=CCCCCC&m=FFFFFF&p=12&s=1&v=0&w=0&aa=1"/><embed id="emb_1313400741484" src="http://'. $chatid .'.chatango.com/group" width="600" height="400" allowScriptAccess="always" allowNetworking="all" type="application/x-shockwave-flash" allowFullScreen="true" flashvars="cid=1313400741484&b=100&c=666666&d=666666&g=333333&j=333333&k=666666&l=CCCCCC&m=FFFFFF&p=12&s=1&v=0&w=0&aa=1"></embed></object>
			
			</div>
	</div>
</div>

<div class="r-add-post-options left clearfix">

<h3 class="title">Consejos del chat</h3>
        <div class="protcl-txt">
        <h3 class="title">Nick</h3>
        <ul>
        <li><i class="bad"></i> ',$txt['prohibited_nick'],'</li>
        <li><i class="good"></i> Debe ser descriptivo.</li>
        <li><i class="bad"></i> No debe ser EXAGERADO!!!</li>
        </ul>
        </div>
        <div class="protcl-txt">
        <h3 class="title">Comportamiento</h3>
        <ul>
        <li><i class="bad"></i> ',$txt['prohibited_respect_is_absent'],'</li>
        <li><i class="bad"></i> ',$txt['prohibited_insult'],'</li>
        </ul>
        </div>
		<div class="protcl-txt">
        <h3 class="title">Mensajes</h3>
        <ul>
        <li><i class="bad"></i> ',$txt['prohibited_spam'],'</li>
        <li><i class="bad"></i> ',$txt['prohibited_spread'],'</li>
        </ul>
        </div>
        <div class="hr"></div>
</div>';

echo'<!-- Small Pirate - Social Community Script -->';
}

function template_editarcom()
{
    global $context, $settings, $options, $txt, $scripturl, $modSettings, $boardurl,$sourcedir;
    global $db_prefix, $user_info, $query_this_board, $func;

$ID_MEMBER = $context['user']['id'];
$name = $context['user']['name'];

if(isset($_REQUEST['editarcom']))
{


		require_once($sourcedir . '/Subs-Post.php');

      $comentario = mysql_real_escape_string($_REQUEST['comentario']);
      $id_user = (int) $_REQUEST['id'];
      $fecha = time();
      $id_post = (int) $_REQUEST['id_topic'];
      $id_coment = (int) $_REQUEST['id_coment'];
      $razon = mysql_real_escape_string($_REQUEST['razon']); 
     
$request = db_query("SELECT * FROM {$db_prefix}comentarios WHERE id_coment = '". $id_coment. "'", __FILE__, __LINE__);
            $com = mysql_fetch_assoc($request);    

$request = db_query("SELECT subject FROM {$db_prefix}messages WHERE ID_TOPIC = '". id_post. "'", __FILE__, __LINE__);
            $post = mysql_fetch_assoc($request);    
            $subject = $post['subject']; 

$id_user = $com['id_user'];

if($razon==''){fatal_error('No has ingresado una razon.', false);}
if($comentario==''){fatal_error('No has ingresado un comentario.', false);}

      $request = db_query("UPDATE {$db_prefix}comentarios SET comentario = '". $comentario. "', id_post = '". $id_post. "', fecha = '". $fecha. "' WHERE id_coment = '". $id_coment. "'", __FILE__, __LINE__);

      $pm_recipients = array(
						'to' => array($id_user),
						'bcc' => array(),
					);

				

		$notify_body = '
'.$name.' ha editado tu comentario en un [url='.$scripturl.'?topic='.$id_post.'#cmt_'.$id_coment.']post[/url]

Razon: [color=red][b]'.$razon.'[/b][/color].
';

		$titulo= 'Comentario Editado';
		
		$pm_from = array(
					'id' => $ID_MEMBER,
					'username' => '',
					'name' => '',
				);
				
                if($ID_MEMBER!=$id_user){
		sendpm($pm_recipients,$titulo , $notify_body,false,$pm_from);
                logAction('Comentario Editado', array('topic' => $id_post, 'subject' => $subject, 'member' => $ID_MEMBER, 'causa' => $razon));
                                         }

         if($request)
            Header("Location: $scripturl?topic=$id_post#cmt_$id_coment");
      }else{

      if($context['user']['is_guest'])
      {
          fatal_error($txt['acc_canot_do'], false);
      }
      else{
            $id_coment = (int) $_REQUEST['id_coment'];
            $id_topic = (int) $_REQUEST['id_topic'];
            $id_coment = (int) $_REQUEST['id_coment'];
            $request = db_query("SELECT * FROM {$db_prefix}comentarios as c,{$db_prefix}members as m  WHERE c.id_coment = '". $id_coment. "' AND c.id_user = m.ID_MEMBER", __FILE__, __LINE__);
            $com = mysql_fetch_assoc($request);
            if(allowedTo('manage_bans'))
            {
                echo'<br>
                <div id="previacomentario"></div>
                <center><div id="jojo" class="box_title" style="width:776px;"><div class="box_txt box_780-34">',$txt['acc_edit_comm'],'</div>
                <div class="box_rss"><img  src="', $settings['default_theme_url'], '/images/blank.gif" style="width: 16px; height: 16px;
                " border="0"></div></div><div class="windowbg" border="0" style="width: 784px; padding: 4px; -webkit-border-bottom-left-radius:10px;
                -webkit-border-bottom-right-radius:10px;
                -moz-border-radius-bottomleft:10px;
                -moz-border-radius-bottomright:10px;">
                <form action="'.$scripturl.'?action=rz;m=editarcom" method="post" accept-charset="UTF-8" enctype="multipart/form-data"><center>
                Razon de Edicion: <input type="text" name="razon" style="width:350px;"><br>
                <textarea  id="cuerpo_comment" name="comentario" class="markItUpEditor" tabindex="1">'.$com['comentario'].'</textarea><br>
                 <input type="hidden" name="autor" value="', $com['realName'], '" />
                 <input type="hidden" name="id_topic" value="', $id_topic, '" />
                 <input type="hidden" name="id_coment" value="', $id_coment, '" />
                 <input type="submit" value="',$txt['acc_save_comm'],'" name="editarcom" class="login" />
                 <input type="button" value="',$txt['acc_preview'],'" onclick="previacom(this.form.cuerpo_comment.value,this.form.autor.value);return false" name="editarcom" class="login" />
                </form>
                <span class="size11"><script>
                    function cerrarprevia(){

                      $(\'#previacomentario\').fadeOut("slow");
                    }
                         </script></center>
                <label id="error"></label><br><div align="right" id="cargando_previa" style=" margin-right:20px; margin-bottom:20px;display:none;"><img src="',$boardurl,'/Themes/default/images/cargando-ajax.gif">&nbsp;',$txt['acc_loading'] ,'&nbsp;</div>
                </center></span></div></center>';
                }
            else{fatal_error($txt['acc_cannot_edit'], false);}
      }

   }
}

?>