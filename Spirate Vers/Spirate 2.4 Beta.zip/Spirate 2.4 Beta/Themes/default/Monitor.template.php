<?php

function template_main(){
	global $context, $settings, $txt, $modSettings, $scripturl, $tipo, $eliminados, $cantnot;

echo '<style type="text/css">
        #main .globalcontent{
            padding:0;
            background: #f7f6f5
        }
    </style>';
// ... #dd4814
echo '<div class="left clearfix" style=" background:#FFF; width:670px; border-right: 1px solid #CCC">
        <div class="wrap-uibtabs clearfix">
        <ul class="ui-btabs clearfix">
            <li class="on"><div class="clearfix"><a>Notificaciones</a></div></li>
            <li><div class="clearfix"><a>Fotos</a></div></li>
            <li><div class="clearfix"><a>Seguimientos</a> <span class="count">10</span></div></li>
            <li><div class="clearfix"><a>Posts</a></div></li>
        </ul>
        </div>
            <div class="feed-notifications">';

            if(empty($context['notifications']))
                echo '<div class="error margin-10">No tienes notificaciones por el momento.</div>';
                
                echo '<ul class="notif-list list-notifications" style="margin-bottom: 5px">';
                // seteamos los avatars
                $avatars = array();
                $iterator = 0;
                foreach($context['notifications'] as $date => $n){
                    $last = end($n);
                    echo '<li class="separate_date"><div class="context-n">' . (!in_array($date, array('today', 'yesterday')) ? strtr(date('M d', $last['time']), $txt['months_trans']) : $txt[$date]) . '</li>';

                    foreach($n as $notif){
                    if($notif['notifiers']){
                                $count = count($notif['notifiers']);
                            // dividimos los avatars por cada uno
                            $i = 0;
                            foreach($notif['notifiers'] as $member){
                            $i++;
                                switch($count){
                                    case 2: // 2 usuarios
                                        $avatars[$notif['id']][] = '<span class="split"><img src="'.$member['avatar'].'" width="48" height="48"></span>';
                                    break;
                                    case 3: // 3 usuarios
                                        $setClass = array(1 => 'three', 2 => 'top', 3 => 'bottom');
                                        $avatars[$notif['id']][] = '<span class="split '.$setClass[$i].'"><img src="'.$member['avatar'].'" width="48" height="48"></span>';
                                    break;
                                    case 4: // 4 usuarios
                                        $setClass = array(1 => 'top', 2 => 'top', 3 => 'bottom', 4 => 'bottom');
                                        $avatars[$notif['id']][] = '<span class="split four '.$setClass[$i].'"><img src="'.$member['avatar'].'" width="48" height="48"></span>';
                                    break;
                                }
                            }
                            }else // Solo fue un usuario el que realizo la accion, tomemos su avatar, :it's something:
                                $avatars[$notif['id']] = '<img src="'.$notif['first_sender']['avatar'].'" width="48" height="48">';

                            // un o unos avatars ?
                            $avatars[$notif['id']] = is_array($avatars[$notif['id']]) ? implode('', $avatars[$notif['id']]) : $avatars[$notif['id']];

                    //echo $date;
                    echo '<li class="clearfix', !$notif['is_read'] ? ' recent' : '' ,'">
                        <div class="context-n clearfix">
                        <div class="history notify clearfix">
                            <div class="thumbnails-stack avatar">
                                '.$avatars[$notif['id']].'
                            </div>
                            <div class="notif-history">
                                <span class="info">'.$notif['template']['extended'].'</span>
                                <span class="time"><i class="icon notifyIcon '.$notif['type'].'"></i> '.$notif['date'].'</span>
                            </div>
                        </div>
                        </div>
                    </li>';
                    
                    }
                }
                    /*
                     * <li>
                        <div class="context-n clearfix">
                        <div class="history clearfix">
                            <div class="thumbnails-stack">
                                <img src="http://dribbble.s3.amazonaws.com/users/55507/avatars/original/275111_1208391676_321586_n.jpg?1313878829" width="50" height="50">
                            </div>
                            <div class="notif-history">
                                <span class="info"><a class="author">Jonathan</a> Comento en tu post &nbsp;<a>Peor es nada no?</a></span>
                                <span class="time"><i class="icon notifyIcon comment"></i> Hace menos de 1 minuto</span>

                            </div>
                        </div>
                        </div>
                    </li>
                     */
                    echo '
                </ul>
            </div>
        </div>';

echo '<div class="left padding-20 clearfix">
        <h3 style="color:#555">Estad&iacute;sticas</h3>
      </div>';

}

function template_adminmonitor(){
	global $context, $txt, $scripturl,$setting_mon;
	
	echo'
	<div class="box_title">
		',$txt['admin_edit'],'
	</div>
	<div class="box_cuerpo">
		<form action="',$scripturl,'?action=adminmonitor" method="POST">
			<table width="60%">';
			foreach($context['adminmonitor'] as $m){
				if (!empty($setting_mon[@$m['vr']])){
					echo'
						<tr>
							<td>
								<b>',$txt['admin_'.$m['vr']],'</b>
							</td>'; 
							
							if($setting_mon[$m['vr']]!='textarea')
								echo'<td><input type="',$setting_mon[$m['vr']],'" name="',$m['vr'],'" value="',$m['vl'],'"></td>';
							else
								echo'<td><textarea name="',$m['vr'],'" style="width:100%;height:100px;">',$m['vl'],'</textarea></td>';
						echo'
						</tr>';
				}
			}
			echo'
			</table>
			<br />
			<input type="submit" class="button" value="Editar" name="edit" />
		</form>
	</div><!-- /box_cuerpo -->';
}

?>