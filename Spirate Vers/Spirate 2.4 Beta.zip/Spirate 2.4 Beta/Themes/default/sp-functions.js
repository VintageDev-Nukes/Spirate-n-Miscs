var clientPC = navigator.userAgent.toLowerCase();
var clientVer = parseInt(navigator.appVersion);
var is_ie = ((clientPC.indexOf("msie") != -1) && (clientPC.indexOf("opera") == -1));
var is_nav = ((clientPC.indexOf('mozilla')!=-1) && (clientPC.indexOf('spoofer')==-1) && (clientPC.indexOf('compatible') == -1) && (clientPC.indexOf('opera')==-1) && (clientPC.indexOf('webtv')==-1) && (clientPC.indexOf('hotjava')==-1));
var is_win = ((clientPC.indexOf("win")!=-1) || (clientPC.indexOf("16bit") != -1));
var is_mac = (clientPC.indexOf("mac")!=-1);
var is_moz = 0;

function el(id){
  if(document.getElementById)
    return document.getElementById(id);
  else if(window[id])
    return window[id];

  return null;
}
/******************/


function getPuntos(cant,post){

cant = cant;

var i = 0;
var aux = '';
for(i=11;i<cant;i++){

aux +=' - <a href="#" onclick="addPuntos('+post+','+i+');return false">'+i+'</a>';

//por si las dudas
if(i==99){
aux +=' - <a href="#" onclick="addPuntos('+post+','+i+');return false">'+i+'</a> - ... - ';
break;
}

if(i==(cant-1))
aux += ' - ';
}
$('#pointbreak').html(aux);

}


function vaciarmonitor()
{

$('#filout').slideUp("slow");
$('#cargando').slideDown("slow");
 
        var ajax = 'ok';
        var actionajax = 'vaciarmonitor';  

$.ajax({
      type: 'POST',
     url: url_sp + '/?action=nr',
      data: 'ajax='+ ajax +'&actionajax='+ actionajax,
      success: function(h){
               $('#filout').html(h);
               $('#filout').slideDown("slow", function(){
               $('#cargando').css('display', 'none');   
			   setTimeout("filmonitor(0)",3000);		   
       });
      },
      error: function(){
         // errores
      }
   });
	  
	  
}

function filmonitor(id)
{

$('#filout').slideUp("slow");
$('#cargando').slideDown("slow");
 
        var ajax = 'ok';
        var actionajax = 'filmonitor';  

$.ajax({
      type: 'POST',
     url: url_sp + '/?action=nr',
      data: 'ajax='+ ajax +'&actionajax='+ actionajax +'&id='+id,
      success: function(h){
               $('#filout').html(h);
               $('#filout').slideDown("slow", function(){
               $('#cargando').css('display', 'none');   
       });
      },
      error: function(){
         // errores
      }
   });
	  
	  
}

//Agregar a Mis Amigos
function add_friend(u)
{
           
    $("#friendadd").slideUp("slow");
    $("#gif_cargando").slideDown("slow");
	
 $.ajax({
		type: 'POST',
		url: '/?action=buddies;sa=add',
		data: 'u='+ u,
		success: function(h){
				        
			$("#friendadd").html(h);
			$("#gif_cargando").slideUp("slow");
		    $("#friendadd").slideDown("slow");			
                                      										
			setInterval("closeddiv('friendadd')",3000);	
		},

		
		});
	
}

function closeddiv(div){
    $("#"+div).slideUp("slow");

}

//Videos
function convertir_id(imagen,id,id_wall){
$(imagen).wrap('<div class="video_on_action" id="new_'+id_wall+'" style="display:none;"></div>');
//damos un efecto de loading...

//$(imagen).parent().children('.thumbnail_video').hide();
$(imagen).parent().children('.thumbnail_video').children('span').addClass('wait_thumb');
$(imagen).parent().show();

// contamos cuantos videos esta viendo el usuario.
var total_on_reproducion = $('.video_on_action').size();

        var ajax = 'ok';
        var actionajax = 'videotube';  

$.ajax({
      type: 'POST',
     url: url_sp + '/?action=nr',
      data: 'ajax='+ ajax +'&actionajax='+ actionajax +'&video=' + encodeURIComponent(id) + (total_on_reproducion > 1 ? '&num=1&autoplay=0' : '&autoplay=1'), // Si esta viendo un video y hace click en otro no ponemos autoplay 8)
success: function(html){
if(html.charAt(0) == 0){
alert(html.substring(3));
$(imagen).parent().children('.thumbnail_video').children('span').removeClass('wait_thumb');

			  }
else{
	
$(imagen).hide('fast',function(){
$(imagen).parent().children('loading_youtube_img');
$('#new_'+id_wall).append(html); });
$('#new_'+id_wall).show();
$("#text_vid_"+id_wall).css('display', 'none');
}
}
});
}

 
//previa del editor de comentarios by j0n4th4ntub3
function previacom(cuerpo_comment,autor)
{
   $("#previacomentario").slideUp(1);
   $('#cargando_previa').css('display', 'block');         

        var ajax = 'ok';
        var actionajax = 'previacom';  

   $.ajax({
      type: 'POST',
     url: url_sp + '/?action=nr',
      data: 'ajax='+ ajax +'&actionajax='+ actionajax +'&cuerpo_comment='+encodeURIComponent($('#cuerpo_comment').val()) +'&autor=' + autor,
      success: function(h){
               $('#previacomentario').html(h);
               $('#previacomentario').slideDown("slow", function(){
               $('#cargando_previa').css('display', 'none');   
       });
      },
      error: function(){
         // errores :P
      }
   });
}

function mostrar_sc(id)
{
 $("#ocultar_sc"+id).slideDown("slow");
 $("#link"+id).slideUp("slow");
}

function add_cperfil(avatar,comment,userid,tipo,idc)
{
      
        if(tipo==1){
	$("#coment_muro").slideUp("slow");
        $('#markItUp').attr('disabled', 'true');
        $("#coment_load").slideDown("slow");
                    }
        else{
        $("#box_sc"+idc).slideUp("slow");
        $('#muro_textarea').attr('disabled', 'true');
        $("#coment_load2"+idc).slideDown("slow");
        if(tipo==3)
        {
         $("#coment_load3"+idc).slideDown("slow");
        }
            }

        var ajax = 'ok';
        var actionajax = 'add_cperfil';   

 $.ajax({
		type: 'POST',
		url: url_sp + '/?action=nr',
		data: 'ajax='+ ajax +'&actionajax='+ actionajax +'&avatar='+ avatar  +'&comment='+ comment +'&userid=' + userid +'&tipo=' + tipo +'&idc=' + idc,
		success: function(h){
				        
					$("#coment_load").hide("slow");
                                        $("#coment_load2"+idc).hide("slow");
                                        $("#coment_load3"+idc).hide("slow");
                                        $("#nocoment").hide("slow");
                                          
                                        if(tipo==1)
					$('#coment_previa').html(h);  
 
                                        if(tipo==2)
                                        $('#subcoment_previa'+idc).html(h);

                                        if(tipo==3)
                                        {
                                         $("#subcoment"+idc).hide("slow");
                                         $('#subcoment_delete'+idc).html(h);
                                        }
                                        

										
				
		},

		
		});
	
}

/* Seleccionar y copiar input */
function selectycopy(field) {
    field.focus();
    field.select();
    window.status = 'Texto en el portapapel';
    var flashcopier = 'flashcopier';
    var divholder = document.createElement('div');
    divholder.id = flashcopier;
    document.body.appendChild(divholder);
    divholder.innerHTML = '';
    return false;
}

/* Actualizar comentarios */
function actualizar_comentarios(){
  $('#last_comments').fadeOut('slow');

        var ajax = 'ok';
        var actionajax = 'comentarios'; 

  $.ajax({
    type: 'POST',
    data: 'ajax='+ ajax +'&actionajax='+ actionajax,
   url: url_sp + '/?action=nr',
    success: function(h){
      $('#last_comments').html(h);
     $('#last_comments').fadeIn('slow');
	
    }
  });
}

/*Crear carpetas*/
function mensajes_crear_carpeta_form(visible){
	$('#crear_carpeta_link').css('display',(visible)?'none':'inline');
	$('#crear_carpeta_div').css('display',(visible)?'inline':'none');
}
/* Fin Crear carpetas*/

/* Citar comentarios */
function citar_comment(id){
  var user = el('autor_cmnt_' + id).getAttribute('user_comment');
  var cita = el('autor_cmnt_' + id).getAttribute('text_comment');
  var text = ($('#cuerpo_comment').val() != '') ? $('#cuerpo_comment').val() + '\n' : '';
	text += '[quote=' + user + ']' + cita + '[/quote]\n';
	$('#cuerpo_comment').val(text);
  $('#cuerpo_comment').focus();
}
/* FIN Citar comentarios */
function ir_a_categoria(){
  if($('#categoria').val()!='root')
    document.location.href='?id=' + $('#categoria').val() + '';
}

/**Comentarios de Imagenes**/
function add_imgcomment(comentario,imagen)
{

$("#act_gif").slideDown("slow");
$("#comment_cont").slideUp("slow");
$("#no_comentarios").slideUp("slow");
$('#postmodify').attr('disabled', 'true');

        var ajax = 'ok';
        var actionajax = 'add_imgcomment';

$.ajax({
		type: 'POST',
		url: url_sp + '/?action=nr',
		data: 'ajax='+ ajax +'&actionajax='+ actionajax +'&imagen='+ imagen +'&comentario='+encodeURIComponent(comentario),
		success: function(h){
				        				
			
					$("#act_gif").slideUp("slow");
					$('#new_comment').html(h);


                                       $('#new_comment').slideDown("slow", function(){
                        
			$("#incremento_c").html(parseInt($('#incremento_c').html()) + 1);

					});
					
					
				
		},
		error: function(){
			// error: $('#comment_cont').slideDown("slow");
		}
		
		});

}

function add_comment(ID_TOPIC,ID_BOARD,ID_MEMBER)
{
      
	$("#previacomentario").slideUp(1);
	$('#gif_cargando_add_comment').css('display', 'block');
        $('#cuerpo_comment').attr('disabled', 'true'); //Bloquemos el FORM
	$('#post').attr('disabled', 'true'); //deshabilitamos el boton "Enviar" para que no se envie dos veces por error

        
        var ajax = 'ok';
        var actionajax = 'add_comment';

	$.ajax({
		type: 'POST',
		url: url_sp + '/?action=nr',
		data: 'ajax='+ ajax +'&actionajax='+ actionajax +'&ID_TOPIC='+ ID_TOPIC +'&ID_BOARD='+ ID_BOARD + '&ID_MEMBER='+ ID_MEMBER +'&cuerpo_comment='+encodeURIComponent($('#cuerpo_comment').val()),
		success: function(h){
				        $('#gif_cargando_add_comment').css('display', 'none');				
					if($('#no_comentarios')) //Mensaje de que no hay comments??
						$('#no_comentarios').hide('slow'); //Entonces lo desaparecemos e insertamos el comment

					$('#cant_comments_post').slideDown("fast");
			                $('#cajacomment').fadeOut('fast');
                                        $('#commentselect').fadeOut('fast');			
					
					$('#previacomentario').html(h);


                                       $('#previacomentario').slideDown("slow", function(){
                        
			$('#cant_com_post').html(parseInt($('#cant_com_post').html()) + 1);

					});
					
					
				
		},
		error: function(){
			// error: $('#previacomentario').slideDown("slow");
		}
		
		});
}


/*Agregar a Favoritos*/

function add_Favoritos(id){

 $('#gif_cargando_fav').css('display', 'block');


 $.ajax({
    type: "GET",
   url: url_sp + '/index.php?action=favoritos;sa=add;ajax=1;topic=' + id ,
    success: function(msg){
			

			var original = $('#favs').html(); 
			$('#gif_cargando_fav').css('display', 'none');
		   	 

            $("#favs").html(msg); 
		
            $("#favs").slideDown({duration:1000});
	    setTimeout("favup();", 5000);
	  	
			if(msg.charAt(21)=='g') 
			$('#cant_favs_post').html(parseInt($('#cant_favs_post').html()) + 1);

			},
			  error: function(){
				 $('#span_opciones1').addClass('status_error');
				 $('#span_opciones1').css('text-align', 'center');
				 $('#span_opciones1').removeClass('size10');
				 $('#span_opciones1').html('Error al intentar procesar lo solicitado');
				 $("#span_opciones1").slideDown("slow");
			  }
		
		
		});
}

function favup(){$("#favs").slideUp({duration:1000});}

/*Agregar puntos a los posts*/

function addPuntos(id, puntos){
  $('#gif_cargando_fav').css('display', 'block');
  $("#contenedor").slideUp("slow");
  $.ajax({
    type: "GET",
   url: url_sp + '/index.php?action=enviar-puntos;do=sendmoney2;ajax=1;topic=' + id + ';amount=' + puntos,
    success: function(msg){
   $('#gif_cargando_fav').css('display', 'none');
 
   if(msg.charAt(21)=='g') 
$('#cant_pts_post').html(parseInt($('#cant_pts_post').html()) + parseInt(puntos));


             $("#favs").html(msg); 
		
            $("#favs").slideDown({duration:1000});
	    setTimeout("favup();", 5000);

   },
      error: function(){
         $('#span_opciones1').addClass('status_error');
         $('#span_opciones1').css('text-align', 'center');
         $('#span_opciones1').removeClass('size10');
         $('#span_opciones1').html('Error al intentar procesar lo solicitado');
         $("#span_opciones1").slideDown("slow");
      }


});
}

function addPuntosImg(puntos, imagen, user){

  $('#gif_cargando_fav').css('display', 'block');
  $("#contenedor").slideUp("slow");


        var ajax = 'ok';
        var actionajax = 'puntosimg';

$.ajax({
    type: 'POST',
   url: url_sp + '/?action=nr',
    data: 'ajax='+ ajax +'&actionajax='+ actionajax +'&puntos='+ puntos +'&imagen='+ imagen +'&user='+ user,
    success: function(msg){

   $('#gif_cargando_fav').css('display', 'none');
 
      if(msg.charAt(21)=='g') 
      $('#cant_pts').html(parseInt($('#cant_pts').html()) + parseInt(puntos));

            $("#contenedor").html(msg); 		
            $("#contenedor").slideDown({duration:1000});


   },
      error: function(){
         $('#span_opciones1').addClass('status_error');
         $('#span_opciones1').css('text-align', 'center');
         $('#span_opciones1').removeClass('size10');
         $('#span_opciones1').html('Error al intentar procesar lo solicitado');
         $("#span_opciones1").slideDown("slow");
      }


});

}

/* FIN - Editor */

var hexcase = 0; 
var b64pad  = "";
var chrsz   = 8; 
function hex_sha1(s){return binb2hex(core_sha1(str2binb(s),s.length * chrsz));}
function b64_sha1(s){return binb2b64(core_sha1(str2binb(s),s.length * chrsz));}
function str_sha1(s){return binb2str(core_sha1(str2binb(s),s.length * chrsz));}
function hex_hmac_sha1(key, data){ return binb2hex(core_hmac_sha1(key, data));}
function b64_hmac_sha1(key, data){ return binb2b64(core_hmac_sha1(key, data));}
function str_hmac_sha1(key, data){ return binb2str(core_hmac_sha1(key, data));}
function sha1_vm_test(){return hex_sha1("abc") == "a9993e364706816aba3e25717850c26c9cd0d89d";}
function core_sha1(x, len)
{	x[len >> 5] |= 0x80 << (24 - len % 32);
	x[((len + 64 >> 9) << 4) + 15] = len;
	var w = Array(80);
	var a =  1732584193;
	var b = -271733879;
	var c = -1732584194;
	var d =  271733878;
	var e = -1009589776;

	for (var i = 0; i < x.length; i += 16)
	{
		var olda = a;
		var oldb = b;
		var oldc = c;
		var oldd = d;
		var olde = e;

		for (var j = 0; j < 80; j++)
		{
			if (j < 16) w[j] = x[i + j];
			else w[j] = rol(w[j-3] ^ w[j-8] ^ w[j-14] ^ w[j-16], 1);
			var t = safe_add(safe_add(rol(a, 5), sha1_ft(j, b, c, d)), safe_add(safe_add(e, w[j]), sha1_kt(j)));
			e = d;
			d = c;
			c = rol(b, 30);
			b = a;
			a = t;
		}

		a = safe_add(a, olda);
		b = safe_add(b, oldb);
		c = safe_add(c, oldc);
		d = safe_add(d, oldd);
		e = safe_add(e, olde);
	}
	return Array(a, b, c, d, e);
}
if (typeof(document.getElementById) == "undefined")
	document.getElementById = function (id)
	{
		return document.all[id];
	}

else if (!window.XMLHttpRequest && window.ActiveXObject)
	window.XMLHttpRequest = function ()
	{
		return new ActiveXObject(navigator.userAgent.indexOf("MSIE 5") != -1 ? "Microsoft.XMLHTTP" : "MSXML2.XMLHTTP");
	};

if (typeof(document.forms) == "undefined")
	document.forms = document.getElementsByTagName("form");
function getXMLDocument(url, callback)
{
	if (!window.XMLHttpRequest)
		return false;

	var myDoc = new XMLHttpRequest();
	if (typeof(callback) != "undefined")
	{
		myDoc.onreadystatechange = function ()
		{
			if (myDoc.readyState != 4)
				return;

			if (myDoc.responseXML != null && myDoc.status == 200)
				callback(myDoc.responseXML);
		};
	}
	myDoc.open('GET', url, true);
	myDoc.send(null);

	return true;
}
function sendXMLDocument(url, content, callback)
{
	if (!window.XMLHttpRequest)
		return false;

	var sendDoc = new window.XMLHttpRequest();
	if (typeof(callback) != "undefined")
	{
		sendDoc.onreadystatechange = function ()
		{
			if (sendDoc.readyState != 4)
				return;

			if (sendDoc.responseXML != null && sendDoc.status == 200)
				callback(sendDoc.responseXML);
			else
				callback(false);
		};
	}
	sendDoc.open('POST', url, true);
	if (typeof(sendDoc.setRequestHeader) != "undefined")
		sendDoc.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');
	sendDoc.send(content);

	return true;
}

function textToEntities(text)
{
	var entities = "";
	for (var i = 0; i < text.length; i++)
	{
		if (text.charCodeAt(i) > 127)
			entities += "&#" + text.charCodeAt(i) + ";";
		else
			entities += text.charAt(i);
	}

	return entities;
}
function reqWin(desktopURL, alternateWidth, alternateHeight, noScrollbars)
{
	if ((alternateWidth && self.screen.availWidth * 0.8 < alternateWidth) || (alternateHeight && self.screen.availHeight * 0.8 < alternateHeight))
	{
		noScrollbars = false;
		alternateWidth = Math.min(alternateWidth, self.screen.availWidth * 0.8);
		alternateHeight = Math.min(alternateHeight, self.screen.availHeight * 0.8);
	}
	else
		noScrollbars = typeof(noScrollbars) != "undefined" && noScrollbars == true;

	window.open(desktopURL, 'requested_popup', 'toolbar=no,location=no,status=no,menubar=no,scrollbars=' + (noScrollbars ? 'no' : 'yes') + ',width=' + (alternateWidth ? alternateWidth : 480) + ',height=' + (alternateHeight ? alternateHeight : 220) + ',resizable=no');

	return false;
}

function storeCaret(text)
{
	if (typeof(text.createTextRange) != "undefined")
		text.caretPos = document.selection.createRange().duplicate();
}
function replaceText(text, textarea)
{
	if (typeof(textarea.caretPos) != "undefined" && textarea.createTextRange)
	{
		var caretPos = textarea.caretPos;

		caretPos.text = caretPos.text.charAt(caretPos.text.length - 1) == ' ' ? text + ' ' : text;
		caretPos.select();
	}
	else if (typeof(textarea.selectionStart) != "undefined")
	{
		var begin = textarea.value.substr(0, textarea.selectionStart);
		var end = textarea.value.substr(textarea.selectionEnd);
		var scrollPos = textarea.scrollTop;

		textarea.value = begin + text + end;

		if (textarea.setSelectionRange)
		{
			textarea.focus();
			textarea.setSelectionRange(begin.length + text.length, begin.length + text.length);
		}
		textarea.scrollTop = scrollPos;
	}
	else
	{
		textarea.value += text;
		textarea.focus(textarea.value.length - 1);
	}}
function surroundText(text1, text2, textarea)
{
	if (typeof(textarea.caretPos) != "undefined" && textarea.createTextRange)
	{
		var caretPos = textarea.caretPos, temp_length = caretPos.text.length;

		caretPos.text = caretPos.text.charAt(caretPos.text.length - 1) == ' ' ? text1 + caretPos.text + text2 + ' ' : text1 + caretPos.text + text2;

		if (temp_length == 0)
		{
			caretPos.moveStart("character", -text2.length);
			caretPos.moveEnd("character", -text2.length);
			caretPos.select();
		}
		else
			textarea.focus(caretPos);
	}
	else if (typeof(textarea.selectionStart) != "undefined")
	{
		var begin = textarea.value.substr(0, textarea.selectionStart);
		var selection = textarea.value.substr(textarea.selectionStart, textarea.selectionEnd - textarea.selectionStart);
		var end = textarea.value.substr(textarea.selectionEnd);
		var newCursorPos = textarea.selectionStart;
		var scrollPos = textarea.scrollTop;

		textarea.value = begin + text1 + selection + text2 + end;

		if (textarea.setSelectionRange)
		{
			if (selection.length == 0)
				textarea.setSelectionRange(newCursorPos + text1.length, newCursorPos + text1.length);
			else
				textarea.setSelectionRange(newCursorPos, newCursorPos + text1.length + selection.length + text2.length);
			textarea.focus();
		}
		textarea.scrollTop = scrollPos;
	}
	else
	{
		textarea.value += text1 + text2;
		textarea.focus(textarea.value.length - 1);
	}
}
function isEmptyText(theField)
{
	var theValue = theField.value;
	while (theValue.length > 0 && (theValue.charAt(0) == ' ' || theValue.charAt(0) == '\t'))
		theValue = theValue.substring(1, theValue.length);
	while (theValue.length > 0 && (theValue.charAt(theValue.length - 1) == ' ' || theValue.charAt(theValue.length - 1) == '\t'))
		theValue = theValue.substring(0, theValue.length - 1);

	if (theValue == '')
		return true;
	else
		return false;
}
function submitonce(theform)
{
	smf_formSubmitted = true;
}
function submitThisOnce(form)
{
	if (navigator.userAgent.indexOf('AppleWebKit') != -1)
		return !smf_formSubmitted;

	if (typeof(form.form) != "undefined")
		form = form.form;

	for (var i = 0; i < form.length; i++)
		if (typeof(form[i]) != "undefined" && form[i].tagName.toLowerCase() == "textarea")
			form[i].readOnly = true;

	return !smf_formSubmitted;
}

function setInnerHTML(element, toValue)
{
	if (typeof(element.innerHTML) != 'undefined')
		element.innerHTML = toValue;
	else
	{
		var range = document.createRange();
		range.selectNodeContents(element);
		range.deleteContents();
		element.appendChild(range.createContextualFragment(toValue));
	}
}
function setOuterHTML(element, toValue)
{
	if (typeof(element.outerHTML) != 'undefined')
		element.outerHTML = toValue;
	else
	{
		var range = document.createRange();
		range.setStartBefore(element);
		element.parentNode.replaceChild(range.createContextualFragment(toValue), element);
	}
}
function getInnerHTML(element)
{
	if (typeof(element.innerHTML) != 'undefined')
		return element.innerHTML;
	else
	{
		var returnStr = '';
		for (var i = 0; i < element.childNodes.length; i++)
			returnStr += getOuterHTML(element.childNodes[i]);

		return returnStr;
	}
}

function getOuterHTML(node)
{
	if (typeof(node.outerHTML) != 'undefined')
		return node.outerHTML;

	var str = '';

	switch (node.nodeType)
	{
	case 1:
		str += '<' + node.nodeName;

		for (var i = 0; i < node.attributes.length; i++)
		{
			if (node.attributes[i].nodeValue != null)
				str += ' ' + node.attributes[i].nodeName + '="' + node.attributes[i].nodeValue + '"';
		}

		if (node.childNodes.length == 0 && in_array(node.nodeName.toLowerCase(), ['hr', 'input', 'img', 'link', 'meta', 'br']))
			str += ' />';
		else
			str += '>' + getInnerHTML(node) + '</' + node.nodeName + '>';
		break;
	case 3:
		str += node.nodeValue;
		break;
	case 4:
		str += '<![CDATA' + '[' + node.nodeValue + ']' + ']>';
		break;
	case 5:
		str += '&' + node.nodeName + ';';
		break;
	case 8:
		str += '<!--' + node.nodeValue + '-->';
		break;
	}

	return str;
}
function in_array(variable, theArray)
{
	for (var i = 0; i < theArray.length; i++)
	{
		if (theArray[i] == variable)
			return true;
	}
	return false;
}
function selectRadioByName(radioGroup, name)
{
	if (typeof(radioGroup.length) == "undefined")
		return radioGroup.checked = true;

	for (var i = 0; i < radioGroup.length; i++)
	{
		if (radioGroup[i].value == name)
			return radioGroup[i].checked = true;
	}

	return false;
}
function invertAll(headerfield, checkform, mask)
{
	for (var i = 0; i < checkform.length; i++)
	{
		if (typeof(checkform[i].name) == "undefined" || (typeof(mask) != "undefined" && checkform[i].name.substr(0, mask.length) != mask))
			continue;

		if (!checkform[i].disabled)
			checkform[i].checked = headerfield.checked;
	}
}
var lastKeepAliveCheck = new Date().getTime();
function smf_sessionKeepAlive()
{
	var curTime = new Date().getTime();
	if (smf_scripturl && curTime - lastKeepAliveCheck > 900000)
	{
		var tempImage = new Image();
		tempImage.src = smf_scripturl + (smf_scripturl.indexOf("?") == -1 ? "?" : "&") + "action=keepalive;" + curTime;
		lastKeepAliveCheck = curTime;
	}

	window.setTimeout("smf_sessionKeepAlive();", 1200000);
}
window.setTimeout("smf_sessionKeepAlive();", 1200000);
function smf_setThemeOption(option, value, theme, cur_session_id)
{
	if (cur_session_id == null)
		cur_session_id = smf_session_id;

	var tempImage = new Image();
	tempImage.src = smf_scripturl + (smf_scripturl.indexOf("?") == -1 ? "?" : "&") + "action=jsoption;var=" + option + ";val=" + value + ";sesc=" + cur_session_id + (theme == null ? "" : "&id=" + theme) + ";" + (new Date().getTime());
}

function smf_avatarResize()
{
	var possibleAvatars = document.getElementsByTagName ? document.getElementsByTagName("img") : document.all.tags("img");

	for (var i = 0; i < possibleAvatars.length; i++)
	{
		if (possibleAvatars[i].className != "avatar")
			continue;

		var tempAvatar = new Image();
		tempAvatar.src = possibleAvatars[i].src;

		if (smf_avatarMaxWidth != 0 && tempAvatar.width > smf_avatarMaxWidth)
		{
			possibleAvatars[i].height = (smf_avatarMaxWidth * tempAvatar.height) / tempAvatar.width;
			possibleAvatars[i].width = smf_avatarMaxWidth;
		}
		else if (smf_avatarMaxHeight != 0 && tempAvatar.height > smf_avatarMaxHeight)
		{
			possibleAvatars[i].width = (smf_avatarMaxHeight * tempAvatar.width) / tempAvatar.height;
			possibleAvatars[i].height = smf_avatarMaxHeight;
		}
		else
		{
			possibleAvatars[i].width = tempAvatar.width;
			possibleAvatars[i].height = tempAvatar.height;
		}
	}

	if (typeof(window_oldAvatarOnload) != "undefined" && window_oldAvatarOnload)
	{
		window_oldAvatarOnload();
		window_oldAvatarOnload = null;
	}
}

function hashLoginPassword(doForm, cur_session_id)
{
	if (cur_session_id == null)
		cur_session_id = smf_session_id;

	if (typeof(hex_sha1) == "undefined")
		return;
	if (doForm.user.value.indexOf("@") != -1)
		return;
	if (typeof(window.opera) == "undefined")
		doForm.passwrd.autocomplete = "off";

	doForm.hash_passwrd.value = hex_sha1(hex_sha1(doForm.user.value.php_to8bit().php_strtolower() + doForm.passwrd.value.php_to8bit()) + cur_session_id);
	if (navigator.userAgent.indexOf("Firefox/") != -1)
		doForm.passwrd.value = "";
	else
		doForm.passwrd.value = doForm.passwrd.value.replace(/./g, "*");
}

function hashAdminPassword(doForm, username, cur_session_id)
{
	if (cur_session_id == null)
		cur_session_id = smf_session_id;

	if (typeof(hex_sha1) == "undefined")
		return;

	doForm.admin_hash_pass.value = hex_sha1(hex_sha1(username.toLowerCase() + doForm.admin_pass.value) + cur_session_id);
	doForm.admin_pass.value = doForm.admin_pass.value.replace(/./g, "*");
}
function sha1_ft(t, b, c, d)
{
	if (t < 20) return (b & c) | ((~b) & d);
	if (t < 40) return b ^ c ^ d;
	if (t < 60) return (b & c) | (b & d) | (c & d);
	return b ^ c ^ d;
}
function sha1_kt(t)
{
	return (t < 20) ?  1518500249 : (t < 40) ?  1859775393 :
	       (t < 60) ? -1894007588 : -899497514;
}
function core_hmac_sha1(key, data)
{
	var bkey = str2binb(key);
	if (bkey.length > 16) bkey = core_sha1(bkey, key.length * chrsz);

	var ipad = Array(16), opad = Array(16);
	for (var i = 0; i < 16; i++)
	{
		ipad[i] = bkey[i] ^ 0x36363636;
		opad[i] = bkey[i] ^ 0x5C5C5C5C;
	}

	var hash = core_sha1(ipad.concat(str2binb(data)), 512 + data.length * chrsz);
	return core_sha1(opad.concat(hash), 512 + 160);
}
function safe_add(x, y)
{
	var lsw = (x & 0xFFFF) + (y & 0xFFFF);
	var msw = (x >> 16) + (y >> 16) + (lsw >> 16);
	return (msw << 16) | (lsw & 0xFFFF);
}
function rol(num, cnt)
{
	return (num << cnt) | (num >>> (32 - cnt));
}
function str2binb(str)
{
	var bin = Array();
	var mask = (1 << chrsz) - 1;
	for (var i = 0; i < str.length * chrsz; i += chrsz)
		bin[i>>5] |= (str.charCodeAt(i / chrsz) & mask) << (24 - i%32);
	return bin;
}
function binb2str(bin)
{
	var str = "";
	var mask = (1 << chrsz) - 1;
	for (var i = 0; i < bin.length * 32; i += chrsz)
		str += String.fromCharCode((bin[i>>5] >>> (24 - i%32)) & mask);
	return str;
}
function binb2hex(binarray)
{
	var hex_tab = hexcase ? "0123456789ABCDEF" : "0123456789abcdef";
	var str = "";
	for (var i = 0; i < binarray.length * 4; i++)
	{
		str += hex_tab.charAt((binarray[i>>2] >> ((3 - i%4)*8+4)) & 0xF) +
		       hex_tab.charAt((binarray[i>>2] >> ((3 - i%4)*8  )) & 0xF);
	}
	return str;
}
function binb2b64(binarray)
{
	var tab = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/";
	var str = "";
	for (var i = 0; i < binarray.length * 4; i += 3)
	{
		var triplet = (((binarray[i   >> 2] >> 8 * (3 -  i   %4)) & 0xFF) << 16)
		            | (((binarray[i+1 >> 2] >> 8 * (3 - (i+1)%4)) & 0xFF) << 8 )
		            |  ((binarray[i+2 >> 2] >> 8 * (3 - (i+2)%4)) & 0xFF);
		for (var j = 0; j < 4; j++)
		{
			if (i * 8 + j * 6 > binarray.length * 32) str += b64pad;
			else str += tab.charAt((triplet >> 6*(3-j)) & 0x3F);
		}
	}
	return str;
}
String.prototype.php_strtr = function (sFrom, sTo) {
	return this.replace(new RegExp('[' + sFrom + ']', 'g'), function (sMatch) {
		return sTo.charAt(sFrom.indexOf(sMatch));
	});
}
String.prototype.php_strtolower = function () {
	return typeof(smf_iso_case_folding) != "undefined" && smf_iso_case_folding == true ? this.php_strtr(
		'ABCDEFGHIJKLMNOPQRSTUVWXYZ\x8a\x8c\x8e\x9f\xc0\xc1\xc2\xc3\xc4\xc5\xc6\xc7\xc8\xc9\xca\xcb\xcc\xcd\xce\xcf\xd0\xd1\xd2\xd3\xd4\xd5\xd6\xd7\xd8\xd9\xda\xdb\xdc\xdd\xde',
		'abcdefghijklmnopqrstuvwxyz\x9a\x9c\x9e\xff\xe0\xe1\xe2\xe3\xe4\xe5\xe6\xe7\xe8\xe9\xea\xeb\xec\xed\xee\xef\xf0\xf1\xf2\xf3\xf4\xf5\xf6\xf7\xf8\xf9\xfa\xfb\xfc\xfd\xfe'
	) : this.php_strtr('ABCDEFGHIJKLMNOPQRSTUVWXYZ', 'abcdefghijklmnopqrstuvwxyz');
}
String.prototype.php_to8bit = function () {
	if (smf_charset == 'UTF-8')
	{
		var n, sReturn = '';

		for (var i = 0, iTextLen = this.length; i < iTextLen; i++)
		{
			n = this.charCodeAt(i);
			if (n < 128)
				sReturn += String.fromCharCode(n)
			else if (n < 2048)
				sReturn += String.fromCharCode(192 | n >> 6) + String.fromCharCode(128 | n & 63);
			else if (n < 65536)
				sReturn += String.fromCharCode(224 | n >> 12) + String.fromCharCode(128 | n >> 6 & 63) + String.fromCharCode(128 | n & 63);
			else
				sReturn += String.fromCharCode(240 | n >> 18) + String.fromCharCode(128 | n >> 12 & 63) + String.fromCharCode(128 | n >> 6 & 63) + String.fromCharCode(128 | n & 63);
		}

		return sReturn;
	}
	else if (smf_charset == 'ISO-8859-2')
	{
		return this.php_strtr(
			'\u0104\u02d8\u0141\u013d\u026a\u0160\u015e\u0164\u0179\u017d\u017b\u0105\u02db\u0142\u013e\u015b\u02c7\u0161\u015f\u0165\u017a\u02dd\u017e\u017c\u0154\u0102\u0139\u0106\u010c\u0118\u011a\u010e\u0110\u0143\u0147\u0150\u0158\u016e\u0170\u0162\u0155\u0103\u013a\u0107\u010d\u0119\u011b\u010f\u0111\u0144\u0148\u0151\u0159\u016f\u0171\u0163\u02d9',
			'\xa1\xa2\xa3\xa5\xa6\xa9\xaa\xab\xac\xae\xaf\xb1\xb2\xb3\xb5\xb6\xb7\xb9\xba\xbb\xbc\xbd\xbe\xbf\xc0\xc3\xc5\xc6\xc8\xca\xcc\xcf\xd0\xd1\xd2\xd5\xd8\xd9\xdc\xde\xe0\xe3\xe5\xe6\xe8\xea\xec\xef\xf0\xf1\xf2\xf5\xf8\xf9\xfb\xfe\xff'
		);
	}
	else if (smf_charset == 'ISO-8859-9')
	{
		return this.php_strtr(
			'\u011e\u0130\u015e\u011f\u0131\u015f',
			'\xd0\xdd\xde\xf0\xfd\xfe'
		);
	}
	else if (smf_charset == 'tis-620')
	{
		return this.php_strtr(
			'\u0e01\u0e02\u0e03\u0e04\u0e05\u0e06\u0e07\u0e08\u0e09\u0e0a\u0e0b\u0e0c\u0e0d\u0e0e\u0e0f\u0e10\u0e11\u0e12\u0e13\u0e14\u0e15\u0e16\u0e17\u0e18\u0e19\u0e1a\u0e1b\u0e1c\u0e1d\u0e1e\u0e1f\u0e20\u0e21\u0e22\u0e23\u0e24\u0e25\u0e26\u0e27\u0e28\u0e29\u0e2a\u0e2b\u0e2c\u0e2d\u0e2e\u0e2f\u0e30\u0e31\u0e32\u0e33\u0e34\u0e35\u0e36\u0e37\u0e38\u0e39\u0e3a\u0e3f\u0e40\u0e41\u0e42\u0e43\u0e44\u0e45\u0e46\u0e47\u0e48\u0e49\u0e4a\u0e4b\u0e4c\u0e4d\u0e4e\u0e4f\u0e50\u0e51\u0e52\u0e53\u0e54\u0e55\u0e56\u0e57\u0e58\u0e59\u0e5a\u0e5b',
			'\xa1\xa2\xa3\xa4\xa5\xa6\xa7\xa8\xa9\xaa\xab\xac\xad\xae\xaf\xb0\xb1\xb2\xb3\xb4\xb5\xb6\xb7\xb8\xb9\xba\xbb\xbc\xbd\xbe\xbf\xc0\xc1\xc2\xc3\xc4\xc5\xc6\xc7\xc8\xc9\xca\xcb\xcc\xcd\xce\xcf\xd0\xd1\xd2\xd3\xd4\xd5\xd6\xd7\xd8\xd9\xda\xdf\xe0\xe1\xe2\xe3\xe4\xe5\xe6\xe7\xe8\xe9\xea\xeb\xec\xed\xee\xef\xf0\xf1\xf2\xf3\xf4\xf5\xf6\xf7\xf8\xf9\xfa\xfb'
		);
	}
	else if (smf_charset == 'windows-1251')
	{
		return this.php_strtr(
			'\u0402\u0403\u201a\u0453\u201e\u2026\u2020\u2021\u20ac\u2030\u0409\u2039\u040a\u040c\u040b\u040f\u0452\u2018\u2019\u201c\u201d\u2022\u2013\u2014\u2122\u0459\u203a\u045a\u045c\u045b\u045f\u040e\u045e\u0408\u0490\u0401\u0404\u0407\u0406\u0456\u0491\u0451\u2116\u0454\u0458\u0405\u0455\u0457\u0410\u0411\u0412\u0413\u0414\u0415\u0416\u0417\u0418\u0419\u041a\u041b\u041c\u041d\u041e\u041f\u0420\u0421\u0422\u0423\u0424\u0425\u0426\u0427\u0428\u0429\u042a\u042b\u042c\u042d\u042e\u042f\u0430\u0431\u0432\u0433\u0434\u0435\u0436\u0437\u0438\u0439\u043a\u043b\u043c\u043d\u043e\u043f\u0440\u0441\u0442\u0443\u0444\u0445\u0446\u0447\u0448\u0449\u044a\u044b\u044c\u044d\u044e\u044f',
			'\x80\x81\x82\x83\x84\x85\x86\x87\x88\x89\x8a\x8b\x8c\x8d\x8e\x8f\x90\x91\x92\x93\x94\x95\x96\x97\x99\x9a\x9b\x9c\x9d\x9e\x9f\xa1\xa2\xa3\xa5\xa8\xaa\xaf\xb2\xb3\xb4\xb8\xb9\xba\xbc\xbd\xbe\xbf\xc0\xc1\xc2\xc3\xc4\xc5\xc6\xc7\xc8\xc9\xca\xcb\xcc\xcd\xce\xcf\xd0\xd1\xd2\xd3\xd4\xd5\xd6\xd7\xd8\xd9\xda\xdb\xdc\xdd\xde\xdf\xe0\xe1\xe2\xe3\xe4\xe5\xe6\xe7\xe8\xe9\xea\xeb\xec\xed\xee\xef\xf0\xf1\xf2\xf3\xf4\xf5\xf6\xf7\xf8\xf9\xfa\xfb\xfc\xfd\xfe\xff'
		);
	}
	else if (smf_charset == 'windows-1253')
	{
		return this.php_strtr(
			'\u20ac\u201a\u0192\u201e\u2026\u2020\u2021\u2030\u2039\u2018\u2019\u201c\u201d\u2022\u2013\u2014\u2122\u203a\u0385\u0386\u2015\u0384\u0388\u0389\u038a\u038c\u038e\u038f\u0390\u0391\u0392\u0393\u0394\u0395\u0396\u0397\u0398\u0399\u039a\u039b\u039c\u039d\u039e\u039f\u03a0\u03a1\u03a3\u03a4\u03a5\u03a6\u03a7\u03a8\u03a9\u03aa\u03ab\u03ac\u03ad\u03ae\u03af\u03b0\u03b1\u03b2\u03b3\u03b4\u03b5\u03b6\u03b7\u03b8\u03b9\u03ba\u03bb\u03bc\u03bd\u03be\u03bf\u03c0\u03c1\u03c2\u03c3\u03c4\u03c5\u03c6\u03c7\u03c8\u03c9\u03ca\u03cb\u03cc\u03cd\u03ce',
			'\x80\x82\x83\x84\x85\x86\x87\x89\x8b\x91\x92\x93\x94\x95\x96\x97\x99\x9b\xa1\xa2\xaf\xb4\xb8\xb9\xba\xbc\xbe\xbf\xc0\xc1\xc2\xc3\xc4\xc5\xc6\xc7\xc8\xc9\xca\xcb\xcc\xcd\xce\xcf\xd0\xd1\xd3\xd4\xd5\xd6\xd7\xd8\xd9\xda\xdb\xdc\xdd\xde\xdf\xe0\xe1\xe2\xe3\xe4\xe5\xe6\xe7\xe8\xe9\xea\xeb\xec\xed\xee\xef\xf0\xf1\xf2\xf3\xf4\xf5\xf6\xf7\xf8\xf9\xfa\xfb\xfc\xfd\xfe'
		);
	}
	else if (smf_charset == 'windows-1255')
	{
		return this.php_strtr(
			'\u20ac\u201a\u0192\u201e\u2026\u2020\u2021\u02c6\u2030\u2039\u2018\u2019\u201c\u201d\u2022\u2013\u2014\u02dc\u2122\u203a\u20aa\u00d7\u00f7\u05b0\u05b1\u05b2\u05b3\u05b4\u05b5\u05b6\u05b7\u05b8\u05b9\u05bb\u05bc\u05bd\u05be\u05bf\u05c0\u05c1\u05c2\u05c3\u05f0\u05f1\u05f2\u05f3\u05f4\u05d0\u05d1\u05d2\u05d3\u05d4\u05d5\u05d6\u05d7\u05d8\u05d9\u05da\u05db\u05dc\u05dd\u05de\u05df\u05e0\u05e1\u05e2\u05e3\u05e4\u05e5\u05e6\u05e7\u05e8\u05e9\u05ea\u200e\u200f',
			'\x80\x82\x83\x84\x85\x86\x87\x88\x89\x8b\x91\x92\x93\x94\x95\x96\x97\x98\x99\x9b\xa4\xaa\xba\xc0\xc1\xc2\xc3\xc4\xc5\xc6\xc7\xc8\xc9\xcb\xcc\xcd\xce\xcf\xd0\xd1\xd2\xd3\xd4\xd5\xd6\xd7\xd8\xe0\xe1\xe2\xe3\xe4\xe5\xe6\xe7\xe8\xe9\xea\xeb\xec\xed\xee\xef\xf0\xf1\xf2\xf3\xf4\xf5\xf6\xf7\xf8\xf9\xfa\xfd\xfe'
		);
	}
	else if (smf_charset == 'windows-1256')
	{
		return this.php_strtr(
			'\u20ac\u067e\u201a\u0192\u201e\u2026\u2020\u2021\u02c6\u2030\u0679\u2039\u0152\u0686\u0698\u0688\u06af\u2018\u2019\u201c\u201d\u2022\u2013\u2014\u06a9\u2122\u0691\u203a\u0153\u200c\u200d\u06ba\u060c\u06be\u061b\u061f\u06c1\u0621\u0622\u0623\u0624\u0625\u0626\u0627\u0628\u0629\u062a\u062b\u062c\u062d\u062e\u062f\u0630\u0631\u0632\u0633\u0634\u0635\u0636\u0637\u0638\u0639\u063a\u0640\u0641\u0642\u0643\u0644\u0645\u0646\u0647\u0648\u0649\u064a\u064b\u064c\u064d\u064e\u064f\u0650\u0651\u0652\u200e\u200f\u06d2',
			'\x80\x81\x82\x83\x84\x85\x86\x87\x88\x89\x8a\x8b\x8c\x8d\x8e\x8f\x90\x91\x92\x93\x94\x95\x96\x97\x98\x99\x9a\x9b\x9c\x9d\x9e\x9f\xa1\xaa\xba\xbf\xc0\xc1\xc2\xc3\xc4\xc5\xc6\xc7\xc8\xc9\xca\xcb\xcc\xcd\xce\xcf\xd0\xd1\xd2\xd3\xd4\xd5\xd6\xd8\xd9\xda\xdb\xdc\xdd\xde\xdf\xe1\xe3\xe4\xe5\xe6\xec\xed\xf0\xf1\xf2\xf3\xf5\xf6\xf8\xfa\xfd\xfe\xff'
		);
	}else return this;}
function createXMLHttpRequest(){ var xmlhttp = null;
    try {xmlhttp = window.XMLHttpRequest ? new XMLHttpRequest() : new ActiveXObject("Microsoft.XMLHTTP");} catch (e) {
        alert("Tu explorador no soporta este sitema, Small Pirate te recomienda que uses Firefox (http://www.mozilla-europe.org/es/firefox/)");
    }
    return xmlhttp;}
var xhr = createXMLHttpRequest();

function handleResponse(){
	if(xhr.readyState == 4){
    var response = xhr.responseText.split('|');
    
        
        if(response[0] == 'done'){
            if(response[1]){
                document.getElementById("down-"+response[1]).src        = '';
                document.getElementById("down-"+response[1]).onclick    = '';
                document.getElementById("up-"+response[1]).src          = '';
                document.getElementById("up-"+response[1]).onclick      = '';
                if(response[2] <= 0){
                    var prefix = '<b style="color:#E2C62F;">';
                } else {
                    var prefix = '<b style="color:#E2C62F;">+';
                }
                if(!response[4]){document.getElementById("error-"+response[1]).innerHTML = 'Hubo un error, Intenta nuevamente.';}
               var karmanumber = prefix + response[2];
               document.getElementById("karma-"+response[1]).innerHTML = karmanumber+'</b>';
               
               var quedan = response[3];
               document.getElementById("quedan-"+response[1]).innerHTML = 'Te quedan '+quedan+' votos disponibles - ';
                
            } else {
                document.getElementById("error-"+response[1]).innerHTML = 'Hubo un error, Intenta nuevamente.';
            }
        }
        else if(response[0] == 'error')
        {
            var error = response[1];
           document.getElementById("error-"+response[2]).innerHTML = '<br style="margin:0px;"><span class="size10" style="color: red;">'+error+'</span>';
        } else {
        	document.getElementById("error-"+response[2]).innerHTML = '<br style="margin:0px;"><span class="size10" style="color: red;">Hubo un error, Intenta nuevamente.</span>';
        }
    }
    
}

/* Easing 1.3 */
jQuery.extend(jQuery.easing,{easeOutBounce:function(x,t,b,c,d){if((t/=d)<(1/2.75)){return c*(7.5625*t*t)+b;}else if(t<(2/2.75)){return c*(7.5625*(t-=(1.5/2.75))*t+.75)+b;}else if(t<(2.5/2.75)){return c*(7.5625*(t-=(2.25/2.75))*t+.9375)+b;}else{return c*(7.5625*(t-=(2.625/2.75))*t+.984375)+b;}}});

