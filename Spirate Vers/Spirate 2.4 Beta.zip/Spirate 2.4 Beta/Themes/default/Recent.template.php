<?php
/*****************************************
*              Spirate v2.4              *
* ---------------------------------------*
* Small Pirate - Social Community Script *
* ---------------------------------------*
*            www.spirate.net             *
******************************************/

function template_main(){
    global $context, $settings, $txt, $scripturl, $limit_posts, $db_prefix, $url;
    global $id, $pagarray, $modSettings, $tcomments, $tmembers, $tposts;
	
//Columna izquierda - Bloque Ultimos post
echo'<!-- .home-column-1 -->
<div class="home-column-1 clearfix">

	<div class="box">
            <div class="box_title">'.$txt['lasts_topics'].'</div>
            <div class="box_cuerpo">';
		echo posts();
	echo'</div></div>';
       
       if($context['paginacion'])
        echo '<strong>P&aacute;ginas:</strong> ' . $context['total_pages'].'<div class="inset-bar wrap-paginator clearfix">' .$context['paginacion'] . '</div>';

echo '</div><!-- .home-column-1 -->';


//Columna Central
echo'<!-- columna 2 -->
     <div class="home-column-2">
<div class="minimal-box" style="padding-top: 0;">
<div class="title" style="padding-top: 0"><h3 class="color-orange">'.$txt['statics'].'</h3></div>
    <div class="content">
         <div style="margin:5px 0 0 0;">
             <div class="clearfix">
                <div class="left">'.sprintf('<strong>%d</strong> usuario%s online', $context['only_users_online'], $context['only_users_online'] > 1 || $context['only_users_online'] == 0 ? 's' : '').'</div>
                <div class="right"><strong>'.$tmembers.'</strong>  miembros</div>
             </div>

             <div class="clearfix">
                <div class="left"><strong>'.$tposts.'</strong>  posts</div>
                <div class="right"><strong>'.$tcomments.'</strong>  comentarios</div>
            </div>
        </div>
    </div>
</div>


<div class="minimal-box" style="padding-top: 0;">
<div class="title"><h3>'. $txt['lasts_comments'] .'</h3></div>
    <div class="content">
		<ul id="last_comments" class="list smallfont">';
                if(empty($context['ult_comms']))
                    echo '<div class="error">No se encontraron comentarios.</div>';
                else
                    foreach ($context['ult_comms'] as $comments)
                                    echo '<li><span class="subinfo"><a href="'.$scripturl.'?action=profile;user='.$comments['realName'].'">'.$comments['realName'].'</a></span> <a href="'.$scriptur.'?topic='.$comments['ID_TOPIC'] .'#comentarios" title="',$comments['titulo'],'">'. _substr($comments['titulo'], 0, 35, 30).'</a></li>';
                        
echo '</ul>
	</div>
</div>

<div id="topPosts" class="minimal-box" style="padding-top: 0;">
	<div class="title clearfix">
		<h3 class="left">'.$txt['top_posts'].'</h3>
		<div class="UIdrop drop">
			<span id="nTopsTitulo" class="Semanal"><a class="color-black">Semanal</a></span>
			<ul id="nTopsMenu">
				<li id="Mensual" class="Mensual"><a onclick="nTopsTabs(\'Mensual\');">Mensual</a></li>
				<li id="Todos" class="Todos"><a onclick="nTopsTabs(\'Todos\');">Todos</a></li>				
			</ul>
		</div>
	</div>';
	
	
    echo'<div class="content">
		<ul id="boxSemanal" class="list tops">';

	$iterator = 1;
	if($context['top_posts_week'])
	foreach( $context['top_posts_week'] as $top )
	{
		echo'<li><div class="subinfo"><span class="number-list color-black size-15">' . $iterator . '</span> <a href="'.$scripturl.'?topic='.$top['id'].'">'.$top['titulo'].'</a></div> <span class="UIspan points">'.$top['puntos'].'</span></li>';
	
		$iterator++;
	}
	else
	echo'<div class="npa">Nada por aqu&iacute;.</div>'; 
	echo '
	</ul>
	
	<ul id="boxMensual" class="list tops hide">';

	$iterator = 1;
	if($context['top_posts_month'])
	foreach( $context['top_posts_month'] as $top )
	{
		echo'<li><div class="subinfo"><span class="number-list color-black size-15">' . $iterator . '</span> <a href="'.$scripturl.'?topic='.$top['id'].'">'.$top['titulo'].'</a></div> <span class="UIspan points">'.$top['puntos'].'</span></li>';
	
		$iterator++;
	}
	else
	echo'<div class="npa">Nada por aqu&iacute;.</div>';
	echo '
	</ul>
	
	<ul id="boxTodos" class="list tops hide">';

	$iterator = 1;
	if($context['top_posts_all'])
	foreach( $context['top_posts_all'] as $top )
	{
		echo'<li><div class="subinfo"><span class="number-list color-black size-15">' . $iterator . '</span> <a href="'.$scripturl.'?topic='.$top['id'].'">'.$top['titulo'].'</a></div> <span class="UIspan points">'.$top['puntos'].'</span></li>';
	
		$iterator++;
	}
	else
	echo'<div class="npa">Nada por aqu&iacute;.</div>';
	echo '
	</ul>
</div>
</div>

<div class="minimal-box">
<div class="title"><h3>'.$txt['advertising'].'</h3></div>
    <div class="content">
		',get_advertise(1),'
	</div>
</div>

</div><!-- .columna 2 -->';


        
//Columna Derecha			
echo'<div class="home-column-3">';


/* Tops Users */
echo'<div class="box">
	  <div class="box_title">Tops Users
	    <div class="UIdrop drop small-font right" style="margin-top:4px;">
			<span id="nTopsTituloU" class="Semana"><a class="color-black">Semana</a></span>
			<ul id="nTopsMenuU">
				<li id="Posts" class="Posts"><a onclick="nTopsTabsU(\'Posts\');">Posts</a></li>
				<li id="Puntos" class="Puntos"><a onclick="nTopsTabsU(\'Puntos\');">Puntos</a></li>				
			</ul>
		</div>
     </div>
	 <div class="box_cuerpo" style="min-height:214px">
	 <ul id="boxSemana" class="list tops">';
	 
	     /* posteadores de la semana */
        if(!empty($context['top_posters_week'])){
            echo '<ul class="list">';
            foreach ($context['top_posters_week'] as $poster)
		echo '<li class="clearfix"><a class="fleft" href="', $scripturl . '?action=profile;u=' . $poster['id'] ,'">'.$poster['name'].'</a><span class="UIspan blue rounded">', $poster['num_posts'], '</span></li>';
            echo '</ul>';
        }
        else
            echo '<div class="error">Ningun usuario en este top.</div>';
echo'</ul>
	 <ul id="boxPosts" class="list tops hide">';
	 /* usuarios con mas posts */
	 if(empty($context['top_starters']))
            echo '<div class="error">Ningun usuario en este top.</div>';
        else
            foreach ($context['top_starters'] as $poster)
			echo'<li class="clearfix"><a class="fleft" href="', $scripturl . '?action=profile;u=' . $poster['id'] ,'">'.$poster['name'].'</a><span class="UIspan blue rounded">', $poster['num_topics'], '</span></li>';
	 echo'</ul>
	 <ul id="boxPuntos" class="list tops hide">';
	 /* usuarios con mas puntos */	
	 if(empty($context['shop_richest']))
            echo '<div class="error">Ningun usuario en este top.</div>';
        else
            foreach ($context['shop_richest'] as $row)
		echo '<li class="clearfix"><a class="fleft" href="', $scripturl . '?action=profile&u=' . $row['ID_MEMBER'] ,'">'.$row['realName'].'</a><span class="UIspan points rounded">', comma_format($row['money']), '</span><div class="clear">&nbsp;</div></li>';

	 echo'</ul>
	 </div>
	</div>';
	

/* ultimos usuarios registrados */		
echo'
	<div class="box">
		<div class="box_title">'.$txt['newest_users'].'</div>
			<div class="box_cuerpo">
				<ul class="list new-users-recent">';
				
	if(empty($context['yeniuyeler']))
            echo '
			<div class="error">No se encontro usuarios.</div>';
			
	else
		foreach ($context['yeniuyeler'] as $poster)
			echo '
			<li class="clearfix">
				<div class="user-avatar">
					<a title="'.$poster['name'].'" class="avatar-thumb s-32 inline" href="'.$poster['href'].'"><img class="avatar" style="'.$poster['avatar']['coords'].'" src="'.$poster['avatar']['src'].'"></a>
				</div>
				<div class="user-text">
					<a title="'.$poster['name'].'" class="size-13 ovellipsis" href="'.$poster['href'].'">'.$poster['name'].'</a>
					<span class="time-story ovellipsis">' . hace($poster['time_stamp']) . '</span>
				</div>
			</li>';
		
		
		
	echo'</ul>
	
	</div></div>';
    
echo'<div class="box">
	<div class="box_title">Enlaces</div>
	<div class="box_cuerpo">';
	if(!empty($context['advertising_links'])){
	    foreach($context['advertising_links'] as $link)
		echo $link . '<hr class="divider margin-5" />';
		echo '<div class="align-c"><a class="small-font" href="'.$scripturl.'?action=enlazanos" title="Enl&aacute;zanos en tu Web">Enl&aacute;zanos en tu Web</a></div>';
	}
	else
		echo '<div class="align-c padding-5"><a class="small-font" href="'.$scripturl.'?action=enlazanos" title="Enl&aacute;zanos en tu Web">Enl&aacute;zanos en tu Web</a></div>';

	echo '</div></div>';

echo '</div><!-- /columna 3 -->';
}

function posts(){
    global $context, $settings, $options, $txt, $scripturl, $limit_posts, $db_prefix;
    global $pagarray, $id, $func;

foreach($context['sticky'] as $st){
	$titulo = censorText($st['title']);	
	// <i class="icon categorias '.str_url($st['category']).'"></i>
echo'<div class="list-post sticky clearfix"><div class="left"><img src="'.$settings['images_url'].'/post/icono_'.$st['id_category'].'.gif" alt="'.$st['category'].'" title="'.$st['category'].'" align="absmiddle" style="margin-bottom:-2px"> &nbsp; <a href="'.$scripturl.'?topic='.$st['id'].'" title="'.$titulo.'">'.$titulo.'</a></div><img src="'.$settings['images_url'].'/sticky.png" style="margin-bottom:-2px;" class="right"></div>
	';
}

echo '<div id="posts"', empty($context['sticky']) ? ' style="border-top:none"' : '' ,'>';

//Muestro los posts normales
if($context['normal_posts']){
	$i = 0;
        // DEBUG: corregir dise�o de los iconos de los posts
	foreach ($context['normal_posts'] as $np){
	$class = ($i%2) ? "" : " impar";
	$i++;
        $titulo = censorText($np['title']);
        echo'
        <div class="list-post clearfix'.$class.'">
        <div class="left">
        <!-- <i class="icon left categorias '.strtolower(preg_replace('~[^A-Za-z0-9-_]~', '', $np['category'])).'"></i> -->
        <a style="background:url('.$settings['images_url'].'/post/icono_'.$np['id_category'].'.gif) no-repeat; padding: 2px 1px 2px 25px" href="', $scripturl . '?topic=' . $np['id'] ,'" title="'.$titulo.'">'. $func['substr']($titulo, 0, 45) . '</a></div>';

        
        if($np['private'] == '1')
                echo'<div class="right"><i class="icon private-post"></i></div>';
        
        echo'</div>';
        
        }
}

else {
        if(empty($context['total_posts']))
            echo '<div class="error">Todav&iacute;a no hay posts. <a class="bold" href="'.$scripturl.'?action=post" title="Crear Post">Agrega el primero!</a></div>';
        else if($_REQUEST['page'] > $context['total_posts'])
            echo '<div class="notice">Eso es todo!, no se encontraron mas posts</div>';
}

echo '</div>';

}
?>