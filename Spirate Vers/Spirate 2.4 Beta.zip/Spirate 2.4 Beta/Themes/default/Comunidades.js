
/*********************************************************
* jQuery Comunidades Plugin                              *
* Copyright (c) 2012, Mr.Freack (esawarez@yahoo.com)     *
* Dual licensed under the MIT or GPL Version 2 licenses. *
* Date: 20/01/2012                                       *
*                                                        *
* @author Mr.Freack                                      *
* @version 1.2.6                                         *
**********************************************************/

$(document).ready(function(){
   $.Comunidades.on_ready();
   
});

global.cache['last_seguir'] = 'none';

;(function($) {
  $.Comunidades = {
     
     //presets:
     is_img: false,
     id_c: false,	
     borrador_setTimeout: false,
	   borrador_ult_guardado: false,
	   borrador_is_enabled: true,
	   follows: false,
     
     // on ready
     on_ready: function(){
        var sbaction = $('input[name=sub-action]').val();
        if(sbaction == 'crearcomunidad' || sbaction == 'editar-comunidad' || sbaction ==  'updatecomunidad' || sbaction ==  'nuevacomunidad'){
         $('.slimScroll').slimScroll({
            width: 'auto',
            height: '300px',
            size: '10px',
            position: 'right',
            color: '#333',
            alwaysVisible: false,
            distance: '5px',
            start: 'top'
         });
        }
   
        var li = $('li.push').remove();
                 $('ul#form-categorias li:eq(2)').before(li);
                 $('#form-categorias li:last-child').addClass('rounded-bottom');
        
        $.Comunidades.select_category('');
        $.Comunidades.tipsy();
        
	       $('.follow-buttons .sp-button').hover(function(){
				    var btn = $(this);
				    if(!btn.is('.wait')){
					     if(btn.is('.following')){
						      btn.hide().siblings('.unfollowing').show();
					     }
				    }
			   },
			   function() {
				    var btn = $(this);
				    if(btn.is('.unfollowing') && !btn.is('.wait')){
					     btn.hide().siblings('.following').show();
				    }
				    if(btn.is('.wait')){
					     btn.removeClass('wait');
				    }
			   });
			   
        
        
     },
     
     // show tipsy
     tipsy: function(){
        $('#sw,.sw').tipsy({gravity: 'sw'});
        $('#nw,.nw').tipsy({gravity: 'nw'});
        $('#ne,.ne').tipsy({gravity: 'ne'});
        $('#se,.se').tipsy({gravity: 'se'});
        
        $('#n,.n').tipsy({gravity: 'n'});
        $('#w,.w').tipsy({gravity: 'w'});
        $('#e,.e').tipsy({gravity: 'e'});
        $('#s,.s').tipsy({gravity: 's'});
     },
     
     // mostrar menu top
     ntopshow: function(th){
        if(th > 0){$('#topTemas-menu').show();}
        else{$('#topTemas-menu').hide();}
     },
     
     // Change Top Temas
     nTopsTabs: function(parent, tab, callerid) {
	      if($('#'+tab).css('display') == 'block')return;

	      $('#'+parent+' > div.tabsp-drop > span').html($('#'+callerid).html()+'<i class="iconos_ droparrow" style="float:right"></i>');
        $('#'+parent+'-menu > li.act').removeClass('act');
	      $('#'+parent+'-menu > li.'+tab).addClass('act');
	      $('#'+parent+'-menu').hide();
	      $('#'+parent+' > div.list:visible').hide();
	      $('#'+tab).show();
     },
     
     // Change Top Temas
     nTopsTabsTop: function(parent, tab, callerid) {
     
	      if($('#'+tab).css('display') == 'block')return;
	      $('#'+parent+' > div > div.UIdrop > span a').html($('#'+callerid.id).html());
	      $('#'+parent+' > div ul.list:visible').hide();
	      $('#'+tab).show();
     },
     
     // Ir a categoria
     categoria: function(value){
        if(boardid != value){
				document.location.href=global.data.scripturl+'?action=comunidades;categoria='+value;
        }
     },
     
     // cambiar el menu
     menu:function(parent,tab, cl) {
	      if($('#'+tab).css('display') == 'block') return;
	      
	      $('.selected').removeClass('selected');
	      $('#'+cl).addClass('selected');
	      
	      $('.'+parent+' div.content:visible').hide();
	      $('#'+tab).show();
     },
     
     // error de portada
     portada_error:function(txtc){
        $('#img-portada').html('<span style="color:red;font-weight:bold;">'+txtc+'</span>');  
     },
     
     // seleccion de categoria
     select_category:function(s){
        
        $('ul#form-'+s+'categorias li a').click(function(){
            $('ul#form-'+s+'categorias li').removeClass('selected');
            $(this).parent().addClass('selected');

            var val = $(this).attr('val');
            $('input[name='+s+'categoria]').val(val);
        }); 
     },
     //verificar imagen
     verify_img: function(n){
     
     var Img = /^http:\/\/.+\.(gif|png|jpg|jpeg)$/i;
         urlImg = $('input[name='+n+']');
         imgnew = new Image();
         imgnew.src = urlImg.val();
         $('#previa_portada').html('<img src="'+urlImg.val()+'" id="previa_portada2">');
         imgsrc = $('#previa_portada2');
         imgsrc.removeAttr('width').removeAttr('height');
           
           if(imgnew.src.match(Img) && imgsrc.height() != 0 && imgsrc.width() != 0){
              urlImg.removeClass('focus_input_error').addClass('focus_input_ok'); /*$('#error_'+n).hide().html('');*/
           }
           else{
              $('.error_c').hide();
              urlImg.removeClass('focus_input_ok').addClass('focus_input_error'); 
              /*$('#error_'+n).show().html('<div class="box_error_c" style="top:244px;"><div class="box_alert_body">'+$('#error_'+n).attr('error')+'</div></div><div class="arrow_down_border"><div class="arrow_down"></div></div>');*/
           }
     },
     
     // contamos las letras
     cuenta_c: function(n){
       var input = $('*[name=descripcion]').val().length;
     	 var maxlength = $('*[name=descripcion]').attr('maxlength');
     	 var maxlength2 = maxlength > 11 ? (maxlength-10):maxlength;
       var count = maxlength - input;
       
        if(input < 20){
           $('.error_c').hide();
           $('#contador').hide();
           $('*[name='+n+']').removeClass('focus_input_ok, focus_input_alert').addClass('focus_input_error'); 
           /*$('#error_'+n).show().html('<div class="box_error_c" style="top:377px;"><div class="box_alert_body">'+$('#error_'+n).attr('error')+'</div></div><div class="arrow_down_border"><div class="arrow_down"></div></div>');*/
        }
        else if(input > maxlength2){
           $('.error_c').hide();
           $('*[name='+n+']').removeClass('focus_input_ok, focus_input_error').addClass('focus_input_alert'); 
           $('#contador').show();
           $('#html_ct').html(count+' restantes');
        }
        else{
           $('#contador').hide();
           $('*[name='+n+']').removeClass('focus_input_error, focus_input_alert').addClass('focus_input_ok'); 
           $('#error_'+n).hide().html(''); 
        }
     },
     
     // change subcategoria
     changeCategorias: function(input, cat){
        
        var categoria = input.id;
        var deposit = $('#subcategorias');
        
        if(categoria != 0 ){
        
        if($.Comunidades.id_c != categoria){
        
        deposit.html('<center>Cargando... <img src="'+ global.comunidad.images_comunidad+'loader.gif"></center>');
        
        setTimeout(function(){
        
           $.ajax({
              type : 'POST',
              url  : global.data.scripturl + "?action=comunidades;sa=subcategorias",
              data : 'id='+categoria+'&cat='+cat,
              success: function(h){
                 $(deposit).html(h);	  
                 $(deposit).attr('disabled','');
              }
        });
        },1000);
        
        $.Comunidades.id_c = categoria;
        }
        }
        else{
        deposit.html('');
        }
     },
     
     // el logo fallo :o
     error_logo: function(o){
		   o.src = global.data.images_url + '/avatar.gif';
	   },
     
     //mostramos errores
     showError: function(obj, str) {
		    if(obj.tagName.toLowerCase() == 'textarea'){
				   obj = $(obj).parent().parent().parent();
			  }
			  $(obj).parent('div').find('span').addClass('error').html(str).show();
			  $.scrollTo($(obj).parent(), 500);
     },
     
     //ocultamos errores
     hideError: function(obj) {
			  if (obj.tagName.toLowerCase() == 'textarea') {
				   obj = $(obj).parent().parent().parent();
			  }
			  $(obj).parent().find('span').removeClass('error').html('').hide();
     },
			
     // vista previa temas
     previa_tema: function(ly){
     
     		var error = false;
     		var cuerpo = $('textarea[name=cuerpo]').val();
     		var titulo = $('input[name=titulo]').val();
     		var mx_lnght = $('input[name=maxlenght]').val();
					
				$('.requerido, .required').each(function(){
					if (!$.trim($(this).val())) {
						$.Comunidades.showError(this, 'Este campo es obligatorio');
						$(this).parent('li').addClass('error');
						error = true;
						return false;
					}
				});
				if(error){
					return false;
				}
				
				if (cuerpo.length > mx_lnght) {
					$.Comunidades.showError($('textarea[name=cuerpo]').get(0), 'El tema es demasiado largo. No debe exceder los '+mx_lnght+' caracteres.');
					return false;
				}

				if (mx_lnght > 101 &&cuerpo.length < 100) {
					$.Comunidades.showError($('textarea[name=cuerpo]').get(0), 'El tema es demasiado corto. No debe ser menor a los 100 caracteres.');
					return false;
				}
				
				sp_dialog.load();
        
        $.ajax({
           type : "POST",
           url  : global.data.scripturl + "?action=comunidades;sa=previaTema",
           data : 'cuerpo='+ encodeURIComponent(cuerpo),
           success : function(data){
              data = data.substring(3);
              sp_dialog.endload();
              sp_dialog.options = {
                 title : $(ly).attr('tit')+'"'+titulo+'"',
                 body : data,
                 beforeShow : function(){
                    sp_dialog.center();
                 }
              }
              sp_dialog.show('load');
              sp_dialog.buttons([{text: $(ly).attr('ops'),"class": 'sp-button green right ui-button ui-widget ui-state-default ui-corner-all ui-button-text-only',
                 click: function() {$('#creartema').submit();}
              }]);
            },
           error : function(){
               dialogbox.close();
               dialogbox.alert($txt['error_while_processing'], $txt['error']);
           }
       }); 
    },
			
     // suspender user
     suspender_show: function(id, cmd, tipo, th){
        
       sp_dialog.close();
       
       $.ajax({
           type : "POST",
           url  : global.data.scripturl + '?action=comunidades;sa=suspender_causa',
           data : 'id='+id,
           dataType: 'json',
           success : function(data){
              switch(data['status']){
					       case 0: //ERROR
					          sp_dialog.alert(data['title'],data['data']);
						     break;
					       case 1: //SUCESS
					          $.Comunidades.dialog(data['title'], data['data']);
                    sp_dialog.buttons([{text: 'Aceptar',"class": 'sp-button green right ui-button ui-widget ui-state-default ui-corner-all ui-button-text-only',
                       click: function() {$.Comunidades.suspender(id, cmd, tipo, th);}
                    }]);
						     break;
				      }
				   },
           error : function(){
               alert('error');
           }
       });
     },
     
     suspender: function(id, cmd, tipo, th){
     
       sp_dialog.close();
       
       var razon = $('input[name=suspension_'+id+']').val();
       
       $.ajax({
           type : "POST",
           url  : global.data.scripturl + '?action=comunidades;sa=suspender',
           data : 'id='+id+'&tipo='+ tipo+'&cmd='+ cmd+'&adm='+id_admin+'&causa='+razon,
           dataType: 'json',
           success : function(data){
              switch(data['status']){
					       case 0: //ERROR
					          $.Comunidades.dialog_alert(data['data']);
						     break;
					       case 1: //SUCESS
					          /*sp_dialog.alert(data['title'],data['data']);*/
                    $('.suspender').html(data['titulo']).attr({'title':data['titulo'], 'onclick':data['id']});
                    $('.suspender_'+id).removeClass('baned').addClass('s-ok').attr({'title':data['titulo'], 'onclick':data['id']});
                    if(tipo == 1){
                       $('.suspender_'+id).removeClass('baned').addClass('s-ok')
                    }else{
                       $('.suspender_'+id).removeClass('s-ok').addClass('baned')
                    }
						     break;
				      }
            },
           error : function(){
               alert('error');
           }
       });
    },
     
     // dialog
     dialog: function(title, data){
        sp_dialog.endload();
        sp_dialog.options = {
           title : title,
           body : data,
           beforeShow : function(){
              sp_dialog.center();
           }
        }
        sp_dialog.show('load');
     },
     
     dialog_error: function(){
           
		    sp_dialog.close();
		    $.Comunidades.dialog($txt['doh'],'<div><p>Ocurri&oacute; un error al procesar lo solicitado</p></div>');
		    sp_dialog.center();
        setTimeout(function(){
           $('.load-dialog').fadeOut().removeClass('mask-load');
        },500);
        sp_dialog.buttons([{text: $txt['buttons']['retry'],"class": 'sp-button blue right ui-button ui-widget ui-state-default ui-corner-all ui-button-text-only',
           click: function() {$.Comunidades.save_borrador();}
        }]);
     },
     
     dialog_alert: function(txt){
		    sp_dialog.close();
		    $.Comunidades.dialog($txt['doh'],empty(txt)?'<div><p>Ocurri&oacute; un error al procesar lo solicitado</p></div>':txt);
		    sp_dialog.center();
        setTimeout(function(){
           $('.load-dialog').fadeOut().removeClass('mask-load');
        },500);
        sp_dialog.buttons([{text: $txt['buttons']['accept'],"class": 'sp-button right ui-button ui-widget ui-state-default ui-corner-all ui-button-text-only',
           click: function() {sp_dialog.close();}
        }]);
     },
    
    // cancelar solicitud
    cancel_solicitud: function(box, id, rg){
       
       $.Comunidades.dialog($(box).attr('titulo_b'), $(box).attr('titulo_t'));

       sp_dialog.buttons([{text: 'Aceptar',"class": 'sp-button bluesky right ui-button ui-widget ui-state-default ui-corner-all ui-button-text-only',
          click: function() {$.Comunidades.cancelar_solicitud(box,id, rg);}
       }]);
       setTimeout(function(){
          $('.load-dialog').fadeOut().removeClass('mask-load');
       },500);
    },
        // unirse a la comunidad
    cancelar_solicitud: function(box,id, rg){
       sp_dialog.close();
       
       $.ajax({
           type : "POST",
           url  : global.data.scripturl + '?action=comunidades;sa=cancelar_solicitud',
           data : 'id='+id+'&rg='+ rg+'&adm='+id_admin,
           dataType: 'json',
           success : function(data){
              switch(data['status']){
					       case 0: //ERROR
					          sp_dialog.alert(data['title'],data['data']);
					          sp_dialog.center();
                    $(box).show();
                    $('.sp-button.add').hide();
					          if(data['set'] == true){
			                 $.Comunidades.setTime('comunidad;idco='+id,3000);
			              }
						     break;
					       case 1: //SUCESS
                    $(box).hide();
                    $('.sp-button.add').show();
					          if(data['tipo'] == 2){
					             sp_dialog.alert(data['title'],data['data']);
					             sp_dialog.center();
					          }
					          if(data['set'] == true){
			                 $.Comunidades.setTime('comunidad;idco='+id,3000);
			              }
						     break;
				      }
            },
           error : function(){
                    $(box).show();
                    $('.sp-button.add').hide();
           }
       });
				
    },
    
    // unirse a la comunidad
    unirse: function(box, id, rg){
       var MembersCount = $('.members-count > span');
		   var actualMembers = $('.members-count > span').data('val');
		   var updatedMembers = parseInt(actualMembers)+1;
		     
       $.ajax({
           type : "POST",
           url  : global.data.scripturl + '?action=comunidades;sa=unirse',
           data : 'id='+id+'&rg='+ rg+'&adm='+id_admin,
           dataType: 'json',
           success : function(data){
              switch(data['status']){
					       case 0: //ERROR
					          sp_dialog.alert(data['title'],data['data']);
					          sp_dialog.center();
                    $(box).show();
                    $('.sp-button.aband').hide();
					          if(data['set'] == true){
							  if(empty(global.comunidad.id_tema)){
			                     $.Comunidades.setTime('comunidades;sa=tema;idtema='+global.comunidad.id_tema,3000);
							  }
							  else{
			                     $.Comunidades.setTime('comunidad;idco='+id,3000);
						      }
			              }
						     break;
					       case 1: //SUCESS
                    $(box).hide();
                    $('.sp-button.aband').show();
					          if(data['tipo'] == 2){
					             sp_dialog.alert(data['title'],data['data']);
					             sp_dialog.center();
					          }
					          if(data['set'] == true){
							  if(!empty(global.comunidad.id_tema)){
			                     $.Comunidades.setTime('tema;idtema='+global.comunidad.id_tema,3000);
							  }
							  else{
			                     $.Comunidades.setTime('comunidad;idco='+id,3000);
						      }
			              }
			              MembersCount.hide().html($.Comunidades.number_format(updatedMembers)).attr('data-val',updatedMembers).show();
						     break;
				      }
            },
           error : function(){
                    $(box).show();
                    $('.sp-button.aband').hide();
           }
       });
				
    },
    
    
    abandonar: function(box, id, rg){
       var MembersCount = $('.members-count > span');
		   var actualMembers = $('.members-count > span').data('val');
		   var updatedMembers = parseInt(actualMembers)-1;
       
       $.ajax({
           type : "POST",
           url  : global.data.scripturl + '?action=comunidades;sa=abandonar',
           data : 'id='+id+'&rg='+ rg+'&adm='+id_admin,
           dataType: 'json',
           success : function(data){
              switch(data['status']){
					       case 0: //ERROR
					          sp_dialog.alert(data['title'],data['data']);
					          sp_dialog.center();
                    $(box).show();
                    $('.sp-button.add').hide();
					          if(data['set'] == true){
			                 $.Comunidades.setTime('comunidad;idco='+id,3000);
			              }
						     break;
					       case 1: //SUCESS
                    $(box).hide();
                    $('.sp-button.add').show();
					          if(data['tipo'] == 2){
					             sp_dialog.alert(data['title'],data['data']);
					             sp_dialog.center();
					          }
					          if(data['set'] == true){
			                 $.Comunidades.setTime('comunidad;idco='+id,3000);
			              }
			              MembersCount.hide().html($.Comunidades.number_format(updatedMembers)).attr('data-val',updatedMembers).show();
						     break;
				      }
            },
           error : function(){
                    $(box).show();
                    $('.sp-button.add').hide();
           }
       });
       
    },
    
    setTime: function(data,time){
       setTimeout(function(){
				  document.location.href = global.data.scripturl+'?action=comunidades;sa='+data;
			 },time);
    },
    
    // guardamos tema en borradores
    save_borrador: function(){
    
         var params = 'titulo=' + encodeURIComponent($('input[name="titulo"]').val()) + '&cuerpo=' + encodeURIComponent($('textarea[name="cuerpo"]').val()) + '&comunidad=' + encodeURIComponent($('input[name="comid"]').val());
	           params += $('input[name="follow"]').is(':checked') ? '&follow=1' : '';
	           params += $('input[name="cerrado"]').is(':checked') ? '&sin_comentarios=1' : '';
	           params += $('input[name="sticky"]').is(':checked') ? '&sticky=1' : '';
	           params += '&categoria=' + encodeURIComponent($('input[name="categoria"]').val());
	           params += '&subcategoria=' + encodeURIComponent($('input[name="subcategoria"]').val());
		
		       $('div#borrador-guardado').html('Guardando...');
	         
	         $.Comunidades.borrador_setTimeout = setTimeout('$.Comunidades.borrador_save_enabled()', 60000);
	         
	         $.Comunidades.borrador_save_disabled();
	         
	         //Actualizo el borrador id
	         if(!empty($('input[name="borrador"]').val())){
		          $.ajax({
		             type: 'POST',
		             url: global.data.scripturl + '?action=comunidades;sa=borradores-guardar',
		             data: params + '&borrador_id=' + encodeURIComponent($('input[name="borrador"]').val()),
                 dataType: 'json',
			           success: function(data){
                    switch(data['status']){
					             case 0: //ERROR
						              clearTimeout($.Comunidades.borrador_setTimeout);
						              $.Comunidades.borrador_setTimeout = setTimeout('$.Comunidades.borrador_save_enabled()', 5000);
						              $.Comunidades.borrador_ult_guardado = data['data'];
						              $('div#borrador-guardado').html($.Comunidades.borrador_ult_guardado);
						           break;
					             case 1: //Guardado
						              var currentTime = new Date();
						              $.Comunidades.borrador_ult_guardado = 'Guardado a las ' + currentTime.getHours() + ':' + currentTime.getMinutes() + ':' + currentTime.getSeconds() + ' hs.';
						              $('div#borrador-guardado').html($.Comunidades.borrador_ult_guardado);

						           break;
				            } 
			           },
			           error: function(){
				            $.Comunidades.dialog_error();
			           }
		          });
	         }
	         else{
		          $.ajax({
			           type: 'POST',
			           url: global.data.scripturl + '?action=comunidades;sa=borradores-agregar',
			           data: params,
			           dataType: 'json',
			           success: function(data){
                    switch(data['status']){
					             case 0: //ERROR
						              clearTimeout($.Comunidades.borrador_setTimeout);
						              $.Comunidades.borrador_setTimeout = setTimeout('$.Comunidades.borrador_save_enabled()', 5000);
						              $.Comunidades.borrador_ult_guardado = data['data'];
						              $('div#borrador-guardado').html($.Comunidades.borrador_ult_guardado);
						           break;
					             case 1: //Creado
						              $('input[name="borrador"]').val(data['data']);
						              var currentTime = new Date();
						              $.Comunidades.borrador_ult_guardado = 'Guardado a las ' + currentTime.getHours() + ':' + currentTime.getMinutes() + ':' + currentTime.getSeconds() + ' hs.';
						              $('div#borrador-guardado').html($.Comunidades.borrador_ult_guardado);
						           break;
				            } 
			           },
			           error: function(){
				            $.Comunidades.dialog_error();
			           }
		          });
	         }
    },
    
    borrador_save_enabled: function(){
		   if($('input#borrador-save'))
			    $('input#borrador-save').removeClass('disabled').removeAttr('disabled');
		      $.Comunidades.borrador_is_enabled = true;
	  },
	  
	  borrador_save_disabled:	function(){
		   if($('input#borrador-save'))
			    $('input#borrador-save').addClass('disabled').attr('disabled', 'disabled');
		      $.Comunidades.borrador_is_enabled = false;
	  },
	  
	  tema_votar: function(voto, obj){
		   var noajax = false;
		   if (obj) {
			   if( $(obj).hasClass('disabled')){
			   	return false;
			   };
			   var rel;
			   if (voto == -1) {
			   	rel = $(obj).prev();
			   } else {
			   	rel = $(obj).next();
			   }
			   $(obj).addClass('green disabled');
			   $(obj).button('option', 'disabled', true);
			   rel.addClass('disabled');
		   }
		   var votesCount = $('#comunidad-data-stats .votes-count > span');
		   var actualVotes = $('#comunidad-data-stats .votes-count > span').data('val');
		   var updatedVotes = parseInt(actualVotes)+voto;
		   if(!$.Comunidades.gget('user')){
		   	noajax = true;
		   }
		   if(!noajax){
			   $.ajax({
				   type: 'POST',
				   url: global.data.scripturl + '?action=comunidades;sa=votos',
				   data: 'voto='+voto+$.Comunidades.gget('idtema')+$.Comunidades.gget('comunidad')+$.Comunidades.gget('user'),
				   dataType: 'json',
				   success: function(data){
              switch(data['status']){
					       case 0: //ERROR
					          $.Comunidades.dialog_alert(data['data']);
			              $(obj).removeClass('green disabled');
			              rel.removeClass('disabled');
						     break;
					       case 1: //SUCCESS
		                votesCount.hide().html($.Comunidades.number_format(updatedVotes)).attr('data-val',updatedVotes).show();
			              $.Comunidades.setTime('tema;idtema='+global.comunidad.id_tema,100);
						        break;
				      } 
			   	},
			   	error: function(){
			        $.Comunidades.dialog_alert();
			     }
			   });
		   }
	  },
	
  // seguir comunidad o tema
  seguir: function(obj, id, type){
    var named = Array();
		var noajax = false;
		
     switch(type){case 1: named = 'comunidad';break; case 2: named = 'tema';break;}
     
	   if(empty(id) || empty(type))
		    return false;
		    
	   if(global.cache['last_seguir'] == 'seguir')
		    return false;
		    
	   if(!global.onetime['seguir_'+named])
        global.onetime['seguir_'+named] = true;
    else
        return;		
        
    var followsCount = $('.followers-count > span');
		var actualFollows = $('.followers-count > span').data('val');
		var updatedFollows = parseInt(actualFollows)+1;
		
    if(!$.Comunidades.gget('user')){
			noajax = true;
		}
		if(!noajax){
			$.ajax({
				type: 'POST',
				url: global.data.scripturl + '?action=comunidades;sa=follows',
				data: 'id='+parseInt(id)+'&type='+type,
				dataType: 'json',
				success: function(data){
           switch(data['status']){
					    case 0: //ERROR
					       $.Comunidades.dialog_alert(data['data']);
						  break;
					    case 1: //SUCCESS
			           global.cache['last_seguir'] = 'seguir';	
			           global.onetime['seguir_'+named] = false;
			           $('#'+obj.id+'.seguir > span').html('Siguiendo');
			           $('#'+obj.id+'.seguir').removeClass('red not-following').addClass('green following');
			           $(obj).unbind('click').bind('click', function(){
				            return $.Comunidades.noseguir(obj, id, type);
			           });
			           followsCount.hide().html($.Comunidades.number_format(updatedFollows)).attr('data-val',updatedFollows).show();
		             $.Comunidades.follows = updatedFollows;
						  break;
				   } 
				},
				error: function(){
				   $.Comunidades.dialog_alert();
				}
			});
		}
  },
	
  // seguir comunidad o tema
  noseguir: function(obj, id, type){
    var named = Array();
		var noajax = false;
        
     switch(type){case 1: named = 'comunidad';break; case 2: named = 'tema';break;}
     
	   if(empty(id) || empty(type))
		    return false;
		    
	   if(global.cache['last_seguir'] == 'noseguir')
		    return false;
		    
	   if(!global.onetime['seguir_'+named])
        global.onetime['seguir_'+named] = true;
     else
        return;		
     
		 var followsCount = $('.followers-count > span');
		 
     if(empty($.Comunidades.follows)){
		    var actualFollows = $('.followers-count > span').data('val');
		 }
		 else{
		    actualFollows = $.Comunidades.follows;
		 }
		
    if(!$.Comunidades.gget('user')){
			noajax = true;
		}
		
		var updatedFollows = parseInt(actualFollows)-1;
		followsCount.hide().html($.Comunidades.number_format(updatedFollows)).attr('data-val',updatedFollows).show();
		
		$.Comunidades.follows = false;
		
		if(!noajax){
			$.ajax({
				type: 'POST',
				url: global.data.scripturl + '?action=comunidades;sa=nofollows',
				data: 'id='+parseInt(id)+'&type='+type,
				dataType: 'json',
				success: function(data){
           switch(data['status']){
					    case 0: //ERROR
					       $.Comunidades.dialog_alert(data['data']);
						  break;
					    case 1: //SUCCESS
			           global.cache['last_seguir'] = 'noseguir';	
			           global.onetime['seguir_'+named] = false;
			           $('#'+obj.id+'.seguir > span').html('Seguir');
			           $('#'+obj.id+'.noseguir').hide();
			           $('#'+obj.id+'.seguir').addClass('not-following').removeClass('red green following').show();
			           $(obj).unbind('click').bind('click', function(){
				            return $.Comunidades.seguir(obj, id, type);
			           });
						  break;
				   } 
				},
				error: function(){
				   $.Comunidades.dialog_alert();
				}
			});
		}
  },
  
  // add bookmark
  add_bookmark : function(){
		 var noajax = false;
		 var favsCount = $('.favs-count > span');
		 var actualFavs = $('.favs-count > span').data('val');
		 var updatedFavs = parseInt(actualFavs)+1;
		 
     if(!global.onetime['add_bookmark'])
         global.onetime['add_bookmark'] = true;
     else
         return;
         
     if(!$.Comunidades.gget('user')){
			 noajax = true;
		 }
		 
     if(!noajax){
     $.Comunidades.add_load('a.add_bookmark i');
     $.ajax({
         type : 'POST',
         url : global.data.scripturl + '?action=comunidades;sa=bookmark',
         data : $.Comunidades.gget('idtema')+'&autor='+id_auhor+'&id='+id_comunidad,
         dataType: 'json',
         success : function(data){
           switch(data['status']){
					    case 0: //ERROR
					       $.Comunidades.dialog_alert(data['data']);
                 $.Comunidades.end_load('a.add_bookmark i');
						  break;
					    case 1: //SUCCESS
                 $.Comunidades.end_load('a.add_bookmark i');
                 $('a.add_bookmark').addClass('green').find('e.txt').html(data['data']);
			           favsCount.hide().html($.Comunidades.number_format(updatedFavs)).attr('data-val',updatedFavs).show();
						  break;
				   }     
         },
				error: function(){
				   $.Comunidades.dialog_alert();
				}
     });
     }
        
  },
  
  /*

			           */
  
  add_load: function(data){
     $(data).addClass('load');
  },
  
  end_load: function(data){
     $(data).removeClass('load');
  },
	
	/* number_format */
  number_format:function(a,b,e,f){
     a=a;
     b=b;
     var c=function(i,g){
        g=Math.pow(10,g);
        return(Math.round(i*g)/g).toString()
     };
     a=!isFinite(+a)?0:+a;
     b=!isFinite(+b)?0:Math.abs(b);
     f=typeof f==="undefined"?",":f;
     e=typeof e==="undefined"?".":e;
     var d=b>0?c(a,b):c(Math.round(a),b);
     c=c(Math.abs(a),b);
     var h;if(c>=1E3){c=c.split(/\D/);
     h=c[0].length%3||3;
     c[0]=d.slice(0,h+(a<0))+c[0].slice(h).replace(/(\d{3})/g,f+"$1");
     d=c.join(e)}else d=d.replace(".",e);
     a=d.indexOf(e);
     if(b>=1&&a!==-1&&d.length-a-1<b)d+=(new Array(b-(d.length- a-1))).join(0)+"0";
     else if(b>=1&&a===-1)d+=e+(new Array(b)).join(0)+"0";return d
  },
  
  my_number_format: function(numero){
	   return number_format(numero, 0, ',', '.');
  },
  
  gget: function(data, sin_amp){
	   var r = data+'=';
	   if(!sin_amp){
		    r = '&'+r;
		 }
	   switch(data){
		    case 'user':
			     if(global.comunidad.user_comunidad!='')
				      return r+global.comunidad.user_comunidad;
			  break;
		    case 'idcomunidad':
			     if(global.comunidad.id_comunidad!='')
				      return r+global.comunidad.id_comunidad;
			  break;
		    case 'comunidad':
			     if(id_comunidad!='')
				      return r+id_comunidad;
			  break;
		    case 'idtema':
			     if(global.comunidad.id_tema!='')
				      return r+global.comunidad.id_tema;
			  break;
	   }
	   return '';
  },
  new_answer : function(retry){

        if(!global.cache['new_answer'])
            global.cache['new_answer'] = {
                retry : false,
                wait : false,
                last_error : '',
                ready : false
            };
        
        if(!retry)
            datac = {answer : encodeURIComponent($('textarea.answer').val()), ID_TEMA : $.Comunidades.gget('idtema')};
        else
            datac = global.cache['new_answer']['retry'];

        if(!global.cache['new_answer']['retry'])
            global.cache['new_answer']['retry'] = datac;

        if(global.cache['new_answer']['wait'])
            if(global.cache['new_answer']['wait'] > 0)
                return $.Comunidades.dialog_alert(global.cache['new_answer']['last_error']);

        if(global.cache['new_answer']['ready'])
            return false;
        else
            global.cache['new_answer']['ready'] = true;

        var maskload = $('.new-comment .mask-load').fadeIn();
        
		    var AnswerCount = $('.answer-count > span');
		   
		    var actualAnswer = $('.answer-count > span').data('val');
		    
		    var updatedAnswer = parseInt(actualAnswer)+1;
		    
        $.ajax({
            type : 'POST',
            url : global.data.scripturl + '?action=comunidades;sa=comentar',
            data : 'comentario=' + datac.answer + datac.ID_TEMA + '&idcomunidad='+id_comunidad+'&show_answer=' + (last_page ? 0 : 1),
            dataType: 'json',
            cache: false,
            async: true,
            success : function(data){
               switch(data['status']){
					        case 0: //ERROR                    
					           if(data['type'] == 'timeout'){ 
                        global.cache['new_answer']['wait'] = data['timeout'];
                        $.Comunidades.checkTimeout();
                     } // suponiendo que el tema se cerro en ese instante.
                     else if(data['type'] == 'locked' && $('.new-comment').length > 0)
                        $('.new-comment').slideUp(function(){$(this).remove();});
                        
                        global.cache['new_answer']['last_error'] = data['data'];
                        return $.Comunidades.dialog_alert(data['data']);
						      break;
					        case 1: //SUCCESS
						      break;
				       }
                        var template = $(data['gotolast'] ? "#gotoLastPageTmpl" : "#newAnswerTmpl").tmpl(data).appendTo("#comentarios");
                        $(template).slideDown('slow');
			                  $.Comunidades.tipsy();
					              
					           $('textarea.answer').val('').focus().blur();
                
                     if($('.no-answers').length > 0)
                        $('.no-answers').fadeOut();
                

                        var scrollheight = 40;
                        if($(template).find('.UI-comment').length > 0)
                            scrollheight = $(template).find('.UI-comment')[0].offsetHeight;

                        $.scrollTo('+=' + scrollheight + 'px', 800);
			                  AnswerCount.hide().html($.Comunidades.number_format(updatedAnswer)).attr('data-val',updatedAnswer).show();
            },
            error : function(){
                errors.retry('$.Comunidades.new_answer(true)');
            },
            complete : function(){
                global.cache['new_answer']['ready'] = false;
                $(maskload).fadeOut();
            }
        });
    },
    
    checkTimeout: function(){
       if(global.cache['new_answer']['wait'] <= 0)
          return false;
        
          global.cache['new_answer']['wait']--;

          setTimeout(function(){
             $.Comunidades.checkTimeout();
          }, 1000);
    },
    
    citar_answer: function(id){
       
       var user = $('#comment-'+id+' .author-data .nick a').attr('text-quote');
       var cita = $('.answer_'+id).attr('text-quote');
       var text = ($('.answer.comment').val() != '') ? $('.answer.comment').val() + '\n' : '';
	         text += '[quote=' + user + ']' + cita + '[/quote]\n';
	     $('.answer.comment').val(text).focus();

    },
    
    edit_answer: function(mid, cid){
       
       sp_dialog.close();
       
       $.ajax({
           type : "POST",
           url  : global.data.scripturl + '?action=comunidades;sa=edite_answer',
           data : 'mid='+mid+'&cid='+cid+'&idcomunidad='+id_comunidad+$.Comunidades.gget('idtema'),
           dataType: 'json',
           success : function(data){
              switch(data['status']){
					       case 0: //ERROR
					          sp_dialog.alert(data['title'],data['data']);
						     break;
					       case 1: //SUCESS
					          sp_dialog.alert(data['title'],data['data']);
					          /*$.Comunidades.dialog(data['title'], data['data']);*/
                    sp_dialog.buttons([{text: 'Guardar',"class": 'sp-button blue right ui-button ui-widget ui-state-default ui-corner-all ui-button-text-only',
                       click: function() {$.Comunidades.save_answer(mid, cid);}
                    }]);
                    sp_dialog.endload(false, true);
						     break;
				      }
				   },
           error : function(){
               $.Comunidades.dialog_alert();;
           }
       });
    },    
    
    save_answer: function(mid, cid){
       
       sp_dialog.close();
       
       var edicion = $('input[name=edicion_'+mid+']').val();
       
       $.ajax({
           type : "POST",
           url  : global.data.scripturl + '?action=comunidades;sa=save_answer',
           data : 'mid='+mid+'&cid='+cid+'&idcomunidad='+id_comunidad+$.Comunidades.gget('idtema')+'&answer='+edicion,
           dataType: 'json',
           success : function(data){
              switch(data['status']){
					       case 0: //ERROR
					          sp_dialog.alert(data['title'],data['data']);
						     break;
					       case 1: //SUCESS
					          /*sp_dialog.alert(data['title'],data['data']);
					          /*$.Comunidades.dialog(data['title'], data['data']);*//*
                    sp_dialog.buttons([{text: 'Guardar',"class": 'sp-button blue right ui-button ui-widget ui-state-default ui-corner-all ui-button-text-only',
                       click: function() {$.Comunidades.save_answer(mid, cid);}
                    }]);*/
                    $('.comment-content.answer_'+cid).html(data['data']).attr({'text-quote':data['source']});
						     break;
				      }
				   },
           error : function(){
               $.Comunidades.dialog_alert();;
           }
       });
    },
    
    changed_val_edicion: function(th, id){
       $('input[name=edicion_'+id+']').val(th);
    },
    
    actualizar_respuestas: function(type, category){
       $('#last_comments').css('opacity', 0.4);
		   if($.Comunidades.gget('idcomunidad'))
			    var params = $.Comunidades.gget('idcomunidad', true);
			    
		   if(category)
			    var params = 'cat='+category;
			    
		   $.ajax({
			    type: 'POST',
			    url: global.data.scripturl + '?action=comunidades;sa=reload_answer',
			    cache: false,
			    data: params+'&type='+type,
			    success: function(h){
				     $('#last_comments').html(h.substring(3));
				     $('#last_comments').css('opacity',1);
			    },
		      error: function(){
				     $('#last_comments').css('opacity', 1);
			    }
		   });
    },
    
    
    
    
    
  }  
})(jQuery);

