<?php
if (!defined('SPIRATE'))
	die('Hacking attempt...');

function template_main(){
	global $context, $settings, $scripturl, $txt, $return, $boardurl;
	echo'
	
		<style>
	.BlocD{
		color: #444444;
		font-size: 14px;
		line-height: 25px;
		margin-bottom: 20px;
		padding: 0;
	}
	.BlocD h1{
		
		line-height: 25px;
		
	}</style>
	
	<div class="left cleafix" style="width:230px; margin-right: 20px">';
echo '<h3 class="blue" style="margin-left: 10px">Publicidad</h3>';
echo ' ', ssi_destacado(6),'
              
           ';
	echo'
	</div>
	<div class="left cleafix" style="width:700px; margin-right: 20px">
	
	<div class="box-border-striped" id="Section_1">
		<div class="stripes"></div>
			<div class="content">
				<div class="header">
					<h3>Mis Posts favoritos</h3>
					<hr />
				</div>
		';
			
			if(!empty($return)){
				echo '<b class="size11">', $return, '</b><hr />';
			}
			echo'<form action="', $scripturl ,'?action=favoritos;sa=delete" method="post">';	
				if (!empty($context['favoritos'])){
					echo'<table style="width:100%;"><tbody>';
					foreach ($context['favoritos'] as $topic){
						echo'
						<tr>
							<td style="width:60%;">
								<span style="float:left;"><img title="', $topic['board']['name'],'" src="', $settings['images_url'] ,'/post/icono_', $topic['board']['id'],'.gif" />
								&nbsp;<a href="', $scripturl ,'?topic='.$topic['id'].'">'.substr($topic['subject'],0,40).'</a></span>

								<span style="float:right;"><span class="opc_fav"><b title="Creaci&oacute;n del post">'.$topic['time'].'</b> | por: <a href="', $scripturl ,'?action=profile;user=', $topic['poster']['name'],'">', $topic['poster']['name'],'</a> | ', $topic['puntos'],' pts.|</span><input type="checkbox" name="remove_favoritos[]" value="', $topic['id'], '" class="check" /></span>
							</td>

						</tr>';
					}
					echo'</tbody></table>';
				}
				else{
					echo $txt['no_favorites'],'<hr />';
				}

				if(!empty($context['favoritos'])){
					echo'
					<hr />
					<p class="alignR">
						<span class="size10">', $txt['selected_favorites'],'</span> <input class="login" name="send" style="font-size: 9px;" value="Eliminar" type="submit" />
					</p>';
				}
			echo'</form></div>
	</div>
	
	</div>
	<!-- Small Pirate - Social Community Script -->
	';
}

?>