<?php
function template_manual_above(){}
function template_manual_below(){}
function template_manual_intro(){
global $context, $settings, $options, $txt, $scripturl, $modSettings, $boardurl, $db_prefix;

/*******************************************
*                  Sp-widget               *
*------------------------------------------*
*                                          *
*         Widget doble opcion              *
*                                          *
********************************************
*  Version: 1.0                            *
*  Creado por: fivezone                    *
*  SP v: 2.4                               *
********************************************
*               Small Pirate               *
********************************************/

echo'	
<script type="text/javascript">
	var ancho=new Array();
	var alto=new Array();
	ancho[\'0\']=350;
	alto[\'0\']=100;
	ancho[\'1\']=200;
	alto[\'1\']=200;
	ancho[\'2\']=200;
	alto[\'2\']=250; 
	ancho[\'3\']=285;
	alto[\'3\']=134;
	ancho[\'4\']=200;
	alto[\'4\']=300;
	ancho[\'5\']=320;
	alto[\'5\']=100;
	ancho[\'6\']=320;
	alto[\'6\']=200;
	ancho[\'7\']=320;
	alto[\'7\']=300;
	
	var color = new Array();
	color[\'0\'] = "rojo";
	color[\'1\'] = "amarillo";
	color[\'2\'] = "gris";
	color[\'3\'] = "rosa";
	color[\'5\'] = "violeta";
	color[\'6\'] = "verde";
	color[\'7\'] = "turquesa";
	
	var id = new Array();
	id[\'0\'] = "' . $context['user']['id'], '";
	id[\'1\'] = "todo";
	
	function actualizar_preview(noselect){
		document.getElementById("cantidad").value = parseInt(document.getElementById("cantidad").value);
		if (isNaN(document.getElementById("cantidad").value)) {
			document.getElementById("cantidad").value="";
			alert("', $txt['should_be_integer'], '");
			return;
		}
		if (!document.getElementById("cantidad").value){
			alert("', $txt['should_input_something'], '");
			document.getElementById("cantidad").focus();
			return;
		}
		if (document.getElementById("cantidad").value > 50){
			alert("', $txt['maximun_listed_topics'], ' 50");
			document.getElementById("cantidad").focus();
			return;
		}
		code=\'<div style="border: 1px solid rgb(213, 213, 213); padding: 2px 5px 5px; background: #D7D7D7 url('.$boardurl.'/Themes/default/images/widget/fondo2-widget-\'+ color[document.getElementById("color").value] + \'.gif) repeat-x scroll center top; width: \'+ ancho[document.getElementById("tamano").value] + \'px; -moz-background-clip: -moz-initial; -moz-background-origin: -moz-initial; -moz-background-inline-policy: -moz-initial; text-align: left;">';
		echo '<a href="'.$boardurl.'/"><img src="'.$boardurl.'/Themes/default/images/widget/widget-logo.png" alt="'.$boardurl.'" style="border: 0pt none; margin: 0px 0px 5px 5px;" /></a><br />';
		echo '<iframe src="'.$boardurl.'/web/otros/sp-widget.php?cat=\' + document.getElementById("categ").value + \'&cant=\'+ document.getElementById("cantidad").value + \'&an=\'+ ancho[document.getElementById("tamano").value] + \'&color=\'+ color[document.getElementById("color").value] + \'&id=\'+ id[document.getElementById("id").value]  + \'" style="border: 1px solid rgb(213, 213, 213); margin: 0pt; padding: 0pt; width: \'+ ancho[document.getElementById("tamano").value] + \'px; height: \'+ alto[document.getElementById("tamano").value] + \'px;" frameborder="0"></iframe></div>\';

		document.getElementById("widget-preview").innerHTML=code;
		document.getElementById("codigo").value=code;
		focus_code(noselect);
		return;
	}
	function focus_code(noselect){
		if(!noselect)
			document.getElementById("codigo").focus();
			document.getElementById("codigo").select();
		return;
	}
</script>
<div class="left cleafix" style="width:260px; margin-right: 20px">';
echo '<h3 class="blue" style="margin-left: 10px">Opciones</h3>';
echo '<div class="box-selection">
        <div class="context">
            <ul>
                <li class="selected first-child"><a href="',$scripturl,'?action=widget">Posts</a><i class="arrow"></i></li>';
				if($context['user']['is_logged']){
echo'
  <li><a href="'.$scripturl.'?action=widget;page=Info">Mi informaci&oacute;n</a><i class="arrow"></i></li>
';
}
echo'
            </ul>
        </div>
     </div>
	 
	<div class="box_title"><widget class="Iconos BloqConfg"></widget>
		Configuracion
	</div><!-- /box_title -->
	<div class="box_cuerpo alignC">
	<ul style="list-style:none;"
		<li>
		', $txt['category'], ':
			<select id="categ" class="WidgetCats" onchange="actualizar_preview();">';
				$request = db_query("SELECT ID_BOARD, name
				FROM {$db_prefix}boards
				ORDER BY name ASC", __FILE__, __LINE__);
				echo '<option selected="selected" value="0">', $txt['all'], '</option>';
				while($categoria = mysql_fetch_assoc($request)){
					echo'<option value="'.$categoria['ID_BOARD'].'">'.$categoria['name'].'</option>';
				}
				echo'
			</select>
			<widget class="Iconos confCat"></widget>
		</li>
		<li ><a class="selected"  title="', $txt['how_much'], ':">', $txt['how_much'], ':</a><input class="widgetOpcCampos" maxlength="2" id="cantidad" value="20" onchange="actualizar_preview();" type="text" />&nbsp;<span class="smalltext">(max 50)</span><widget class="Iconos confCantidad"></widget></li>
	
		
		<li >
			', $txt['size'], ':
			<select id="tamano" class="WidgetTamano" onchange="actualizar_preview();">
				<option value="0">350 x 100</option>
				<option value="1">200 x 200</option>
				<option value="2">200 x 250</option>
				<option value="3">285 x 134</option>
				<option value="4">200 x 300</option>
				<option value="5">320 x 100</option>
				<option value="6">320 x 200</option>
				<option value="7">320 x 300</option>
			</select>
			<widget class="Iconos confTamano"></widget>
		</li>
		
		<li >
			', $txt['color'], ':
			<select id="color" class="WidgetColor" onchange="actualizar_preview();">
				<option value="0">', $txt['red'], '</option>
				<option value="1">', $txt['yellow'], '</option>
				<option value="2">', $txt['grey'], '</option>
				<option value="3">', $txt['pink'], '</option>
				<option value="5">', $txt['violet'], '</option>
				<option value="6">', $txt['green'], '</option>
				<option value="7">', $txt['lightblue'], '</option>
			</select>
			<widget class="Iconos confColor"></widget>
		</li>
		
		<li  style="border-bottom: 0 none;">
		Posts:
			<select id="id" class="WidgetPosts" onchange="actualizar_preview();">';
				if($context['user']['is_logged']){
					echo' <option value="0">Solo mios</option>';
				}
				echo'
				<option value="1">Todos</option>
			</select>
			<widget class="Iconos confPost" style="margin-top: 2px;"></widget>
		</li></ul>
	</div><!-- /box_cuerpo -->   

	</div>
	
	
	<div class="left cleafix" style="width:650px; margin-right: 20px">
	<div class="box-border-striped" id="Section_1">
		<div class="stripes"></div>
			<div class="content">
				<div class="header">
					<h3>C&oacute;mo se ve...</h3>
					<hr />
				</div>
	<input style="width:450px;" type="hidden" size="4" maxlength="2" id="cantidad" value="20" onchange="actualizar_preview();" />
		<center><div id="widget-preview"></div></center>

		<script type="text/javascript">
			actualizar_preview(1);
		</script>		
			</div>
	</div>
	
	<div class="box-border-striped orange" id="Section_1">
		<div class="stripes"></div>
			<div class="content">
				<div class="header">
					<h3>C&oacute;digo</h3>
					<hr />
				</div>
	<center><textarea style="width:450px;" id="codigo" cols="47" rows="6" onClick="focus_code();" ></textarea></center>
		<input type="hidden" size="4" maxlength="2" id="cantidad" value="20" style="width:400px;"onchange="actualizar_preview();" />
		<script type="text/javascript">
			actualizar_preview(1);
		</script>		
			</div>
	</div>
	
	</div>
';
}

function template_manual_Info(){
global $context, $settings, $options, $txt, $scripturl, $modSettings, $boardurl, $db_prefix;

echo'	
	<script type="text/javascript">
  var ancho=new Array();
  var alto=new Array();
  ancho[\'0\']=350;
  alto[\'0\']=100;
  ancho[\'1\']=200;
  alto[\'1\']=200;
  ancho[\'2\']=200;
  alto[\'2\']=250; 
  ancho[\'3\']=285;
  alto[\'3\']=134;
  ancho[\'4\']=200;
  alto[\'4\']=300;
  ancho[\'5\']=320;
  alto[\'5\']=100;
  ancho[\'6\']=320;
  alto[\'6\']=200;
  ancho[\'7\']=320;
  alto[\'7\']=300;
  
  var color = new Array();
  color[\'0\'] = "rojo";
  color[\'1\'] = "amarillo";
  color[\'2\'] = "gris";
  color[\'3\'] = "rosa";
  color[\'5\'] = "violeta";
  color[\'6\'] = "verde";
  color[\'7\'] = "turquesa";
  
    var id = new Array();
  id[\'0\'] = "' . $context['user']['id'], '";
      
  function actualizar_preview(noselect){
    document.getElementById("cantidad").value = parseInt(document.getElementById("cantidad").value);
  	if (isNaN(document.getElementById("cantidad").value)) {
		  document.getElementById("cantidad").value="";
      alert("', $txt['should_be_integer'], '");
		  return;
	  }
    if (!document.getElementById("cantidad").value){
      alert("', $txt['should_input_something'], '");
      document.getElementById("cantidad").focus();
      return;
    }
    if (document.getElementById("cantidad").value > 50){
      alert("', $txt['maximun_listed_topics'], ' 50");
      document.getElementById("cantidad").focus();
      return;
    }
    code=\'<div style="border: 1px solid rgb(213, 213, 213); padding: 2px 5px 5px; background: #D7D7D7 url('.$boardurl.'/Themes/default/images/widget/fondo2-widget-\'+ color[document.getElementById("color").value] + \'.gif) repeat-x scroll center top; width: \'+ ancho[document.getElementById("tamano").value] + \'px; -moz-background-clip: -moz-initial; -moz-background-origin: -moz-initial; -moz-background-inline-policy: -moz-initial; text-align: left;">';
    echo '<a href="'.$boardurl.'/"><img src="'.$boardurl.'/Themes/default/images/widget/widget-logo.png" alt="'.$boardurl.'" style="border: 0pt none; margin: 0px 0px 5px 5px;" /></a><br>';
    echo '<iframe src="'.$boardurl.'/web/otros/sp-widget-info.php?tipo=\' + document.getElementById("tipo").value + \'&cant=\'+ document.getElementById("cantidad").value + \'&an=\'+ ancho[document.getElementById("tamano").value] + \'&color=\'+ color[document.getElementById("color").value] + \'&id=\'+ id[document.getElementById("id").value]  + \'" style="border: 1px solid rgb(213, 213, 213); margin: 0pt; padding: 0pt; width: \'+ ancho[document.getElementById("tamano").value] + \'px; height: \'+ alto[document.getElementById("tamano").value] + \'px;" frameborder="0"></iframe></div>\';

    document.getElementById("widget-preview").innerHTML=code;
    document.getElementById("codigo").value=code;
    focus_code(noselect);
    return;
  }

  function focus_code(noselect){
    if(!noselect)
      document.getElementById("codigo").focus();
    document.getElementById("codigo").select();
    return;
  }

</script>';

	echo '
		<div class="left cleafix" style="width:260px; margin-right: 20px">';
echo '<h3 class="blue" style="margin-left: 10px">Opciones</h3>';
echo '<div class="box-selection">
        <div class="context">
            <ul>
                <li ><a href="',$scripturl,'?action=widget">Posts</a><i class="arrow"></i></li>';
				if($context['user']['is_logged']){
echo'
  <li class="selected first-child"><a href="'.$scripturl.'?action=widget;page=Info">Mi informaci&oacute;n</a><i class="arrow"></i></li>
';
}
echo'
            </ul>
        </div>
     </div>
	 
	<div class="box_title"><widget class="Iconos BloqConfg"></widget>
		Configuracion
	</div><!-- /box_title -->
	<div class="box_cuerpo alignC">
	<ul style="list-style:none;"

	
		
		<li >
			', $txt['size'], ':
			<select id="tamano" class="WidgetTamano" onchange="actualizar_preview();">
				<option value="0">350 x 100</option>
				<option value="1">200 x 200</option>
				<option value="2">200 x 250</option>
				<option value="3">285 x 134</option>
				<option value="4">200 x 300</option>
				<option value="5">320 x 100</option>
				<option value="6">320 x 200</option>
				<option value="7">320 x 300</option>
			</select>
			<widget class="Iconos confTamano"></widget>
		</li>
		
		<li >
			', $txt['color'], ':
			<select id="color" class="WidgetColor" onchange="actualizar_preview();">
				<option value="0">', $txt['red'], '</option>
				<option value="1">', $txt['yellow'], '</option>
				<option value="2">', $txt['grey'], '</option>
				<option value="3">', $txt['pink'], '</option>
				<option value="5">', $txt['violet'], '</option>
				<option value="6">', $txt['green'], '</option>
				<option value="7">', $txt['lightblue'], '</option>
			</select>
			<widget class="Iconos confColor"></widget>
		</li>
		
		
			<input id="id" type="hidden" value="0" onchange="actualizar_preview();">
			
	
			<li  style="border-bottom: 0 none;">
		Tipo:
		<select id="tipo" onchange="actualizar_preview();">
			  <option value="0">Tipo 1</option>
			  <option value="1">Tipo 2</option>
						 			  </select>
		</li>
		</ul>
	</div><!-- /box_cuerpo -->   

	</div>
	
	
	<div class="left cleafix" style="width:650px; margin-right: 20px">
	<div class="box-border-striped" id="Section_1">
		<div class="stripes"></div>
			<div class="content">
				<div class="header">
					<h3>C&oacute;mo se ve...</h3>
					<hr />
				</div>
	<input style="width:450px;" type="hidden" size="4" maxlength="2" id="cantidad" value="20" onchange="actualizar_preview();" />
		<center><div id="widget-preview"></div></center>

		<script type="text/javascript">
			actualizar_preview(1);
		</script>		
			</div>
	</div>
	
	<div class="box-border-striped orange" id="Section_1">
		<div class="stripes"></div>
			<div class="content">
				<div class="header">
					<h3>C&oacute;digo</h3>
					<hr />
				</div>
	<center><textarea style="width:450px;" id="codigo" cols="47" rows="6" onClick="focus_code();" ></textarea></center>
		<input type="hidden" size="4" maxlength="2" id="cantidad" value="20" style="width:400px;"onchange="actualizar_preview();" />
		<script type="text/javascript">
			actualizar_preview(1);
		</script>		
			</div>
	</div>
	
	</div>

';
}
?>