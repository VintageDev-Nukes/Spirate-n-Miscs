global.lang['enable_wisiwyg'] = false;

$(document).ready(function(){

    global.cache['add-post'] = {
        'ejShowed': false
    };

    $('.slimScroll').slimScroll({
        width: 'auto',
        height: '300px',
        size: '10px',
        position: 'right',
        color: '#333',
        alwaysVisible: false,
        distance: '5px',
        start: 'top'
    });

            var li = $('li.push').remove();
            $('ul#form-category li:eq(2)').before(li);
            select_category();

            $('#form-category li:last-child').addClass('rounded-bottom');

            
            $('a.ej-fuente').click(function () {
                if(!global.cache['add-post']['ejShowed']){
                $(this).effect('transfer', { to: $('.input-plus:first input') }, 1000, function(){
                    $('.input-plus:first input').val($(this).html()).next().trigger('click').removeClass('hide').addClass('loading');
                    setTimeout(function(){
                        $('.input-plus:first').find('a').remove();
                        $('.input-plus:first').append('<i><img src="http://www.google.com/s2/favicons?domain=www.wikipedia.org"></i>');
                    }, 1000);
                });
                global.cache['add-post']['ejShowed'] = true;
                }
            });
            

});

function select_category(){
        
        $("ul#form-category li a").click(function(){
            $("ul#form-category li").removeClass("selected");
            $(this).parent().addClass("selected");

            var val = $(this).attr("val");
            $("#category-from-box").val(val);
        });
        
}

(function(c){var a=["DOMMouseScroll","mousewheel"];c.event.special.mousewheel={setup:function(){if(this.addEventListener){for(var d=a.length;d;){this.addEventListener(a[--d],b,false)}}else{this.onmousewheel=b}},teardown:function(){if(this.removeEventListener){for(var d=a.length;d;){this.removeEventListener(a[--d],b,false)}}else{this.onmousewheel=null}}};c.fn.extend({mousewheel:function(d){return d?this.bind("mousewheel",d):this.trigger("mousewheel")},unmousewheel:function(d){return this.unbind("mousewheel",d)}});function b(i){var g=i||window.event,f=[].slice.call(arguments,1),j=0,h=true,e=0,d=0;i=c.event.fix(g);i.type="mousewheel";if(i.wheelDelta){j=i.wheelDelta/120}if(i.detail){j=-i.detail/3}d=j;if(g.axis!==undefined&&g.axis===g.HORIZONTAL_AXIS){d=0;e=-1*j}if(g.wheelDeltaY!==undefined){d=g.wheelDeltaY/120}if(g.wheelDeltaX!==undefined){e=-1*g.wheelDeltaX/120}f.unshift(i,j,e,d);return c.event.handle.apply(this,f)}})(jQuery);