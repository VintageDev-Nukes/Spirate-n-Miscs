<?php

function template_main(){
global $topic, $context, $settings, $options, $txt, $scripturl, $modSettings;
global $db_prefix, $user_info, $scripturl, $modSettings, $board, $no_avatar, $boardurl;
global $query_this_board, $func, $dar_puntos, $puntos_puedo, $ID_MEMBER, $relacionados, $is_followed;
$cantidad = 1;
$id_post = $topic;

// $txt['reason_elimination'];

$request = db_query("
SELECT den.id
FROM {$db_prefix}denuncias AS den
WHERE den.id = '$id_post'
AND den.tipo = 1", __FILE__, __LINE__);
$context['contando'] = mysql_num_rows($request);

mysql_free_result($request);

// seteamos el post siguiente y anterior

$nextTopic = $topic + 1;
$prevTopic = $topic - 1;


if($context['contando'] > 5 && empty($context['user']['is_admin']))
fatal_error($txt['post_denounced'], false);

if($context['contando'] > 5 && $context['user']['is_admin'])
echo'<p align="center" style="color: #FF0000;">',$txt['disp_verif1'],' '.$context['contando'].' ',$txt['disp_verif2'],'</p>';

if ($context['user']['is_guest'] && $context['can_view_post'] == '1')
fatal_error($txt['post_private'], false);

// set .globalcontent padding to 0px
echo '<style type="text/css">
    #main .globalcontent{
    padding:0;
    }
    </style>';

while ($message = $context['get_message']()){

    $firma = str_replace('if(this.width >720) {this.width=720}','if(this.width >376) {this.width=376}',$message['member']['signature']);

echo '<div class="top-info-post' . ( $context['is_sticky'] ? ' sticky' : '' ) . ' clearfix"><a class="tt-element arrows-post left" title="Ir al anterior post" href="',$scripturl,'?topic=',$prevTopic,'&rel=prevTopic"></a><a class="tt-element arrows-post right" title="Ir al siguiente post" href="',$scripturl.'?topic=',$nextTopic,'&rel=nextTopic"></a> <div style="text-align:center"><h1 class="title">'.$context['subject'].'</h1></div> </div>';

$author = array(
    'avatar' => $message['member']['avatar']['src'],
    'avatar_coords' => $message['member']['avatar']['coords'][100]['style'],
    'gender_img' => '',
    'country_img' => '',
    'mood_img'
);

if (!empty($settings['show_gender']) && $message['member']['gender']['image'] != '')
    $author['gender_img'] = '<span title="'. $message['member']['gender']['name']. '" style="margin:0 0 -3px 5px">'. $message['member']['gender']['image']. '</span>';

if($message['member']['title'])
    $autor['country_img'] = ' <img alt="" title="'. nombre_pais($message['member']['title'])  . '" src="'.$settings['images_url'].'/icons/banderas/'.nombre_pais($message['member']['title'],false).'.png" />';
else
    $autor['country_img'] = ' <img alt="" title="" src="'.$settings['images_url'].'/icons/banderas/ot.png" />';

if (!empty($message['member']['options']['bear_tab']))
     $autor['mood_img'] = '&nbsp;<img style="margin:0 0 -3px 5px" width="18" height="18" title="'. restado($message['member']['options']['bear_tab']) . '" src="'. $settings['default_images_url']. '/estado/'. $message['member']['options']['bear_tab']. '.png" />';

// aca marca los comentarios de los usuarios
$request = db_query("SELECT id_user
                     FROM {$db_prefix}comentarios
                     WHERE id_user = " . $message['member']['id'], __FILE__, __LINE__);
$context['comentuser'] = mysql_num_rows($request);

// aca marca los posts de los usuarios
$request2 = db_query("SELECT ID_MEMBER
                     FROM {$db_prefix}messages
                     WHERE ID_MEMBER = " . $message['member']['id'], __FILE__, __LINE__);
$message['member']['topics'] = mysql_num_rows($request2);

mysql_free_result($request);

$memID = $message['member']['id'];

$request = db_query("SELECT *
               FROM {$db_prefix}members_info
               WHERE ID_MEMBER = $memID
               ", __FILE__, __LINE__);
    $context['info'] = mysql_fetch_assoc($request);

$link = $scripturl .'?topic='. $context['current_topic'];



echo '<div class="globalcontent2 clearfix" style="margin-top:10px">
      <div class="post-first-col">
      <div class="nano-tooltips clearfix blue left" style="left:4px"><span class="izq"></span><span class="text">', (!empty($message['member']['group']) ? $message['member']['group'] : $message['member']['post_group']), '</span><span class="der"></span></div>
      <div class="clear"></div>
      <div class="user-profile-post clearfix">
      <div class="left">
      <div class="box-inset white shadow clearfix left">
      <div class="avatar avatar_thumbnail s100 clearfix">
      <img class="user-avatar" src="'.$author['avatar'].'" style="'.$author['avatar_coords'].'">
      </div>
      <i class="arrow"></i>
	  <!--- <a class="status tt-element" title="', $message['member']['online']['is_online'] ? 'Online' : 'Offline' ,'"><i class="icon ', $message['member']['online']['is_online'] ? 'on' : 'off' ,'"></i></a> --->
	  </div>
      <div class="clear"></div>
      <div class="a-nick"><a href="', $scripturl . '?action=profile&u=' . $message['member']['id'], '" title="Ver Perfil">', $message['member']['name'], '</a><br /></div>

      
      </div>
      <div class="left">
      <div class="user-info">';

                                    if($message['member']['id'] != $ID_MEMBER){
                                      if($message['is_followed'])
                                      echo '<input class="sp-button red no-shadow" type="button" onclick="unfollow_u(this, '.$message['member']['id'].', \'display\')" value="Dejar de seguir">';
                                      else
                                      echo '<input class="sp-button green no-shadow" type="button" onclick="follow_u(this, '.$message['member']['id'].', \'display\')" value="Seguir usuario">';
                                    }
                                     echo'<ul class="info-user-post" style="margin-top:10px;">
                                     <li class="data"><img src="'.$settings['images_url'].'/documents.png" style="margin:0 5px -3px 0"> <strong>', $message['member']['topics'], '</strong> posts</li>
                                     <li class="data puntos"><img src="'.$settings['images_url'].'/point.png" style="margin:0 5px -2px 0"> <strong>', $message['member']['money'], '</strong> puntos</li>
                                     <li class="data comentarios"><img src="'.$settings['images_url'].'/balloons-box.png" style="margin:0 5px -3px 0"> <strong>'.$context['comentuser'].'</strong> comentarios</li>
                                     <li class="data seguidores"><img src="'.$settings['images_url'].'/user--plus.png" style="margin:0 5px -3px 0"> <strong>', $message['member']['followers'], '</strong> seguidores</li>
                                         <li>
                                             ' . $author['country_img'] . '
                                             ' . $author['gender_img'] . '
                                             '.$autor['mood_img'].'';

                                    if ($settings['show_profile_buttons'])
                                    {
                                            if ($context['can_send_pm'])
                                                echo '<span class="icons emp2"><a href="', $scripturl . '?action=mp;sa=send;u=' . $message['member']['id'], '" title="',$txt['send_message'],'"><span class="size11"><!-- EDIT: IMG --></span></a></span>';
                                            if ($context['user']['is_logged'])
                                                echo '<span class="icons fot2"><a href="', $scripturl,'?action=imagenes;usuario=', $message['member']['name'], '" title="',$txt['disp_images'],'"><span class="size11"><!-- EDIT: IMG --></span></a></span>';
											
											echo '<a class="tt-element visible left" style="width:17px" title="', $message['member']['online']['is_online'] ? 'Online' : 'Offline' ,'"><i class="icon status-', $message['member']['online']['is_online'] ? 'on' : 'off' ,'"></i></a>';
                                    }
                                   echo '</li>
                                     </ul>
                                     </div></div>
                                     <div class="clear"></div>';
                                        echo '<div class="about"><span style="color:#999;font-size:11px;margin-left:1px">Acerca</span> <div>', !empty($context['info']['biografia']) ? $context['info']['biografia'] : $message['member']['name'] . ' no ha descrito nada.', '</div></div>';

     

      echo '</div>';

       
       echo'<div class="minimal-box">
      <div class="title"><h3 class="blue">Posts relacionados</h3></div>
      <div class="content">
      <ul class="mini-post-list">';
	  
	  if($relacionados)
	   foreach($relacionados as $r)
	    echo'<li><img src="'.$settings['images_url'].'/post/icono_'.$r['ID_BOARD'].'.gif" style="margin-bottom:-3px"> &nbsp; <a href="'.$scripturl .'?topic='.$r['ID_TOPIC'].'">'.$r['titulo'].'</a></li>';
	  else
	   echo'<center><span style="color:#999;font-size:11px;margin-left:1px">No se han encontrado posts relacionados.</span></center>';
      echo'</ul>
      </div>
      </div>';

      echo'
      <div class="minimal-box">
      <div class="title"><h3>Publicidad</h3></div>
      <div class="content">
      <p align="center">',ssi_destacado(2),'</p>
      </div>
      </div>

      

      </div>

      <div class="post-second-col">

      <div class="post-content">
      <div class="inset-bar post-datainfo relative clearfix">
      <div class="left">
      <div class="data rounded clearfix">
      <div><img src="'.$settings['images_url'].'/categories.gif" style="margin:0 4px 0 0" > Categoria: &nbsp;<a title="' . $message['board']['name'], '" href="'.$scripturl.'?id=' . $message['board']['id'], '">' . $message['board']['name'], '</a></div>
      <div class="divisor"></div>
      <div><img src="'.$settings['images_url'].'/calendar.gif" style="margin:0 4px -3px 0"> Creado: &nbsp;<strong><a class="tt-element" title="'.date('d/m/Y g:i:s', $message['timestamp']).'">' . hace($message['timestamp']), '</a></strong></div>
      </div>
      </div>';
      if($context['user']['started'] || $context['allow_admin']){

          echo '<div class="absolute" style="right: 0; top: 10px">';
          echo '<button class="sp-button" onclick="location.href=\'', $scripturl,'?action=post;msg=', $message['id'], ';topic=', $context['current_topic'], '.', $context['start'], ';sesc=', $context['session_id'], '\'">Editar</button>';
      if ($ID_MEMBER == $message['member']['id'])
          echo ( $message['can_remove'] ? '<button class="sp-button red" onclick="if (!confirm(\'\xbf'.$txt['confirm_delete_post'].'\')) return false; location.href=\''. $scripturl.'?action=removetopic2;topic='. $context['current_topic']. ';sesc='. $context['session_id']. '\'">Eliminar</button>' : '' );

          echo '</div>';
      }
      echo '</div>
          
      <div class="clear"></div>
      <div id="post-body">'.$message['body'].'</div>';
      echo'<div class="clearfix fuente-title"><div class="left"><span>Fuentes de Informaci&oacute;n</span></div><div class="left dotccc">&nbsp;</div></div>';
        
	  
	  if(!empty($context['fuente'])){
        
          for($j=0;$j<count($context['fuente']);$j++){

            $url = str_replace(' ', '', $context['fuente'][$j]);
            $urlname = str_replace(' ', '', $context['fuente'][$j]);
            $tamano = strlen($url);
            //if($tamano > "30"){
            //$urlname = substr($context['fuente'][$j], 0, 10)."...";
            //}
            if(!preg_match("@^(?:www.)?([^/]+)@i", $url))
              echo'';
            else{

              $url = "http://www.".$url;
            }
            echo'<a class="fuente" target="_blank" href="'.$url.'">'.$urlname.'</a><br>';
          }
      }
      else{
         echo'<table><tbody><tr><td><img src="'.$author['avatar'].'" class="avatar" style="width:16px;height:16px;"></td><td><span style="margin-left:5px;">'.$txt['user_is_author'].'</span></td></tr></tbody></table>';
      }
	  
	  
      echo'</div>
          
      <div class="post-options">
      <div class="sheets">
      <div class="data clearfix" style="padding: 7px 7px 15px;">';


      echo'<div class="title clearfix"><div class="left"><span>Opciones</span></div><div class="right" style="padding-right:10px"><strong>',$txt['add_to'],'</strong>
        &nbsp;
        <a href="http://www.facebook.com/share.php?u='.$link.'" rel="nofollow" target="_blank" title="',$txt['add_facebook'],'"><img src="',$settings['images_url'],'/icons/facebook.png"></a>
        &nbsp;<a href="http://technorati.com/faves/?add='.$link.'" rel="nofollow" target="_blank" title="',$txt['add_technorati'],'"><img src="',$settings['images_url'],'/icons/technorati.png" style="cursor: pointer;display: inline;"></a>
        &nbsp;<a href="http://del.icio.us/post?url='.$link.'" rel="nofollow" target="_blank" title="',$txt['add_delicio'],'"><img src="',$settings['images_url'],'/icons/delicious.png" style="cursor: pointer;display: inline;"></a>
        &nbsp;<a href="http://digg.com/submit?phase=2&url='.$link.'" rel="nofollow" target="_blank" title="',$txt['add_digg'],'"><img src="',$settings['images_url'],'/icons/digg.png" style="cursor: pointer;display: inline;"></a>
        &nbsp;<a href="http://twitter.com/home?status=Les%20recomiendo%20este%20post:%20'.$link.'" rel="nofollow" target="_blank" title="',$txt['add_twitter'],'"><img src="',$settings['images_url'],'/icons/twitter.png"></a>

      </div></div>
      
      <div class="left container_puntos', $context['user']['is_guest'] ? '' : ' hideObj' ,'" style="width:285px;">';
      if($context['user']['is_guest'])
          echo '<div class="info margin-10" style="margin-right: 0; padding-left:4px; padding-right: 4px"><center>Necesitas estar registrado para poder puntuar</center></div>';
      
      if($ID_MEMBER != $message['member']['id'] &&  $context['user']['is_logged']){
          if( $puntos_puedo !=0 && $dar_puntos>0){
          echo '<div class="UI-menu-box clearfix" id="puntos-post" style="margin-top:25px">
          ', $puntos_puedo > 10 ? '<span class="descr" style="top:-17px"> <a class="prev inactive">&laquo;</a> <a class="next" style="margin-left:5px">&raquo;</a> </span>' : '' ,'
          <div class="nano-tooltips clearfix blue left" style="position: absolute; left:1px; top:-22px"><span class="izq"></span><span class="text">Dar puntos a este post</span><span class="der"></span></div>
          <div class="puntos" id="puntos">
          <ul id="ul-points" class="clearfix">
          <!-- <li><a style="background:url(http://localhost/designs/sp_24/images/price_tag.png) no-repeat;margin-top:3px; display:block; width:18px; height:15px"></a></li> -->';
          for($i=1;$i<=$dar_puntos;$i++)
          echo '<li><a href="javascript:post.puntuar('.$i.')">'.$i.'</a></li>';
          echo '<li>&nbsp;</li>
          </ul></div></div>';
          }
          else{
          if( $puntos_puedo == 0 )
              echo '<div class="error" style="margin: 20px 0 0 20px"><center>' . $txt['no_qualify'] . '</center></div>';
          else
              echo '<div class="error" style="margin-top: 20px"><center>' . $txt['no_point'] . '</center></div>';
          }
    }
      echo'</div><div class="right clearfix" style="margin-top:15px;">
      <ul class="data-post">
      <li class="clearfix"><span class="ballon rounded"><strong>'.$context['puntos-post'].'</strong><i></i></span><img src="'.$settings['images_url'].'/point.png" style="margin:0 1px -3px 0"> puntos</li>
      <li class="clearfix"><span class="ballon rounded"><strong>', $context['num_views'], '</strong><i></i></span><img src="'.$settings['images_url'].'/chart.png" style="margin:0 1px -3px 0"> visitas</li>
      <li class="clearfix"><span class="ballon rounded"><strong>'. $context['fav1'] .'</strong><i></i></span><img src="'.$settings['images_url'].'/eye--plus.png" style="margin:0 1px -3px 0"> seguidores</li>
      <li class="clearfix"><span class="ballon rounded"><strong>'. $context['fav1'] .'</strong><i></i></span><img src="'.$settings['images_url'].'/031.png" style="margin:0 1px -3px 0"> favoritos</li>
      </ul>
      </div>
      <div class="clear"></div>';
	  
	 if($context['user']['is_logged']){
	  
	  echo'<hr>';
     // echo'<a class="sp-button clearfix follow_post" onclick="post.follow_post"><span><i class="icon" style="background:url('.$settings['images_url'].'/eye--plus.png) no-repeat scroll top left transparent;"></i><span class="txt">Seguir post</span></span></a>';
      echo'<a class="sp-button clearfix add_bookmark" onclick="post.add_bookmark()"><span><i class="icon" style="background:url('.$settings['images_url'].'/031.png) no-repeat scroll top left transparent;"></i><span class="txt">Agregar a favoritos</span</span></a>
      <a class="sp-button clearfix" onclick="if(',$message['member']['id'],'==',$context['user']['id'],'){alert(\'No podes denunciar tu propio post.\');return false;}else{denuncias.nueva(', $context['current_topic'], ', 1);}"><span><i class="icon" style="background:url('.$settings['images_url'].'/flag.png) no-repeat"></i><span class="txt">Denunciar</span></span></a>';
     }
	  
      if($context['allow_admin']){
          echo '<fieldset class="descr" style="padding-bottom:0">';
          echo '<legend>Administrar/Moderar</legend>';
          echo '<strong style="display:block">Causa de eliminaci&oacute;n: </strong>
                <form action="', $scripturl,'?action=removetopic2;topic=', $context['current_topic'], ';sesc=', $context['session_id'], '" method="post" accept-charset="', $context['character_set'], '" name="causa" id="causa">
                <input type="text" name="causa" style="padding:5px;"> <input type="submit" class="sp-button red" value="Eliminar">
                </form>';
          echo '</fieldset>';
      }
      echo '</div>
      <div class="sheets-bottom"><strong></strong><span></span></div>
      </div>
      </div>
      <div class="padding-com" id="all-comments">
      <div class="clearfix"><h3 class="left">'. (int) $context['numcom'] .' comentarios</h3>', $context['is_locked'] && $message['is_author'] ? '<strong class="right color-dark-red" style="margin: 1px 20px 0 20px"> El post se encuetra cerrado actualmente</strong>' : '' ,'</div>';

      
      $allow_comment = $context['user']['is_logged'] && !$context['is_locked'];
      if(!$allow_comment)
        if(allowedTo('moderate_forum') || $ID_MEMBER == $message['member']['id'])
            $allow_comment = true;
      
      if(!empty($context['comentarios']) && $context['show_paginator'])
        echo '<div class="inset-bar wrap-paginator clearfix">'.$context['paginacion'].'<div class="clear"></div></div>';

      $i = 0;
      echo '<div id="comentarios">';
      //Creamos el form para eliminar comentarios manualmente
      echo'<form action="', $scripturl,'?action=rz;m=eliminarc" method="post" accept-charset="', $context['character_set'], '" name="coments" id="coments">';


      foreach($context['comentarios'] as $comment){

        $idcom = $comment['comentario']['id'];

          echo '<div class="relative">
              <div onmouseover="post.com_opt('.$idcom.', 1);" onmouseout="post.com_opt('.$idcom.', 2);" id="com_'.$idcom.'" class="UI-comment clearfix'.($comment['member']['id'] == $message['member']['id'] ? ' author' : ($ID_MEMBER == $comment['member']['id'] ? ' own' : '') ).'">
                    <div class="author-data">
                        <div class="author-avatar box-shadow-soft"><div class="img"><img src="'.$comment['member']['avatar'].'" class="avatar"></div></div>
                        <div class="nick"><a class="nick" href="'.$scripturl.'?action=profile&u='.$comment['member']['id'].'">'.$comment['member']['name'].'</a></div>
                    </div>
                    <div class="comment-data rounded-3 box-shadow-soft">
                        <div class="context">
                        <i class="arrow-dialog"></i>
                        <b style="position:relative" id="author_'.$idcom.'" quote-author="'.$comment['member']['name'].'" quote-com="'.$comment['comentario']['source'].'"></b>
                                <div class="msg">
                                    <div class="options" id="opt_'.$idcom.'">';
                          
                                      echo'
                                      <a class="tt-element" title="Citar"><span style="height:20px" onclick="post.citar('.$idcom.')">
                                      <img src="'.$settings['images_url'].'/quote.png">
                                      </span></a>';
                                      if(allowedTo('moderate_forum') || $ID_MEMBER == $message['member']['id']){
                                      echo'
                                      <a class="tt-element" title="Eliminar"><span style="height:20px" onclick="post.erase_com('.$idcom.', '.$message['id'].')">
                                      <img src="'.$settings['images_url'].'/del-com.png">
                                      </span>';
                                       echo'
                                       <a class="tt-element" title="Seleccionar para borrar">
                                       <input class="tt-element"  style="height:12px" type="checkbox" name="campos['.$idcom.']" /></a>';
                                       }
                                
                                   echo'
                                  </div>
                           '.$comment['comentario']['bbcode'].'
                           </div>
                        </div>
                        <div class="footer">
                        <span stlye="float:left"><img src="'.$settings['images_url'].'/calendar.gif" style="margin: 0 3px -2px 0"> '.$comment['fecha']['howlong'].'</span>
                        </div>
                   </div>
                </div>
                </div>';

      }
      echo '</div>';

      if(allowedTo('moderate_forum') || $ID_MEMBER == $message['member']['id']){
      echo'<div id="commentselect" style="padding-bottom:5px;padding-top:10px;"><span class="size10">',$txt['selected_commentaries'],'</span> 
      <input class="sp-button" style="font-size: 9px;" type="submit" value="',$txt['disp_delete'],'"></div>
      <input type="hidden" name="topic" value="'.$topic.'" />
      <input type="hidden" name="memberid" value="'. $message['member']['id'].'" />
      </form>
     ';
      }
      
      if($context['user']['is_guest'])
          echo '<div class="info"><center>Para poder comentar debes estar <a rel="registro">registrado</a>. Ya tienes usuario? <a href="'.$scripturl.'?action=login">Logueate!</a></center></div>';
      else if($context['is_locked'])
          echo '<div class="error"><center>', !$allow_comment ?  'El post se encuentra cerrado. No puedes comentar' : 'El post se encuentra cerrado actualmente.' ,'</center></div>';
      else if (empty($context['comentarios']))
          echo '<div class="info no-comments"><center>Este post no tiene comentarios. Deseas ser el primero en comentar?</center></div>';



      if(!empty($context['comentarios']) && $context['show_paginator'])
        echo '<div class="inset-bar wrap-paginator clearfix">'.$context['paginacion'].'<div class="clear"></div></div>';


      if($allow_comment)
      echo '<div class="new-comment clearfix add-comment">
                <div class="mask-load with-icon"></div>
                <div class="author-data">
                        <div class="author-avatar box-shadow-soft"><div class="img"><img class="avatar" src="'.$context['user']['avatar']['src'].'"></div></div>
                </div>
                <div class="wrap-comment">
                <i class="arrow-dialog"></i>
                <textarea id="com_markitup" name="comment" class="comment autogrow" style="overflow: hidden; resize: none;" rows="1"></textarea>
                </div>
                <div class="clear"></div>
                <div class="right"><input type="button" class="sp-button" value="Comentar" onclick="post.new_comment()"></div>
            </div>';


      echo '</div>
         </div>
     </div>
     ';

/* Javascript */
?>
<script type="text/javascript">
var last_page = <?= $context['is_last_page'] ? 'true' : 'false' ?>;
</script>
<?php if($puntos_puedo > 10){ ?>
    <script type="text/javascript">
            $.getScript("<?=$settings['theme_url']?>/jcarousellite_1.0.1.js", function(){
                $("div#puntos").jCarouselLite({
                                                btnNext : ".descr a.next",
                                                btnPrev : ".descr a.prev",
                                                circular :  false,
                                                scroll : 4,
                                                speed : 1,
                                                mouseWheel : true
                                            }).css({"width" : "279px", "height" : "17px"});
                $('.container_puntos').removeClass('hideObj');
            });
          </script>
<?php } ?>
<script id="gotoLastPageTmpl" type="text/x-jquery-tmpl">
      <div class="info hide">{{html message}} <a href="<?=$context['last_page_href']?>">${txt_gotolast}</a></div>
</script>
 <script id="newCommentTmpl" type="text/x-jquery-tmpl">
      <div class="relative" id="comment-${id_comment}" style="display:none">
              <div class="UI-comment clearfix${type_comment}">
                    <div class="author-data">
                        <div class="author-avatar box-shadow-soft"><div class="img"><img src="${avatar}" class="avatar"></div></div>
                        <div class="nick"><a class="nick" href="<?=$scripturl?>?action=profile&u=${id_member}">${nick}</a></div>
                    </div>
                    <div class="comment-data rounded-3 box-shadow-soft">
                        <div class="context">
                        <i class="arrow-dialog"></i>
                            <div class="msg">{{html comment}}</div>
                        </div>
                        <div class="footer"><img src="<?=$settings['images_url']?>/calendar.gif" style="margin: 0 3px -2px 0">${time}</div>
                   </div>
                </div>
                </div>
</script>

<?php

}// THAT's ALL FRIENDS

}// fin function template_main



function restado($valor){
  $valor = str_replace("mcontento", "Muy Contento", $valor);
  $valor = str_replace("contento", "Contento", $valor);
  $valor = str_replace("sueno", "Con Sue&ntilde;o", $valor);
  $valor = str_replace("descansar", "Descansando", $valor);
  $valor = str_replace("triste", "Triste", $valor);
  $valor = str_replace("enferm", "Enfermo", $valor);
  $valor = str_replace("emusic", "Escuchando Musica", $valor);
  return $valor;
}

function reported_block(){

  fatal_error('El posts fue borrado por acumulaci&oacute;n de denuncias.', false);
}


?>
