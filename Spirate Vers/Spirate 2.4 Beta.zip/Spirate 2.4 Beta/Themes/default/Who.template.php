<?php

function template_main(){
	global $context, $settings, $options, $scripturl, $txt, $member;

echo'
<div class="box_title">
	', $context['num_users_online'], ' ',$txt['who_user'],'
</div><!-- /box_title -->
<div class="box_cuerpo">

', implode(' ', $context['list_users_online']);


if(empty($context['list_users_online'])){
	echo'<div class="info_box">No se encontraron Usuarios Registrados Online</div>';
}

echo'
<div class="clearfix"></div>
</div><!-- /box_cuerpo -->

<br class="space" />
<table width="222px" border="0" cellspacing="0" cellpadding="0" height="17px">
	<tr>
		<td style=" background: url(',$settings['images_url'],'/buttons/pag_bg.gif) no-repeat; ">
			<span style="color:#FFFFFF;">&nbsp; ',$txt['who_pages'],'&nbsp;&nbsp;&nbsp;&nbsp; ', $context['page_index'], '</span>
		</td>
	</tr>
</table>';

}

?>