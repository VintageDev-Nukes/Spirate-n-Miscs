<?php
// Spirate Script - Version 2.4
function template_manual_above(){}
function template_manual_below(){}

function template_manual_intro(){

global $context, $settings, $txt, $db_prefix, $scripturl, $modSettings, $url;

echo'<script language="JavaScript" type="text/javascript">
function showrequerido(comentario, email)
	{	
			if(comentario == \'\')
			{
				alert(\'',$txt['comment_denunciation'],'\');
				return false;
			}				if(email == \'\')
			{
				alert(\'',$txt['select_post'],'\');
				return false;
			}		
					
			}
	</script>';
	
$id = (int) $_GET['id'];

if ($context['user']['is_guest'])
echo'
<div class="box_title">'.$txt['denounce_post'].'</div>
		<table align="center" class="box_cuerpo">
		<tr class="windowbg">
		<td align="center">
		<br />
	',$txt['denounce_login'],'
		<br />
		<br />
	    <input class="login" style="font-size: 11px;" type="submit" title="',$txt['principal_page'],'" value="',$txt['principal_page'],'" onclick="location.href=\'',$scripturl,'\'" />
        <br />
        <br />
		</td>
		</tr>
    	</table>
        </div>
        <br /><br />'; 

$request = db_query("
                SELECT *
                FROM ({$db_prefix}messages AS m, {$db_prefix}members AS user)
                WHERE m.ID_TOPIC = '$id'
                AND m.ID_MEMBER = user.ID_MEMBER", __FILE__, __LINE__);
	while ($row = mysql_fetch_assoc($request)){
			$titulo = $row['subject'];
			$id = $row['ID_TOPIC'];
			$usuario = $row['memberName'];		
			}
	mysql_free_result($request);
if($usuario_id==$context['user']['id']){  fatal_error("No podes Denunciar tus propios post.",false);}
if ($context['user']['is_logged'])
echo'
<div class="box_title">'.$txt['denounce_post'].'</div>
<div class="box_cuerpo">
    <form action="',$scripturl,'?action=rz;m=endenuncias" method="post">
			<p align="center" class="size11"><b>',$txt['denounce_to_post'],'</b> <br />
', $id , ' / ', $titulo, '
			<p align="center" class="size11"><b>',$txt['created_by'],'</b> <br />
', $usuario, '
<br /><br /><font class="size11"><b>',$txt['denounce_reason'],'</b></font><br />
			<select name="razon" style="color: black; background-color: rgb(250, 250, 250); font-size: 12px;">
			<option value="0">',$txt['denounce_repost'],'</option>
			<option value="1">',$txt['denounce_spam'],'</option>
			<option value="2">',$txt['denounce_links'],'</option>
			<option value="3">',$txt['denounce_disrespectful'],'</option>
			<option value="4">',$txt['denounce_personal_information'],'</option>
			<option value="5">',$txt['denounce_mayus'],'</option>
			<option value="6">',$txt['denounce_porn'],'</option>
			<option value="7">',$txt['denounce_gore'],'</option>
			<option value="8">',$txt['denounce_fount'],'</option>
			<option value="9">',$txt['denounce_poor'],'</option>
			<option value="10">',$txt['denounce_pass'],'</option>
			<option value="11">',$txt['denounce_protocol'],'</option>
			<option value="12">',$txt['denounce_other'],'</option>
			</select><br /><br />
			<font class="size11"><b>',$txt['denounce_explanation'],'</b></font><br />
			<textarea name="comentario" cols="40" rows="5" wrap="hard" tabindex="6"></textarea><br /><font size="1">',$txt['repost_link'],'</font>
<br /><br /><input onclick="return showrequerido(this.form.comentario.value, this.form.email.value);" class="button" type=submit value="Denunciar Post"><br /><input value="', $context['user']['id'] , '" type="hidden" name="ID_MEMBER"><input type="hidden" name="ID_TOPIC" size="25" value="', $id , '">
	</form>
</div>'; 
}
function template_manual_login(){
        global $scripturl, $txt;
echo'
<div class="box_title">
	'.$txt['denounce_envoy'].'
</div>
<div class="box_cuerpo">
		<br />
		'.$txt['denounce_envoy2'].'
		<br />
		<br />
	    <input class="button" type="submit" title="'.$txt['principal_page'].'" value="'.$txt['principal_page'].'" onclick="location.href=\''.$scripturl.'\'" />
        <br />
        <br />
</div>';
}
?>