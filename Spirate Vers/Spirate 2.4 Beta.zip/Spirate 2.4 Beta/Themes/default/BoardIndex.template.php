<?php
// Version: 1.1; BoardIndex

function template_main()
{
    global $scripturl;

    Header("Location: $scripturl");
}

?>