<?php

function template_main(){
global $context, $txt, $modSettings, $settings, $scripturl, $boardurl, $mbname, $txtjs;

echo '1: <div class="registro-form" id="registro-form">
        <div class="paso_1">
        <div class="input-form">
        
        <label for="nombre">'.$txt['enter_name'].'</label>
        <input type="text" name="nombre" id="nombre" class="reginput box-shadow-soft text" title="'.$txt['enter_name'].'." onfocus="fregister.active(this)" onblur="fregister.out(this)">
        <div class="fhtooltip"><span class="arrow o"></span><i class="icon"></i><strong></strong></div>
        </div>

        <div class="input-form">
        <label for="apellido">'.$txt['enter_lastname'].'</label>
        <input type="text" name="apellido" id="apellido" class="reginput box-shadow-soft text" title="'.$txt['enter_lastname'].'." onfocus="fregister.active(this)" onblur="fregister.out(this)">
        <div class="fhtooltip"><span class="arrow o"></span><i class="icon"></i><strong></strong></div>
        </div>

        <div class="input-form">
        <label for="nick">'.$txt['enter_nick'].'</label>
        <input type="text" name="nick" id="nick" class="reginput box-shadow-soft text" title="'.$txt['enter_nick'].'." onfocus="fregister.active(this)" onblur="fregister.out(this)">
        <div class="fhtooltip"><span class="arrow o"></span><i class="icon"></i><strong></strong></div>
        </div>

        <div class="input-form">
        <label for="password">'.$txt['enter_password'].'</label>
        <input type="password" name="password" id="password" class="reginput box-shadow-soft text" title="'.$txt['enter_nick'].'." onfocus="fregister.active(this)" onblur="fregister.out(this)">
        <div class="fhtooltip"><span class="arrow o"></span><i class="icon"></i><strong></strong></div>
        </div>

        <div class="input-form">
        <label for="password2">'.$txt['enter_password2'].'</label>
        <input type="password" name="password2" id="password2" class="reginput box-shadow-soft text" title="'.$txt['enter_password2'].'" onfocus="fregister.active(this)" onblur="fregister.out(this)">
        <div class="fhtooltip"><span class="arrow o"></span><i class="icon"></i><strong></strong></div>
        </div>

        <div class="input-form">
        <label for="email">'.$txt['enter_email'].'</label>
        <input type="text" name="email" id="email" class="reginput box-shadow-soft text" title="'.$txt['enter_email'].'" onfocus="fregister.active(this)" onblur="fregister.out(this)">
        <div class="fhtooltip"><span class="arrow o"></span><i class="icon"></i><strong></strong></div>
        </div>

        <div class="input-form">
        <label for="dia">'.$txt['enter_birthdate'].'</label>
        <select name="dia" id="dia" class="reginput box-shadow-soft select" title="'.$txt['enter_day_birthdate'].'" onfocus="fregister.active(this)" onblur="fregister.out(this)">
        <option value="0">D&iacute;a</option>';
        foreach($context['dias'] as $dia)
            echo '<option value="' . $dia . '">' . $dia . '</option>';
        echo'
            </select>
            
        <select name="mes" id="mes" class="reginput box-shadow-soft select" title="'.$txt['enter_month_birthdate'].'" onfocus="fregister.active(this)" onblur="fregister.out(this)">
        <option value="0">Mes</option>';
        foreach($context['meses'] as $val)
            echo '<option value="' . $val[0] . '">' . $val[1] . '</option>';
        echo'
            </select>

        <select name="anio" id="anio" class="reginput box-shadow-soft select" title="'.$txt['enter_year_birthdate'].'" onfocus="fregister.active(this)" onblur="fregister.out(this)">
        <option value="0">A&ntilde;o</option>';
        foreach($context['anios'] as $anio)
            echo '<option value="' . $anio . '">' . $anio . '</option>';
        echo'
            </select>
        <div class="fhtooltip"><span class="arrow o"></span><i class="icon"></i><strong></strong></div>
        </div>

        </div>
        <div class="paso_2">
        <div class="input-form" style="padding-bottom:15px">

        <label for="sexo">'.$txt['enter_gender'].'</label>
        Masculino <input type="radio" name="sexo" id="sexo_m" value="m" class="reginput radio" title="Selecciona tu sexo." onfocus="fregister.active(this)" onblur="fregister.out(this)">
        Femenino <input type="radio" name="sexo" id="sexo_f" value="f" class="reginput radio" title="Selecciona tu sexo." onfocus="fregister.active(this)" onblur="fregister.out(this)">

        <div class="fhtooltip"><span class="arrow o"></span><i class="icon"></i><strong></strong></div>
        
        </div>

        <div class="input-form">
        
        <label for="pais">'.$txt['enter_country'].'</label>
       
        <select name="pais" id="pais" class="reginput box-shadow-soft select" title="'.$txt['enter_country'].'" onfocus="fregister.active(this)" onblur="fregister.out(this)">
        <option value="0">Selecciona tu pa&iacute;s</option>';
        foreach($context['paises'] as $country)
            echo '<option value="' .  $country['ID_PAIS'] . '">' . $country['nombre'] . '</option>';
        echo '</select>
        <div class="fhtooltip"><span class="arrow o"></span><i class="icon"></i><strong></strong></div>
        </div>';
        if($modSettings['enable_plugin_cities']){
         echo '<div class="input-form geolocation" style="margin:5px 0">
         <div style="padding:1px 4px 4px 4px;"><p align="center">
         <label for="ciudad_state">'.$txt['enter_city'].'</label>
         <input type="text" disabled="disabled" name="ciudad_state" id="ciudad_state" class="reginput box-shadow-soft disabled text" title="'.$txt['enter_city'].'" onfocus="fregister.active(this)" onblur="fregister.out(this)">
         <img class="googleMap" src="'.$settings['images_url'].'/blank.gif" width="180" height="180"></p>
         </div>
         <div class="fhtooltip ciudad_state"><span class="arrow o"></span><i class="icon"></i><strong></strong></div>
         </div>';

         echo '</div>';

        echo '<div class="paso_3">';

        }
        if(!empty($modSettings['visual_verification']) && $modSettings['visual_verification'] != 'none'){
            echo '<div class="input-form"><label>'.$txt['enter_captcha'].'</label><div align="center">';
        
        switch($modSettings['visual_verification']){
            case 'recaptcha':
             echo '<div id="recaptcha_ajax">
				<div id="recaptcha_image"></div>
				<input type="text" class="box-shadow-soft" id="recaptcha_response_field" name="recaptcha_response_field" />
			</div>';

         break;
         case 'captcha':
         if ($context['use_graphic_library'])
			echo '
							<img src="', $context['verificiation_image_href'], '" alt="', $txt['visual_verification_description'], '" id="verificiation_image" /><br />';
		else
			echo '
				<img src="', $context['verificiation_image_href'], ';letter=1" alt="', $txt['visual_verification_description'], '" id="verificiation_image_1" />
				<img src="', $context['verificiation_image_href'], ';letter=2" alt="', $txt['visual_verification_description'], '" id="verificiation_image_2" />
				<img src="', $context['verificiation_image_href'], ';letter=3" alt="', $txt['visual_verification_description'], '" id="verificiation_image_3" />
				<img src="', $context['verificiation_image_href'], ';letter=4" alt="', $txt['visual_verification_description'], '" id="verificiation_image_4" />
				<img src="', $context['verificiation_image_href'], ';letter=5" alt="', $txt['visual_verification_description'], '" id="verificiation_image_5" />';

        echo '<input type="text" id="visual_verification_code" name="visual_verification_code" title="'.$txt['enter_captcha'].'" maxlength="5" size="5" tabindex="', $context['tabindex']++, '" onfocus="fregister.active(this)" onblur="fregister.out(this)" /> &nbsp; <a class="smalltext" href="', $scripturl ,'?action=registrarse" onclick="refreshImages(); return false;">', $txt['Refresh'], '</a>';
        break;

         }
        echo '</div>';
        echo '<div class="fhtooltip captcha" id="captcha"><span class="arrow o"></span><i class="icon"></i><strong></strong></div></div>';
        }
        echo '<div class="input-form">
            <label for="terminos">'.$txt['terms_'].'</label>
                '.sprintf($txt['accept_sprintf'], '<a href="'.$scripturl.'?action=terminos-y-condiciones">'.$txt['terms_'].'</a>?').' <input type="checkbox" name="terminos" id="terminos" title="'.$txt['accept_terms'].'"  onfocus="fregister.active(this)" onblur="fregister.out(this)">
            <div class="fhtooltip"><span class="arrow o"></span><i class="icon"></i><strong></strong></div></div>
            </div>';

        echo '</div>';


$banned_passwords = array();
if(!empty($modSettings['banned_passwords'])){
    $bp_arr = explode(',', $modSettings['banned_passwords']);

    if(!empty($bp_arr))
        foreach($bp_arr as $pass)
            $banned_passwords[] = preg_replace('~^\s+((.+)(?:[^\s]))\s+$~', '$1', $pass); // ok un password puede tener un espacio, pero no uno baneado ;)

}
?>
<script type="text/javascript">
    
sp_dialog.center();

var registerSett = {
    banned_passwords : <?php echo json_encode($banned_passwords) ?>,
    limit_age        : <?php echo !empty($modSettings['limit_age']) ? $modSettings['limit_age'] : 'false' ?>,
    pasos            : <?php echo $modSettings['enable_plugin_cities'] ? 3 : 2 ?>,
    visual_verification : '<?php echo $modSettings['visual_verification'] == 'recaptcha' ? 'recaptcha' : ($modSettings['visual_verification'] == 'captcha' ? 'captcha' : ($modSettings['visual_verification'] == 'none' ? 'false' : 'false')) /* 'false' or 'VAR' */ ?>'
    
}

$.getScript("<?php echo $settings['theme_url'] . '/register.ajax.js' . ($_SERVER['HTTP_HOST'] == 'localhost' ? '?upd=' . time() : '') ?>", function(){
        <?php if($modSettings['enable_plugin_cities']){ ?>
        $.getScript("<?php echo $settings['theme_url'] ?>/autocomplete.js", function(){
            $('input#ciudad_state').autocomplete('<?php echo $scripturl ?>?ajax&action=fast-register&section=ciudad', {
                    minChars: 2,
                    width: 298
            }).result(function(event, data, formatted){
                    fregister.values['ciudad_id'] = (data) ? data[1] : '';
                    fregister.values['ciudad_text'] = (data) ? data[0].toLowerCase() : '';

                    $('.googleMap').attr('src', 'http://maps.google.com/maps/api/staticmap?center='+data[2]+','+data[3]+'&zoom=12&size=200x200&sensor=true&markers=color:blue|'+data[2]+','+data[3])
                    //if(data)			$('#RegistroForm .pasoDos #terminos').focus();
            });
	}); <?php } ?>
                fregister.nextstep(1, true);
                sp_dialog.endload(false, true);                
	});
        
<?php if($modSettings['visual_verification'] != 'none'){ ?>
<?php  if($modSettings['visual_verification'] == 'recaptcha' && ($modSettings['api_public_key_recaptcha'] && $modSettings['api_public_key_recaptcha'] != 'XXX')){ ?>
$.getScript("http://www.google.com/recaptcha/api/js/recaptcha_ajax.js", function(){
	Recaptcha.create('<?php echo $modSettings['api_public_key_recaptcha'] ?>', 'recaptcha_ajax', {
		theme:'custom', lang:'es', tabindex:'13', custom_theme_widget: 'recaptcha_ajax',
		callback: function(){
			$('#recaptcha_response_field').blur(function(){
				fregister.out(this);
			}).focus(function(){
				fregister.active(this);
			}).attr('title', '<?php echo $txt['enter_captcha'] ?>');
		}
	});
});
<?php
}else if($modSettings['visual_verification']=='captcha'){
if ($context['visual_verification'])
	{
		echo '
	function refreshImages()
	{
		var new_url = new String("', $context['verificiation_image_href'], '");
		new_url = new_url.substr(0, new_url.indexOf("rand=") + 5);

		// Quick and dirty way of converting decimal to hex
		var hexstr = "0123456789abcdef";
		for(var i=0; i < 32; i++)
			new_url = new_url + hexstr.substr(Math.floor(Math.random() * 16), 1);';

		if ($context['use_graphic_library'])
			echo '
		document.getElementById("verificiation_image").src = new_url;';
		else
			echo '
		document.getElementById("verificiation_image_1").src = new_url + ";letter=1";
		document.getElementById("verificiation_image_2").src = new_url + ";letter=2";
		document.getElementById("verificiation_image_3").src = new_url + ";letter=3";
		document.getElementById("verificiation_image_4").src = new_url + ";letter=4";
		document.getElementById("verificiation_image_5").src = new_url + ";letter=5";';
		echo '
	}';
	}
        
        }
}
?>
// cargamos las variables de texto.
var $txt = new Array();
<?php foreach($txt['register_javascript'] as $k => $v)
    echo '$txt[\'' . $k . '\'] = ' . '\'' . $v . '\'
        ';
?>

</script>
<?php

}

?>