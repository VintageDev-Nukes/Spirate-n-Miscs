<?php

/*************************************
*      Recent-Gestor v1.2            *
*------------------------------------*
*      Hecho por 002 para Sp v2.4    *
**************************************/

function template_main(){
    global $context, $settings, $options, $txt, $scripturl, $limit_posts, $db_prefix;
    global $PagAnt, $PagAct, $PagSig, $PagUlt, $id;
	
	$contar6= 1;
	$id_cat= $_GET['id'];
	
	$request = db_query("SELECT *
	FROM {$db_prefix}bloques
	ORDER BY ID DESC LIMIT 1", __FILE__, __LINE__);
	while ($row = mysql_fetch_assoc($request)){
		$giros= $row['ID'];
	}
	mysql_free_result($request);
	
$i=0;

do{
$i = $i + 1;
$padding = '';
$requestbloques = db_query("SELECT *
FROM {$db_prefix}bloquesf as f, {$db_prefix}bloques as b
WHERE b.columna = '$i'
AND f.id_columna = b.ID
ORDER BY f.filabloque ASC", __FILE__, __LINE__);
$context['bloques'] = array();
while($row = mysql_fetch_assoc($requestbloques)){
	$context['bloques'][] = array(
		'id_columna' => $row['id_columna'],
		'bloque' => $row['ID_BLOQUE'],
		'titulo' => $row['tibloque'],
		'contenido' => $row['cobloque'],
		'conttipe' => $row['conttipe'],
		'fila' => $row['filabloque'],
		'on' => $row['onbloque'],
		'rss' => $row['rssbloque'],
		'bd' => $row['bdbloque'],
		'ancho' => $row['ancho'],
		'tituloimg' => $row['tituloimg'],
		'contcolor' => $row['contcolor'],
		'bordera' => $row['bordera'],
		'bordert' => $row['bordert'],
		'borderc' => $row['borderc'],
		'custom' => $row['custom']
	);
}
mysql_free_result($requestbloques);

if($i==1){
	$padding= 'margin-right:4px';
}
else if($i==2){
	$padding= 'margin:0 4px';
}
else{
	$padding= 'margin-left:4px';
}
echo'<div style="float:left; ',$padding,';">';

foreach($context['bloques'] as $filas){
	if($filas['on']==1){
		$columnas = $columnas+1;
		$bordes = '';
		$tituloimg = '';
		$contenido = '';
		
		if($filas['bd']!=''){
			eval($filas['bd']);
		}
		
		if($filas['custom']==1){
			$tituloimg = 'background: url('.$filas['tituloimg'].') repeat-x';
			$contenido = 'background:'.$filas['contcolor'];
			$bordes = 'border: '.$filas['bordera'].'px '.$filas['bordert'].' '.$filas['borderc'];
		}
		
		echo'
		<div id="',$columnas,'" style="float:left;clear:left;width:',$filas['ancho'],'px;">
			<div class="box_title" style="',$tituloimg,'">
				',htmlspecialchars($filas['titulo'],ENT_QUOTES,'UTF-8'),'
				<div class="box_rss">
					',$filas['rss'],'
				</div>
			</div><!-- /box_title -->
		<div class="box_cuerpo" style="',$contenido,'; ',$bordes,'">';

		if($filas['conttipe']==bbc){
			$filas['contenido'] = htmlspecialchars($filas['contenido'],ENT_QUOTES,'UTF-8');
			echo parse_bbc($filas['contenido']);
		}
		else{
			eval($filas['contenido']);
		}
		echo'</div><!-- /box_cuerpo -->
		<br class="space" />
		</div><!-- /',$columnas,' -->';
	}
}

echo'</div>';
}while($i<$giros);

}

function ultimos_comments(){
	global $context, $scripturl, $db_prefix;
	$rs = db_query("SELECT c.id_post, c.id_coment, m.subject, m.ID_TOPIC, c.id_user, mem.ID_MEMBER, mem.realName
	FROM ({$db_prefix}comentarios AS c, {$db_prefix}messages AS m, {$db_prefix}members AS mem)
	WHERE id_post = m.ID_TOPIC AND c.id_user = mem.ID_MEMBER
	ORDER BY c.id_coment DESC
	LIMIT 15", __FILE__, __LINE__);
	$context['ult_comms'] = array();
	while ($row = mysql_fetch_assoc($rs))
	$context['ult_comms'][] = array(
		'id_comment' => $row['id_coment'],
		'titulo' => $row['subject'],
		'ID_TOPIC' => $row['ID_TOPIC'],
		'memberName' => $row['memberName'],
		'realName' => $row['realName'],
	);
	mysql_free_result($rs);
	foreach ($context['ult_comms'] as $comments){
		$tamano = 35; 
		$titulo = $comments['titulo'];
		if (strlen($comments['titulo'])>$tamano){
			$comments['titulo']=substr($comments['titulo'],0,$tamano-1)."...";
		}
		echo '<li><strong><a href="',amigables_profile($comments['realName']),'">'.$comments['realName'].'</a></strong> - <a href="',amigables_post($comments['ID_TOPIC']),'#cmt_'.$comments['id_comment'] .'" title="',$titulo,'">'. ucfirst (strtolower(quitarc($comments['titulo']))).'</a></li>';
	}
}

function posts(){
    global $context, $settings, $options, $txt, $scripturl, $limit_posts, $db_prefix;
    global $pagarray, $id;

foreach($context['sticky'] as $st){
	$titulo = censorText($st['title']);
	
	
	echo'
	<ul class="listas">
			<li style="background:#fcf5ab;border:none;margin:1px;margin-top:-2px;">
			<img style="background:none;" title="'.$st['category'].'" src="'. $settings['images_url'] .'/post/icono_'.$st['id_category'].'.gif" align="absmiddle"/>
		
			<span style="float:right;background:none;"><img style="background:none;" title="Sticky" src="'. $settings['images_url'] .'/icons/sticky.png" align="absmiddle"/></span>
			
			<a href="',amigables_post($st['id']),'" title="'.$titulo.'">
				'.$titulo.'
			</a>
		</li>
	</ul><!-- /sticky -->';
}


//Muestro los posts normales
if($context['normal_posts']){
	echo'';
	foreach ($context['normal_posts'] as $np){
	$class= ($i%2)? "backposts" : "backposts2";
	$i++;
		$titulo = censorText($np['title']);
		echo'
		<ul class="listas">
			<li class="'.$class.'">
				<img src="'.$settings['images_url'].'/post/icono_'.$np['id_category'].'.gif" alt="'.$np['category'].'" title="'.$np['category'].'" align="absmiddle"/>
			
			
				<a href="',amigables_post($np['id']),'" title="'.$titulo.'">
					'.utf8_encode (ucfirst (strtolower (substr (utf8_decode($titulo), 0, 47)))).'
				</a>
			';
			if($np['private'] == '1'){
				echo'<span style="float:right;"><span title="Post Privado" class="menuIconnew privado">&nbsp;</span></span>';
			}
			
		echo'
		</li>';
		echo'</ul>';
	}
	
}
else {
	echo'<div class="message yellow">Todav&iacute;a no hay posts. <a class="bold" href="',amigables('?action=post&board=4'),'" title="Crear Post">Agrega el primero!</a></div>';
}

echo'<div class="alignC">';
	  
    echo $pagarray['paginacion'];
	
echo'</div><!-- /alignC -->';


}

function formatMoney($money){
	global $modSettings;
	$money = (float) $money;
	return $modSettings['shopCurrencyPrefix'] . $money;
}


?>