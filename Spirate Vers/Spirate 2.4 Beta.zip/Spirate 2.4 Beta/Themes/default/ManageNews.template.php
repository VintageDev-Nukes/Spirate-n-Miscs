<?php
// Version: 1.1; ManageNews

// Form for editing current news on the site.
function template_edit_news()
{
	global $context, $settings, $options, $scripturl, $txt;

	echo '
<div class="box_title">	', $txt[507], ' <span class="floatR"><input type="checkbox" class="check" onclick="invertAll(this, this.form);" /></span>
	
	</div>
		<form action="', $scripturl, '?action=news;sa=editnews" method="post" accept-charset="', $context['character_set'], '" name="postmodify" id="postmodify">
			<div class="box_cuerpo">
				';

	// Loop through all the current news items so you can edit/remove them.
	foreach ($context['admin_current_news'] as $admin_news)
		echo '
				
						 <span class="floatR">
						 <input type="checkbox" name="remove[]" value="', $admin_news['id'], '" class="check" /></span><div style="margin-bottom: 2ex;"><textarea rows="3" cols="65" name="news[]" style="width: 85%;">', $admin_news['unparsed'], '</textarea></div>
					
						<b>Previa:</b>
						<div class="box-info"><div style="overflow: auto; width: 100%; height: 10ex;">', $admin_news['parsed'], '</div>
					</div>
						
					';

	// This provides an empty text box to add a news item to the site.
	echo '
				
						<div id="moreNewsItems"></div>
						<div id="moreNewsItems_link" style="display: none;"><a href="javascript:void(0);" onclick="addNewsItem(); return false;"><b>', $txt['editnews_clickadd'], '<b></a></div>
						<br /><script language="JavaScript" type="text/javascript"><!-- // --><![CDATA[
							document.getElementById("moreNewsItems_link").style.display = "";

							function addNewsItem()
							{
								setOuterHTML(document.getElementById("moreNewsItems"), \'<div style="margin-bottom: 2ex;"><textarea rows="3" cols="65" name="news[]" style="width: 85%;"></textarea></div><div id="moreNewsItems"></div>\');
							}
						// ]]></script>
						<noscript>
							<div style="margin-bottom: 2ex;"><textarea rows="3" cols="65" style="width: 85%;" name="news[]"></textarea></div>
						</noscript>
					
					
						<input  class="sp-button bluesky" type="submit" name="save_items" value="Guardar" /> <input  class="sp-button bluesky" type="submit" name="delete_selection" value="', $txt['editnews_remove_selected'], '" onclick="return confirm(\'', $txt['editnews_remove_confirm'], '\');" />
					
			<input type="hidden" name="sc" value="', $context['session_id'], '" />
		</form></div>';
}

function template_email_members()
{
	global $context, $settings, $options, $txt, $scripturl;

	            echo '
		        <form action="', $scripturl, '?action=news;sa=mailingcompose" method="post" accept-charset="', $context['character_set'], '">
				<div class="box_title">', $txt[6], '</div>
				<div class="box_cuerpo">
				<div class="configBloqs" style="border-bottom: 0 none;">', $txt['smf250'], '</div><br><div class="noHover"><space></div>';

	            foreach ($context['groups'] as $group)
				echo '
				<div class="configBloqs"><label for="who_', $group['id'], '"><input type="checkbox" name="who[', $group['id'], ']" id="who_', $group['id'], '" value="', $group['id'], '" checked="checked" class="check" /> ', $group['name'], '</label> <i>(', $group['member_count'], ')</i></div>';

	            echo '
				<br><br><div class="configBloqs">
			    <label for="checkAllGroups"><input type="checkbox" id="checkAllGroups" checked="checked" onclick="invertAll(this, this.form, \'who\');" class="check" /> <i>', $txt[737], '</i></label><br />
                </div>
				';

	            if ($context['can_send_pm'])
		        echo '
				<div class="configBloqs"><label for="sendPM"><input type="checkbox" name="sendPM" id="sendPM" value="1" class="check" /> ', $txt['email_as_pms'], '</label></div>';
                echo '
				<div class="configBloqs"><label for="email_force"><input type="checkbox" name="email_force" id="email_force" value="1" class="check" /> ', $txt['email_force'], '</label></div>
				<div class="configBloqs" style="border-bottom: 0 none;"><input class="sp-button bluesky" type="submit" style="margin-left: 680px;" value="', $txt[65], '" /></div>
			    <input type="hidden" name="sc" value="', $context['session_id'], '" />
		        </form></div>';
}

function template_email_members_compose()
{
	global $context, $settings, $options, $txt, $scripturl;

	            echo '
		        <form action="', $scripturl, '?action=news;sa=mailingsend" method="post" accept-charset="', $context['character_set'], '">
			    <div class="box_title"> ', $txt[6], '</div>
				<div class="box_cuerpo">	
				<div class="configBloqs">', $txt[735], '</div>
				<div class="configBloqs">
				<center><textarea cols="70" rows="7" name="emails" class="editor">', $context['addresses'], '</textarea></center>
			    </div>
			    </div>
			    <br>
				<div class="box_title">', $txt[338], '</div>
				<div class="box_cuerpo">
				<div class="configBloqs">', $txt['email_variables'], '</div>
				<div class="configBloqs">
				<center><input type="text" name="subject" size="60" value="', $context['default_subject'], '" /></center>
				</div>
				<div class="configBloqs"><center><textarea cols="70" rows="9" name="message" class="editor">', $context['default_message'], '</textarea></center></div>
				<div class="configBloqs"><label for="send_html"><input type="checkbox" name="send_html" id="send_html" class="check" onclick="this.form.parse_html.disabled = !this.checked;" /> ', $txt['email_as_html'], '</label></div>
				<div class="configBloqs"><label for="parse_html"><input type="checkbox" name="parse_html" id="parse_html" checked="checked" disabled="disabled" class="check" /> ', $txt['email_parsed_html'], '</label></div>
				<div class="configBloqs" style="border-bottom: 0 none;"><input style="margin-left: 680px;" class="sp-button bluesky" type="submit" value="', $txt['sendtopic_send'], '" /></div>
			    <input type="hidden"  name="sc" value="', $context['session_id'], '" />
		        </form></div>';
}

function template_email_members_send()
{
	global $context, $settings, $options, $txt, $scripturl;

	echo '
		<form action="', $scripturl, '?action=news;sa=mailingsend" method="post" accept-charset="', $context['character_set'], '" name="autoSubmit" id="autoSubmit">
			<table width="600" cellpadding="4" cellspacing="0" border="0" align="center" class="tborder">
				<tr class="titlebg">
					<td>
						<a href="', $scripturl, '?action=helpadmin;help=email_members" onclick="return reqWin(this.href);" class="help"><img src="', $settings['images_url'], '/helptopics.gif" alt="', $txt[119], '" align="top" /></a> ', $txt[6], '
					</td>
				</tr><tr>
					<td class="windowbg2"><b>', $context['percentage_done'], '% ', $txt['email_done'], '</b></td>
				</tr><tr>
					<td class="windowbg2" style="padding-bottom: 1ex;" align="center">
						<input type="submit" name="b" value="', $txt['email_continue'], '" />
					</td>
				</tr>
			</table>
			<input type="hidden" name="sc" value="', $context['session_id'], '" />
			<input type="hidden" name="emails" value="', $context['emails'], '" />
			<input type="hidden" name="subject" value="', $context['subject'], '" />
			<input type="hidden" name="message" value="', $context['message'], '" />
			<input type="hidden" name="start" value="', $context['start'], '" />
			<input type="hidden" name="send_html" value="', $context['send_html'], '" />
			<input type="hidden" name="parse_html" value="', $context['parse_html'], '" />
		</form>
		<script language="JavaScript" type="text/javascript"><!-- // --><![CDATA[
			var countdown = 2;
			doAutoSubmit();

			function doAutoSubmit()
			{
				if (countdown == 0)
					document.forms.autoSubmit.submit();
				else if (countdown == -1)
					return;

				document.forms.autoSubmit.b.value = "', $txt['email_continue'], ' (" + countdown + ")";
				countdown--;

				setTimeout("doAutoSubmit();", 1000);
			}
		// ]]></script>';
}

function template_news_settings()
{
	global $context, $settings, $options, $scripturl, $txt, $modSettings;

	echo '
	<form action="', $scripturl, '?action=news;sa=settings" method="post" accept-charset="', $context['character_set'], '">
		
			
				<div class="box_title">', $txt['settings'], '</div><div class="box_cuerpo">
			';
	if ($context['can_change_permissions'])
	{
	echo '
			<div class="configBloqs">
				', $txt['groups_edit_news'], ':
				';
		theme_inline_permissions('edit_news');
		echo '
				</div>
			<div class="configBloqs">', $txt['groups_send_mail'], ':	';
		theme_inline_permissions('send_mail');
		echo '
				
				</div>	';
	}
	echo '
			<div class="configBloqs">', $txt['xmlnews_enable'], '</label> (<a href="', $scripturl, '?action=helpadmin;help=xmlnews_enable" onclick="return reqWin(this.href);">?</a>):
				
					<input type="checkbox" name="xmlnews_enable" id="xmlnews_enable_check"', empty($modSettings['xmlnews_enable']) ? '' : ' checked="checked"', ' class="check" onclick="document.getElementById(\'xmlnews_maxlen_input\').disabled = !this.checked;" />
				</div>
		
			
			<div class="configBloqs">
			Longitud m&aacute;xima del mensaje:
					<input type="hidden" name="xmlnews_maxlen" value="', empty($modSettings['xmlnews_maxlen']) ? '0' : $modSettings['xmlnews_maxlen'], '" />
					<input type="text" name="xmlnews_maxlen" id="xmlnews_maxlen_input" value="', empty($modSettings['xmlnews_maxlen']) ? '0' : $modSettings['xmlnews_maxlen'], '" />
					<script language="JavaScript" type="text/javascript"><!-- // --><![CDATA[
						document.getElementById("xmlnews_maxlen_input").disabled = !document.getElementById("xmlnews_enable_check").checked;
					// ]]></script>(cero para deshabilitarlo.)
</div>
			<div class="configBloqs" style="border-bottom: 0 none;">		<input type="submit" style="margin-left: 680px;" class="sp-button bluesky" name="save_settings" value="', $txt['news_settings_submit'], '" /></div>
				
		<input type="hidden" name="sc" value="', $context['session_id'], '" />
	</div></form>';
}

?>