<?php
// Spirate Script - Version 2.4

function template_enlazanos(){
	global $context, $settings, $options, $txt, $scripturl, $modSettings, $mbname,$boardurl;

// me cargo el index.php de la ruta
$ruta = $boardurl;
$titul=$mbname;

echo'
	<div class="box_title">
		'.$txt['enlazanos'].'
	</div><!-- /box_title -->
	<div class="box_cuerpo">

    <table border="1px" bgcolor="#FFFFFF" align="center" width="100%">
		<td width="100" nowrap="nowrap">
			<a tile="'; echo $titul; echo'" href="'.$ruta.'">
			<p align="center">
				<img src="'.$ruta.'/web/enlazanos/16x16.gif" alt="'; echo $titul; echo'" width="16" border="0" height="16" />
			</p>
		</td>
		<td class="windowbg2" style="background:#FFF;border:1px dashed #424242" width="751">&lt;a title="'; echo $titul; echo'" href="'.$ruta.'"&gt;<br>
		&lt;img src="'.$ruta.'/web/enlazanos/16x16.gif" alt="'; echo $titul; echo'" width="16" border="0" height="16" /&gt;<br>

					&lt;/a&gt;</td><tr>

					<td width="100" nowrap="nowrap"><a title="'; echo $titul; echo'" href="'.$ruta.'">

	<p align="center"><img src="'.$ruta.'/web/enlazanos/88x31.gif" alt="'; echo $titul; echo'" border="0"></td>

	<td class="windowbg2" width="751" style="background:#FFF;border:1px dashed #424242">&lt;a title="'; echo $titul; echo'" href="'.$ruta.'"&gt;<br>

					&lt;img src="'.$ruta.'/web/enlazanos/88x31.gif" alt="'; echo $titul; echo'" width="88" border="0" height="31" /&gt;<br>

					&lt;/a&gt;</td></tr><tr><td width="100" nowrap="nowrap"><a title="'; echo $titul; echo'" href="'.$ruta.'">

	<p align="center"><img src="'.$ruta.'/web/enlazanos/100x20.gif" alt="'; echo $titul; echo'"border="0"></td>

	<td class="windowbg2" width="751" style="background:#FFF;border:1px dashed #424242">&lt;a title="'; echo $titul; echo'" href="'.$ruta.'"&gt;<br>

					&lt;img src="'.$ruta.'/web/enlazanos/100x20.gif" alt="'; echo $titul; echo'" width="100" border="0" height="20" /&gt;<br>

					&lt;/a&gt;</td></tr>

					<tr><td width="100" nowrap="nowrap"><a title="'; echo $titul; echo'" href="'.$ruta.'">

	<p align="center"><img src="'.$ruta.'/web/enlazanos/125x125.gif" alt="'; echo $titul; echo'" width="125" border="0" height="125"></td>

	<td class="windowbg2" width="751" style="background:#FFF;border:1px dashed #424242">&lt;a title="'; echo $titul; echo'" href="'.$ruta.'"&gt;<br>

					&lt;img src="'.$ruta.'/web/enlazanos/125x125.gif" alt="'; echo $titul; echo'" width="125" border="0" height="125" /&gt;<br>

					&lt;/a&gt;</td></tr></table>

	</div><!-- /box_cuerpo -->';

echo'<!-- esta web usa small pirate script -->';

}

function template_enviado(){
	global $txt, $scripturl;

echo'
	<div class="box_title">
		'.$txt['contacto_title'].'
	</div><!-- /box_title -->
	<div class="box_cuerpo alignC">
		<div class="MailEnviado">El mail fue enviado correctamente</div>
		<br />
		<br />
		<a href="',$scripturl,'">
			<input class="button" type="button" value="Inicio" />
		</a>
	</div><!-- /box_cuerpo -->';
}

function template_intro(){

	global $context, $settings, $options, $txt, $scripturl, $modSettings, $boardurl;

$ip = $_SERVER['REMOTE_ADDR'];

echo'
	<div class="box_title">
		'.$txt['contacto_title'].'
	</div><!-- /box_title -->
	<div class="box_cuerpo alignC">
<center><div id="Contacto_Contenedor">
<script type="text/JavaScript">
<!--
function MM_findObj(n, d) { //v4.01
	var p,i,x;  if(!d) d=document; if((p=n.indexOf("?"))>0&&parent.frames.length){
		d=parent.frames[n.substring(p+1)].document; n=n.substring(0,p);
	}
	if(!(x=d[n])&&d.all)
		x=d.all[n];
	
	for (i=0;!x&&i<d.forms.length;i++)
		x=d.forms[i][n];
	for(i=0;!x&&d.layers&&i<d.layers.length;i++)
		x=MM_findObj(n,d.layers[i].document);
	
	if(!x && d.getElementById)
		x=d.getElementById(n);
		return x;
}



function MM_validateForm() { //v4.0

  var i,p,q,nm,test,num,min,max,errors=\'\',args=MM_validateForm.arguments;

  for (i=0; i<(args.length-2); i+=3) { test=args[i+2]; val=MM_findObj(args[i]);

    if (val) { nm=val.name; if ((val=val.value)!="") {

      if (test.indexOf(\'isEmail\')!=-1) { p=val.indexOf(\'@\');

        if (p<1 || p==(val.length-1)) errors+=\'- \'+nm+\' must contain an e-mail address.\n\';

      } else if (test!=\'R\') { num = parseFloat(val);

        if (isNaN(val)) errors+=\'- \'+nm+\' must contain a number.\n\';

        if (test.indexOf(\'inRange\') != -1) { p=test.indexOf(\':\');

          min=test.substring(8,p); max=test.substring(p+1);

          if (num<min || max<num) errors+=\'- \'+nm+\' must contain a number between \'+min+\' and \'+max+\'.\n\';

    } } } else if (test.charAt(0) == \'R\') errors += \'- \'+nm+\' es requerido.\n\'; }

  } if (errors) alert(\'Han ocurrido los siguientes errores:\n\'+errors);

  document.MM_returnValue = (errors == \'\');

}

//-->

</script>

<form action="',$boardurl,'/web/contacto/mailer.php" method="post" name="form1" id="form1"  onsubmit="MM_validateForm(\'from\',\'\',\'RisEmail\',\'asunto\',\'\',\'R\',\'verif_box\',\'\',\'R\',\'mensaje\',\'\',\'R\');return document.MM_returnValue">

<li class="contacoPasos"><b>',$txt['contacto_Email'],'</b><br />

<input name="from" type="text" id="from" style="width: 184px;" value="',$_GET['from'],'"/>

</li>



<li class="contacoPasos"><b>',$txt['contacto_Asunto'],'</b><br />

<input name="asunto" type="text" id="asunto" style="width: 184px;" value="',$_GET['asunto'],'"/>

</li>



<li class="contacoPasos"><b>',$txt['contacto_Comentarios'],'</b><br />

<textarea name="mensaje" cols="6" rows="5" id="mensaje" style="padding:2px; border:1px solid #CCCCCC; width:300px; height:100px; font-family:Verdana, Arial, Helvetica, sans-serif; font-size:11px;">',$_GET['mensaje'],'</textarea>

</li>



<li class="contacoPasos"><b>',$txt['contacto_imagen_code'],'</b><br />

<img src="',$boardurl,'/web/contacto/verificationimage.php?<?php echo rand(0,9999);?>" alt="Im&aacute;gen de Verificaci&oacute;n" width="50" height="24" align="absbottom" /><br />

<input name="verif_box" type="text" id="verif_box" style="width: 184px;"/>

</li>

<!-- if the variable "wrong_code" is sent from previous page then display the error field -->

';

if(isset($_GET['wrong_code'])){
    echo '<div style="border:1px solid #990000; background-color:#D70000; color:#FFFFFF; padding:4px; padding-left:6px;width:295px;">',$txt['contacto_wrong_code'],'</div><br />';
}

echo '

<br />
<input class="login" name="Submit" type="submit" style="font-size: 10px;" size="50" value="Enviar" title="Enviar"/>
</form>
<br />
<span class="size9">',$txt['contacto_ip_save'],' ',$ip,' ',$txt['contacto_ip_saveb'],'
</div></div></center><!-- /box_cuerpo -->'; 

}
function template_protocolo(){
	global $txt,$context;
	echo '
	<style>
	.BlocD{
		color: #444444;
		font-size: 14px;
		line-height: 25px;
		margin-bottom: 20px;
		padding: 0;
	}
	.BlocD h1{
		
		line-height: 25px;
		
	}</style>
	
	<div class="left cleafix" style="width:230px; margin-right: 20px">';
echo '<h3 class="blue" style="margin-left: 10px">Navegaci&oacute;n</h3>';
echo '<div class="box-selection">
        <div class="context">
            <ul>
                <li class="selected first-child"><a href="#Section_1">'.$txt['Protocolo'].'</a><i class="arrow"></i></li>
                <li><a href="#Section_2">Sobre los Posts</a><i class="arrow"></i></li>
                <li><a href="',$scripturl,'?action=terminos">T&eacute;rminos</a><i class="arrow"></i></li>
            </ul>
        </div>
     </div>';
	echo'
	</div>
	<div class="left cleafix" style="width:700px; margin-right: 20px">
		
	<div class="box-border-striped" id="Section_1">
		<div class="stripes"></div>
			<div class="content">
				<div class="header">
					<h3>	'.$txt['Protocolo'].'</h3>
					<hr />
				</div>
		<p class="BlocD">
		Este es un sitio de entretenimiento para usuarios de habla hispana en el cual los usuarios comparten informaci&oacute;n de diversas tem&aacute;ticas (links, im&aacute;genes, noticias, v&iacute;deos, etc.) por medio de posts.<br><br>Esta web fu&eacute; creada con la idea de responder a consultas o debatir temas como tal Web.<br><br>Los moderadores son los encargados de filtrar, eliminar o editar la informaci&oacute;n que se comparte, de esta forma se evita que el contenido se transforme en una gran cantidad de "nada" y siempre se mantenga con la mejor calidad posible. Existen reglas en las cuales se basa la filosof&iacute;a de administraci&oacute;n llamado protocolo y se detalla a continuaci&oacute;n.</p>
			</div>
	</div>
	
	
		
	<div class="box-border-striped orange" id="Section_2">
		<div class="stripes"></div>
			<div class="content">
				<div class="header">
					<h3>Relaci&oacute;n a Publicaciones</h3>
					<hr />
				</div>

		<p class="BlocD">
			<p>* Asunto sin MAYUSCULAS (ya que esto ind&iacute;ca que se est&aacute; gritando).</p>
<p>* Que el tama&ntilde;o de la letra sea el adecuado (Pueden haber exepciones en plabras importantes).</p>
<p>* Ser lo m&aacute;s descriptivo o lo m&aacute;s claro posible, a la hora de postear, para evitar malentendidos o que su comentario o post sea eliminado.</p>
<p>* Postear temas en la categor&iacute;a correspondiente.</p>
<p>* Fijarse que los links funcionen correctamente.</p>
<p>* No revelar Informaci&oacute;n personal propia o de terceros tales como e-mail, msn, nombres, apellidos, tel&eacute;fonos, etc... La web no se hace cargo de problemas al publicar tal contenido.)</p>
<br />
<p><h2>+ Se eliminan los post:</h2></p>
<p>* Que est&eacute; considerado SPAM</p>
<p>* Que sea Repost.</p>
<p>* Que contenga un vocabulario vulgar.</p>
<p>* Que haga referencia a la violacion de los derechos humanos.</p>
<p>* Que tenga enlaces rotos.</p>
<p>* Que los soft esten sin licencia (DEMO).</p>
<p>* Que contenga material pornogr&aacute;fico (Im&aacute;genes, Videos, Enlaces, etc).</p>
<br />
<p><h2>+ Se modifican los post que contengan:</h2></p>
<p>* Que no cumpla con las caracteristicas para postear.</p>
<p>* Titulo con opinion propia.</p>
<p>* Que contenga faltas de ortograf&iacute;a.</p>
<p>* Post con mayor de 1000 comentario (Se cierra los comentarios).</p>
<br />
<p><h2>+ Se eliminan comentarios que contengan:</h2></p>
<p>* May&uacute;sculas o con abuso de may&uacute;sculas.</p>
<p>* Que el usuario halla comentado primero su post.</p>
<p>* Insultos, ofensas, etc. (hacia otro usuario o de forma general).</p>
<p>* Comentarios racistas.</p>
<p>* Tipograf&iacute;as muy grandes o con el claro efecto de llamar la atenci&oacute;n.</p>
<p>* SPAM.</p>
<br />
<p><h2>+ Se eliminan o suspende a los usuarios que:</h2></p>
<p>* Que el usuario halla comentado primero su post o im&aacute;gen (en su galer&iacute;a).</p>
<p>* Comentarios racistas.</p>
<p>* Usuarios que postea material pornogr&aacute;fico o material con morbo</p>
<br />
<p><h2>+ Se modifican a los usuario:</h2></p>
<p>* Cuando tiene una firma con SPAM.</p>
<p>* Cuando tiene mensaje personal con SPAM.</p>
<p>* Cuando tiene un avatar con contenido pornografico.</p>
<p>* Cuando URL del avatar no funciona.</p>
<br />
<p><h2>+ Se eliminan o modifica las im&aacute;genes en la galer&iacute;a que contengan:</h2></p>
<p>* SPAM (Im&aacute;gen con url de un sitio)</p>
<p>* Imagenes con pornograf&iacute;a.</p>
<p>* Im&aacute;genes morbosas.</p>
<br />
<p><h2>+ Se eliminan los comentarios en la galeria que contengan:</h2></p>
<p>* SPAM</p>
<p>* Insultos, ofensas, descriminaci&oacute;n, etc. (hacia otro usuario o de forma general).</p>
<p>* Tipograf&iacute;as muy grandes o con el claro efecto de llamar la atenci&oacute;n.</p>
<p>* May&uacute;sculas o con abuso de may&uacute;sculas.</p>
<p>* Que el usuario halla comentado primero su im&aacute;gen.</p></p></div>
	</div></div>


	<!-- Small Pirate - Social Community Script -->';
}
function template_terminos(){
	global $txt,$context;
	echo '
	<style>
	.BlocD{
		color: #444444;
		font-size: 14px;
		line-height: 25px;
		margin-bottom: 20px;
		padding: 0;
	}
	.BlocD h1{
		
		line-height: 25px;
		
	}</style>
	
	<div class="left cleafix" style="width:230px; margin-right: 20px">';
echo '<h3 class="blue" style="margin-left: 10px">Navegaci&oacute;n</h3>';
echo '<div class="box-selection">
        <div class="context">
            <ul>
                <li class="selected first-child"><a href="#Section_1">'.$txt['terminos_title'].'</a><i class="arrow"></i></li>
                <li><a href="#Section_2">Aceptaci&oacute;n / usuarios</a><i class="arrow"></i></li>
                <li><a href="#Section_3">Legal / usuarios</a><i class="arrow"></i></li>
                <li><a href="#Section_4">Registro / usuarios</a><i class="arrow"></i></li>
                <li><a href="#Section_5">Comunicaci&oacute;n / usuarios</a><i class="arrow"></i></li>
              
            </ul>
        </div>
     </div>';
	echo'
	</div>
	<div class="left cleafix" style="width:700px; margin-right: 20px">
	
	<div class="box-border-striped" id="Section_1">
		<div class="stripes"></div>
			<div class="content">
				<div class="header">
					<h3>'.$txt['terminos_condiciones_title'].'</h3>
					<hr />
				</div>
		<p class="BlocD">
			En forma previa a la utilizaci&oacute;n de cualquier servicio o contenido ofrecido en ' . $context['forum_name'] . ', debe leerse completa y atentamente este documento. <br />
				Las presentes Condiciones Generales constituyen las normas y reglas dispuestas por ' . $context['forum_name'] . ', relativas a todos los servicios existentes actualmente o que resulten incluidos en el futuro dentro del sitio ' . $context['forum_name'] . ' (el Sitio). Dichos servicios si bien pueden ser gratuitos, no son de libre utilizaci&oacute;n, sino que est&aacute;n sujetos a un conjunto de pautas que regulan su uso. El aprovechamiento que un individuo haga de los servicios incluidos en el Sitio, s&oacute;lo se considerar&aacute; l&iacute;cito y autorizado cuando lo sea en cumplimiento de las obligaciones impuestas, con los l&iacute;mites y alcances aqu&iacute; delineados, as&iacute; como los que surjan de disposiciones complementarias o accesorias, y/o de las diferentes normativas legales de orden nacional e internacional cuya aplicaci&oacute;n corresponda. <br /><br />
					' . $context['forum_name'] . ' podr&aacute; en cualquier momento y sin necesidad de previo aviso modificar estas Condiciones Generales. Tales modificaciones ser&aacute;n operativas a partir de su fijaci&oacute;n en el sitio ' . $context['forum_name'] . '. Los usuarios deber&aacute;n mantenerse actualizados en cuanto al los t&eacute;rminos aqu&iacute; incluidos ingresando en forma peri&oacute;dica al apartado de legales de ' . $context['forum_name'] . '.
		</p></div>
	</div>
	
		<div class="box-border-striped orange" id="Section_2">
		<div class="stripes"></div>
			<div class="content">
				<div class="header">
					<h3>La aceptaci&oacute;n por parte de los Usuarios</h3>
					<hr />
				</div>
		<p class="BlocD">
			' . $context['forum_name'] . ', se reserva el derecho a exigir que cada usuario, acepte y cumpla los t&eacute;rminos aqu&iacute; expresados como condici&oacute;n previa y necesaria para el acceso, y utilizaci&oacute;n de los servicios y/o contenidos brindados por el Sitio.
				Cuando un usuario accediere al Sitio y utilizare cualquiera de los servicios y/o contenidos existentes, har&aacute; presumir el conocimiento del presente texto y que ha manifestado su plena aceptaci&oacute;n con respecto a todas y cada una de las disposiciones que lo integran.
					El usuario que no acepte, se halle en desacuerdo, o incurriere en incumplimiento de las disposiciones fijadas por la ' . $context['forum_name'] . ' en estas Condiciones Generales, no contar&aacute; con autorizaci&oacute;n para el uso de los servicios y contenidos que existen o puedan existir en el Sitio, debiendo retirarse del Sitio en forma inmediata, y abstenerse de ingresar nuevamente al mismo.
		</p></div>
	</div>
	
	
		<div class="box-border-striped green" id="Section_3">
		<div class="stripes"></div>
			<div class="content">
				<div class="header">
					<h3>Capacidad legal de los usuarios.</h3>
					<hr />
				</div>
		<p class="BlocD">
			Solo podr&aacute;n acceder y utilizar los servicios y/o contenidos de ' . $context['forum_name'] . ', quienes a tenor de la legislaci&oacute;n vigente en su lugar de residencia puedan v&aacute;lidamente emitir su consentimiento para la celebraci&oacute;n de contratos. Quienes a tenor de la legislaci&oacute;n vigente no posean tal capacidad para acceder u obligarse v&aacute;lidamente a los t&eacute;rminos y condiciones aqu&iacute; establecidos, deber&aacute;n obtener inexcusablemente autorizaci&oacute;n previa de sus representantes legales, quienes ser&aacute;n considerados responsables de todos los actos realizados por los incapaces a su cargo.
				Cuando se trate de falta de capacidad por minor&iacute;a de edad, la responsabilidad en la determinaci&oacute;n de los servicios y contenidos a los que acceden los menores de edad corresponde a los mayores a cuyo cargo se encuentren, sin embargo en ning&uacute;n caso estar&aacute; permitido el acceso al sitio por parte de menores de 18 a&ntilde;os de edad.
		</p></div>
	</div>
	

	
<div class="box-border-striped" id="Section_4">
		<div class="stripes"></div>
			<div class="content">
				<div class="header">
					<h3>Registro de los Usuarios.</h3>
					<hr />
				</div>
		<p class="BlocD">
			Para valerse de los servicios prestados en ' . $context['forum_name'] . ', basta la sola aceptaci&oacute;n de estas Condiciones Generales. Sin embargo para la utilizaci&oacute;n de algunos servicios o el acceso a ciertos contenidos, podr&aacute; establecerse como requisito, el previo registro del usuario. Dicho registro tendr&aacute; por finalidad establecer la identidad e informaci&oacute;n de contacto del usuario.
	Toda vez que para la registraci&oacute;n de un usuario le sea requerida informaci&oacute;n, la misma deber&aacute; ser fidedigna, y poseer&aacute; el car&aacute;cter de declaraci&oacute;n jurada. Cuando la informaci&oacute;n suministrada no atienda a las circunstancias reales de quien la brinda, se considerara tal usuario incurso en incumplimiento de estas Condiciones Generales, siendo responsable por todos los perjuicios que derivaren para ' . $context['forum_name'] . ' o terceros como consecuencia de tal falta de veracidad o exactitud.
	El usuario dispondr&aacute;, una vez registrado, de un nombre de usuario y una contrase&ntilde;a que le permitir&aacute; el acceso personalizado, confidencial y seguro a su cuenta personal dentro del Sitio. Los servicios sujetos a registraci&oacute;n han sido concebidos para el uso personal del usuario requirente, por tanto el nombre de usuario y la contrase&ntilde;a de acceso concedidos por ' . $context['forum_name'] . ' solo podr&aacute;n ser usados por este, estando prohibida su utilizaci&oacute;n por otra persona distinta al mismo. El usuario registrado asumir&aacute; la obligaci&oacute;n de guarda y custodia de su nombre de usuario y contrase&ntilde;a de acceso, debiendo informar inmediatamente a ' . $context['forum_name'] . ' cuando los mismos hubieren perdido su estado de confidencialidad, y/o cuando sean objeto de uso por un tercero.
	Ser&aacute; tambi&eacute;n responsabilidad de cada usuario mantener actualizada su informaci&oacute;n personal asentada en el registro conforme resulte necesario, debiendo comunicar a ' . $context['forum_name'] . ' toda vez que se produzcan cambios en relaci&oacute;n a la misma.
	' . $context['forum_name'] . ' podr&aacute; rechazar cualquier solicitud de registraci&oacute;n o, cancelar una registraci&oacute;n previamente aceptada, sin que tal decisi&oacute;n deba ser justificada, y sin que ello genere derecho alguno en beneficio del Usuario.
	' . $context['forum_name'] . ' utilizar&aacute; la informaci&oacute;n suministrada por el usuario exclusivamente con el objeto expuesto, y en todo momento velar&aacute; por el razonable resguardo a la intimidad y confidencialidad de las comunicaciones del usuario, pero atento que ' . $context['forum_name'] . ' hace uso de sistemas tecnol&oacute;gicos que bajo ciertas condiciones pueden resultar falibles, se pone en conocimiento de los usuarios que ' . $context['forum_name'] . ' no garantiza la inviolabilidad de sus sistemas, motivo por el cual los usuarios deber&aacute;n tomar en consideraci&oacute;n esta circunstancia al momento de decidir su registraci&oacute;n.
	En todos los casos, y de acuerdo con la Pol&iacute;tica de Privacidad sostenida por ' . $context['forum_name'] . ', la informaci&oacute;n de car&aacute;cter personal suministrada por los Usuarios ser&aacute; objeto de adecuado tratamiento y preservaci&oacute;n, en resguardo de la privacidad de la misma. Sin embargo, los servicios de ' . $context['forum_name'] . ' fueron dise&ntilde;ados entre otros fines para permitir que los usuarios accedan a ciertos datos (no sensibles) de otros usuarios permitiendo la interacci&oacute;n entre los mismos dentro de un esquema de red social. Por consiguiente, haciendo entrega de cualquier informaci&oacute;n personal distinta de su nombre, el usuario renuncia a cualquier expectativa de privacidad que posea con respecto al uso de esa informaci&oacute;n personal proporcionada dentro del sitio. Los usuarios que no deseen que su fotograf&iacute;a o imagen, p&aacute;gina web, mensajero, ciudad de residencia, nacionalidad, o descripci&oacute;n personal ingresadas en el Sitio, puedan ser brindadas al p&uacute;blico no deber&aacute;n registrarse en ' . $context['forum_name'] . '
		</p></div>
	</div>
	
	
	<div class="box-border-striped orange" id="Section_5">
		<div class="stripes"></div>
			<div class="content">
				<div class="header">
					<h3>Notificaciones y comunicaciones.</h3>
					<hr />
				</div>
	<p class="BlocD">
			A los fines que los usuarios puedan tomar contacto con ' . $context['forum_name'] . ', se considerar&aacute;n v&aacute;lidas las comunicaciones dirigidas al correo de la web.
			Las notificaciones y comunicaciones cursadas por ' . $context['forum_name'] . ' a la casilla de correo electr&oacute;nico que surja como direcci&oacute;n de correo del usuario o remitente se considerar&aacute;n eficaces y plenamente v&aacute;lidas. Asimismo se considerar&aacute;n eficaces las comunicaciones que consistan en avisos y mensajes insertos en el sitio, o que se env&iacute;en durante la prestaci&oacute;n de un servicio, que tengan por finalidad informar a los usuarios sobre determinada circunstancia.   
		</p></div>
	</div></div>
	<!-- Small Pirate - Social Community Script -->';
}

function template_AdminPaises(){

	global $settings, $user_info, $language, $context, $txt, $db_prefix, $subActions;
		
        if (!empty($subActions[@$_GET['get']]) && $_GET['get']=='guardar')
		$subActions[$_GET['get']]();

echo'<div class="box_title">',$txt['pais_ae_country'],'</div>
     <div class="box_cuerpo">
	 <table style="margin:5px;width:100%"><tr>
	 <td>',$txt['pais_select_edit'],'</td>
	 <td>',$txt['pais_add'],'</td>
	 </tr><tr>
	 <td width="50%" valign="top" style="border-right:2px dotted #CCCCCC">
         <form name="elegirpais">
	 
	 ',$txt['pais_country'],' <select name="paisedit" onChange="javascript:getpais(this.form);">
	 <option value="-1">',$txt['pais_select'],'</option>';
	 foreach($context['paises'] as $p)
	 {echo'<option value="',$p['ID_PAIS'],'">',$p['nombre'],'</option>';}
	        
echo'</select><br />
     <div id="cargando" style="display:none;float:right;">
     <img alt="" src="',$settings['images_url'],'/loading.gif" style="width: 16px; height: 16px;" border="0">
     </div>
         <span id="paisin"></span>
         </form>
	 </td>
	 <td width="50%" valign="top">
         <form action="'.$scripturl.'?action=paises;get=guardar" method="POST" name="creando">
	 ',$txt['pais_name'],': <input type="text" name="nombre" style="width:250px"><br><br>
	 ',$txt['pais_name_img'],': <input type="text" name="img" style="width:100px">.png<br>
	 ',$txt['pais_img_help'],'<br><br>
	 <center><input type="submit" class="button" value="',$txt['pais_create'],'"></center>
         </form>
	 </td>
	 </tr></table></div>';
}

?>