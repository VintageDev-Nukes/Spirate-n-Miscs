<?php
// Spirate Script - Version 2.4
if (!defined('SPIRATE'))
	die('Hacking attempt...');

function template_pm_above(){

	global $context, $settings, $options, $txt, $scripturl, $boardurl;

    /* Remove Padding from .globalcontent */
    echo '<style type="text/css">

    #main .globalcontent{
        padding:0 !important;
    }
    </style>';

    echo '<div class="main-content-pm-area">
            <div class="col-left-pm equal-height clearfix">
            <h3>'.$context['page_title'].'</h3>
            <ul class="pm-areas">';
            $unread_messages = (int) $context['pm_areas']['folders']['areas']['inbox']['unread_messages'];
    
            foreach ($context['pm_areas'] as $section)
                foreach ($section['areas'] as $i => $area)
                    echo '<li  class="'.($i == $context['pm_area'] ? 'selected ' : '').'clearfix"><i class="icon pm-' . ($i == $context['pm_area'] ? $i . ' selected' : $i) . '"></i><a class="relative left" href="' . $area['href'] . '">'.$area['txt'].'  '.(!empty($unread_messages) && $i == 'inbox' ? '<div class="bubble-notify relative right" style="top: -12px; right: 0px;"><span class="arrow"></span><span class="data"><i>'. $unread_messages .'</i></span><span class="right"></span></div>' : '').'</a></li>';
            echo '</ul>';

            
	if($context['pm_areas']['labels'])

		echo'<span class="size10">',$txt['pm_select_folder'],' <input class="sp-button bluesky" type="submit" name="delete" value="',$txt['pm_delete'],'" style="font-weight: normal;" onclick="return confirm(',$txt['pm_sure_delete_folder'],');" />

		</span>'; else echo'';

    echo '</div>'; 


	echo '<div class="col-right-pm clearfix">';
              if($_GET['sa'] != 'send'){
                echo '<div class="optionArea clearfix"><form action="',$scripturl,'?action=pm;sa=pmactions;f=', $context['folder'], ';start=', $context['start'], $context['current_label_id'] != -1 ? ';l=' . $context['current_label_id'] : '', '" method="post" accept-charset="', $context['character_set'], '" name="pmFolder" id="pmFolder">';
				echo '<div class="left padding-10">
                  <ul class="sort_options clearfix">
				  <li><strong>Ordenar por:</strong></li>
                  <li><a', $context['sort_by'] == 'subject' ? ' class="selected rounded"' : '' ,' href="', $scripturl, '?action=pm;f=', $context['folder'], ';start=', $context['start'], ';sort=subject', $context['sort_by'] == 'subject' && $context['sort_direction'] == 'up' ? ';desc' : '', ';', $context['current_label_id'] != -1 ? ';l=' . $context['current_label_id'] : '', '">', $txt[319], '</a></li>
                  <li><a', $context['sort_by'] == 'date' ? ' class="selected rounded"' : '' ,' href="', $scripturl, '?action=pm;f=', $context['folder'], ';start=', $context['start'], ';sort=date', $context['sort_by'] == 'date' && $context['sort_direction'] == 'up' ? ';desc' : '', ';', $context['current_label_id'] != -1 ? ';l=' . $context['current_label_id'] : '', '">', $txt[317], $context['sort_by'] == 'date' ? ' ' : '', '</a></li>
                  <li><a', $context['sort_by'] == 'name' ? ' class="selected rounded"' : '' ,' href="', $scripturl, '?action=pm;f=', $context['folder'], ';start=', $context['start'], ';sort=name', $context['sort_by'] == 'name' && $context['sort_direction'] == 'up' ? ';desc' : '', ';', $context['current_label_id'] != -1 ? ';l=' . $context['current_label_id'] : '', '">', 'Autor', $context['sort_by'] == 'name' ? ' ' : '', '</a></li>
                  </ul>
				  </div>
              <div class="right">
              <strong>Acciones:</strong>
              <select name="pm_action">
				<option value="none">Seleccionar:</option>
                <option value="delete_all">Eliminar</option>
                ', $context['folder'] == 'inbox' ? '<option value="markAsReadAll">Marcar como le&iacute;dos</option>' : '' ,'
              </select>
              <input type="button" class="sp-button" value="Realizar" style="margin-left:10px" onclick="submit_action_pm()" />
              </div></div>';
			  }
              echo '<div class="contentArea relative">
	<table width="98%" border="0" cellpadding="0" cellspacing="0">
	<tr><td valign="top">';

}



function template_pm_below(){

	global $context, $settings, $options;
	echo '</td></tr></table></div></div></div>';
}

function template_folder(){

	global $context, $settings, $options, $scripturl, $modSettings, $txt, $mp_c, $cant_out;

if(isset($context['sl-singlepm']))
    echo '<form action="',$scripturl,'?action=pm;sa=pmactions;f=', $context['folder'], ';start=', $context['start'], $context['current_label_id'] != -1 ? ';l=' . $context['current_label_id'] : '', '" method="post" accept-charset="', $context['character_set'], '" name="pmFolder" id="pmFolder">';
        
print_r($context['limit_bar']);


if(!isset($context['sl-singlepm']))
{
    
    echo '<div class="pretty-table rounded-top">
    <div class="header rounded-top"><h3> ', $context['pm_areas']['folders']['areas'][$context['folder']]['txt'], '</h3></div>';

if ($context['show_delete'])

{	echo '

	<table class="table-pm" width="100%">
         <thead><tr><th width="5%"></th> <th width="40%">Remitente</th> <th>Asunto</th></tr></thead>';

        $next_alternate = false;
        $context['ids_no_reads'] = array();

	while ($message = $context['get_pmessage']())

	{
                if(!$message['is_read'])
                    $context['ids_no_reads'][] = $message['id'];

		echo '<tr', (!$message['is_read'] && $context['from_or_to'] == 'from'  ? ' class="no_read"' : ''), '>
                          <td class="middle-icon"><input type="checkbox" name="pms[]" id="deletelisting', $message['id'], '" class="ui-radio pm_checkbox sort" value="', $message['id'], '"', $message['is_selected'] ? ' checked="checked"' : '', '><label class="ui-radio" for="deletelisting', $message['id'], '"></label></td>
                          <td>
                              <div class="remitente-opt">
                              <div class="avatar avatar_thumbnail s32"><img src="'.$message['member']['avatar']['src'].'" style="'.$message['member']['avatar']['coords'][32]['style'].'"></div>
                              <div class="time_nick"><span>', ($context['from_or_to'] == 'from' ? $message['member']['link'] : (empty($message['recipients']['to']) ? '' : implode(', ', $message['recipients']['to']))), '</span><span class="time">', date('Y-m-d g:i:s', $message['time']), '</span></div></div>
                          </td>
                              <td>
                                  <div class="subject-context">
                                  <a class="post" href="', $message['p'], '" title="', $message['subject'], '">', $message['subject'], '</a>
                                  <div class="descr">', $message['short_body'], '</div>
                              </div>
                          </td>
                      </tr>';

		$next_alternate = $message['alternate'];

	}



	echo '

	</table></div>
        <table width="100%" cellpadding="2" cellspacing="0" border="0"><tr style="" valign="middle">

			<td style="color: #000;">';

			if ($context['page_index'] && $context['show_paginator'])
                            echo '<div class="inset-bar wrap-paginator clearfix">'.$context['page_index'].'<div class="clear"></div></div>';


	if ($context['show_delete'])

	{

		if (!empty($context['currently_using_labels']) && $context['folder'] != 'outbox')

		{

			echo '

				<select name="pm_action" onchange="if (this.options[this.selectedIndex].value) this.form.submit();" onfocus="loadLabelChoices();">

			<option value="">',$txt['pm_move_to_folder'],'</option>';

			foreach ($context['labels'] as $label)

			echo '<option value="rem_', $label['id'], '">&nbsp;', $label['name'], '</option>';

			echo '</select>

';

		}



		echo '

				<input class="hideObj" type="submit" name="del_selected" value="', $txt['quickmod_delete_selected'], '" onclick="if (!confirm(\'', $txt['smf249'], '\')) return false;" />';

	}

	echo '<script type="text/javascript">
                var no_reads = ['.implode(', ', $context['ids_no_reads']).'];
                                        function submit_action_pm(){
                                        
                                        var seleccionados = $("input.pm_checkbox:checked").length;
                                        
                                        if(seleccionados == 0)
                                            return false;
                                        
                                            switch($(\'select[name=pm_action]\').val()){
                                                case "delete_all":
                                                        return $("input[name=del_selected]").trigger("click");
                                                break;
                                                case "markAsReadAll":
                                                    
                                                    var contructUrl = "", amp = "";
                                                    $("input.pm_checkbox").each(function(){
                                                        if($(this).is(":checked") && $.inArray(parseInt($(this).val()), no_reads) !== -1){
                                                            contructUrl += amp + "markAsRead[]=" + parseInt($(this).val());
                                                            amp = ";";
                                                            }
                                                    });
                                                    
                                                    if(contructUrl == "")
                                                        return alert("Selecciona los mensajes no leidos");
                                                        
                                                    if (confirm("Marcar estos mensajes como leídos?"))
                                                        location.href = "'.$scripturl.'?action=pm;" + contructUrl;
                                                        
                                                break;
                                            }

                                        }
                                        
              </script>
              <script language="JavaScript" type="text/javascript"><!-- // --><![CDATA[

					var allLabels = {};
                                        

					function loadLabelChoices()

					{

						var listing = document.forms.pmFolder.elements;

						var theSelect = document.forms.pmFolder.pm_action;

						var add, remove, toAdd = {length: 0}, toRemove = {length: 0};



						if (theSelect.childNodes.length == 0)

							return;';



	echo '

						if (typeof(allLabels[-1]) == "undefined")

						{

							for (var o = 0; o < theSelect.options.length; o++)

								if (theSelect.options[o].value.substr(0, 4) == "rem_")

									allLabels[theSelect.options[o].value.substr(4)] = theSelect.options[o].text;

						}



						for (var i = 0; i < listing.length; i++)

						{

							if (listing[i].name != "pms[]" || !listing[i].checked)

								continue;



							var alreadyThere = [], x;

							for (x in currentLabels[listing[i].value])

							{

								if (typeof(toRemove[x]) == "undefined")

								{

									toRemove[x] = allLabels[x];

									toRemove.length++;

								}

								alreadyThere[x] = allLabels[x];

							}



							for (x in allLabels)

							{

								if (typeof(alreadyThere[x]) == "undefined")

								{

									toAdd[x] = allLabels[x];

									toAdd.length++;

								}

							}

						}



						while (theSelect.options.length > 2)

							theSelect.options[2] = null;



						if (toAdd.length != 0)

						{

									theSelect.options[theSelect.options.length - 1].disabled = true;



							for (i in toAdd)

							{

								if (i != "length")

									theSelect.options[theSelect.options.length] = new Option(toAdd[i], "" + i);

							}

						}



						if (toRemove.length != 0)

						{

												theSelect.options[theSelect.options.length - 1].disabled = true;



							for (i in toRemove)

							{

								if (i != "length")

									theSelect.options[theSelect.options.length] = new Option(toRemove[i], "rem_" + i);

							}

						}

					}

				// ]]></script>';



		echo '

				</div>

			</td>

		</tr></table>';

	}

	else

	echo'	<table width="100%">	<tr>

			<td class="windowbg" colspan="5"><center><br>', $txt[151], '</center><br></td>

		</tr></table>';

	} // end !isset()

	echo '

	<script language="JavaScript" type="text/javascript"><!-- // --><![CDATA[

		var currentLabels = {};

	// ]]></script>';



	if ((isset($context['sl-singlepm']) || (isset($modSettings['enableSinglePM']) && $modSettings['enableSinglePM'] ==0) || !isset($modSettings['enableSinglePM'])))

	{



		while ($message = $context['get_pmessage']())

		{

			$windowcss = $message['alternate'] == 0 ? 'windowbg' : 'windowbg2';




			echo '
				  <span class="floatL"><b>Por:</b>

				  <a href="', $scripturl ,'?action=profile;u=', $message['member']['id'], '">', $message['member']['name'], '</a>&nbsp; |

					

				&nbsp;<b>Enviado:</b>

						', tiempo2($message['time']), '&nbsp; 	| &nbsp; 

					<b>Asunto:</b>', $message['subject'], '&nbsp;
					</span><br />
						 <div style="border-bottom:1px dashed #ccc;margin-top:3px;"></div><br/>

						<b>',$txt['pm_message'],'</b> &nbsp; 

			<div style="background: #FFFFFF;padding:10px;" class="personalmessage">', $message['body'], '</div><br/>
					';

		echo '<input class="sp-button bluesky" style="font-size: 11px;" value="',$txt['pm_message_delete'],'" title="',$txt['pm_message_delete'],'" onclick="if (!confirm(',$txt['pm_sure_delete_message'],')) return false; location.href=\''.$scripturl.'?action=pm;sa=pmactions;pm_actions[', $message['id'], ']=delete;f=', $context['folder'], ';start=', $context['start'], ';', $context['current_label_id'] != -1 ? ';l=' . $context['current_label_id'] : '', ';sesc=', $context['session_id'], '\'" type="button">&nbsp;<input class="sp-button bluesky" style="font-size: 11px;" value="',$txt['pm_respond'],'" title="',$txt['pm_respond'],'" onclick="location.href=\'',$scripturl,'?action=pm;sa=send;f=', $context['folder'], $context['current_label_id'] != -1 ? ';l=' . $context['current_label_id'] : '', ';pmsg=', $message['id'], ';u=', $message['member']['id'], '\'" type="button">

					

					<script language="JavaScript" type="text/javascript"><!-- // --><![CDATA[

						currentLabels[', $message['id'], '] = {';



		if (!empty($message['labels']))

		{

			$first = true;

			foreach ($message['labels'] as $label)

			{

				echo $first ? '' : ',', '

								"', $label['id'], '": "', $label['name'], '"';

				$first = false;

			}

		}



		echo '

						};

					// ]]></script>
';

		}



		echo '

			';

	}



	echo '

	<input type="hidden" name="sc" value="', $context['session_id'], '" />

</form>';

}



function template_search(){}

function template_search_results(){}	



function template_send()

{

	global $context, $settings, $options, $scripturl, $modSettings, $txt;



	if (!empty($context['send_log']))

	{

		echo '

		<br />

		<table border="0" width="80%" cellspacing="1" cellpadding="3" class="bordercolor" align="center">

			<tr class="titlebg">

				<td>', $txt['pm_send_report'], '</td>

			</tr>

			<tr>

				<td class="windowbg">';

		foreach ($context['send_log']['sent'] as $log_entry)

			echo '<span style="color: green">', $log_entry, '</span><br />';

		foreach ($context['send_log']['failed'] as $log_entry)

			echo '<span style="color: red">', $log_entry, '</span><br />';

		echo '

				</td>

			</tr>

		</table><br />';

	}

	echo '
	<div style="float:left;width:730px;margin-left:-25px;margin-top:-20px;">
	<div class="optionArea clearfix" ><div class="left padding-10"><ul class="sort_options clearfix"><li><strong>',$txt['pm_send'],'</strong></li></ul></div></div>
	<div class="box_cuerpo" style="border:none; background:none;">
	<form action="',$scripturl,'?action=pm;sa=send2" method="post" accept-charset="', $context['character_set'], '" name="postmodify" id="postmodify" onsubmit="submitonce(this);saveEntities();">
	
	<font class="size11"><b>De:</b></font>
	'.$context['user']['name'].'
	<br />
	<b>', $txt[150], ':</b>
	<input type="text" name="to" id="to" value="', $context['to'], '" tabindex="1" size="40" style="margin-left:16px;"/>
	<br /><br />
	<b>Asunto:</b>
	<input type="text" name="subject" value="', $context['subject'], '" tabindex="2" size="40" maxlength="50" />

		

<br />

	<center>',template_quickreply_box(),'</center>



	<font class="size11"><b>Opciones:</b></font> 

								<br />
								<label for="outbox">
					<input type="checkbox" name="outbox" id="outbox" value="1" tabindex="3"', $context['copy_to_outbox'] ? ' checked="checked"' : '', ' class="check" /> ', $txt['pm_save_outbox'], '</label>';

								
						echo'<center>
						<input class="sp-button bluesky" type="submit" value="', $txt[148], '" tabindex="4" onclick="return obligatorio(this.form.to.value, this.form.subject.value, this.form.message.value); return submitThisOnce(this);" accesskey="s" /></center>

								

							

						<input type="hidden" name="sc" value="', $context['session_id'], '" />

						<input type="hidden" name="usuarien" value="',$context['user']['id'], '" />

						<input type="hidden" name="seqnum" value="', $context['form_sequence_number'], '" />

						<input type="hidden" name="f" value="', isset($context['folder']) ? $context['folder'] : '', '" />

						<input type="hidden" name="l" value="', isset($context['current_label_id']) ? $context['current_label_id'] : -1, '" />

					</form></div></div>

				';





	echo '

		<script language="JavaScript" type="text/javascript"><!-- // --><![CDATA[

		

		function obligatorio(to, subject, message)

	{	

			if(to == \'\')

			{

				alert(\'',$txt['pm_dont_destiny'],'\');

				return false;

			}

			if(subject == \'\')

			{

				alert(\'',$txt['pm_dont_subject'],'\');

				return false;

			}

			if(message == \'\')

			{

				alert(\'',$txt['pm_dont_nothing'],'\');

				return false;

			}}

			

			function autocompleter(element)

			{

				if (typeof(element) != "object")

					element = document.getElementById(element);



				this.element = element;

				this.key = null;

				this.request = null;

				this.source = null;

				this.lastSearch = "";

				this.oldValue = "";

				this.cache = [];



				this.change = function (ev, force)

				{

					if (window.event)

						this.key = window.event.keyCode + 0;

					else

						this.key = ev.keyCode + 0;

					if (this.key == 27)

						return true;

					if (this.key == 34 || this.key == 8 || this.key == 13 || (this.key >= 37 && this.key <= 40))

						force = false;



					if (isEmptyText(this.element))

						return true;



					if (this.request != null && typeof(this.request) == "object")

						this.request.abort();



					var element = this.element, search = this.element.value.replace(/^("[^"]+",[ ]*)+/, "").replace(/^([^,]+,[ ]*)+/, "");

					this.oldValue = this.element.value.substr(0, this.element.value.length - search.length);

					if (search.substr(0, 1) == \'"\')

						search = search.substr(1);



					if (search == "" || search.substr(search.length - 1) == \'"\')

						return true;



					if (this.lastSearch == search)

					{

						if (force)

							this.select(this.cache[0]);



						return true;

					}

					else if (search.substr(0, this.lastSearch.length) == this.lastSearch && this.cache.length != 100)

					{

						// Instead of hitting the server again, just narrow down the results...

						var newcache = [], j = 0;

						for (var k = 0; k < this.cache.length; k++)

						{

							if (this.cache[k].substr(0, search.length) == search)

								newcache[j++] = this.cache[k];

						}



						if (newcache.length != 0)

						{

							this.lastSearch = search;

							this.cache = newcache;



							if (force)

								this.select(newcache[0]);



							return true;

						}

					}



					this.request = new XMLHttpRequest();

					this.request.onreadystatechange = function ()

					{

						element.autocompleter.handler(force);

					}



					this.request.open("GET", this.source + escape(textToEntities(search).replace(/&#(\d+);/g, "%#$1%")).replace(/%26/g, "%25%23038%25") + ";" + (new Date().getTime()), true);

					this.request.send(null);



					return true;

				}

				this.keyup = function (ev)

				{

					this.change(ev, true);



					return true;

				}

				this.keydown = function ()

				{

					if (this.request != null && typeof(this.request) == "object")

						this.request.abort();

				}

				this.handler = function (force)

				{

					if (this.request.readyState != 4)

						return true;



					var response = this.request.responseText.split("\n");

					this.lastSearch = this.element.value;

					this.cache = response;



					if (response.length < 2)

						return true;



					if (force)

						this.select(response[0]);



					return true;

				}

				this.select = function (value)

				{

					if (value == "")

						return;



					var i = this.element.value.length + (this.element.value.substr(this.oldValue.length, 1) == \'"\' ? 0 : 1);

					this.element.value = this.oldValue + \'"\' + value + \'"\';



					if (typeof(this.element.createTextRange) != "undefined")

					{

						var d = this.element.createTextRange();

						d.moveStart("character", i);

						d.select();

					}

					else if (this.element.setSelectionRange)

					{

						this.element.focus();

						this.element.setSelectionRange(i, this.element.value.length);

					}

				}



				this.element.autocompleter = this;

				this.element.setAttribute("autocomplete", "off");



				this.element.onchange = function (ev)

				{

					this.autocompleter.change(ev);

				}

				this.element.onkeyup = function (ev)

				{

					this.autocompleter.keyup(ev);

				}

				this.element.onkeydown = function (ev)

				{

					this.autocompleter.keydown(ev);

				}

			}



			if (window.XMLHttpRequest)

			{

				var toComplete = new autocompleter("to2"), bccComplete = new autocompleter("bcc");

				toComplete.source = "', $scripturl, '?action=requestmembers;sesc=', $context['session_id'], ';search=";

				bccComplete.source = "', $scripturl, '?action=requestmembers;sesc=', $context['session_id'], ';search=";

			}



			function saveEntities()

			{

				var textFields = ["subject", "message"];

				for (i in textFields)

					if (document.forms.postmodify.elements[textFields[i]])

						document.forms.postmodify[textFields[i]].value = document.forms.postmodify[textFields[i]].value.replace(/&#/g, "&#38;#");

			}

		// ]]></script>';

}



function template_ask_delete()

{

	global $context, $settings, $options, $scripturl, $modSettings, $txt;



	echo '

		<table border="0" width="80%" cellpadding="4" cellspacing="1" class="bordercolor" align="center">

			<tr class="titlebg">

				<td>', ($context['delete_all'] ? $txt[411] : $txt[412]), '</td>

			</tr>

			<tr>

				<td class="windowbg">

					', $txt[413], '<br />

					<br />

					<b><a href="', $scripturl, '?action=pm;sa=removeall2;f=', $context['folder'], ';', $context['current_label_id'] != -1 ? ';l=' . $context['current_label_id'] : '', ';sesc=', $context['session_id'], '">', $txt[163], '</a> - <a href="javascript:history.go(-1);">', $txt[164], '</a></b>

				</td>

			</tr>

		</table>';

}

function template_labels(){

	global $context, $settings, $options, $scripturl, $txt;

	echo '

<form action="',$scripturl,'?action=pm;sa=manlabels;sesc=', $context['session_id'], '" method="post" accept-charset="', $context['character_set'], '">

		<table width="100%" cellpadding="3" cellspacing="0" border="0">	

		<tr>

		<td width="100%" class="titulo_a">&nbsp;</td>

		<td width="100%" class="titulo_b"><center>', $txt['pm_label_add_new'], '</center></td>

		<td width="100%" class="titulo_c">&nbsp;</td>

		</tr></table>	

		<table width="100%" cellpadding="4" cellspacing="0" border="0" align="center" class="windowbg2">

			<tr class="windowbg2">

				<td align="right" width="40%">

					<b class="size11">', $txt['pm_label_name'], ':</b>

				</td>

				<td align="left">

					<input type="text" name="label" value="" size="30" maxlength="20" />

				</td>

			</tr>

			<tr class="windowbg2">

				<td colspan="2" align="center">

					<input class="sp-button bluesky" type="submit" name="add" value="', $txt['pm_label_add_new'], '" style="font-weight: normal;" />

				</td>

			</tr>

		</table>

	</form>

<form action="',$scripturl,'?action=pm;sa=manlabels;sesc=', $context['session_id'], '" method="post" accept-charset="', $context['character_set'], '" style="margin-top: 8px;">

	<table width="100%" cellpadding="3" cellspacing="0" border="0">	

		<tr>

		<td width="100%" class="titulo_a">&nbsp;</td>

		<td width="100%" class="titulo_b"><center>', $txt['pm_manage_labels'], '</center></td>

		<td width="100%" class="titulo_c">&nbsp;</td>

		</tr></table>	

		<table width="100%" class="windowbg">

			<tr class="windowbg2">

				<td colspan="2" style="padding: 1ex;"><center><span class="smalltext">', $txt['pm_labels_desc'], '</span></center></td>

			</tr>

			<tr >

				<td colspan="2" style="background-color: #FBFDFD; color: #000;">

					<div style="float: right; width: 4%; text-align: center;"><input type="checkbox" class="check" onclick="invertAll(this, this.form);" /></div>

					', $txt['pm_label_name'], ':

				</td>

			</tr>';

		$alternate = true;

		foreach ($context['labels'] as $label){
			if ($label['id'] != -1){
				echo'
				<tr class="', $alternate ? 'windowbg2' : 'windowbg', '">
					<td>
						<input type="text" name="label_name[', $label['id'], ']" value="', $label['name'], '" size="30" maxlength="30" />
					</td>
					<td width="4%" align="center">
						<input type="checkbox" class="check" name="delete_label[', $label['id'], ']" />
					</td>
				</tr>';

				$alternate = !$alternate;
			}
		}

		echo '
			<tr>
				<td align="center" colspan="2">
					<br />
					<input class="button" type="submit" name="save" value="',$txt['pm_save_change'],'" style="font-weight: normal;" />
					<input class="button" type="submit" name="delete" value="', $txt['quickmod_delete_selected'], '" style="font-weight: normal;" onclick="return confirm(\'', $txt['pm_labels_delete'], '\');" />
				</td>
			</tr>
		</table>
		<input type="hidden" name="sc" value="', $context['session_id'], '" />
	</form>';

}

function template_prune(){}
function template_report_message(){}
function template_report_message_complete(){}

function template_quickreply_box(){

	global $context, $settings, $options, $txt, $modSettings, $db_prefix;

if(!empty($_REQUEST['pmsg'])){
	$request = db_query("
	SELECT *
	FROM ({$db_prefix}personal_messages)
	WHERE ID_PM = ".$_REQUEST['pmsg']."
	", __FILE__, __LINE__);
	while ($row = mysql_fetch_assoc($request)){
		censorText($row['body']);
		$row['body'] = trim(un_htmlspecialchars(htmlspecialchars(strtr(parse_bbc($row['body'], false, $ID_MSG), array('<br />' => "\n", '</div>' => "\n", '</li>' => "\n", '&#91;' => '[', '&#93;' => ']')))));
		$comentario = $row['body'];
		$fecha = $row['msgtime'];
		$nombre = $row['fromName'];
	}
	mysql_free_result($request);
}

if ($context['show_bbc']){
	echo '<tr><td></td><td>';
	$context['bbc_tags'][] = array();
	$found_button = false;
	foreach ($context['bbc_tags'][0] as $image => $tag){
		if (isset($tag['before'])){
			if (!empty($context['disabled_tags'][$tag['code']]))
				continue;
			
			$found_button = true;
			
			if (!isset($tag['after']))
				echo '<a href="javascript:void(0);" onclick="replaceText(\'', $tag['before'], '\', document.forms.postmodify.message); return false;">';
			else
				echo '<a href="javascript:void(0);" onclick="surroundText(\'', $tag['before'], '\', \'', $tag['after'], '\', document.forms.postmodify.message); return false;">';
		}
		else if ($found_button){
			$found_button = false;
		}
	}

	if(!isset($context['disabled_tags']['size']))
		$found_button = false;

	foreach ($context['bbc_tags'][1] as $image => $tag){
		
		if(isset($tag['before'])){
			if(!empty($context['disabled_tags'][$tag['code']]))
				continue;
			
			$found_button = true;
		}
		else if ($found_button){
			$found_button = false;
		}
	}
}

	$mesesano2 = array("1","2","3","4","5","6","7","8","9","10","11","12");
	$diames2 = date('j',$fecha); $mesano2 = date('n',$fecha) - 1 ; $ano2 = date('Y',$fecha);
	$seg2=date('s',$fecha); $hora2=date('H',$fecha); $min2=date('i',$fecha);
	$fecha2="$diames2.$mesesano2[$mesano2].$ano2 a las $hora2:$min2:$seg2";

	echo '<textarea id="cuerpo_comment" class="markItUpEditor" tabindex="1" cols="75" rows="7" style="width: 95%; height: 160px;float:left;" name="message" tabindex="1" onselect="storeCaret(this);" onclick="storeCaret(this);" onkeyup="storeCaret(this);" onchange="storeCaret(this);">';

	if(!empty($_REQUEST['pmsg'])){
		echo $txt['pm_the'],' '.$fecha2.', '.$nombre.' ',$txt['pm_wrote'],'> '.str_replace("\n", "\n> ", $comentario) .'';
	}

	echo'</textarea><br />';

	if (!empty($context['smileys']['postform'])){
		foreach($context['smileys']['postform'] as $smiley_row){
			foreach($smiley_row['smileys'] as $smiley)
			echo'<a  style="padding-right:4px;" href="javascript:void(0);" onclick="replaceText(\' ', $smiley['code'], '\', document.forms.postmodify.message); return false;"><img src="', $settings['smileys_url'], '/', $smiley['filename'], '" align="bottom" alt="', $smiley['description'], '" title="', $smiley['description'], '" /></a> ';

			if(empty($smiley_row['last']))
			echo '<br />';
		}

		// If the smileys popup is to be shown... show it!
		if(!empty($context['smileys']['popup']))
		echo '
		<script type="text/javascript">function openpopup(){var winpops=window.open("emoticones.php","","width=255px,height=500px,scrollbars");}</script>
		<a href="javascript:openpopup()">[', $txt['more_smileys'], ']</a>
		<br />';
	}

}

?>