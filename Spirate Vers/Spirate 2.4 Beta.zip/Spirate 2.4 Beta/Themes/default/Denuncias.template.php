<?php
// Spirate Script - Version 2.4
// denuncias adminfunction 
function template_denuncias(){
	global $db_prefix, $scripturl, $txt;
	$tipo = $_GET['tipo'];	echo'
	<div id="admR">
		<div class="box_title">
			Denuncias
		</div><!-- /box_title -->
		<div class="box_cuerpo">
			Ac&aacute; vas a poder controlar todas las denuncias que hagan los usuarios.
		</div><!-- /box_cuerpo -->
		
		<br class="space" />
		
		<strong><a href="'.$scripturl.'?action=denuncias&tipo=posts">Posts</a></strong> - <strong><a href="'.$scripturl.'?action=denuncias&tipo=img">Imagenes</a></strong> - <strong><a href="'.$scripturl.'?action=denuncias&tipo=stream">Stream</a></strong> - <strong><a href="'.$scripturl.'?action=denuncias&tipo=usuarios">Usuarios</a></strong>
		
		<br class="space" />
		';
		$razon = array(
			$txt['denounce_spam'], 
			$txt['denounce_links'], 
			$txt['denounce_disrespectful'], 
			$txt['denounce_personal_information'], 
			$txt['denounce_mayus'], 
			$txt['denounce_porn'], 
			$txt['denounce_gore'], 
			$txt['denounce_fount'], 
			$txt['denounce_poor'], 
			$txt['denounce_pass'], 
			$txt['denounce_protocol'], 
			$txt['denounce_other']
			);



		if($tipo == 'posts' or trim($tipo) == ''){
			echo'
			<div class="box_title">
				&Uacute;ltimos Posts Denunciados
			</div><!-- /box_title -->
			<div class="box_cuerpo">';
				$r = db_query(" SELECT den.*, mem.realName, m.subject
								FROM {$db_prefix}denuncias as den, {$db_prefix}members as mem, {$db_prefix}messages as m
								WHERE den.id_user = mem.ID_MEMBER
								AND den.id = m.ID_TOPIC
								AND den.tipo = 1
								GROUP BY den.id
								ORDER BY den.id_denuncia DESC
								LIMIT 50",__FILE__,__LINE__);
								$n = mysql_num_rows($r);
				if($n){
					while($row = mysql_fetch_assoc($r)){
						$qc = db_query("SELECT den.id_denuncia
						FROM {$db_prefix}denuncias as den
						WHERE den.id = '".$row['id']."'",__FILE__,__LINE__);
						$cant = mysql_num_rows($qc);
						mysql_free_result($qc);
						$numraz = nl2br($row['razon']);
						echo '
						<fieldset>
							<legend>
								'.censorText($row['subject']).' ('.$cant.')
							</legend>

						<strong>Denunciante:</strong> <a href="'.$scripturl.'?action=profile&user='.$row['realName'].'" title="'.$row['realName'].'">'.$row['realName'].'</a><br>
						<strong>Post:</strong> <a href="'.$scripturl.'?topic='.$row['id'].'" title="'.$row['subject'].'">'.$row['subject'].'</a><br>
						<strong>Raz&oacute;n:</strong>&nbsp;'.$razon[$numraz].'<br>
						<strong>Comentario:</strong> '.nl2br($row['comentario']).'<br><br>
						<a onclick="denuncias.erase('.$row['id'].', 1);"> Eliminar denuncias de este post</a>
						</fieldset>';
					}
				}
				else {
					echo'<div class="message red">No hay denuncias.</div>';
				}
				mysql_free_result($r);
			echo'
			</div><!-- /box_cuerpo -->';
		}

		if($tipo == 'img'){
			echo'
			<div class="box_title">
				&Uacute;ltimas Imagenes Denunciadas
			</div><!-- /box_title -->
			<div class="box_cuerpo">';
				$r = db_query("SELECT den.*, mem.realName,i.titulo
				FROM {$db_prefix}denuncias as den, {$db_prefix}members as mem, {$db_prefix}imagenes as i
				WHERE den.id_user = mem.ID_MEMBER
				AND den.id = i.IDI
				AND den.tipo = 3
				GROUP BY den.id
				ORDER BY den.id_denuncia DESC
				LIMIT 50",__FILE__,__LINE__);
				$n = mysql_num_rows($r);
				if($n){
					while($row = mysql_fetch_assoc($r)){
						$qc = db_query("SELECT den.id_denuncia
						FROM {$db_prefix}denuncias as den
						WHERE den.id = '".$row['id']."'",__FILE__,__LINE__);
						$cant = mysql_num_rows($qc);
						mysql_free_result($qc);
						$numraz = nl2br($row['razon']);
						echo '
						<fieldset>
							<legend>
								'.censorText($row['titulo']).' ('.$cant.')
							</legend>
						<strong>Denunciante:</strong> <a href="'.$scripturl.'?action=profile&user='.$row['realName'].'" title="'.$row['realName'].'">'.$row['realName'].'</a><br>
						<strong>Imagen:</strong> <a href="'.$scripturl.'?action=galeria;imagen='.$row['id'].'" title="'.$row['titulo'].'">'.$row['titulo'].'</a><br>
						<strong>Raz&oacute;n:</strong>&nbsp;'.$razon[$numraz].'<br>
						<strong>Comentario:</strong> '.nl2br($row['comentario']).'<br><br>
						<a onclick="denuncias.erase('.$row['id'].', 3);"> Eliminar denuncias de esta imagen</a>
						</fieldset>';
					}
				}
				else {
					echo'<div class="message red">No hay denuncias.</div>';
				}
				mysql_free_result($r);
			echo'
			</div><!-- /box_cuerpo -->';
		}

		if($tipo == 'stream'){
			echo'
			<div class="box_title">
				&Uacute;ltimas Imagenes Denunciadas
			</div><!-- /box_title -->
			<div class="box_cuerpo">';
				$r = db_query("SELECT den.*, mem.realName, s.type
				FROM {$db_prefix}denuncias as den, {$db_prefix}members as mem, {$db_prefix}activity as s
				WHERE den.id_user = mem.ID_MEMBER
				AND den.id = s.id
				AND den.tipo = 4
				GROUP BY den.id
				ORDER BY den.id_denuncia DESC
				LIMIT 50",__FILE__,__LINE__);
				$n = mysql_num_rows($r);
				if($n){

					while($row = mysql_fetch_assoc($r)){
						$qc = db_query("SELECT den.id_denuncia
						FROM {$db_prefix}denuncias as den
						WHERE den.id = '".$row['id']."'",__FILE__,__LINE__);
						$cant = mysql_num_rows($qc);
						mysql_free_result($qc);
						$numraz = nl2br($row['razon']);

						if($row['type'] == "re-stream"){

								$result2 = db_query("SELECT s.activity_id, s.msg
									FROM {$db_prefix}activity_stream as s, {$db_prefix}activity as a
									WHERE a.id = '".$row['id']."' AND a.object = s.activity_id",__FILE__,__LINE__);
									$y = mysql_fetch_array($result2);
									mysql_free_result($result2);

									if($y){
										$msg = $y['msg'];
									}	
						}
						else{
									$result2 = db_query("SELECT msg
									FROM {$db_prefix}activity_stream
									WHERE activity_id = '".$row['id']."'",__FILE__,__LINE__);
									$y = mysql_fetch_array($result2);
									mysql_free_result($result2);

									if($y){
										$msg = $y['msg'];
									}
									else{echo'error';}	
						}

						$msg = cortar_texto($msg,"100",$sufijo='...');

						echo '
						<fieldset>
							<legend>
								'.censorText($msg).' ('.$cant.')
							</legend>
						<strong>Denunciante:</strong> <a href="'.$scripturl.'?action=profile&user='.$row['realName'].'" title="'.$row['realName'].'">'.$row['realName'].'</a><br>
						<strong>Publicacion:</strong> <a href="'.$scripturl.'?action=galeria;imagen='.$row['id'].'" title="'.$row['titulo'].'">'.$row['titulo'].'</a><br>
						<strong>Raz&oacute;n:</strong>&nbsp;'.$razon[$numraz].'<br>
						<strong>Comentario:</strong> '.nl2br($row['comentario']).'<br><br>
						<a onclick="denuncias.erase('.$row['id'].', 4);"> Eliminar denuncias de esta publicacion.</a>
						</fieldset>';
					}
				}
				else {
					echo'<div class="message red">No hay denuncias.</div>';
				}
				mysql_free_result($r);
			echo'
			</div><!-- /box_cuerpo -->';
		}


		else if($tipo == 'usuarios'){
			echo'
			<div class="box_title">
				&Uacute;ltimos Usuarios Denunciados
			</div><!-- /box_title -->
			<div class="box_cuerpo">';
				$r = db_query("SELECT den.id_denuncia, den.id, mem.realName
				FROM {$db_prefix}denuncias as den, {$db_prefix}members as mem
				WHERE den.tipo = 2
				AND den.id = mem.ID_MEMBER
				GROUP BY den.id
				ORDER BY den.id_denuncia DESC
				LIMIT 50
				",__FILE__,__LINE__);
				$n = mysql_num_rows($r);
				if($n){
					while($row = mysql_fetch_assoc($r)){
						$qc = db_query("SELECT den.id
						FROM {$db_prefix}denuncias as den
						WHERE den.tipo = 2 AND den.id = '".$row['id']."'",__FILE__,__LINE__);
						$cant = mysql_num_rows($qc);
						mysql_free_result($qc);
						echo'
						<fieldset>
							<legend>
								<a href="'.$scripturl.'?action=profile&user='.$row['realName'].'" target="_blank" title="'.$row['realName'].'">'.$row['realName'].'</a> ('.$cant.' denuncias)
							</legend>';
							denuncias_sp($row['id']);
						echo'
						<a onclick="denuncias.erase('.$row['id'].', 2);"> Eliminar denuncias hacia este usuario</a>
						</fieldset>
						<br />';
					}
				}
				else {
					echo'<div class="message red">No hay denuncias.</div>';
				}
				mysql_free_result($r);
			echo'
			</div><!-- /box_cuerpo -->';
		}
	echo'
	<!-- admR se cierra solo -->';}

function denuncias_sp($id){
	global $db_prefix, $txt, $scripturl, $context;
	
	$tipo = $_GET['tipo'];
	
	if($tipo == 'posts' or trim($tipo) == ''){
		$r = db_query("SELECT den.*, mem.realName, mem.memberIP
		FROM {$db_prefix}denuncias as den, {$db_prefix}members as mem
		WHERE den.id = '$id'
		AND den.id_user = mem.ID_MEMBER
		AND den.tipo = 1
		",__FILE__,__LINE__);
		while($row = mysql_fetch_array($r)){
			$comment = ($row['comentario'] ? $row['comentario'] : 'Sin Comentario');
			echo'<b>Denunciante:</b> <a href="'.$scripturl.'?action=profile&user='.$row['realName'].'" '.$row['realName'].'>'.$row['realName'].'</a>';
			echo' | <b>IP:</b> '.$row['memberIP'];
			echo' | <b>Raz&oacute;n:</b> '.$row['razon'];
			echo' | <b>Comentario:</b> '.$comment;
			echo' | <b>Acci&oacute;n:</b> <a href="'.$scripturl.'?action=removetopic2;topic=', $row['id'], ';sesc=',$context['session_id'],'" title="Borrar Post">Borrar Post</a> - <a href="'.$scripturl.'?action=post;msg=',$row['id'],';topic=',$row['id'],';sesc=',$context['session_id'],'" target="_blank" title="Editar Post">Editar Post</a>';
			echo'<br />';
		}
		mysql_free_result($r);
	}
	else if($tipo == 'usuarios'){
		$qdn = db_query("SELECT den.*, mem.realName, mem.memberIP
		FROM {$db_prefix}denuncias as den, {$db_prefix}members as mem
		WHERE den.id = '$id'
		AND den.id_user = mem.ID_MEMBER
		AND den.tipo = 2
		",__FILE__,__LINE__);
		while($row = mysql_fetch_array($qdn)){
			$comment = ($row['comentario'] ? $row['comentario'] : 'Sin Comentario');
			echo'<b>Denunciante:</b> <a href="'.$scripturl.'?action=profile&user='.$row['realName'].'" '.$row['realName'].'>'.$row['realName'].'</a>';
			echo' | <b>IP:</b> '.$row['memberIP'];
			echo' | <b>Raz&oacute;n:</b> '.$row['razon'];
			echo' | <b>Comentario:</b> '.$comment;
			echo' | <b>Acci&oacute;n:</b> <a href="'.$scripturl.'?action=ban;sa=add" title="Banear Usuario">Banear Usuario</a>';
			echo'<hr class="divider" />';
		}
		mysql_free_result($qdn);
	}
}
// denunciando
function template_denunciar(){	

	global $db_prefix, $scripturl, $context, $txt, $ID_MEMBER;	$tipo = $_GET['tipo'];	$id = (int) $_GET['id'];

		if($tipo == 'post'){
					$j = db_query("SELECT d.id_denuncia
					FROM {$db_prefix}denuncias as d
					WHERE d.id = '$id' AND d.id_user = '$ID_MEMBER' AND d.tipo = 1",__FILE__,__LINE__);
					$h = mysql_num_rows($j);
					mysql_free_result($j);

					if($h){
						fatal_error('Ya denunciaste este post.', false);
					}
		}			

		if($tipo == 'user'){
					$j = db_query("SELECT d.id_denuncia
					FROM {$db_prefix}denuncias as d
					WHERE d.id = '$id' AND d.id_user = '$ID_MEMBER' AND d.tipo = 2",__FILE__,__LINE__);
					$h = mysql_num_rows($j);
					mysql_free_result($j);

					if($h){
						fatal_error('Ya denunciaste a este usuario.', false);
					}
		}		

		if($tipo == 'img'){
					$j = db_query("SELECT d.id_denuncia
					FROM {$db_prefix}denuncias as d
					WHERE d.id = '$id' AND d.id_user = '$ID_MEMBER' AND d.tipo = 3",__FILE__,__LINE__);
					$h = mysql_num_rows($j);
					mysql_free_result($j);

					if($h){
						fatal_error('Ya denunciaste esta imagen.', false);
					}
		}			
	
		echo'	<style type="text/css">				
		ul.denunciar-form {font-size:15px;}		
		ul.denunciar-form li {display:block;margin:6px 0;}	</style>
			<div id="errorBox"><div class="box_title">Denunciar</div>
			<!-- /box_title -->	
			<div class="box_cuerpo alignC">';			
			if($tipo == 'post'){		
	
				$r = db_query("SELECT p.subject, mem.realName				
								FROM {$db_prefix}messages as p, {$db_prefix}members as mem				
								WHERE p.ID_TOPIC = '$id' AND mem.ID_MEMBER = p.ID_MEMBER",__FILE__,__LINE__);
								$n = mysql_num_rows($r);				
								if($n){	$data = mysql_fetch_assoc($r);
									echo'<form action="'.$scripturl.'?action=denuncias&sa=denunciar2" method="post" accept-charset="', $context['character_set'], '">	
									<ul class="denunciar-form"><li><strong>Post:</strong> 
									<a href="'.$scripturl.'?topic='.$id.'" title="'.censorText($data['subject']).'" target="_blank">'.censorText($data['subject']).'</a></li>							
									<li><strong>ID:</strong> '.$id.'</li>
									<li><strong>Autor:</strong> <a href="'.$scripturl.'?action=profile&user='.$data['realName'].'" title="'.$data['realName'].'" target="_blank">'.$data['realName'].'</a></li>
									<li><strong>Raz&oacute;n:</strong></li>
									<li><select name="razon"><option value="0">',$txt['denounce_repost'],'</option>
									<option value="1">',$txt['denounce_spam'],'</option>
									<option value="2">',$txt['denounce_links'],'</option>
									<option value="3">',$txt['denounce_disrespectful'],'</option>
									<option value="4">',$txt['denounce_personal_information'],'</option>
									<option value="5">',$txt['denounce_mayus'],'</option>
									<option value="6">',$txt['denounce_porn'],'</option>
									<option value="7">',$txt['denounce_gore'],'</option>
									<option value="8">',$txt['denounce_fount'],'</option>
									<option value="9">',$txt['denounce_poor'],'</option>
									<option value="10">',$txt['denounce_pass'],'</option>
									<option value="11">',$txt['denounce_protocol'],'</option>
									<option value="12">',$txt['denounce_other'],'</option></select></li>
									<li><strong>Comentario:</strong></li>
									<li><textarea cols="50" rows="5" name="comentario" placeholder="Para ser m&aacute;s espec&iacute;fico en tu denuncia, agrega un comentario."></textarea></li>							
									<li>',$txt['repost_link'],'</li>
							<input type="hidden" name="tipo" value="1" />
							<input type="hidden" name="id" value="'.$id.'" />
							<li><input class="button" type="submit" value="Denunciar Post" /></li></ul></form>';}				
							else {echo'El post fue eliminado.';}	
									mysql_free_result($r);}


				elseif($tipo == "img"){


				$r = db_query("SELECT i.titulo, mem.realName				
								FROM {$db_prefix}imagenes as i, {$db_prefix}members as mem				
								WHERE i.IDI = '$id' AND mem.ID_MEMBER = i.ID_MEMBER",__FILE__,__LINE__);
								$n = mysql_num_rows($r);				
								if($n){	$data = mysql_fetch_assoc($r);
									echo'<form action="'.$scripturl.'?action=denuncias&sa=denunciar2" method="post" accept-charset="', $context['character_set'], '">	
									<ul class="denunciar-form"><li><strong>Imagen:</strong> 
									<a href="'.$scripturl.'?topic='.$id.'" title="'.censorText($data['subject']).'" target="_blank">'.censorText($data['titulo']).'</a></li>							
									<li><strong>ID:</strong> '.$id.'</li>
									<li><strong>Autor:</strong> <a href="'.$scripturl.'?action=profile&user='.$data['realName'].'" title="'.$data['realName'].'" target="_blank">'.$data['realName'].'</a></li>
									<li><strong>Raz&oacute;n:</strong></li>
									<li><select name="razon"><option value="0">',$txt['denounce_repost'],'</option>
									<option value="1">',$txt['denounce_spam'],'</option>
									<option value="3">',$txt['denounce_disrespectful'],'</option>
									<option value="4">',$txt['denounce_personal_information'],'</option>
									<option value="5">',$txt['denounce_mayus'],'</option>
									<option value="6">',$txt['denounce_porn'],'</option>
									<option value="7">',$txt['denounce_gore'],'</option>
									<option value="11">',$txt['denounce_protocol'],'</option>
									<option value="12">',$txt['denounce_other'],'</option></select></li>
									<li><strong>Comentario:</strong></li>
									<li><textarea cols="50" rows="5" name="comentario" placeholder="Para ser m&aacute;s espec&iacute;fico en tu denuncia, agrega un comentario."></textarea></li>							
									<li>',$txt['repost_link'],'</li>
							<input type="hidden" name="tipo" value="3" />
							<input type="hidden" name="id" value="'.$id.'" />
							<li><input class="button" type="submit" value="Denunciar Post" /></li></ul></form>';}				
							else {echo'El post fue eliminado.';}	
									mysql_free_result($r);

				}			



							else if($tipo == 'usuario'){
								$r = db_query("SELECT mem.realName
									FROM {$db_prefix}members as mem
									 ID_MEMBER = '$id'",__FILE__,__LINE__);
								$n = mysql_num_rows($r);
								if($n){	
										$data = mysql_fetch_assoc($r);					
					echo'
					<form action="'.$scripturl.'?action=denuncias&sa=denunciar2" method="post" accept-charset="', $context['character_set'], '">
						<ul class="denunciar-form">
							<li><strong>Usuario:</strong> <a href="'.$scripturl.'?action=profile&user='.$data['realName'].'" title="'.$data['realName'].'" target="_blank">'.$data['realName'].'</a></li>
							<li><strong>Raz&oacute;n:</strong></li>
							<li>
								<select name="razon">
									<option value="13">Hace Spam</option>
									<option value="14">Insulta/Irrespetuoso</option>
									<option value="15">Copia posts de otros usuarios</option>
								</select>
							</li>
							<li><strong>Comentario:</strong></li>
							<li><textarea cols="50" rows="5" name="comentario" placeholder="Para ser m&aacute;s espec&iacute;fico en tu denuncia, agrega un comentario."></textarea></li>
							<input type="hidden" name="tipo" value="2" />
							<input type="hidden" name="id" value="'.$id.'" />
							<li><input class="button" type="submit" value="Denunciar Usuario" /></li>
						</ul>
					</form>';}				
					else {echo'El usuario no existe.';}				
					mysql_free_result($r);}	

					else {echo'Eso no se puede denunciar :)';}
								
							echo'
							</div><!-- /box_cuerpo -->	</div><!-- /errorBox -->	';


						}



// denuncia enviada
function template_denunciar2(){
	global $txt, $scripturl;
	echo'
	<div id="errorBox">
		<div class="box_title">
			'.$txt['denounce_envoy'].'
		</div><!-- /box_title -->
		<div class="box_cuerpo">
			'.$txt['denounce_envoy2'].'
			<br />
			<br />
			<input class="button" type="submit" title="'.$txt['principal_page'].'" value="'.$txt['principal_page'].'" onclick="location.href=\''.$scripturl.'\'" />
		</div><!-- /box_cuerpo -->
	</div><!-- /errorBox -->
	';
}

function cortar_texto($texto,$largo,$sufijo='...'){
            $contador = 0;
            $arrayTexto = explode(" ",$texto);
            $texto = '';
            while($largo >= strlen($texto) + strlen($arrayTexto[$contador])){
                $texto .= ' '.$arrayTexto[$contador];
                $contador++;
            }
            if($texto=='')
                $texto.=substr($arrayTexto[0],0,$largo);
            if(count($arrayTexto)>$contador)
                $texto.=$sufijo;
            return $texto;
        }  
?>