<?php

function formatMoney($money)
{
	global $modSettings;
	$money = (float) $money;
	return $modSettings['shopCurrencyPrefix'] . $money;
}
function template_main(){
	global $context, $settings, $options, $txt, $scripturl, $modSettings, $db_prefix;

echo '<script src="'.$settings['theme_url'].'/slimScroll.min.js" type="text/javascript"></script>';
echo '<script src="'.$settings['theme_url'].'/post.js?upd=0.2" type="text/javascript"></script>';

echo '<style type="text/css">
    .ui-radio{
    margin-bottom: -3px;
    }
    ul#filter-category li{
        padding: 4px 0;
    }
	#scroll-pane {
    display: inline;
    float: left;
    height: 300px;
    margin-bottom: 25px;
    overflow: hidden;
    position: relative;
    width: 200px;
}
#form-category{
position: relative;
}
#scroll-content {position:absolute;top:0;left:0}
.scroll-content-item {background-color:#fcfcfc;color:#003366;width:100px;height:100px;float:left;margin:10px;font-size:3em;line-height:96px;text-align:center;border:1px solid gray;display:inline;}
#slider-wrap{
    float: left;
    margin-left: -17px;
    width: 10px;
}
#slider-vertical{position:relative;height:100%;}

.ui-slider-handle{
    background-color: #CCCCCC;
    border-radius: 15px;
    -moz-border-radius: 15px;
    -webkit-border-radius: 15px;
    display: block;
    height: 10px;
    margin: 0 auto;
    position: absolute;
    width: 10px;
}
.wrap-categories{
margin: 20px 0 0 20px
}
    </style>';

echo '<div class="left cleafix" style="width:230px; margin: 20px 20px 0px 20px;">';
echo '<h3 class="blue" style="margin-left: 10px">Filtrar por periodo</h3>';
echo '<div class="box-selection">
        <div class="context">
            <ul>
                <li class="selected first-child" onclick="tops.filter(\'5\');"><a href="#">Todos los tiempos</a><i class="arrow"></i></li>
                <li onclick="tops.filter(\'1\');"><a href="#" >Tops de hoy</a><i class="arrow"></i></li>
                <li onclick="tops.filter(\'2\');"><a href="#">Tops de la semana</a><i class="arrow"></i></li>
                <li onclick="tops.filter(\'3\');"><a href="#">Tops del mes</a><i class="arrow"></i></li>
                <li onclick="tops.filter(\'4\');"><a href="#">Tops del a&ntilde;o</a><i class="arrow"></i></li>
            </ul>
        </div>
     </div>

       <h3 class="title">'.$txt['post_category'],'</h3>
        <div class="wrap-categories clearfix">
        <div id="scroll-pane" class="box-categories rounded" style="margin-top:30px height:300px;width:240px;margin-left:-20px;">
        <ul class="slimScroll" id="form-category" style="top: 0px;">
        <li></li>
        <li class="selected" onclick="tops.filterbycat();"><a val="0" style="padding:0">Selecciona la categoria</a></li>
        ';
	foreach($context['boards'] as $board){
		echo'<li onclick="tops.filterbycat();"', ( $context['ID_BOARD'] == $board['id'] ) ? ' class="push selected"' : '' ,' ><a  style="background:url('.$settings['images_url'].'/post/icono_', $board['id'], '.gif) no-repeat top left" val="', $board['id'], '">', $board['name'], '</a></li>';
	}
	echo'<li></li></ul></div></div>';

echo ' <input type="text" name="categoria" id="category-from-box" class="hideObj" >
		

</div>';


echo '<div class="bg-tops left cleafix" id="TopsBox">
<table>
<tr>
        <td style="vertical-align:top; padding: 0"><div class="arrow-box" style="width:335px; float:left">
		<div class="title"><span><i></i></span> <strong>Top post m&aacute;s comentado</strong></div>
			<div class="count-list data list">';

                        if(empty($context['tops-topicComments']))
                            echo '<div class="error" style="margin:5px">No se encontro ningun post.</div>';
                        
            foreach($context['tops-topicComments'] as $top)
			echo '<div class="list-element clearfix"><span class="list-number"></span> <img src="'.$settings['images_url'].'/post/icono_'.$top['board']['id'].'.gif" style="float: left; margin-top: 2px;"> <a href="'.$scripturl.'?topic='.$top['id'].'">'.$top['subject'].'</a> <span class="points">'.$top['count'].'</span></div>';
			echo '</div>
		</div>
        <div class="arrow-box yellow" style="width:335px; float:left">
		<div class="title"><span><i></i></span> <strong>Top post con m&aacute;s favoritos</strong></div>
			<div class="count-list data list">';

                        if(empty($context['tops-favoritos']))
                            echo '<div class="error" style="margin:5px">No se encontro ningun post.</div>';
                        
            foreach ($context['tops-favoritos'] as $top)
			echo '<div class="list-element clearfix"><span class="list-number"></span> <img src="'.$settings['images_url'].'/post/icono_'.$top['board']['id'].'.gif" style="float: left; margin-top: 2px;"> <a href="'.$scripturl.'?topic='.$top['id'].'">'.$top['subject'].'</a> <span class="points">', $top['count'], '</span></div>';

			echo '</div>
		</div>
        </td>
                
        <td style="vertical-align:top; padding: 0"><div class="arrow-box green" style="width:335px; float:left">
		<div class="title"><span><i></i></span> <strong>Top post con m&aacute;s puntos</strong></div>
			<div class="count-list data list">';

                        if(empty($context['tops-topicPoints']))
                            echo '<div class="error" style="margin:5px">No se encontro ningun post.</div>';
                        
            foreach ($context['tops-topicPoints'] as $top)
			echo '<div class="list-element clearfix"><span class="list-number"></span> <img src="'.$settings['images_url'].'/post/icono_'.$top['board']['id'].'.gif" style="float: left; margin-top: 2px;"> <a href="'.$scripturl.'?topic='.$top['id'].'">', $top['subject'], '</a> <span class="points">', $top['count'], '</span></div>';

			echo '</div>
		</div>
        </td></tr>
        </table><input type="text" name="seccion" id="seid" class="hideObj" value="5" >
</div>';

echo '<script type="text/javascript">
$(document).ready(function(){
    count_list();
    });
</script>';


}

?>