var fregister = {
    started         : false,
    step            : 1,
    options         : {},
    cache           : new Array(),
    values          : new Array(),
    messages        : new Array(),
    stats           : new Array(),
    classes         : new Array(),
    txts            : new Array(),
    tooltipsClasses : {
        'info' : 'blue',
        'error' : 'red',
        'correct' : 'green',
        'warning' : 'yellow',
        'loading' : 'gray'
    },

    active : function(obj){
        var txt = $(obj).attr('title');
        var name = $(obj).attr('name');
        switch(name){
            case 'ciudad_state':
                $(obj).select();
            break;
        }

        return this.help(obj, 'info', txt, true);

    },
    
    out : function(obj){
        var val = $(obj).val();

        return this.check(obj, false, true);
        
    },

    help : function(obj, _class, html, no_cache, nofind){
        var stat = (_class == 'empty') ? 'error' : _class;
        var name = $(obj).attr('name');

        if(!nofind){
        if(name=='ciudad_state')
            obj = $('.fhtooltip.ciudad_state');
        else if(name=='recaptcha_response_field'||name=='visual_verification_code')
            obj = $('.fhtooltip.captcha');
        else{
        do{
            var obj = $(obj).next();
        }while(!$(obj).is('.fhtooltip'));
        }
        }
        
        $(obj).attr('style', '');
        $(obj).find('strong').html(html);

        var _classes = new Array('blue', 'red', 'green', 'yellow', 'gray');
        
        for(i=0;i<_classes.length;i++)
            $(obj).removeClass(_classes[i]);

        $(obj).addClass(this.tooltipsClasses[stat]).css('display', 'block');

        this.aligntooltips();

        if(!no_cache){
			this.stats[name] = stat;
			this.messages[name] = html;
		}

        return (stat == 'correct');
        
    },

    hideHelp : function(obj, _class, html){
    var stat = (_class == 'empty') ? 'error' : _class;
    var name = $(obj).attr('name');

        if(name=='ciudad_state')
            obj = $('.fhtooltip.ciudad_state');
        else if(name=='recaptcha_response_field'||name=='visual_verification_code')
            obj = $('.fhtooltip.captcha');
        else{
        do{
           var obj = $(obj).next();
        }while(!$(obj).is('.fhtooltip'));
        }
        var _classes = new Array('blue', 'red', 'green', 'yellow', 'gray');
        
        for(i=0;i<_classes.length;i++)
            $(obj).removeClass(_classes[i]);

        $(obj).css('display', 'none');

        this.stats[name] = stat;
        this.messages[name] = html;

        return (stat == 'correct');

    },

    check : function(obj, no_empty, force){
        var input = $(obj).attr('name');
        var val = $(obj).val();
        
        switch(input){
            case 'nombre':
            case 'apellido':
                if(!force && this.values[input] === val)
					if(this.stats[input]=='empty')
						return no_empty ? this.help(obj, this.stats[input], this.messages[input]) : this.hideHelp(obj, this.stats[input], this.messages[input]);
					else
						return this.help(obj, this.stats[input], this.messages[input]);

                this.values[input] = val;

                if(empty(val))
                    return no_empty ? this.help(obj, 'empty', $txt['obligatory_input']) : this.hideHelp(obj, 'empty', $txt['obligatory_input']);

                if(val.length < 2)
                    return no_empty ? this.help(obj, 'empty', sprintf($txt['error_length_input'], 2)) : this.hideHelp(obj, 'empty', sprintf($txt['error_length_input'],2));

                var regex = /^[\sa-zá-úñ]{2,30}$/i;
                if(regex.test(val) === false)
                    return this.help(obj, 'error', $txt['bad_format_name']);

                return this.help(obj, 'correct', $txt['correct']);
                
            break;
            case 'nick':

                if(!force && this.values[input] === val)
					if(this.stats[input]=='empty')
						return no_empty ? this.help(obj, this.stats[input], this.messages[input]) : this.hideHelp(obj, this.stats[input], this.messages[input]);
					else
						return this.help(obj, this.stats[input], this.messages[input]);

                this.values[input] = val;

                 if(empty(val))
                    return no_empty ? this.help(obj, 'empty', $txt['obligatory_input']) : this.hideHelp(obj, 'empty', $txt['obligatory_input']);

                if(val.length < 5 || val.length > 25)
                    return this.help(obj, 'error', $txt['error_nick_length']);

                if(val.match(/[^a-zA-Z0-9_\-\.]/))
                    return this.help(obj, 'error', $txt['bad_format_nick']);

                var valToLower = val.toLowerCase();
				if(!this.cache[input]){
					this.cache[input] = new Array();
					this.cache[input][valToLower] = new Array();
				}else if(this.cache[input][valToLower])
				return this.cache[input][valToLower]['status'] ? fregister.help(obj, 'correct', this.cache[input][valToLower]['text']) :
                                                                                 fregister.help(obj, 'error', this.cache[input][valToLower]['text']);
				
                this.help(obj, 'loading', $txt['loading']);
                $.ajax({
                    type : 'POST',
                    url  : global.data.scripturl + '?ajax&action=fast-register&section=check&input=' + input,
                    data : input + '=' + encodeURIComponent(val),
                    success : function(h){
                        var stat = parseInt(h.charAt(0));
                        fregister.cache[input][valToLower] = new Array();
			fregister.cache[input][valToLower]['text'] = h.substring(3);
                        
                        switch(stat){
                            case 1:
                                 fregister.cache[input][valToLower]['status'] = true;
                                return fregister.help(obj, 'correct', h.substring(3));
                            break;

                            case 0:
                                 fregister.cache[input][valToLower]['status'] = false;
                                return fregister.help(obj, 'error', h.substring(3));
                            break;
                        }


                         
                    }
                });

             break;
             
             case 'password':

                  if(!force && this.values[input] === val)
					if(this.stats[input]=='empty')
						return no_empty ? this.help(obj, this.stats[input], this.messages[input]) : this.hideHelp(obj, this.stats[input], this.messages[input]);
					else
						return this.help(obj, this.stats[input], this.messages[input]);

                 this.values[input] = val;

                 if(empty(val))
                    return no_empty ? this.help(obj, 'empty', $txt['obligatory_input']) : this.hideHelp(obj, 'empty', $txt['obligatory_input']);

                
                if($.inArray(val.toLowerCase(),registerSett.banned_passwords)!=-1)
                    return this.help(obj, 'warning', $txt['insecure_pass']);

                 if(val === this.values['nick'])
                     return this.help(obj, 'warning', $txt['pass=/=nick']);

                 if(val.length<5 || val.length>35)
                     return this.help(obj, 'warning', $txt['error_password_length']);

                 return this.help(obj, 'correct', $txt['correct']);

             break;

             case 'password2':

                 this.values[input] = val;
                 
                  if(empty(val))
                    return no_empty ? this.help(obj, 'empty', $txt['obligatory_input']) : this.hideHelp(obj, 'empty', $txt['obligatory_input']);

                    $('#registro-form #password').focus().blur();

                if(val !== this.values['password']){
                    this.help($('#registro-form #password'), 'error', $txt['different_passwords_2']);
                    return this.help(obj, 'error', $txt['different_passwords']);
                }

                if(this.stats['password']!='correct')
                    return this.help(obj, 'error', this.messages['password']);

                $('#registro-form #password').focus().blur();
                

                 return this.help(obj, 'correct', $txt['correct']);

             break;

             case 'email':

                 if(!force && this.values[input] === val)
					if(this.stats[input]=='empty')
						return no_empty ? this.help(obj, this.stats[input], this.messages[input]) : this.hideHelp(obj, this.stats[input], this.messages[input]);
					else
						return this.help(obj, this.stats[input], this.messages[input]);

                 this.values[input] = val;

                 if(empty(val))
                    return no_empty ? this.help(obj, 'empty', $txt['obligatory_input']) : this.hideHelp(obj, 'empty', $txt['obligatory_input']);

                if(!val.match(/[0-9a-z=_+\-/][0-9a-z=_\'+\-/\.]*@[\w\-]+(\.[\w\-]+)*(\.[\w]{2,6})$/i))
                    return this.help(obj, 'error', $txt['bad_format']);

                var valToLower = val.toLowerCase();
				if(!this.cache[input]){
					this.cache[input] = new Array();
					this.cache[input][valToLower] = new Array();
				}else if(this.cache[input][valToLower])
				return this.cache[input][valToLower]['status'] ? fregister.help(obj, 'correct', this.cache[input][valToLower]['text']) :
                                                                                 fregister.help(obj, 'error', this.cache[input][valToLower]['text']);

                this.help(obj, 'loading', $txt['loading']);
                $.ajax({
                    type : 'POST',
                    url  : global.data.scripturl + '?ajax&action=fast-register&section=check&input=' + input,
                    data : input + '=' + encodeURIComponent(val),
                    success : function(h){
                        var stat = parseInt(h.charAt(0));
                        fregister.cache[input][valToLower] = new Array();
			fregister.cache[input][valToLower]['text'] = h.substring(3);

                        switch(stat){
                            case 1:
                                 fregister.cache[input][valToLower]['status'] = true;
                                return fregister.help(obj, 'correct', h.substring(3));
                            break;

                            case 0:
                                 fregister.cache[input][valToLower]['status'] = false;
                                return fregister.help(obj, 'error', h.substring(3));
                            break;
                        }



                    }
                });

             break;
             
             case 'dia':
             case 'mes':
             case 'anio':

                 

                 var data = new Array('dia', 'mes', 'anio');

                 for(x in data){
                    
                     this.values[data[x]] = $('#registro-form #' + data[x]).val();
                     
                     if(empty($('#registro-form #' + data[x]).val()))
                         return no_empty ? this.help(obj, 'empty', sprintf($txt['complete_birthday'], data[x].replace('anio', 'a&ntilde;o'))) : this.hideHelp(obj, 'empty', sprintf($txt['complete_birthday'], data[x].replace('anio', 'a&ntilde;o')));

                 }
                 
                 if(registerSett.limit_age)
                    if(this.checkAge(new Array(this.values['dia'], this.values['mes'], this.values['anio'])) < registerSett.limit_age)
                        return this.help(obj, 'warning', sprintf($txt['not_adult'], registerSett.limit_age));

                 
                 return this.help(obj, 'correct', $txt['correct']);
                 
             break;

             case 'sexo':
                    if(!$('#registro-form #sexo_f').is(':checked') && !$('#registro-form #sexo_m').is(':checked'))
					val = '';
				else if($('#registro-form #sexo_f').is(':checked'))
					val = 2;
				else
					val = 1;

                 if(!force && this.values[input] === val)
					if(this.stats[input]=='empty')
						return no_empty ? this.help(obj, this.stats[input], this.messages[input]) : this.hideHelp(obj, this.stats[input], this.messages[input]);
					else
						return this.help(obj, this.stats[input], this.messages[input]);

                 this.values[input] = val;

                if(empty(val))
                    return no_empty ? this.help(obj, 'empty', $txt['obligatory_input']) : this.hideHelp(obj, 'empty', $txt['obligatory_input']);

                return this.help(obj, 'correct', $txt['correct']);

             break;

             case 'pais':
                 if(!force && this.values[input] === val)
					if(this.stats[input]=='empty')
						return no_empty ? this.help(obj, this.stats[input], this.messages[input]) : this.hideHelp(obj, this.stats[input], this.messages[input]);
					else
						return this.help(obj, this.stats[input], this.messages[input]);

                 this.values[input] = val;
                 // this.values['ciudad_state'] = '';
                 // this.hideHelp($('#registro-form #ciudad_state'), 'empty', 'Correcto!');

                if(empty(val))
                    return no_empty ? this.help(obj, 'empty', $txt['obligatory_input']) : this.hideHelp(obj, 'empty', $txt['obligatory_input']);


                this.help(obj, 'correct', $txt['correct']);

                 // this.help($('#registro-form #ciudad_state'), 'loading', 'Cargando...');
                $.ajax({
                    type : 'POST',
                    url  : global.data.scripturl + '?ajax&action=fast-register&section=check&input=' + input,
                    data : input + '=' + encodeURIComponent(val),
                    success : function(h){
                        var stat = parseInt(h.charAt(0));

                        switch(stat){
                            case 1:
                             /* $('#registro-form #ciudad_state').setOptions({
								extraParams: {'pais' : fregister.values['pais']}
								}).flushCache();

                                $('#registro-form #ciudad_state').removeClass('disabled').removeAttr('disabled').val('').focus();*/
                                fregister.help(obj, 'correct', 'Correcto!');
                            break;

                            case 0:
                                fregister.help(obj, 'error', h.substring(3));
                            break;
                        }



                    }
                });

             break;/*PLUGIN_CITIES_JS=
             case 'ciudad_state':

                 val = val.toLowerCase();

                 if(!force && val == this.values['ciudad_text'] && this.values[input] === this.values['ciudad_id'])
					if(this.stats[input]=='empty')
						return no_empty ? this.help(obj, this.stats[input], this.messages[input]) : this.hideHelp(obj, this.stats[input], this.messages[input]);
					else
						return this.help(obj, this.stats[input], this.messages[input]);

                 

                if(empty(val))
                    return no_empty ? this.help(obj, 'empty', 'Este campo es necesario.') : this.hideHelp(obj, 'empty', 'Este campo es necesario.');

                if(val != this.values['ciudad_text']){
                    this.values[input] = '';
                    this.values['ciudad_text'] = false;
                    this.values['ciudad_id'] = false;
                    return this.help(obj, 'error', 'La ciudad es incorrecta.');
                }

                this.values[input] = this.values['ciudad_id'];

                this.help(obj, 'loading', 'Cargando...');
                $.ajax({
                    type : 'POST',
                    url  : global.data.scripturl + '?ajax&action=fast-register&section=check&input=' + input,
                    data : input + '=' + encodeURIComponent(val) + '&ciudad_id=' + this.values['ciudad_id'],
                    success : function(h){
                        var stat = parseInt(h.charAt(0));

                        switch(stat){
                            case 1:
                                fregister.help(obj, 'correct', 'Correcto!');
                            break;

                            case 0:
                                fregister.values[input] = '';
                                fregister.values['ciudad_text'] = false;
                                fregister.values['ciudad_id'] = false;
                                fregister.help(obj, 'error', h.substring(3));
                            break;
                        }



                    }
                });

                break;
                =PLUGIN_CITIES_JS*/
                case 'recaptcha_challenge_field':
                    return true;
		break;
                case 'recaptcha_response_field':
                case 'visual_verification_code':

                    
                    if(!force && this.values[input] === val)
					if(this.stats[input]=='empty')
						return no_empty ? this.help(obj, this.stats[input], this.messages[input]) : this.hideHelp(obj, this.stats[input], this.messages[input]);
					else
						return this.help(obj, this.stats[input], this.messages[input]);

                 this.values[input] = val;
                 
                 if(registerSett.visual_verification == 'recaptcha')
                 this.values['recaptcha_challenge_field'] = $('#registro-form #recaptcha_challenge_field').val();

                if(empty(val))
                    return no_empty ? this.help(obj, 'empty', $txt['obligatory_input']) : this.hideHelp(obj, 'empty', $txt['obligatory_input']);


                    return this.help(obj, 'correct', $txt['correct']);

                break;
                case 'terminos':
                    val = $(obj).is(':checked');

                     if(!force && this.values[input] === val)
					if(this.stats[input]=='empty')
						return no_empty ? this.help(obj, this.stats[input], this.messages[input]) : this.hideHelp(obj, this.stats[input], this.messages[input]);
					else
						return this.help(obj, this.stats[input], this.messages[input]);

                 this.values[input] = val;

                  if(empty(val))
                    return no_empty ? this.help(obj, 'empty', $txt['obligatory_input']) : this.hideHelp(obj, 'empty', $txt['obligatory_input']);

                return this.help(obj, 'correct', $txt['correct']);

                break;
             
        }
    },

    checkStep : function(){
        var ok = true, inputs;
        switch(this.step){
			case 1:
				inputs = $('#registro-form .paso_1 :input');
				inputs.each(function(){
					if(!fregister.check(this, true)){
						ok = false;
					}
				});

				return ok;
				break;
			case 2:
				inputs = $('#registro-form .paso_2 :input');
				inputs.each(function(){
					if(!fregister.check(this, true)){
						ok = false;
					}
				});

				return ok;
				break;
                        case 3:
				inputs = $('#registro-form .paso_3 :input');
				inputs.each(function(){
					if(!fregister.check(this, true)){
						ok = false;
					}
				});

				return ok;
				break;
		}
                
		return true;
    },

    nextstep : function(step, first_focus){

        if(step > this.step && !this.checkStep())
            return false;

        if(step > registerSett.pasos)
            return false;

        // Facilidad para el usuario :)
        if(!this.started){
            $('#registro-form .input-form input.text').keypress(function(e){
                if(e.which == 13 && !empty($(this).val())){
                    var _this = $(this).parent().next().children('input.reginput');
                    $(_this).focus();
                }
            });
        }
                                    
       switch(step){
            case 1:
                $('#registro-form .paso_2').hide();
                $('#registro-form .paso_3').hide();
                $('#registro-form .paso_1').show();
                
                sp_dialog.buttons([{
                        text : "Siguiente",
                        "class" : "sp-button blue right",
                        click : function(){
                            fregister.nextstep(2);
                        }
                }]);
                sp_dialog.center();

                if(first_focus)
                setTimeout(function(){
                    $('#registro-form .paso_1 input:first').focus();
                },500);

                
            break;
            case 2:

                $('#registro-form .paso_1').hide();
                $('#registro-form .paso_3').hide();
                $('#registro-form .paso_2').show();

                sp_dialog.buttons([{
                        text : registerSett.pasos == 2 ? "Terminar" : "Siguiente",
                        "class" : registerSett.pasos == 2 ? "sp-button green right" : "sp-button blue right" ,
                        click : function(){
                            if(registerSett.pasos == 2)
                                fregister.register();
                            else
                                fregister.nextstep(3);
                        }
                }]);
                sp_dialog.center();
                
                if(first_focus)
                $('#registro-form .paso_2 input:first').focus();

            break;
            case 3:
                if(registerSett.pasos == 2)
                    return false;

                $('#registro-form .paso_1').hide();
                $('#registro-form .paso_2').hide();
                $('#registro-form .paso_3').show();

                sp_dialog.buttons([{
                        text : "Terminar",
                        "class" : "sp-button green right",
                        click : function(){
                            fregister.register();
                        }
                }]);

                if(first_focus)
                $('#registro-form .paso_3 input:first').focus();

            break;


        }

        this.step = step;

    },

    register : function(){

      if(!this.checkStep())
          return false;

      $('#registro-form .fhtooltip').hide();

      var parametros = '';
      var amp = '';
      
		for(var campo in this.values){
			parametros += amp + campo + '=' + encodeURIComponent(this.values[campo]);
			amp = '&';
		}


      sp_dialog.show('load');

      $.ajax({
			type: 'POST',
			url: global.data.scripturl + '?ajax&action=fast-register&section=registrarse',
			data: parametros,
			success: function(h){
                        
				switch(h.substring(0, strpos(h, ':'))){
					case '0': alert(h); break;
                                        case 'nombre':
                                        case 'apellido':
					case 'nick':
                                        case 'password':
                                        case 'email':
                                                fregister.nextstep(1);
						fregister.help($('#registro-form #' + h.substring(0, strpos(h, ':'))), 'error', h.substring(strpos(h, ':')+2));
						break;
                                        case 'nacimiento':
                                                fregister.nextstep(1);
                                                fregister.help($('#registro-form #dia'), 'error', h.substring(strpos(h, ':')+2));
                                        break;
					case 'sexo':
                                                fregister.nextstep(2);
                                                fregister.help($('#registro-form #sexo_m'), 'error', h.substring(strpos(h, ':')+2));
                                        break;
                                        case 'captcha':
                                            fregister.nextstep(registerSett.pasos);
                                            var object = null;

                                            if(registerSett.visual_verification=='recaptcha')
                                                object = $('#registro-form #recaptcha_response_field');
                                            else if(registerSett.visual_verification=='captcha')
                                                object = $('#registro-form #visual_verification_code');

                                            if(empty(object))
                                                fregister.help($('#captcha'), 'error', h.substring(strpos(h, ':')+2), false, true);
                                            else
                                                fregister.help($(object), 'error', h.substring(strpos(h, ':')+2), false);

					break;
					case '1':
                                                        sp_dialog.close();
                                                        sp_dialog.options = {
                                                            'title' :  h.substring(3).split('|')[0],
                                                            'body' :  h.substring(3).split('|')[1]
                                                        }
                                                        sp_dialog.show();

                                                        sp_dialog.buttons([{
                                                                text : 'Aceptar',
                                                                "class" : 'right close-button-dialog',
                                                                click : function(){
                                                                    sp_dialog.close(function(){
                                                                        location.reload();
                                                                    });
                                                                }
                                                        }]);
													
						break;
				}

                                
				 if(h.substring(0, strpos(h, ':')) != '1'){

                                        if(registerSett.visual_verification == 'captcha')
                                            refreshImages();

                                        else if(registerSett.visual_verification == 'recaptcha'){
                                            Recaptcha.reload('t');
                                            fregister.values['recaptcha_response_field'] = '';
                                        }
                                            }


			},
			error: function(){

                            sp_dialog.close();
                            
                            sp_dialog.alert({
                                'title' : 'Error!',
                                'body' : 'An error has ocurred.'
                            })
                            
			},
			complete: function(){
				
                                sp_dialog.endload(function(){
                                    fregister.aligntooltips();
                                }, true);
                                
			}
		});

                sp_dialog.center();


    },

    aligntooltips : function(element){

        if(!element){
        $('#registro-form .input-form').each(function(){
        
          var left = $(this)[0].offsetWidth;
          var fhtooltip = $(this).children('.fhtooltip');
          $(fhtooltip).css({
              'left' : left + 4
          });

          });
          }else{
                var left = $(element).parent()[0].offsetWidth;
                $(element).css({
                    'left' : left + 4
                });
              

          }
		  
		if(!element){
		
			$('.fhtooltip').each(function(){

				var clone = $(this).clone(),
					width,
					left = $(this).parent('.input-form').offsetWidth+4;

				$(clone).addClass('hideObj').appendTo('body');
				width = $(clone)[0].offsetWidth-25;
				$(clone).remove();

				$(this).css({
					'left' : left,
					'width' : width
				});
				
				

			});
			
		}else{
                var clone = $(element).clone(),
					width,
					left = $(element).parent('.input-form').offsetWidth+4;
				
				$(clone).addClass('hideObj').appendTo('body');
				width = $(clone)[0].offsetWidth-25;
				$(clone).remove();

				$(element).css({
					'left' : left,
					'width' : width
				});
          }

    },

    checkAge : function(age){

    var fecha = new Date(age[1] + '/' + age[0] + '/' + age[2]),
        hoy = new Date(),
        edad = parseInt((hoy-fecha)/365/24/60/60/1000);

        return edad;

    }

}

