<?php

/*********************************
** Spirate Script - Version 2.4 **
*******  Mod Comunidades   *******

*** Mod Created By Mr.Freack  ****
**http://www.angelix-system.net***
**http://facebook.com/Mr.Freack**/

function template_comunidades(){
	global $context, $settings, $txt, $modSettings, $scripturl, $tipo, $eliminados, $cantnot, $options;
	    global $id, $pagarray, $modSettings, $db_prefix;

//Columna izquierda - Bloque Ultimos temas
echo'
<!-- .home-column-1 -->
   <div class="home-column-1 clearfix">
      <div class="box">
         <div class="box_title">
            '.$txt['comunidades_lasts_thems'].'                  
            <select id="post-filter-select" onchange="$.Comunidades.categoria(this.value)">
				       <option value="0">'.$txt['comunidades_selectboard'].'</option>';
						   foreach($context['categorias'] as $board){
			         echo'
			         <option value="'.$board['id'].'" '.($_GET['categoria'] == $board['id'] ?' selected="selected"':'').'>'.$board['name'].'</option>';}			
		        echo'
		        </select>
			   </div>
         <div class="box_cuerpo">';
            last_temas();
    echo'</div>
      </div>';
    if(!empty($context['total_pages'])){
      echo'
      <strong>'.$txt['comunidades_pages'].': </strong>'.$context['total_pages'];
      echo'
      <div class="inset-bar wrap-paginator clearfix">' .$context['paginacion'] . '</div>';
    }
    echo'
   </div>
<!-- .home-column-1 -->';

//Columna Central
echo'
<!-- columna 2 -->
   <div class="home-column-2">
      <div class="minimal-box" style="padding-top: 0;">
         <div class="title" style="padding-top: 0">
            <h3 class="color-orange">'.$txt['comunidades_statics'].'</h3>
         </div>
         <div class="content">
            <div style="margin:5px 0 0 0;">
               <div class="clearfix">
                  <div class="left">
                     '.sprintf('<strong>%d</strong> usuario%s online', $context['only_users_online'], $context['only_users_online'] > 1 || $context['only_users_online'] == 0 ? 's' : '').'
                  </div>
                  <div class="right">
                     <strong>'.(!empty($modSettings['TotalComunidades']) ? $modSettings['TotalComunidades']:0).'</strong>  '.$txt['comunidades_m'].' 
                  </div>
               </div>

               <div class="clearfix">
                  <div class="left">
                     <strong>'.(!empty($modSettings['TotalTemas']) ? $modSettings['TotalTemas']:0).'</strong>  '.$txt['comunidades_thems_m'].'
                  </div>
                  <div class="right">
                     <strong>'.(!empty($modSettings['TotalRespuestas']) ? $modSettings['TotalRespuestas']:0).'</strong>  '.$txt['comunidades_answers_m'].'
                  </div>
               </div>
            </div>
         </div>
      </div>

      <div class="minimal-box fleft" style="padding-top: 0;">
         <div class="title fleft" style="width:306px;">
            <h3 class="fleft">'.$txt['comunidades_last_answers'].'</h3>   
		        <a class="fright" href="#" onclick="$.Comunidades.actualizar_respuestas(1); return false;">
		           <i class="iconos_ reload" style="margin:0"></i>
			      </a>
	       </div>
         <div class="content fleft">
		        <ul id="last_comments" class="list smallfont">';
            if(empty($context['recent']['count'])){
            echo'
               <div class="error">'.$txt['comunidades_empty_answers'].'</div>';
            }else{
               foreach ($context['respuestas']['recent'] as $comments){
         echo '<li>
                  <span class="subinfo">
                     <a href="'.$scripturl.'?action=profile;u='.$comments['autor'].'">'.$comments['username'].'</a>
                  </span> 
                  <a href="'.$scriptur.'?action=comunidades;sa=tema;idtema='.$comments['id'] .'#all-comments" title="',$comments['titulo'],'">
                     '. _substr($comments['titulo'], 0, 35, 30).'
                  </a>
               </li>';}
            }
       echo'</ul>
	       </div>
      </div>









<!-- aqui me quede �� -->












<div class="minimal-box" style="padding-top: 0;" id="TopPopulares">
	<div class="title clearfix">
		<h3 class="left">'.$txt['comunidad_populars'].'</h3>
		<div class="UIdrop drop">
			<span><a class="color-black">Semanal</a></span>
			<ul id="TopPopulares-menu">
				<li><a onclick="$.Comunidades.nTopsTabsTop(\'TopPopulares\',\'weekly\',this);" id="semanal">Semanal</a></li>				
				<li><a onclick="$.Comunidades.nTopsTabsTop(\'TopPopulares\',\'monthly\',this);" id="mensual">Mensual</a></li>				
				<li><a onclick="$.Comunidades.nTopsTabsTop(\'TopPopulares\',\'all\',this);" id="siempre">Siempre</a></li>				
			</ul>
		</div>
	</div>
  <div class="content">
	   <ul class="list" id="weekly">';
     if(!empty($context['comunidades_week'])){
	   $iterator = 1;
	   foreach($context['comunidades_week'] as $cp){
		 echo '
			  <li>
			     <div class="subinfo">
			        <span class="number-list color-black size-15">'.$iterator.'</span> 
			        <a href="'.$scriptul.'?action=comunidades;sa=comunidad;idco='.$cp['id'].'">'.recortart($cp['titulo'],38).'</a>
			     </div> 
			     <span class="UIspan points">'.$cp['puntos'].'</span>
			  </li>';$iterator++;
	   }
	   }
	   else{
	      echo'<div class="error">'.$txt['comunidades_no_populars_week'].'</div>';
	   }
	   echo'
	   </ul>';
	
	echo'
	   <ul class="list hide" id="monthly">';
     if(!empty($context['comunidades_month'])){
	      $iterator = 1;
    foreach($context['comunidades_month'] as $cp){
		 echo '
			  <li>
			     <div class="subinfo">
			        <span class="number-list color-black size-15">'.$iterator.'</span> 
			        <a href="'.$scriptul.'?action=comunidades;sa=comunidad;idco='.$cp['id'].'">'.recortart($cp['titulo'],38).'</a>
			     </div> 
			     <span class="UIspan points">'.$cp['puntos'].'</span>
			  </li>';$iterator++;
	   }
	   }
	   else{
	      echo'<div class="error">'. $txt['comunidades_no_populars_month'].'</div>';
	   }
	   echo '
	   </ul>
	   <ul class="list hide" id="all">';
     if(!empty($context['comunidades_all'])){
        $iterator = 1;
	   foreach($context['comunidades_all'] as $cp){
		 echo '
			  <li>
			     <div class="subinfo">
			        <span class="number-list color-black size-15">'.$iterator.'</span> 
			        <a href="'.$scriptul.'?action=comunidades;sa=comunidad;idco='.$cp['id'].'">'.recortart($cp['titulo'],38).'</a>
			     </div> 
			     <span class="UIspan points">'.$cp['puntos'].'</span>
			  </li>';$iterator++;
	   }
	   }
	   else{
	      echo'<div class="error">'.$txt['comunidades_no_populars'].'</div>';
	   }
	   echo '
	   </ul>
  </div>
</div>

<div class="minimal-box" style="padding-top: 0;">
<div class="title"><h3>'.$txt['comunidad_recents'].'</h3></div>
    <div class="content">';
                if(empty($context['comunidad']['recientes']))
                    echo '<div class="error">No se encontraron comentarios.</div>';
                else
                    foreach ($context['comunidad']['recientes'] as $cm)
                     echo '<div class="list-element ">
<i class="iconos_ cat_'.$cm['id_categoria'].'"></i>
<a style="padding: 2px 1px 2px 25px" href="'.$scriptul.'?action=comunidades;sa=comunidad;idco='.$cm['id'].'" class="titletema" title="'.$cm['titulo'].'">'.recortart($cm['titulo'],38).'</a>
</div>';
echo '
	</div>
</div>

</div>
<!-- .columna 2 -->';
        
//Columna Derecha			
echo'
<!-- .columna 3 -->
<div class="home-column-3 comunidad">

<!-- USER INVITATION -->
	<div class="box comunidad-orange">
    <div class="box_title comunidad-orange">'.$txt['cmds_title'].'</div>
        <div class="box_cuerpo comunidad-orange">
           '.$context['forum_name'].' '.$txt['index_welcome'].'
           <br><br>
           <center>
              <a class="sp-button yellow" onclick="location.href=\''.$scripturl.'?action=comunidades;sa=crearcomunidad\'">'.$txt['potear'].'</a>
           </center>
        </div>
  </div>
	
<!-- COMUNIDADES DESTACADAS -->	

	<div class="box comunidad-orange">
    <div class="box_title comunidad-orange">'.$txt['comunidad_destacada'].'</div>
    <div class="box_cuerpo comunidad-orange">

		   <div class="avaComunidad clearfix">
			    <a href="http://www.taringa.net/comunidades/pprogramar/">
				     <img src="http://localhost/FBA72C58B.gif" alt="pprogramar" title="Programar.org.ar">
			    </a>
		   </div>
		   <a href="http://www.taringa.net/comunidades/pprogramar/" title="Programar.org.ar">
			    Programar.org.ar		
			 </a>
	  </div>
  </div>
</div><!-- /columna 3 -->

<script>
   var boardid = \''.$_GET['id'].'\';
</script>
';

}


// �LTIMOS TEMAS

function last_temas(){
    global $context, $settings, $options, $txt, $scripturl, $limit_posts, $db_prefix;
    global $pagarray, $id, $func;

echo'
<div class="list">';
   if($context['lista']['count']){
      foreach($context['temas']['lista'] as $temas){
    echo'<div class="list-element" style="height:35px;">
            <a href="'.$scriptul.'?action=comunidades;sa=tema;idtema='.$temas['id'].'" class="titletema" title="'.$temas['titulo'].'">
               <i class="iconos_ cat_'.$temas['id_categoria'].'"style="margin-right:10px;"></i>
               '.recortart($temas['titulo'],45).'
            </a>
            <p>En <a href="'.$scriptul.'?action=comunidades;sa=comunidad;idco='.$temas['id_comunidad'].'" title="'.$temas['title'].'">'.recortart($temas['title'],28).'</a> por <a href="'.$scripturl.'?action=profile;u='.$temas['id_admin'].'">'.$temas['name'].'</a></p>
         </div>';
      }
   }
   else{
        if(empty($context['total_comunitys']))
       echo '<div class="notice">
               <center>
                  '.$txt['nocomunidades'].'
                  <br>
                 <a class="sp-button bluesky" href="'.$scripturl.'?action=comunidades;sa=crearcomunidad" title="'.$txt['add_first'].'">
                    '.$txt['add_first'].'
                 </a>
               </center>
             </div>';
        else if($_REQUEST['page'] > $context['total_comunitys'])
            echo '<div class="notice">Eso es todo!, no se encontraron mas Comunidades</div>';
   }
echo'
</div>';
}


// ADMINISTRADOR DE COMUNIDADES
function template_AdminComunidades(){
	global $context, $settings, $txt, $modSettings, $scripturl, $tipo, $eliminados, $cantnot, $options;

echo'
<div id="admR">
   <div class="box_title">'.$txt['comunidades_admin'].'</div>
	 <div class="box_cuerpo">
			   <b>'.$txt['comunidades_welcome'].' '.$context['user']['name'].'!</b>
			   <div style="font-size: 0.85em; padding-top: 1ex;">'.$txt['comunidades_admin_desc'].'</div>
	 </div>
	    
	 <div style="margin: 10px 0 10px">
			<img src="'.$settings['images_url'].'/selected.gif" alt="*" /> 
	    <a href="'.$scripturl.'?action=comunidades;sa=adminComunidades">'.$txt['comunidades'].'</a> | 
			<a href="'.$scripturl.'?action=comunidades;sa=adminPublicidad">'.$txt['comunidades_publicidad_'].'</a> | 
			<a href="'.$scripturl.'?action=comunidades;sa=adminCategorias">'.$txt['comunidades_categorias'].'</a>
	 </div>	
	 
   <form action="'. $scripturl.'?action=comunidades;sa=adminComunidades" method="post" accept-charset="'. $context['character_set'].'">
	    <div class="box_title">'.$txt['comunidades_config_comunidades'].'</div>
	    <div class="box_cuerpo">
			   <table border="0" cellspacing="0" cellpadding="4" align="center" width="100%" class="tborder">	
			      <tr>
	             <th width="50%" align="right">
			            <label for="comunidades_activas_check">'.$txt['comunidades_activas'].'</label> <span style="font-weight: normal;"></span>
			         </th>
			         <td valign="top">
			            <input type="checkbox" name="comunidades_activas" id="comunidades_activas_check"'.(empty($modSettings['comunidades_activas'])?'':' checked="checked"').' class="check" />
			         </td>
	          </tr>
	          
			      <tr>
	             <th width="50%" align="right">
			            <label for="enableStickyComunidades_check">'.$txt['comunidades_enableStickyComunidades'].'</label> <span style="font-weight: normal;"></span>
			         </th>
			         <td valign="top">
			            <input type="checkbox" name="enableStickyComunidades" id="enableStickyComunidades_check"'.(empty($modSettings['enableStickyComunidades'])?'':' checked="checked"').' class="check" />
			         </td>
	          </tr>
	          
			      <tr>
	             <th width="50%" align="right">
			            <label for="enableStickyTemas_check">'.$txt['comunidades_enableStickyTemas'].'</label> <span style="font-weight: normal;"></span>
			         </th>
			         <td valign="top">
			            <input type="checkbox" name="enableStickyTemas" id="enableStickyTemas_check"'.(empty($modSettings['enableStickyTemas'])?'':' checked="checked"').' class="check" />
			         </td>
	          </tr>
	          
			      <tr>
	             <th width="50%" align="right">
			            <label for="subcategoriasTemas_check">'.$txt['comunidades_subcategoriasTemas'].'</label> <span style="font-weight: normal;"></span>
			         </th>
			         <td valign="top">
			            <input type="checkbox" name="subcategoriasTemas" id="subcategoriasTemas_check"'.(empty($modSettings['subcategoriasTemas'])?'':' checked="checked"').' class="check" />
			         </td>
	          </tr>
	 
	          <tr>
			         <th width="50%" align="right">
				          <label for="comunidades_puntos_activos_check">'.$txt['comunidades_puntos_activos'].'</label> <span style="font-weight: normal;"></span>
			         </th>
			         <td valign="top">
				          <input type="checkbox" name="comunidades_puntos_activos" id="comunidades_puntos_activos_check"'.(empty($modSettings['comunidades_puntos_activos']) ? '' : ' checked="checked"'). ' class="check" />
			         </td>
	          </tr>
			
		         <tr>
			         <th width="50%" align="right">
				         <label for="publicidad_activa_check">'.$txt['comunidades_publicidad_activa'].'</label>
			         </th>
			         <td valign="top">
				         <input type="checkbox" name="publicidad_activa" id="publicidad_activa_check" '.(empty($modSettings['publicidad_activa']) ? '' : ' checked="checked"').' class="check" /> &nbsp; <a href="'. $scripturl.'?action=comunidades;sa=adminPublicidad">'.$txt['comunidades_publicidad_activa_link'].'</a>
			         </td>
	          </tr>
			
		         <tr>
			         <th width="50%" align="right">
				         <label for="btn_nextprev_check">'.$txt['active_next_prev'].'</label>
			         </th>
			         <td valign="top">
				         <input type="checkbox" name="btn_nextprev" id="btn_nextprev_check" '.(empty($modSettings['btn_nextprev']) ? '' : ' checked="checked"').' class="check" />
			         </td>
	          </tr>
	 
	          <tr>
			         <th width="50%" align="right">
				         <label for="SetTimeTop_input">'.$txt['comunidades_SetTimeTop'].'</label> <span style="font-weight: normal;"></span>
				         <div class="smalltext" style="font-weight: normal;">'.$txt['comunidades_mins_desc'].'</div>
			         </th>
			         <td valign="top">
				         <input type="text" name="SetTimeTop" id="SetTimeTop_input" value="'.(empty($modSettings['SetTimeTop']) ? '0' : $modSettings['SetTimeTop']).'" size="5" maxlength="2"/> '. $txt['comunidades_mins'].'
		         	</td>
	          </tr>		
	 
	          <tr>
			         <th width="50%" align="right">
				         <label for="SetTimeTopTemas_input">'.$txt['comunidades_SetTimeTopTemas'].'</label> <span style="font-weight: normal;"></span>
				         <div class="smalltext" style="font-weight: normal;">'.$txt['comunidades_mins_desc'].'</div>
			         </th>
			         <td valign="top">
				         <input type="text" name="SetTimeTopTemas" id="SetTimeTopTemas_input" value="'.(empty($modSettings['SetTimeTopTemas']) ? '0' : $modSettings['SetTimeTopTemas']).'" size="5" maxlength="2"/> '. $txt['comunidades_mins'].'
		         	</td>
	          </tr>		
	 
	          <tr>
			         <th width="50%" align="right">
				         <label for="comunidades_index_input">'.$txt['comunidades_index'].'</label> <span style="font-weight: normal;"></span>
				         <div class="smalltext" style="font-weight: normal;">'.$txt['count_cmds_index_zero'].'</div>
			         </th>
			         <td valign="top">
				         <input type="text" name="comunidades_index" id="comunidades_index_input" value="'.(empty($modSettings['comunidades_index']) ? '0' : $modSettings['comunidades_index']).'" size="5" /> '. $txt['cmds_title'].'
		         	</td>
	          </tr>		
	 
	          <tr>
			         <th width="50%" align="right">
				         <label for="comunidades_mycommunitys_input">'.$txt['comunidades_mycommunitys'].'</label> <span style="font-weight: normal;"></span>
				         <div class="smalltext" style="font-weight: normal;">'.$txt['count_cmds_index_zero'].'</div>
			         </th>
			         <td valign="top">
				         <input type="text" name="comunidades_mycommunitys" id="comunidades_mycommunitys_input" value="'.(empty($modSettings['comunidades_mycommunitys']) ? '0' : $modSettings['comunidades_mycommunitys']).'" size="5" /> '. $txt['cmds_title'].'
		         	</td>
	          </tr>		
	 
	          <tr>
		         	<th width="50%" align="right">
				         <label for="temas_index_input">'.$txt['comunidades_thems_index'].'</label> <span style="font-weight: normal;"></span>
				         <div class="smalltext" style="font-weight: normal;">'.$txt['comunidades_thems_index_zero'].'</div>
			         </th>
			         <td valign="top">
			         	<input type="text" name="temas_index" id="temas_index_input" value="'.(empty($modSettings['temas_index']) ? '0' : $modSettings['temas_index']).'" size="5" /> '.$txt['pub_title'].'
			         </td>
	          </tr>	

	          <tr>
			         <th width="50%" align="right">
				         <label for="comentarios_index_input">'. $txt['comunidades_comentarios_index'].'</label>
				         <div class="smalltext" style="font-weight: normal;">'. $txt['comunidades_comentarios_index_zero'].'</div>
			         </th>
			         <td valign="top">
				         <input type="text" name="comentarios_index" id="comentarios_index_input" value="'.(empty($modSettings['comentarios_index']) ? '0' : $modSettings['comentarios_index']).'" size="5" /> '. $txt['comunidades_comments'].'
			         </td>
		         </tr>

	          <tr>
			         <th width="50%" align="right">
				         <label for="comentarios_comunidades_input">'. $txt['comunidades_comentarios_index_c'].'</label>
				         <div class="smalltext" style="font-weight: normal;">'. $txt['comunidades_comentarios_index_zero'].'</div>
			         </th>
			         <td valign="top">
				         <input type="text" name="comentarios_comunidades" id="comentarios_comunidades_input" value="'.(empty($modSettings['comentarios_comunidades']) ? '0' : $modSettings['comentarios_comunidades']).'" size="5" /> '. $txt['comunidades_comments'].'
			         </td>
		         </tr>

	          <tr>
			         <th width="50%" align="right">
				         <label for="comentarios_temas_input">'. $txt['comunidades_comentarios_index_t'].'</label>
				         <div class="smalltext" style="font-weight: normal;">'. $txt['comunidades_comentarios_index_zero'].'</div>
			         </th>
			         <td valign="top">
				         <input type="text" name="comentarios_temas" id="comentarios_temas_input" value="'.(empty($modSettings['comentarios_temas']) ? '0' : $modSettings['comentarios_temas']).'" size="5" /> '. $txt['comunidades_comments'].'
			         </td>
		         </tr>

	          <tr>
			         <th width="50%" align="right">
				         <label for="subcomentarios_temas_input">'. $txt['comunidades_comentarios_index_sub'].'</label>
				         <div class="smalltext" style="font-weight: normal;">'. $txt['comunidades_comentarios_index_zero_sub'].'</div>
			         </th>
			         <td valign="top">
				         <input type="text" name="subcomentarios_temas" id="subcomentarios_temas_input" value="'.(empty($modSettings['subcomentarios_temas']) ? '0' : $modSettings['subcomentarios_temas']).'" size="5" /> '. $txt['comunidades_subcomments'].'
			         </td>
		         </tr>

	          <tr>
			         <th width="50%" align="right">
				         <label for="max_descripcionLength_input">'. $txt['comunidades_max_descripcionLength'].'</label>
				         <div class="smalltext" style="font-weight: normal;">'.$txt['comunidades_characters_zero'].'</div>
			         </th>
			         <td valign="top">
				         <input type="text" name="max_descripcionLength" id="max_descripcionLength_input" value="'.(empty($modSettings['max_descripcionLength']) ? '0' : $modSettings['max_descripcionLength']).'" size="5" maxlength="5"/> '.$txt['comunidades_characters'].'
			         </td>
		         </tr>

	          <tr>
			         <th width="50%" align="right">
				         <label for="max_bodyLength_input">'.$txt['comunidades_max_bodyLength'].'</label>
				         <div class="smalltext" style="font-weight: normal;">'.$txt['comunidades_characters_zero'].$txt['comunidades_max_bodyLength_help'].'</div>
			         </th>
			         <td valign="top">
				         <input type="text" name="max_bodyLength" id="max_bodyLength_input" value="'.(empty($modSettings['max_bodyLength']) ? '0' : $modSettings['max_bodyLength']).'" size="5" maxlength="5"/> '.$txt['comunidades_characters'].'
			         </td>
		         </tr>

	          <tr>
			         <th width="50%" align="right">
				         <label for="comunidades_anti_flood_input">'.$txt['comunidades_time_min_flood'].'</label>
				         <div class="smalltext" style="font-weight: normal;">'.$txt['comunidades_zero_desc_antiflood'].'</div>
			         </th>
			         <td valign="top">
				         <input type="text" name="comunidades_anti_flood" id="comunidades_anti_flood_input" value="'.(empty($modSettings['comunidades_anti_flood']) ? '0' : $modSettings['comunidades_anti_flood']).'" size="5" maxlength="2"/> '.$txt['comunidades_segundos'].'
			         </td>
		         </tr>

	          <tr>
			         <th width="50%" align="right">
				         <label for="user_twitter_input">'.$txt['comunidades_twt'].'</label>
				         <div class="smalltext" style="font-weight: normal;">'.$txt['comunidades_twt_desc'].'</div>
			         </th>
			         <td valign="top">
				         @<input type="text" name="user_twitter" id="user_twitter_input" value="'.(empty($modSettings['user_twitter']) ? '' : $modSettings['user_twitter']).'" size="20" maxlength="60"/>
			         </td>
		         </tr>
		         
         </table>
			   <center>
            <input class="sp-button bluesky" type="submit" name="save_settings" value="'.$txt['manageposts_settings_submit'].'" />
		        <input type="hidden" name="sc" value="'. $context['session_id'].'" />
         </center>
	    </div>
	 </form>
</div>
';
}


// ADMINISTRADOR DE PUBLICIDAD EN COMUNIDADES
function template_adminPublicidad(){
	global $context, $settings, $txt, $modSettings, $scripturl, $tipo, $eliminados, $cantnot, $options;
echo'
<div id="admR">
   <div class="box_title">'.$txt['comunidades_publicidad'].'</div>
	    <div class="box_cuerpo">
					'.$txt['comunidades_publicidad_desc'].'
			</div>
	    
	    <div style="margin: 10px 0 10px">
				 <a href="'.$scripturl.'?action=comunidades;sa=adminComunidades">'.$txt['comunidades'].'</a> | 
				 <img src="'.$settings['images_url'].'/selected.gif" alt="*" /> 
				 <a href="'.$scripturl.'?action=comunidades;sa=adminPublicidad">'.$txt['comunidades_publicidad_'].'</a> | 
			   <a href="'.$scripturl.'?action=comunidades;sa=adminCategorias">'.$txt['comunidades_categorias'].'</a> 
			</div>	 
	      
      <div class="box_title">'.$txt['comunidades_publicidad_space'].'</div>
		  <form action="'.$scripturl.'?action=comunidades;sa=adminPublicidad" method="post" accept-charset="'. $context['character_set'].'">
			  <div class="box_cuerpo">
				   <span class="floatR">
						  '.$txt['comunidades_publicidad_over_title'].'
					 </span>
						  
					 <div style="margin-bottom: 2ex;">
						  <textarea rows="3" cols="65" name="publicidad_one" style="width: 85%;">'.$modSettings['publicidad_one'].'</textarea>
					 </div>
					
					 <b>'.$txt['comunidades_previa'].'</b>
					 <div class="box-info">
						  <div style="overflow: auto; width: 100%; height: 15ex;">'.$modSettings['publicidad_one'].'</div>
					 </div>
						  
					 <hr>
					 
				   <span class="floatR">
						  '.$txt['comunidades_publicidad_over_comment'].'
					 </span>
						  
					 <div style="margin-bottom: 2ex;">
						  <textarea rows="3" cols="65" name="publicidad_two" style="width: 85%;">'.$modSettings['publicidad_two'].'</textarea>
					 </div>
					
					 <b>'.$txt['comunidades_previa'].'</b>
					 <div class="box-info">
						  <div style="overflow: auto; width: 100%; height: 15ex;">'.$modSettings['publicidad_two'].'</div>
					 </div>
					
					 <hr>
						  
					 <center>
					    <input  class="sp-button bluesky" type="submit" name="save_settings" value="'.$txt['manageposts_settings_submit'].'" /> 
			        <input type="hidden" name="sc" value="'. $context['session_id'].'" />
			     </center>
			  </div>
		  </form>
</div>
';
}


// ADMINISTRADOR DE PUBLICIDAD EN COMUNIDADES
function template_adminCategorias(){
	global $context, $settings, $txt, $modSettings, $scripturl, $tipo, $eliminados, $cantnot, $options;

echo'
<div id="admR">
   <div class="box_title">'.$txt['comunidades_categorias_'].'</div>
			<div class="box_cuerpo">
					'.$txt['comunidades_categorias_desc'].'
			</div>
			
			<div style="margin: 10px 0 10px">
	       <a href="'.$scripturl.'?action=comunidades;sa=adminComunidades">'.$txt['comunidades'].'</a> | 
			   <a href="'.$scripturl.'?action=comunidades;sa=adminPublicidad">'.$txt['comunidades_publicidad_'].'</a> | 
			   <img src="'.$settings['images_url'].'/selected.gif" alt="*" /> 
			   <a href="'.$scripturl.'?action=comunidades;sa=adminCategorias">'.$txt['comunidades_categorias'].'</a>
			</div>
			
						
						
		<div class="box_title">'.$txt['comunidades_categorias'].'</div>
		<div class="box_cuerpo">
		
		<table border="0" align="center" cellspacing="1" cellpadding="4" class="bordercolor" width="100%">
			<tr>
				<td  width="100%" valign="top">
					<table width="100%" border="0" cellpadding="1" cellspacing="0">
						<tr>
							<td style="padding-left: 1ex;" colspan="2"><b>Nombre</b></td>
							<td style="padding-left: 1ex;" colspan="2"><b>Acciones</b></td>
						</tr>';
						foreach($context['categorias'] as $ct){
						echo'
						<tr class="windowbg">
							<td style="padding-left: 5px;">'.$ct['name'].'</td>
							<td width="10%" align="right"></td>
							<td width="10%" align="right"><a href="'.$scripturl.'?action=comunidades;sa=adminCategorias;op=board;boardid='.$ct['id'].'">'.$txt['comunidades_config'].'</a></td>
						</tr>';
						}
						echo'
					</table>
					<input type="hidden" name="sc" value="2b620e37ef4f67da633a596c31ca4576" />
				</td>
			</tr>
		</table>
	</div>
</div>
';
}

// EDITOR DE CATEGORIAS

function template_EditeCategorias(){
	global $context, $settings, $txt, $modSettings, $scripturl, $tipo, $eliminados, $cantnot, $options;
echo'
<div id="admR">
   <div class="box_title">'.$txt['comunidades_categorias_'].'</div>
	 <div class="box_cuerpo">
			'.$txt['comunidades_categorias_desc'].'
	 </div>
			
	 <div style="margin: 10px 0 10px">
	    <a href="'.$scripturl.'?action=comunidades;sa=adminComunidades">'.$txt['comunidades'].'</a> | 
		  <a href="'.$scripturl.'?action=comunidades;sa=adminPublicidad">'.$txt['comunidades_publicidad_'].'</a> | 
		  <img src="'.$settings['images_url'].'/selected.gif" alt="*" /> 
		  <a href="'.$scripturl.'?action=comunidades;sa=adminCategorias">'.$txt['comunidades_categorias'].'</a>
	 </div>
					
	 <div class="box_title">'.$txt['comunidades_categorias_modificar'].' "'.$context['board']['name'].'"</div>
	 <div class="box_cuerpo">
      <form action="'.$scripturl.'?action=comunidades;sa=adminCategorias;op=board2" method="post" accept-charset="UTF-8">
         <table border="0" cellspacing="0" cellpadding="4" align="center" width="100%" class="tborder">	
			      
			      <tr>
	             <td width="50%" align="right">
			            <b>'.$txt['comunidades_categoria'].'</b><br>
			            <span style="font-weight: normal;">'.$txt['comunidades_categorias_desc_'].'</span>
			         </td>
			         <td valign="top">
			            <input type="text" name="board_name" value="'.$context['board']['name'].'" size="30" />
			         </td>
	          </tr>
			      
			      <tr>
	             <td width="50%" align="right">
			            <b>'.$txt['comunidades_groups'].'</b><br>
			            <span style="font-weight: normal;">'.$txt['comunidades_groups_desc'].'</span>
			         </td>
			         <td valign="top">';
							// List all the membergroups so the user can choose who may access this board.
	             foreach ($context['groups'] as $group){
		        echo '<label for="groups_', $group['id'], '">
				             <span', $group['is_post_group'] ? ' style="border-bottom: 1px dotted;" title="'.$txt['comunidades_groups_post_group'].'"' : '', '>
				                ', $group['name'], '
				             </span> 
				             <input type="checkbox" name="groups[]" value="', $group['id'], '" id="groups_', $group['id'], '"', $group['checked'] ? ' checked="checked"' : '', ' />
		              </label>
		              <br />';}
		              echo'<i>', $txt[737], '</i> <input type="checkbox" onclick="invertAll(this, this.form, \'groups[]\');" /><br />
									<br />
			         </td>
	          </tr>
	          
         </table>
			   <center>
            <input class="sp-button bluesky" type="submit" name="edit" value="'.$txt['manageposts_settings_submit'].'" onclick="return !isEmptyText(this.form.board_name);" />
            <input class="sp-button red" type="submit" name="delete" value="'.$txt['comunidades_delete_ct'].'" onclick="return confirm(\''.$txt['comunidades_delete_categoria'].'\');" />
		        <input type="hidden" name="sc" value="'. $context['session_id'].'" />	
		        <input type="hidden" name="boardid" value="'.$context['board']['id'].'" />
         </center>
      </form>
	 </div>
</div>';
}


// CREAR NUEVA COMUNIDAD
function template_nuevacomunidad(){
	global $context, $settings, $options, $txt, $scripturl, $modSettings, $db_prefix, $modSettings;

echo '
<script src="'.$settings['theme_url'].'/slimScroll.min.js?up='.rand(1,999).'" type="text/javascript"></script>
<style>#main .globalcontent{padding:0 !important;}</style>
';
  
//contenedor general de una nueva comunidad
echo'
<div class="comunidad-main clearfix">
   <div class="contenedor_comunidad left clearfix">
      <h3 class="blue" style="margin:3px auto -6px 10px">'.($context['nueva_comunidad']?$context['page_title']:$txt['comunidades_edite_community']).'</h3>
      <hr>
      <form action="'.$scripturl.'?action='.$_REQUEST['action'].';sa=',$context['nueva_comunidad'] ? 'nuevacomunidad':'updatecomunidad;idco='.$context['comunidad']['id'],'" name="nuevacomunidad" id="nuevacomunidad" method="post" accept-charset="UTF-8" enctype="multipart/form-data">
         
         <!-- Columna uno -->';
         if(!empty($context['is_subcategorias']) && !empty($context['comunidad']['id_subcategoria'])){
         echo'
         <script>
            $(document).ready(function(){
               $(\'li#cat_'.$context['comunidad']['id_categoria'].' a\').click();
            });
        </script>';
         }
         echo'
         <div class="box-opciones left clearfix">
            <div class="wrap-categories clearfix">
               <div class="box-categories rounded" style="margin-top:50px;overflow: hidden; width: auto; height: 300px;">
                  <ul id="form-categorias" class="slimScroll">
                     <li></li>
                     <li '.(empty($context['comunidad']['id_categoria'])?' class="selected"':'').'><a onclick="$.Comunidades.changeCategorias(this);" id="0" val="0" style="padding:0"><i class="iconos_ categorias"></i>'.$txt['comunidades_select_categories'].'</a></li>';
	                   foreach($context['categorias'] as $board){
		            echo'<li id="cat_'.$board['id'].'" ',$context['comunidad']['id_categoria'] == $board['id'] ? ' class="selected"' : '' ,'><a '.(!empty($context['is_subcategorias'])?'onclick="$.Comunidades.changeCategorias(this'.(!empty($context['comunidad']['id_subcategoria'])?','.$context['comunidad']['id_subcategoria']:'').');" id="'.$board['id'].'"':'').' val="'.$board['id'].'"><i class="iconos_ cat_'.$board['id'].'"></i>'.$board['name'].'</a></li>';}
	             echo'<li></li>
	                </ul>
	             </div>
	             
	             <div id="subcategorias"></div>
	             
	             <input type="hidden" value="'.$context['comunidad']['id_categoria'].'" name="categoria">
	             <input type="hidden" value="'.$context['comunidad']['id_subcategoria'].'" name="sub-categoria">
	             <input type="hidden" value="'.$_GET['sa'].'" name="sub-action">
	             <input type="hidden" value="'.$context['comunidad']['id'].'" name="id_comunidad">
               <input type="hidden" value="'.(!empty($context['comunidad']['idmember']) ? $context['comunidad']['idmember']:0).'" name="admin">
	             
	             <hr>
	             <center><h3>'.$txt['comunidades_portada_vprevia'].'</h3></center>
	             <hr>
	             <center>
                  <div id="previa_portada"></div>
               </center>
	          </div>
	       </div>
	       
	       <!-- Columna dos -->
	       
	       <div class="box-content-comunidad-nueva left clearfix">';
	       if(!empty($context['comunidad_error'])){
            echo '
            <div class="error">' . implode('<br>', $context['comunidad_error']['messages']) . '</div>';}
            echo'
            <div class="box-border-striped">
               <div class="stripes"></div>
               
               <div id="title" class="content clearfix">
                  <div class="header"><h3>'.$txt['comunidades_title'].'</h3></div>
                  <div class="html-content">
                     <span class="description">'.$txt['comunidades_title_desc'].'</span>                     
                     <input type="text" name="titulo" class="input-add-blog box-shadow-soft" size="60" maxlength="54" value="'.(!empty($context['comunidad']['titulo']) ? $context['comunidad']['titulo']:'').'">
                     </div>  
                  
                  <hr>
                        
                  <div class="header"><h3>'.$txt['comunidades_face'].'</h3></div>
                  <div class="html-content">
                     <span class="description">'.$txt['comunidades_face_desc'].' <e>'.$txt['comunidades_limit_size'].'</e></span>
                     <input onchange="$.Comunidades.verify_img(this.name)" onblur="$.Comunidades.verify_img(this.name)" type="text" name="portada" id="portada" class="input-add-blog box-shadow-soft" tabindex="1" size="60" maxlength="200" value="'.(!empty($context['comunidad']['portada'])?$context['comunidad']['portada']:'').'">
                  </div>
                     
                  <hr>
                     
                  <div class="header"><h3>', $txt['comunidades_desc'],'</h3></div>  
                  <div class="html-content form-add-post">
                     <span class="description">'.$txt['comunidades_desc_desc'].'</span>
                     <div id="contador" style="width: 150px; z-index: 99999; margin-right: -96px; margin-top: -20px;" class="dsp_none bubble-notify right">
                        <span class="arrow"></span>
                        <span class="data"><i id="html_ct"></i></span>
                        <span class="right"></span>
                     </div> 
                        
                     <textarea onchange="$.Comunidades.cuenta_c(this.name);" onkeypress="$.Comunidades.cuenta_c(this.name);" cols="40" rows="5" class="add-blog-desc box-shadow-soft" name="descripcion" maxlength="'.(!empty($modSettings['max_descripcionLength'])?$modSettings['max_descripcionLength']:'').'">'.(!empty($context['comunidad']['descripcion'])?$context['comunidad']['descripcion']:'').'</textarea>
                     <div id="desc" class="error" style="display:none"></div>
                  </div>

                  <hr>  
                    
                  <div class="header"><h3>'.$txt['comunidades_background_title'].'</h3></div>
                  <div class="html-content">
                     <span class="description">'.$txt['comunidades_background'].'</span>
                     <input type="text" name="background" id="background" class="input-add-blog box-shadow-soft" tabindex="1" size="60" maxlength="" value="'.(!empty($context['comunidad']['background'])?$context['comunidad']['background']:'').'"><br>
                  </div>
               </div>
            </div>
            
            <div class="box-border-striped orange">
               <div class="stripes"></div>
               
               <div id="title" class="content clearfix">    
                  <div class="header"><h3>'.$txt['comunidades_members_validate'].'</h3></div>
                  <div class="html-content">
                     <span class="description">'.$txt['comunidades_members_validate_desc'].'</span>
                     <ul>
                        <li><input type="radio" name="miembros" id="all_members" class="ui-radio" value="1" ',$context['comunidad']['validacion2'] == 1 ? 'checked="checked"':'checked="checked"','><label class="ui-radio" for="all_members"></label> <span>'.$txt['comunidades_all_members'].'</span></li>
                        <li><input type="radio" name="miembros" id="admin_members" class="ui-radio" value="2" ',$context['comunidad']['validacion2'] == 2 ? 'checked="checked"':'','><label class="ui-radio" for="admin_members"></label> <span>'.$txt['comunidades_admin_members'] .'</span></li>
                        <li><input type="radio" name="miembros" id="no_members" class="ui-radio" value="3" ',$context['comunidad']['validacion2'] == 3 ? 'checked="checked"':'','><label class="ui-radio" for="no_members"></label> <span>'.$txt['comunidades_no_members'].'</span></li>
                     </ul>
                     <div id="rangos_admin">
                        <hr>
                        <span class="description">'.$txt['comunidades_range_members_auto'].'</span>
                        <ul>
                           <li><input type="radio" name="rangos" id="guest" class="ui-radio" value="1" '.($context['comunidad']['rango'] == 1 ? 'checked="checked"':'').'><label class="ui-radio" for="guest"></label> <span>'.$txt['comunidades_guest_member'].'</span></li>
                           <li><input type="radio" name="rangos" id="poster" class="ui-radio" value="2" '.(empty($context['comunidad']['rango']) ? 'checked="checked"':($context['comunidad']['rango'] == 2 ? 'checked="checked"':'')).'><label class="ui-radio" for="poster"></label> <span>'.$txt['comunidades_poster_member'].'</span></li>
                        </ul>
                     </div>
                  </div>
               </div>
            </div>
            
            <div class="box-border-striped green">
               <div class="stripes"></div>
               
               <div id="title" class="content clearfix">
                        
                  <div class="header"><h3>'.$txt['comunidades_opciones'].'</h3></div>
                  <div class="html-content">';
                     if($context['is_sticky'] && $context['allow_admin']){
                     echo'
                     <input type="checkbox" name="sticky" id="sticky" class="ui-radio" value="1" ',$context['comunidad']['sticky'] == 1 ? 'checked="checked"':'','>
                     <label class="ui-radio" for="sticky"></label> 
                     <span> ',$context['comunidad']['sticky'] == 1 ? $txt['comunidades_nosticky']:$txt['comunidades_yessticky'],'</span>
                     <br>';}
                        
                echo'
                     <ul>
                        <li>
                           <input type="radio" name="privacidad" id="privacidad0" class="ui-radio" value="0" '.(empty($context['comunidad']['privacidad2'])?'checked="checked"':($context['comunidad']['privacidad2']==0?'checked="checked"':'')).'>
                           <label class="ui-radio" for="privacidad0"></label> 
                           <span>'.$txt['comunidades_yesprivacy0'].'</span>
                        </li>
                        
                        <li>
                           <input type="radio" name="privacidad" id="privacidad1" class="ui-radio" value="1" '.($context['comunidad']['privacidad2']==1?'checked="checked"':'').'>
                           <label class="ui-radio" for="privacidad1"></label> 
                           <span>'.$txt['comunidades_yesprivacy1'].'</span>
                        </li>
                        
                        <li>
                           <input type="radio" name="privacidad" id="privacidad2" class="ui-radio" value="2" '.($context['comunidad']['privacidad2']==2?'checked="checked"':'').'> 
                           <label class="ui-radio" for="privacidad2"></label> 
                           <span>'.$txt['comunidades_yesprivacy2'].'</span>
                        </li>
                     </ul>
                  </div>
                  <hr>
                  <center><input onclick="verficar_form(this.form, 1);" type="submit" name="submit" value="'.($context['nueva_comunidad'] ? $txt['comunidades_post']:$txt['comunidades_save_and_post']).'" class="submit sp-button green"/></center>
               </div>
            </div>
         </div>
      </form>
   </div>

      
   <!-- SideBar -->
      
   <div class="r-add-blog-options left clearfix">
      <h3 class="title">'.$txt['comunidades_consejos'].'</h3>
      <div class="hr"></div>
      <div class="protcl-txt">
         <h3 class="title">'.$txt['comunidades_title2'].'</h3>
         <ul>
             <li><i class="bad"></i> '.$txt['comunidades_mayusculas'].'</li>
             <li><i class="good"></i> '.$txt['comunidades_descriptive'].'</li>
             <li><i class="bad"></i> '.$txt['comunidades_exagerade'].'</li>
         </ul>
      </div>
      <div class="protcl-txt">
         <h3 class="title">'.$txt['comunidades_content_bad'].'</h3>
         <ul>
             <li><i class="bad"></i> '.$txt['comunidades_bad_info'].'</li>
             <li><i class="bad"></i> '.$txt['comunidades_no_photos'].'</li>
             <li><i class="bad"></i> '.$txt['comunidades_bad_dead'].'</li>
             <li><i class="bad"></i> '.$txt['comunidades_racist'].'</li>
             <li><i class="bad"></i> '.$txt['comunidades_bad_quality'].'</li>
             <li><i class="bad"></i> '.$txt['comunidades_no_answer'].'</li>
             <li><i class="bad"></i> '.$txt['comunidades_no_polemic'].'</li>
             <li><i class="bad"></i> '.$txt['comunidades_no_delits'].'</li>
             <li><i class="bad"></i> '.$txt['comunidades_no_troyans'].'</li>
         </ul>
      </div>
   </div>
</div>
<!-- end comunidades -->

';
}

// COMUNIDAD AGREGADA
function template_comunidad_agregada(){
	global $context, $settings, $options, $txt, $scripturl, $modSettings, $db_prefix, $modSettings;

echo'<style type="text/css">
        #main .globalcontent{
        min-height: 500px;
        }
     </style>
	<div id="errorBox">
		<div class="box_title">',$txt['acc_congrats'],'</div>
		<div class="box_cuerpo"><center>
			<br />
			'.$txt['comunidades_the_community'].' "<b>'.$context['comunidad_nueva']['titulo'].'</b>" '.$txt['comunidades_add_exitosamente'].'<br />
			<br />
			<input class="sp-button bluesky" type="submit" title="'.$txt['comunidades_goto_home'].'" value="'.$txt['comunidades_goto_home'].'" onclick="location.href=\''.$scripturl.'?action=comunidades\'" />
			<input class="sp-button green" type="submit" title="'.$txt['comunidades_goto_new_community'].'" value="'.$txt['comunidades_goto_new_community'].'" onclick="location.href=\''.$scripturl.'?action=comunidades;sa=comunidad;idco='.$context['comunidad_nueva']['id'].'\'" />
			<br /></center>
		</div>
	</div>
';
}

// COMUNIDAD EDITADA
function template_comunidad_editada(){
	global $context, $settings, $options, $txt, $scripturl, $modSettings, $db_prefix, $modSettings;

echo'<style type="text/css">
        #main .globalcontent{
        min-height: 500px;
        }
     </style>
	<div id="errorBox">
		<div class="box_title">',$txt['acc_congrats'],'</div>
		<div class="box_cuerpo"><center>
			<br />
			'.$txt['comunidades_the_community'].' "<b>'.$context['comunidad_editada']['titulo'].'</b>" '.$txt['comunidades_edite_exitosamente'].'<br />
			<br />
			<input class="sp-button bluesky" type="submit" title="'.$txt['comunidades_goto_home'].'" value="'.$txt['comunidades_goto_home'].'" onclick="location.href=\''.$scripturl.'?action=comunidades\'" />
			<input class="sp-button green" type="submit" title="'.$txt['comunidades_goto_community'].'" value="'.$txt['comunidades_goto_community'].'" onclick="location.href=\''.$scripturl.'?action=comunidades;sa=comunidad;idco='.$context['comunidad_editada']['id'].'\'" />
			<br /></center>
		</div>
	</div>
';
}

// DISPLAY COMUNIDAD
function template_Comunidad_Display(){
	global $context, $settings, $txt, $modSettings, $scripturl, $tipo, $eliminados, $comunidades, $options, $db_prefix, $puedopostear;
	global $pagAnterior, $pagActual, $pagTotal, $pagSiguiente, $modSettings, $ID_MEMBER;
  
echo'	
  <style type="text/css">	
		body{background-position: 0 116px!important;background-image: url('.$context['comunidad']['background'].');}
		#main .globalcontent{padding:0 15px!important;}
	</style>

<div class="bg_comunidad">
	
<!-- BOX LEFT -->
<div class="fleft box-left-comunidad">

    <!-- BREADCRUMP -->
    
    <ul class="fleft breadcrump clearfix">
		    <li class="first"><a href="'.$scripturl.'?action=comunidades" title="'.$txt['comunidades'].'">'.$txt['comunidades'].'</a></li>
		    <li><a href="'.$scripturl.'?action=comunidades;categoria='.$context['comunidad']['id_categoria'].'" title="'.$context['comunidad']['bname'].'">'.$context['comunidad']['bname'].'</a></li>
		    <li>'.$context['comunidad']['titulo'].'</li>		
		    <li class="last"></li>
	  </ul>
	  
	  <!-- BOX SHORT DESCRIPTION-->
	  
    <div class="big-group-info fleft" id="com-short-desc" style="display: none;">
       <div class="fleft">
          <a href="'.$scripturl.'?action=comunidades;sa=comunidad;idco='.$context['comunidad']['id'].'">
				     <img class="avatar-32" src="'.$context['comunidad']['portada'].'" title="'.$txt['go-to-comunity'].'" onerror="$.Comunidades.error_logo(this)">
			    </a>
			 </div>
       <div class="fleft big-group-data" style="width: 630px;">
          <h1><a href="'.$scripturl.'?action=comunidades;sa=comunidad;idco='.$context['comunidad']['id'].'">'.$context['comunidad']['titulo'].'</a></h1>
			 </div>
			 <a onclick="$(\'#com-short-desc, #com-long-desc\').toggle();">
	        <i class="iconos_ expand fright"></i>
	     </a>
    </div>
	   
	  <!-- BOX LARGE DESCRIPTION-->
	   
	  <div class="big-group-info fleft" id="com-long-desc">
       <div class="fleft">
          <a href="'.$scripturl.'?action=comunidades;sa=comunidad;idco='.$context['comunidad']['id'].'">
				     <img class="big-avatar avatar-120" src="'.$context['comunidad']['portada'].'" alt="'.$txt['comunidades_go-to-comunidad'].'" title="'.$txt['comunidades_go-to-comunidad'].'" onerror="$.Comunidades.error_logo(this)">
			    </a>
			 </div>
			 <div class="fleft big-group-data" style="margin-left:0px;">
          <h1><a href="'.$scripturl.'?action=comunidades;sa=comunidad;idco='.$context['comunidad']['id'].'">'.$context['comunidad']['titulo'].'</a></h1>
          <div class="info-basic">
				     <p>'.$context['comunidad']['descripcion'].'</p>
				     <a onclick="$(\'.view-more-info\').show();$(this).remove()" title="'.$txt['comunidades_see-more'].'">'.$txt['see-more'].''.$txt['comunidades_raquo'].'</a>
				  </div>
			 </div> 
			 <a onclick="$(\'#com-short-desc, #com-long-desc\').toggle();">
	        <i class="iconos_ collapse fright"></i>
	     </a>
	     
	     <div class="fright" style="width:560px;margin-bottom:-0px">
		      <div class="view-more-info fleft" style="display:none;">
				     <ul>
					     <li>
						     <strong>'.$txt['comunidades_categoria'].'</strong>
						     <a href="'.$scripturl.'?action=comunidades;categoria='.$context['comunidad']['id_categoria'].'" title="'.$context['comunidad']['bname'].'">'.$context['comunidad']['bname'].'</a> '.(!empty($context['subcategoria'])? '> '.$context['subcategoria']['name']:'').'
						   </li>
					     <li>
						     <strong>'.$txt['comunidades_created-how'].':</strong>
						     '.$txt['comunidades_by2'].'
						     <a id="sw" title="'.$txt['comunidades_see-profile-of'].' '.$context['comunidad']['postername'].'" href="'.$scripturl.'?action=profile&u='.$context['comunidad']['idmember'].'"><strong>'.$context['comunidad']['postername'].'</strong></a> '.howlong($context['comunidad']['fecha']).'
						   </li>
					     <li>
						      <strong>'.$txt['comunidades_type'].':</strong>
						      '.$context['comunidad']['privacity']['txt'].'
						   </li>';
		      echo'<li>
						      <strong>'.$txt['comunidades_type_validation'].':</strong>
						      '.$context['comunidad']['validation']['txt'].'';
					  if(!empty($context['comunidad']['validation']['range'])){
					   echo'<br>'.$txt['comunidades_the_range'].' <b>'.querango($context['comunidad']['validation']['rango']).'</b>';}					
				  echo'</li>
				    </ul>
		      </div> 
		      
          <!-- OPCIONES PARA USUARIOS Y MIEMBROS -->
          
          <div class="fleft box-opciones">';
		      
		    // OPCIONE SPARA REGISTRADOS
		    if($context['user']['is_logged']){
          
          if($context['miembro']['in_solicitud']){
          echo '<button class="sp-button red fleft" onclick="$.Comunidades.cancel_solicitud(this,'.$context['comunidad']['id'].','.$context['comunidad']['rango'].')" titulo_t="'.$txt['comunidades_cancel_solicitud_desc'].'" titulo_b="'.$txt['comunidades_cancel_solicitud'].'">
                   <e>'.$txt['comunidades_cancel_solicitud'].'</e>
                </button>
                <button class="sp-button fleft add" onclick="$.Comunidades.unirse(this, '.$context['comunidad']['id'].','.$context['comunidad']['rango'].')" style="display:none">
                   <e>'.$txt['comunidades_add-comunidad'].'</e>
                </button>';
          }
          else{
             // se muestra si se pueden agregar miembros, sino es el admin, sino es miembro
             if(!empty($context['comunidad']['validation']['index']) && empty($context['miembro']['is_member']) && empty($context['comunidad']['is_admin'])){
             echo'
                <button class="sp-button fleft add" onclick="$.Comunidades.unirse(this, '.$context['comunidad']['id'].','.$context['comunidad']['rango'].')">
                   <e>'.$txt['comunidades_add-comunidad'].'</e>
                </button>
                <button class="sp-button fleft aband" onclick="$.Comunidades.abandonar(this, '.$context['comunidad']['id'].','.$context['comunidad']['rango'].')" style="display:none">
                   <e>'.$txt['comunidades_aband'].'</e>
                </button>';
             }
             // se muestra si soy miembro y sino soy el admin
             else if(!empty($context['miembro']['is_member']) && empty($context['comunidad']['is_admin'])){
             echo'
                <button class="sp-button fleft add" onclick="$.Comunidades.unirse(this, '.$context['comunidad']['id'].','.$context['comunidad']['rango'].')" style="display:none">
                   <i class="icon_c"></i>
                   <e>'.$txt['comunidades_add-comunidad'].'</e>
                </button>
                <button class="sp-button left aband" onclick="$.Comunidades.abandonar(this, '.$context['comunidad']['id'].','.$context['comunidad']['rango'].')">
                  <i class="icon_c"></i>
                   <e>'.$txt['comunidades_aband'].'</e>
                </button>';
             }
          }
          // se muestra a todos menos a los seguidores y al admin
          if(empty($context['comunidad']['is_admin'])){
             if(empty($context['siguiendo'])){
          echo'
             <div class="follow-buttons">
                <button id="follows_button" class="sp-button left not-following seguir" onclick="$.Comunidades.seguir(this, '.$context['comunidad']['id'].',1)">
                   <i class="iconos_ follows"></i>
                   <span>'.$txt['comunidades_follow-comunidad'].'</span>
                </button>
                
                <button id="follows_button" class="sp-button red left unfollowing noseguir" onclick="$.Comunidades.noseguir(this, '.$context['comunidad']['id'].',1)" style="display:none">
                   <span>'.$txt['comunidades_unfollowing'].'</span>
                </button>
             </div>';
             }
             else{
          echo'
             <div class="follow-buttons">
                <button id="follows_button" class="sp-button green left following seguir" onclick="$.Comunidades.seguir(this, '.$context['comunidad']['id'].',1)">
                   <i class="iconos_ follows"></i>
                   <span>'.$txt['comunidades_following'].'</span>
                </button>
                
                <button id="follows_button" class="sp-button red left unfollowing noseguir" onclick="$.Comunidades.noseguir(this, '.$context['comunidad']['id'].',1)" style="display:none">
                   <span>'.$txt['comunidades_unfollowing'].'</span>
                </button>
             </div>';
             }
          }
        }
		    else{
        echo' 
           <!-- OPCIONES PARA VISITANTES -->
           
           <a class="sp-button green left" rel="registro"><i class="icon_c"></i><e>'.$txt['comunidades_register'].'</e></a>';  
        }
     echo'</div>
     
	        <ul class="clearfix fright action-data" style="padding-top:10px;">
				     <li class="members-count"><span style="text-align: right;" data-val="'.$context['comunidad']['miembros'].'">'.$context['comunidad']['miembros'].'</span> '.$txt['comunidades_members'].'</li>
				     <li class="temas-count"><span style="text-align: right;" data-val="'.$context['comunidad']['temas'].'">'.$context['comunidad']['temas'].'</span> '.$txt['comunidades_thems'].'</li>
				     <li class="followers-count" style="border-right:none;padding-right:0!important;"><span style="text-align: right;" data-val="'.$context['comunidad']['follows'].'">'.$context['comunidad']['follows'].'</span> '.$txt['comunidades_followers'].'</li>
			    </ul>
		   </div>
	     
		</div>';
		
		// si el usuario se bloqueo :D
    echo $context['user']['bloqueado'];
    
// filtro para privacidad de registrados, el admin siempre puede verla
if(!empty($context['puedeverla']) || !empty($context['comunidad']['is_admin'])){

// lo mostramos si hay stickys
if(!empty($context['comunidad']['temas']) && !empty($context['importantes']['count'])){
echo'
    <!-- BOX IMPORTANTES -->

    <div class="fleft thread-box">
	     <div class="title clearfix"><h2>'.$txt['comunidades_stickys'].'</h2></div>
	     <table cellpadding="0" cellspacing="0" colspan="3" style="margin-bottom:0;" style="display:inline-block;">';
				  foreach($context['temas']['importantes'] as $tems){
		 echo'<tr>
		         <td>
		            <a href="" class="author-avatar">
		               <img src="'.$tems['avatar'].'" onerror="$.Comunidades.error_logo(this)">
		            </a>
		         </td>
		         <td class="temaTitulo">
						    <i class="iconos_ s-sticky" style="margin-right:6px"></i><a href="'.$scritpturl.'?action=comunidades;sa=tema;idtema='.$tems['id'].'">'.$tems['titulo'].'</a>
						    <br>
						    '.$txt['comunidades_by2'].' <a href="'.$scripturl.'?action=profile;u='.$tems['id_admin'].'">'.$tems['name'].'</a> <span class="datetema">'.$tems['hace'].'</span>
					   </td>
					   <td class="datetema answer"><i class="iconos_ s-comment" style="margin: auto -60px 0 6px"></i>'.$tems['respuestas'].'</td>
					   <td class="datetema answer"><i class="iconos_ s-like" style="margin: auto -60px 0 6px"></i>'.$tems['calificacion'].'</td>';
					   if(!empty($context['comunidad']['is_admin']) or !empty($context['miembro']['moderador'])){echo'
					   <td class="datetema for_admin">
					      <a onclick=""><i class="iconos_ fire" style="margin: auto 4px  auto -5px" id="se" title="'.$txt['comunidades_delete_them'].'"></i></a> 
					      <a onclick=""><i class="iconos_ pencil" id="se" title="'.$txt['comunidades_edite_them'].'"></i></a> 
					   </td>
					   ';}
		 echo'</tr>';}
		echo'	
		   </table>
    </div>';}
		if(empty($context['comunidad']['validation']['tipo']) || $context['comunidad']['validation']['tipo'] == 3){
    echo' 
    <br>
    <!-- ALERT NO MEMBERS VALIDATION -->
    
    <div class="fleft alert infofix">'.$context['comunidad']['validation']['txt'].'</div>';
    }
    else if(!empty($context['miembro']['in_solicitud'])){
    echo'<br>
    <!-- ALERT NO MEMBERS ABOUT IN SOLICITUD -->
    <div class="fleft notice infofix">
		   '.$txt['comunidades_solicitud_pend'].'
		</div>';
    }
    else if(empty($context['miembro']['is_member'])){
    echo'<br>
    <!-- ALERT NO MEMBERS -->
    <div class="fleft info infofix">
		   '.$txt['comunidades_register_one'].'
		   <a onclick="$.Comunidades.unirse(\'\', '.$context['comunidad']['id'].','.$context['comunidad']['rango'].');">
		      '.$txt['comunidades_registre_two'].'
		   </a>
		   '.$txt['comunidades_register_three'].'
		</div>';
    }
    
 echo'
    <!-- BOX TEMAS -->

    <div class="fleft thread-box">
	     <div id="ComInfo" class="Container">
	        <div class="fleft title clearfix">
		         <h2 class="fleft">'.$txt['thems'].'</h2>';
		         if(!empty($context['comunidad']['poster']) or !empty($context['miembro']['publicador']) && !empty($context['comunidad']['tipo']) && !empty($context['miembro']['is_member']) || !empty($context['comunidad']['is_admin'])){
             echo'
             <button class="sp-button green right" onclick="location.href=\''.$scripturl.'?action=comunidades;sa=creartema;idco='.$context['comunidad']['id'].'\'">
                '.$txt['comunidades_new-them'].'
             </button>';}
		      echo'
		      </div>
		      <br>';
		      if(!empty($context['comunidad']['temas']) && !empty($context['normales']['count'])){
		 echo'<table cellpadding="0" cellspacing="0" colspan="3" style="margin-bottom:0;" style="display:inline-block;">';
				        
				     foreach($context['temas']['normales'] as $tems){
				     echo'
				     <tr>
		            <td>
		               <a href="" class="author-avatar">
		                  <img src="'.$tems['avatar'].'" onerror="$.Comunidades.error_logo(this)">
		               </a>
		            </td>
		         <td class="temaTitulo">
						    <a href="'.$scritpturl.'?action=comunidades;sa=tema;idtema='.$tems['id'].'">'.$tems['titulo'].'</a>
						    <br>
						    '.$txt['comunidades_by2'].' <a href="'.$scripturl.'?action=profile;u='.$tems['id_admin'].'">'.$tems['name'].'</a> <span class="datetema">'.$tems['hace'].'</span>
					   </td>
					      <td class="datetema answer"><i class="iconos_ s-comment" style="margin: auto -60px 0 3px"></i>'.$tems['respuestas'].'</td>
					   <td class="datetema answer"><i class="iconos_ s-'.($tems['calificacion']<0 ? 'no':'').'like" style="margin: auto -60px 0 3px"></i><span '.($tems['calificacion']<0 ? 'style="color:red"':'').'>'.$tems['calificacion'].'</span></td>';
					   if(!empty($context['comunidad']['is_admin']) or !empty($context['miembro']['moderador'])){echo'
					   <td class="datetema for_admin">
					      <a onclick=""><i class="iconos_ fire" style="margin: auto 4px  auto -5px" id="se" title="'.$txt['comunidades_delete_them'].'"></i></a> 
					      <a onclick=""><i class="iconos_ pencil" id="se" title="'.$txt['comunidades_edite_them'].'"></i></a> 
					   </td>
					   ';}
		 echo'</tr>';}
				     echo'	
		      </table>';}
		      else
			    if(empty($context['comunidad']['temas'])){
		 echo'<div class="emptyData">
		         <div class="error" style="margin-top:35px;">
		            <center>'.$txt['comunidades_empty_thems'].'</center>
		         </div>
		      </div>';
			    }
		 echo'<div class="pages clearfix">
		         <ul class="fleft paginator_mr">';
                if($pagActual!=1 && $pagActual!=0){echo '
                <a href="'.$scripturl.'?action=comunidades;sa=comunidad;idco='.$context['comunidad']['id'].'&pag=1" title="'.$txt['comunidades_go_to_start'].'">
                   <li>'.$txt['comunidades_laquo'].$txt['comunidades_laquo'].'</li>
                </a>';}
                if($pagAnterior>0){echo'
                <a href="'.$scripturl.'?action=comunidades;sa=comunidad;idco='.$context['comunidad']['id'].'&pag='.$pagAnterior.'">
                   <li>'.$txt['comunidades_prev'].'</li>
                </a>';}
                $pgIntervalo = 3; 
                $pgMaximo = ($pgIntervalo*2)+1;
                $pg = $pagActual-$pgIntervalo;
                $i = 0;
                while($i < $pgMaximo){
                   if($pg == $pagActual){
                      $b = array('','');
                      $bli = 'active';
                   } 
                   else{
                   $b = array('<a href="'.$scripturl.'?action=comunidades;sa=comunidad;idco='.$context['comunidad']['id'].'&pag='.$pg.'">','</a>');
                   $bli = '';
                   }
                  if($pg > 0 and $pg <= $pagTotal){
                  echo '
                   '.$b[0].'<li class="'.$bli.'">'.$pg.'</li>'.$b[1].'';
                  $i++;
                  }
                  if($pg > $pagTotal){
                     $i = $pgMaximo;
                  }
                $pg++;
                }
                if($pagSiguiente <= $pagTotal){echo'
                <a href="'.$scripturl.'?action=comunidades;sa=comunidad;idco='.$context['comunidad']['id'].'&pag='.$pagSiguiente.'">
                   <li>'.$txt['comunidades_next'].'</li>
                </a>';}
                if($pagActual!=$pagTotal && $pagTotal!=0){echo'
                <a href="'.$scripturl.'?action=comunidades;sa=comunidad;idco='.$context['comunidad']['id'].'&pag='.$pagTotal.'" title="'.$txt['comunidades_go_to_end'].'">
                   <li>'.$txt['comunidades_raquo'].$txt['comunidades_raquo'].'</li>
                </a>';}
                echo'
		         </ul>
		      </div>
       </div>
    </div>';

} 
else if(empty($context['puedeverla']) || empty($context['comunidad']['is_admin'])){
   echo $context['puedeverla_txt'];
}

echo'

</div>

<!-- END BOX LEFT -->

<!-- BOX RIGHT -->

<div class="fleft box-right-comunidad">
   
   <!-- BUSCADOR -->
	 <div class="title clearfix">
	    <h2>'.$txt['comunidades_search_comunidad'].'</h2>
	 </div>
	 <form name="search-com" type="post" action="/buscar/temas/">
			<input name="comunidad" value="'.$_GET['idco'].'" type="hidden">
			<input name="q" style="width: 140px; display: block; margin:-4px 10px 0 0 ;" class="text-search left" type="text" maxlength="60" placeholder="'.$txt['comunidades_word_key'].'">
			<a role="button" class="sp-button green left" style="margin:-5px 0 0 0 ;" onclick="return $(\'form[name=search-com]\').submit()">Buscar</a>
	 </form>
	 <br>
	 <hr>
	 
	 <!-- STAFF -->
	 <div class="title clearfix" style="margin-bottom:5px">
	    <h2>'.$txt['comunidades_staff'].'</h2>
	 </div>
	 <div class="list">
	    <ul class="avatar-list avatar-list-48 clearfix">';
		  foreach($context['staff'] as $staff){
			echo'
			   <li data-uid="'.$staff['id'].'" class="relative ',$staff['admin'].'">
				    <a href="'.$scripturl.'?action=profile;u='.$staff['id'].'">
					     <img class="avatar-48" src="'.$staff['avatar'].'" title="'.$staff['name'].'" id="n" onerror="$.Comunidades.error_logo(this)">
					  </a>
					  <span title="'.$staff['online'].'line" class="is_'.$staff['online'].'line" id="ne"></span>
				 </li>';}
				echo'
			</ul>
	 </div>
	 <hr>
	 
	 <!-- ESTADISTICAS -->
	 <div class="title clearfix">
			<h2>'.$txt['comunidades_statics'].'</h2>
   </div>
	 <ul class="clearfix action-data">
			<li class="members-count"><span data-val="'.$context['comunidad']['miembros'].'">'.$context['comunidad']['miembros'].'</span> '.$txt['comunidades_members'].'</li>
			<li class="temas-count"><span data-val="'.$context['comunidad']['temas'].'">'.$context['comunidad']['temas'].'</span> '.$txt['comunidades_thems'].'</li>
			<li class="followers-count" style="border-right:0 none; padding-right:0!important;"><span class="data-followers-count" data-val="'.$context['comunidad']['follows'].'">'.$context['comunidad']['follows'].'</span> '.$txt['comunidades_followers'].'</li>
	 </ul><hr>';
	 
	 if($context['user']['is_logged']){
	 echo'
	 <!-- OPCIONES -->  	 
	 <div class="title clearfix">
			<h2>'.$txt['comunidades_opciones'].'</h2>
   </div>';
         
      if($context['comunidad']['idmember'] == $context['user']['id'] || $context['allow_admin']){
        echo'<button class="sp-button red left" onclick="location.href=\''.$scripturl.'?action=comunidades;sa=eliminar-comunidad;idco='.$context['comunidad']['id'].'\'">
                '.$txt['comunidades_delete'].'
             </button>
             
             <button class="sp-button left" onclick="location.href=\''.$scripturl.'?action=comunidades;sa=editar-comunidad;idco='.$context['comunidad']['id'].'\'">
                '.$txt['comunidades_edite'].'
             </button>
    <br>
    <br>
    <hr>';
      }
	 }
	 
	 if($context['comunidad']['miembros']){
   echo'
   <!-- �LTIMOS MIEMBROS -->
	 <div class="title clearfix">
		  <h2>'.$txt['comunidades_last_members'].'</h2>
	 </div>
	 <div class="list">
	    <ul class="avatar-list-32 clearfix">';
	    $i = 0;
			   foreach($context['miembros']['unlimited'] as $miembros){
			   $i++;
			   if(empty($miembros['in_solicitud'])){
		echo'<li data-uid="'.$miembros['id'].'">
			      <a href="'.$scripturl.'?acttion=profile;u='.$miembros['idmember'].'">
               <img  class="avatar-32" src="'.$miembros['avatar'].'" title="'.$miembros['nombre'].'" id="'.($i==7 ? 's':'n').'" onerror="$.Comunidades.error_logo(this)">
			      </a>
			   </li>';}
			   }
 echo'</ul>
      <hr>
 
      <div class="read-more clearfix" style="margin:-15px 0 0 0">
         <span class="show-more fright">
		        <a href="'.$scripturl.'?action=comunidades;sa=miembros;idco='.$context['comunidad']['id'].'">'.$txt['comunidades_see-more'].' '.$txt['comunidades_raquo'].'</a>
		     </span>
      </div>
   </div>';}

	 echo'
	 
	 <!-- ULTIMAS RESPUESTAS -->
	 <div class="title clearfix"><br>
		  <h2 class="fleft">'.$txt['comunidades_last_answers'].'</h2>   
		  <a class="fright" href="#" onclick="$.Comunidades.actualizar_respuestas(2); return false;">
		     <i class="iconos_ reload" style="margin:5px 0 0 0"></i>
			</a>
	 </div>
	 <div class="list" id="last_comments">';
	 if(empty($context['list']['count'])){
   echo'
      <div class="error">'.$txt['comunidades_empty_answers'].'</div>';
   }else{
   foreach ($context['respuestas']['list'] as $comments){
 echo'<div class="list-element">
			   <a href="'.$scriptur.'?action=comunidades;sa=tema;idtema='.$comments['id'] .'#all-comments">'. _substr($comments['titulo'], 0, 35, 30).'</a>
		  </div>';}
   }
    echo'
	 </div>';
	 
	 /*
	       <div class="minimal-box fleft" style="padding-top: 0;">
         <div class="title fleft" style="width:306px;">
            <h3 class="fleft">'.$txt['comunidades_last_answers'].'</h3>
	       </div>
         <div class="content fleft">
		        <ul id="last_comments" class="list smallfont">';
            if(empty($context['recent']['count'])){
            echo'
               <div class="error">'.$txt['comunidades_empty_answers'].'</div>';
            }else{
               foreach ($context['respuestas']['recent'] as $comments){
         echo '<li>
                  <span class="subinfo">
                     <a href="'.$scripturl.'?action=profile;u='.$comments['autor'].'">'.$comments['username'].'</a>
                  </span> 
                  <a href="'.$scriptur.'?action=comunidades;sa=tema;idtema='.$comments['id'] .'#all-comments" title="',$comments['titulo'],'">
                     '. _substr($comments['titulo'], 0, 35, 30).'
                  </a>
               </li>';}
            }
       echo'</ul>
	       </div>
      </div>
      */
	 
	 if(!empty($context['temas_week']) || !empty($context['temas_month']) || !empty($context['temas_all'])){
	 echo'
	 <!-- TOP TEMAS -->
	 
   <div class="minimal-box" style="padding-top: 5px;" id="TopPopulares">
	    <div class="title clearfix" style="height:20px">
		     <h2 class="left">'.$txt['comunidades_tops_temas'].'</h2>
		     <div class="UIdrop drop">
			      <span><a class="color-black">Semanal</a></span>
			      <ul id="TopPopulares-menu">
				       <li><a onclick="$.Comunidades.nTopsTabsTop(\'TopPopulares\',\'weekly\',this);" id="semanal">Semanal</a></li>				
				       <li><a onclick="$.Comunidades.nTopsTabsTop(\'TopPopulares\',\'monthly\',this);" id="mensual">Mensual</a></li>				
				       <li><a onclick="$.Comunidades.nTopsTabsTop(\'TopPopulares\',\'all\',this);" id="siempre">Siempre</a></li>				
			      </ul>
		     </div>
	    </div>
      <div class="content">
	       <ul class="list" id="weekly">';
         if(!empty($context['temas_week'])){
	       $iterator = 1;
	       foreach($context['temas_week'] as $cp){
		     echo '
			      <li>
			         <div class="subinfo">
			            <span class="number-list color-black size-15">'.$iterator.'</span> 
			            <a href="'.$scriptul.'?action=comunidades;sa=tema;idtema='.$cp['id'].'">'.recortart($cp['titulo'],38).'</a>
			         </div> 
			         <span class="UIspan points">'.$cp['puntos'].'</span>
			      </li>';$iterator++;
	       }
	       
	       }
	       else{
	          echo'<div class="error">'.$txt['comunidades_no_populars_thems_week'].'</div>';
	       }
	       echo'
	       </ul>';
	
	    echo'
	       <ul class="list hide" id="monthly">';
         if(!empty($context['temas_month'])){
	          $iterator = 1;
	       foreach($context['temas_month'] as $cp){
		     echo '
			      <li>
			         <div class="subinfo">
			            <span class="number-list color-black size-15">'.$iterator.'</span> 
			            <a href="'.$scriptul.'?action=comunidades;sa=tema;idtema='.$cp['id'].'">'.recortart($cp['titulo'],38).'</a>
			         </div> 
			         <span class="UIspan points">'.$cp['puntos'].'</span>
			      </li>';$iterator++;
	       }
	       
	       }
	       else{
	          echo'<div class="error">'. $txt['comunidades_no_populars_thems_month'].'</div>';
	       }
	       echo '
	       </ul>
	       <ul class="list hide" id="all">';
         if(!empty($context['temas_all'])){
            $iterator = 1;
	       foreach($context['temas_all'] as $cp){
		     echo '
			      <li>
			         <div class="subinfo">
			            <span class="number-list color-black size-15">'.$iterator.'</span> 
			            <a href="'.$scriptul.'?action=comunidades;sa=tema;idtema='.$cp['id'].'">'.recortart($cp['titulo'],38).'</a>
			         </div> 
			         <span class="UIspan points">'.$cp['puntos'].'</span>
			      </li>';$iterator++;
	       }
	       }
	       else{
	          echo'<div class="error">'.$txt['comunidades_no_populars_thems'].'</div>';
	       }
	       echo '
	       </ul>
      </div>
   </div>
	 
	 <hr>';
	 }
	 echo'
	 <div class="denunciar">
	    <i class="iconos_ flag"></i>
			<a id="s" href="javascript:com.denuncia_publica()" title="'.$txt['comunidades_denunciar_comunidad'].'">'.$txt['comunidades_denunciar'].'</a>
			-
			<a id="s" href="'.$scripturl.'?action=comunidades;sa=historial;idco='.$context['comunidad']['id'].'" title="'.$txt['comunidades_history_comunidad'].'">'.$txt['comunidades_history'].'</a>
	 </div>
	 
</div>
</div>

<script>
var id_admin = "'.$context['comunidad']['idmember'].'";
</script>

<!-- END BOX RIGHT -->';	

}

// CREAR NUEVO TEMA

function template_nuevoTema(){
	global $context, $settings, $txt, $modSettings, $scripturl, $tipo, $eliminados, $comunidades, $options, $db_prefix, $puedopostear;

echo'
  <style type="text/css">
		#main .globalcontent{padding:0 15px!important;}
	</style>
	
<form action="'.$scripturl.'?action='.$_REQUEST['action'].';sa=',$context['nuevo_tema'] ? 'creandotema':'updatetema','" name="creartema" id="creartema" method="post" accept-charset="UTF-8" enctype="multipart/form-data">      

<!-- BOX LEFT -->

<div class="fleft left-nuevo-tema">
   
   <div class="box-border-striped" style="width:710px;">
      <div class="stripes"></div>
      <div id="title" class="content clearfix">
         
         <div id="mensaje-top">
				    <a target="_blank" href="'.$scripturl.'?action=comunidades;sa=protocolo">'.$txt['comunidades_protocolo_text'].'</a>
				 </div>
         <hr>
         <div class="form-container clearfix">
					
            <div class="header"><h3>'.$txt['comunidades_title'].'</h3></div>
				    <input type="hidden" name="borrador" value="'.$context['comunidad']['is_borrador'].'" />
						<input type="hidden" name="comid" value="'.$_GET['idco'].'" />
						<input type="hidden" name="categoria" value="'.$context['comunidad']['id_categoria'].'" />
						<input type="hidden" name="subcategoria" value="'.$context['comunidad']['id_subcategoria'].'" />
						<input type="hidden" name="seqnum" value="', $context['form_sequence_number'], '" />
						<input type="hidden" name="maxlenght" value="',$modSettings['max_bodyLength'], '" />
						
						<div class="item-add-community tit clearfix">
							 <span class="tema-errormsg fleft"></span>
						   <input onchange="$.Comunidades.hideError(this);" onkeyup="$.Comunidades.hideError(this);" class="c_input ui-corner-all requerido form-input-text box-shadow-soft" type="text" value="" name="titulo" tabindex="1" maxlength="50" />
						</div>

						
            <div class="header"><h3>'.$txt['comunidades_body'].'</h3></div>
						<div class="item-add-community  form-add-community clearfix">
								<span class="tema-errormsg" style="margin-bottom:20px;"></span>
								<textarea onchange="$.Comunidades.hideError(this);" onkeyup="$.Comunidades.hideError(this);" id="markItUp" name="cuerpo" style="height:400px;margin-top:0px;width:655px;max-width:655px;min-width:655px;resize:auto;" class="c_input_desc required ui-corner-all-bottom form-input-text box-shadow-soft markItUpEditor"  tabindex="8" datatype="text" dataname="Cuerpo"></textarea>
							</div>

						<div class="item-add-community corto clearfix">
							 <input type="button" class="sp-button green" name="preview" onclick="$.Comunidades.previa_tema(this)" tit="'.$txt['comunidades_previa_tema'].'" ops="'.$txt['comunidades_add_tema'].'" value="'.$txt['comunidades_continue'].'">
							 <input type="button" id="borrador-save" class="sp-button" onclick="$.Comunidades.save_borrador(2)" value="'.$txt['comunidades_save_eraser'].'">
						</div>
						
						<div id="borrador-guardado" style="margin-left:2px;padding-left:2px;"></div>
						
					</div>
      </div>
  </div>   
</div>

<!-- BOX RIGHT -->
<div class="fleft right-nuevo-tema">
   <div class="box-border-striped green">
      <div class="stripes"></div>
      <div id="title" class="content clearfix">
         <div class="header"><h3>'.$txt['comunidades_opciones'].'</h3></div>
         <div class="html-content">
				    
				    <div class="option clearfix">
               <input type="checkbox" name="follow" id="follow" class="ui-radio"',$context['comunidad']['privado'] == 1 ? ' value="0"':' value="1"','>
                     <label class="ui-radio" for="follow"></label> 
                     
					     <p style="width:192px;" class="fright">
						       <strong for="check_follow">'.$txt['comunidades_follow_tema'].'</strong><br/>
						       '.$txt['comunidades_follow_tema_desc'].'					
						   </p>
				    </div>
				       
				    <div class="option clearfix">
				       <input type="checkbox" name="cerrado" id="cerrado" class="fleft ui-radio"',$context['comunidad']['privado'] == 1 ? ' value="0"':' value="1"','>
					     <label class="ui-radio" for="cerrado"></label>
					     <p style="width:192px;" class="fright">
						       <strong for="check_cerrado">'.$txt['comunidades_close_answer'].'</strong><br />
						       '.$txt['comunidades_close_answer_desc'].'				
						   </p>
				    </div>';
				    
				    if($context['enable_stickys'] && $context['is_admin_comunidad']){
				    echo'
				    <div class="option clearfix">
				       <input type="checkbox" name="sticky" id="sticky" class="fleft ui-radio"'.($context['comunidad']['privado'] == 1 ? ' value="0"':' value="1"').'>
					     <label class="ui-radio" for="sticky"></label>
					     <p style="width:192px;" class="fright">
						       <strong for="check_sticky">'.$txt['comunidades_yessticky'].'</strong><br />
						       '.$txt['comunidades_sticky_desc'].'				
						   </p>
				    </div>';
				    
				    }
				    echo'
				    
         </div>
      </div>
   </div>
</div>

</form>
';
}

// COMUNIDAD AGREGADA
function template_tema_agregado(){
	global $context, $settings, $options, $txt, $scripturl, $modSettings, $db_prefix, $modSettings;

echo'<style type="text/css">
        #main .globalcontent{
        min-height: 500px;
        }
     </style>
	<div id="errorBox">
		<div class="box_title">',$txt['acc_congrats'],'</div>
		<div class="box_cuerpo"><center>
			<br />
			'.$txt['comunidades_the_them'].' "<b>'.$context['tema_nuevo']['titulo'].'</b>" '.$txt['comunidades_add_exitosamente2'].'<br />
			<br />
			<input class="sp-button bluesky" type="submit" title="'.$txt['comunidades_goto_home'].'" value="'.$txt['comunidades_goto_home'].'" onclick="location.href=\''.$scripturl.'?action=comunidades\'" />
			<input class="sp-button green" type="submit" title="'.$txt['comunidades_goto_new_them'].'" value="'.$txt['comunidades_goto_new_them'].'" onclick="location.href=\''.$scripturl.'?action=comunidades;sa=tema;idtema='.$context['tema_nuevo']['id'].'\'" />
			<br /></center>
		</div>
	</div>
';
}

// TEMA DISPLAY
function template_Tema_Display(){
	global $context, $settings, $options, $txt, $scripturl, $modSettings, $db_prefix, $modSettings;
	global $context, $settings, $txt, $modSettings, $scripturl, $tipo, $eliminados, $comunidades, $options, $db_prefix, $puedopostear;
	global $pagAnterior, $pagActual, $pagTotal, $pagSiguiente, $modSettings, $boardurl, $ID_MEMBER;

	echo'	

<script type="text/javascript">
  window.___gcfg = {lang: \'es\'};

  (function() {
    var po = document.createElement(\'script\'); po.type = \'text/javascript\'; po.async = true;
    po.src = \'https://apis.google.com/js/plusone.js\';
    var s = document.getElementsByTagName(\'script\')[0]; s.parentNode.insertBefore(po, s);
  })();
</script>

  <style type="text/css">	
		body{background-position: 0 116px!important;background-image: url('.$context['comunidad']['background'].');}
		#main .globalcontent{padding:0 15px!important;}
	</style>

<div class="bg_comunidad">

<!-- BOX LEFT -->
<div class="fleft box-left-comunidad">

    <!-- BREADCRUMP -->
    
    <ul class="fleft breadcrump clearfix">
		    <li class="first"><a href="'.$scripturl.'?action=comunidades" title="'.$txt['comunidades'].'">'.$txt['comunidades'].'</a></li>
		    <li><a href="'.$scripturl.'?action=comunidades;categoria='.$context['comunidad']['id_categoria'].'" title="'.$context['comunidad']['bname'].'">'.$context['comunidad']['bname'].'</a></li>
		    <li><a href="'.$scripturl.'?action=comunidades;sa=comunidad;idco='.$context['comunidad']['id'].'" title="'.$context['comunidad']['titulo'].'">'.$context['comunidad']['titulo'].'</a></li>		
		    <li>'.recortart($context['tema']['titulo'],40).'</li>
		    <li class="last"></li>
	  </ul>
	  
	  <!-- BOX SHORT DESCRIPTION-->
	  
    <div class="big-group-info fleft" id="com-short-desc" style="display: none;">
       <div class="fleft">
          <a href="'.$scripturl.'?action=comunidades;sa=comunidad;idco='.$context['comunidad']['id'].'">
				     <img class="avatar-32" src="'.$context['comunidad']['portada'].'" title="'.$txt['go-to-comunity'].'" onerror="$.Comunidades.error_logo(this)">
			    </a>
			 </div>
       <div class="fleft big-group-data" style="width: 630px;">
          <h1><a href="'.$scripturl.'?action=comunidades;sa=comunidad;idco='.$context['comunidad']['id'].'">'.$context['comunidad']['titulo'].'</a></h1>
			 </div>
			 <a onclick="$(\'#com-short-desc, #com-long-desc\').toggle();">
	        <i class="iconos_ expand fright"></i>
	     </a>
    </div>
	   
	  <!-- BOX LARGE DESCRIPTION-->
	   
	  <div class="big-group-info fleft" id="com-long-desc">
       <div class="fleft">
          <a href="'.$scripturl.'?action=comunidades;sa=comunidad;idco='.$context['comunidad']['id'].'">
				     <img class="big-avatar avatar-120" src="'.$context['comunidad']['portada'].'" alt="'.$txt['comunidades_go-to-comunidad'].'" title="'.$txt['comunidades_go-to-comunidad'].'" onerror="$.Comunidades.error_logo(this)">
			    </a>
			 </div>
			 <div class="fleft big-group-data" style="margin-left:0px;">
          <h1><a href="'.$scripturl.'?action=comunidades;sa=comunidad;idco='.$context['comunidad']['id'].'">'.$context['comunidad']['titulo'].'</a></h1>
          <div class="info-basic">
				     <p>'.$context['comunidad']['descripcion'].'</p>
				     <a onclick="$(\'.view-more-info\').show();$(this).remove()" title="'.$txt['comunidades_see-more'].'">'.$txt['see-more'].''.$txt['comunidades_raquo'].'</a>
				  </div>
			 </div> 
			 <a onclick="$(\'#com-short-desc, #com-long-desc\').toggle();">
	        <i class="iconos_ collapse fright"></i>
	     </a>
	     
	     <div class="fright" style="width:560px;margin-bottom:-0px">
		      <div class="view-more-info fleft" style="display:none;">
				     <ul>
					     <li>
						     <strong>'.$txt['comunidades_categoria'].'</strong>
						     <a href="'.$scripturl.'?action=comunidades;categoria='.$context['comunidad']['id_categoria'].'" title="'.$context['comunidad']['bname'].'">'.$context['comunidad']['bname'].'</a> '.(!empty($context['subcategoria'])? '> '.$context['subcategoria']['name']:'').'
						   </li>
					     <li>
						     <strong>'.$txt['comunidades_created-how'].':</strong>
						     '.$txt['comunidades_by2'].'
						     <a id="sw" title="'.$txt['comunidades_see-profile-of'].' '.$context['comunidad']['postername'].'" href="'.$scripturl.'?action=profile&u='.$context['comunidad']['idmember'].'"><strong>'.$context['comunidad']['postername'].'</strong></a> '.howlong($context['comunidad']['fecha']).'
						   </li>
					     <li>
						      <strong>'.$txt['comunidades_type'].':</strong>
						      '.$context['comunidad']['privacity']['txt'].'
						   </li>';
		      echo'<li>
						      <strong>'.$txt['comunidades_type_validation'].':</strong>
						      '.$context['comunidad']['validation']['txt'].'';
					  if(!empty($context['comunidad']['validation']['range'])){
					   echo'<br>'.$txt['comunidades_the_range'].' <b>'.querango($context['comunidad']['validation']['rango']).'</b>';}					
				  echo'</li>
				    </ul>
		      </div> 
		      
          <!-- OPCIONES PARA USUARIOS Y MIEMBROS -->
          
          <div class="fleft box-opciones">';
		      
		    // OPCIONE SPARA REGISTRADOS
		    if($context['user']['is_logged']){
          
          if($context['miembro']['in_solicitud']){
          echo '<button class="sp-button red fleft" onclick="$.Comunidades.cancel_solicitud(this,'.$context['comunidad']['id'].','.$context['comunidad']['rango'].')" titulo_t="'.$txt['comunidades_cancel_solicitud_desc'].'" titulo_b="'.$txt['comunidades_cancel_solicitud'].'">
                   <e>'.$txt['comunidades_cancel_solicitud'].'</e>
                </button>
                <button class="sp-button fleft add" onclick="$.Comunidades.unirse(this, '.$context['comunidad']['id'].','.$context['comunidad']['rango'].')" style="display:none">
                   <e>'.$txt['comunidades_add-comunidad'].'</e>
                </button>';
          }
          else{
             // se muestra si se pueden agregar miembros, sino es el admin, sino es miembro
             if(!empty($context['comunidad']['validation']['index']) && empty($context['miembro']['is_member']) && empty($context['comunidad']['is_admin'])){
             echo'
                <button class="sp-button fleft add" onclick="$.Comunidades.unirse(this, '.$context['comunidad']['id'].','.$context['comunidad']['rango'].')">
                   <e>'.$txt['comunidades_add-comunidad'].'</e>
                </button>
                <button class="sp-button fleft aband" onclick="$.Comunidades.abandonar(this, '.$context['comunidad']['id'].','.$context['comunidad']['rango'].')" style="display:none">
                   <e>'.$txt['comunidades_aband'].'</e>
                </button>';
             }
             // se muestra si soy miembro y sino soy el admin
             else if(!empty($context['miembro']['is_member']) && empty($context['comunidad']['is_admin'])){
             echo'
                <button class="sp-button fleft add" onclick="$.Comunidades.unirse(this, '.$context['comunidad']['id'].','.$context['comunidad']['rango'].')" style="display:none">
                   <i class="icon_c"></i>
                   <e>'.$txt['comunidades_add-comunidad'].'</e>
                </button>
                <button class="sp-button left aband" onclick="$.Comunidades.abandonar(this, '.$context['comunidad']['id'].','.$context['comunidad']['rango'].')">
                  <i class="icon_c"></i>
                   <e>'.$txt['comunidades_aband'].'</e>
                </button>';
             }
          }
          // se muestra a todos menos a los seguidores y al admin
          if(empty($context['comunidad']['is_admin'])){
             if(empty($context['siguiendo'])){
          echo'
             <div class="follow-buttons">
                <button id="follows_button" class="sp-button left not-following seguir" onclick="$.Comunidades.seguir(this, '.$context['comunidad']['id'].',1)">
                   <i class="iconos_ follows"></i>
                   <span>'.$txt['comunidades_follow-comunidad'].'</span>
                </button>
                
                <button id="follows_button" class="sp-button red left unfollowing noseguir" onclick="$.Comunidades.noseguir(this, '.$context['comunidad']['id'].',1)" style="display:none">
                   <span>'.$txt['comunidades_unfollowing'].'</span>
                </button>
             </div>';
             }
             else{
          echo'
             <div class="follow-buttons">
                <button id="follows_button" class="sp-button green left following seguir" onclick="$.Comunidades.seguir(this, '.$context['comunidad']['id'].',1)">
                   <i class="iconos_ follows"></i>
                   <span>'.$txt['comunidades_following'].'</span>
                </button>
                
                <button id="follows_button" class="sp-button red left unfollowing noseguir" onclick="$.Comunidades.noseguir(this, '.$context['comunidad']['id'].',1)" style="display:none">
                   <span>'.$txt['comunidades_unfollowing'].'</span>
                </button>
             </div>';
             }
          }
        }
		    else{
        echo' 
           <!-- OPCIONES PARA VISITANTES -->
           
           <a class="sp-button green left" rel="registro"><i class="icon_c"></i><e>'.$txt['comunidades_register'].'</e></a>';  
        }
     echo'</div>
     
	        <ul class="clearfix fright action-data" style="padding-top:10px;">
				     <li class="members-count"><span style="text-align: right;" data-val="'.$context['comunidad']['miembros'].'">'.$context['comunidad']['miembros'].'</span> '.$txt['comunidades_members'].'</li>
				     <li class="temas-count"><span style="text-align: right;" data-val="'.$context['comunidad']['temas'].'">'.$context['comunidad']['temas'].'</span> '.$txt['comunidades_thems'].'</li>
				     <li class="followers-count" style="border-right:none;padding-right:0!important;"><span style="text-align: right;" data-val="'.$context['comunidad']['follows'].'">'.$context['comunidad']['follows'].'</span> '.$txt['comunidades_followers'].'</li>
			    </ul>
		   </div>
		</div>
		
		<div class="clearfix">
	     <div class="fleft breadcrumb clearfix">
			    <a title="'.$context['tema']['fecha_title'].'" class="sw">
					   '.$context['tema']['hace'].'
				  </a>
			 </div>
			 
	     <script>!function(d,s,id){var js,fjs=d.getElementsByTagName(s)[0];if(!d.getElementById(id)){js=d.createElement(s);js.id=id;js.src="//platform.twitter.com/widgets.js";fjs.parentNode.insertBefore(js,fjs);}}(document,"script","twitter-wjs");</script>
			 <ul class="comunidad-share comunidad-share-list">';
			 if(!empty($context['user_twitter'])){
			 echo'
	        <li>
		         <a href="https://twitter.com/share" class="twitter-share-button" data-via="'.$context['user_twitter'].'" data-lang="es"></a>
	        </li>';}
	        echo'
	        <li>
		         <g:plusone size="medium" href="the_permalink"></g:plusone>
	        </li>
		      <li>
		         <iframe src="//www.facebook.com/plugins/like.php?'.(!empty($context['appID_FB'])? 'app_id='.$context['appID_FB'].'&amp;':'').'href='.$scripturl.'?action=comunidades;sa=tema;idtema='.$context['tema']['id'].'&amp;send=false&amp;layout=button_count&amp;width=120&amp;show_faces=false&amp;action=like&amp;colorscheme=light&amp;font&amp;height=21" scrolling="no" frameborder="0" style="border:none; overflow:hidden; width:120px; height:21px;" allowTransparency="true"></iframe>
	        </li>
       </ul>

		</div>
		<div style="width:710px;overflow:hidden;">
		   <h1>'.$context['tema']['titulo'].'</h1>';
		   if(!empty($modSettings['publicidad_one'])){
		   echo'
		   <div class="publicidad 710x75 fleft">
		      '.$modSettings['publicidad_one'].'
		   </div>';}
		   echo'
		   <div class="body_tema fleft">
		      '.$context['tema']['cuerpo'].'
		   </div>
		   
		   <div class="clearfix">
          <div class="fleft ctn_title_tema">
             <div class="fleft border-left-tema"></div>
             <div class="fleft box-center-tema">
                <div class="fleft center-tema">
                   <ul class="fright">';
                   if(!empty($context['user_twitter'])){
                   echo'
	                    <li>
	                       <a href="https://twitter.com/share" class="twitter-share-button" data-via="'.$context['user_twitter'].'" data-lang="es" data-count="vertical"></a>
	                    </li>';}
	                    echo'
	                    <li>
		                     <g:plusone size="tall"></g:plusone>
	                    </li>
		                  <li>
	                    	 <iframe src="//www.facebook.com/plugins/like.php?href='.$scripturl.'?action=comunidades;sa=tema;idtema='.$context['tema']['id'].'&amp;send=false&amp;layout=box_count&amp;width=80&amp;show_faces=false&amp;action=like&amp;colorscheme=light&amp;font&amp;height=68'.(!empty($context['appID_FB'])? '&amp;appId='.$context['appID_FB']:'').'" scrolling="no" frameborder="0" style="border:none; overflow:hidden; width:80px; height:68px;" allowTransparency="true"></iframe>
	                    </li>
                   </ul>
                </div>
             </div>
             <div class="fleft border-right-tema"></div>
          </div>
       </div>

       <div class="comunidad-data box clearfix rounded shadow" id="comunidad-data-stats" style="margin-top:15px;padding:0;">
	        <div class="comunidad-stats clearfix" style="border:none;margin:10px;padding:0;*height:1%">
		         <div class="fleft" style="height: 30px; overflow: hidden;">';
		         if($context['tema']['id_admin'] != $ID_MEMBER && $context['user']['is_logged']){
		         echo'
	              <a class="sp-button '.(!empty($context['ya_vote']) && $context['voto_type'] == '1' ? 'green disabled':'').' fleft" onclick="$.Comunidades.tema_votar(1, this)" class="require-login ui-btn" role="button">
	                 <i class="iconos_ liked" style="margin: auto 5px auto 3px"></i>
                   <e>'.$txt['comunidades_Ilike'].'</e>
                </a>
                
	              <a class="sp-button '.(!empty($context['ya_vote']) && $context['voto_type'] == '2' ? 'red disabled':'').' fleft" onclick="$.Comunidades.tema_votar(-1, this)" class="require-login ui-btn" role="button">
	                 <i class="iconos_ noliked" style="margin-right:-4px"></i>
	                 &nbsp;
                </a>
                
	              <a class="sp-button fleft">
	                 <i class="iconos_ follows" style="margin: auto 5px auto 3px"></i>
                   <e>'.$txt['comunidades_follow-comunidad'].'</e>
                </a>
	              <a class="sp-button fleft add_bookmark" onclick="$.Comunidades.add_bookmark()">
	                 <i class="iconos_ favs" style="margin: auto 5px auto 3px"></i>
                   <e class="txt">'.$txt['comunidades_to_favorite'].'</e>
                </a>';}
                echo'
	           </div>
	           
		         <ul class="comunidad-action-data fright">
				        <li class="votes-count">
								   <i class="iconos_ votes '.($context['tema']['calificacion']<0 ? 'noliked':'liked').' fright" style="margin: -2px 0 0 0"></i>
								   <span class="positive" data-val="'.$context['tema']['calificacion'].'" '.($context['tema']['calificacion']<0 ? 'style="color:red"':'').'>'.$context['tema']['calificacion'].'</span>
								   <strong>'.$txt['comunidades_votes'].'</strong>
				        </li>
				        <li class="followers-count">
					        <i class="iconos_ follows fright" style="margin:0"></i>
					        <span class="data-followers-count" data-val="0">0</span>
					        <strong>'.$txt['comunidades_followers'].'</strong>
				        </li>
				        <li>
					        <i class="iconos_ guests fright" style="margin:0"></i>
					        <span>'.$context['tema']['visitas'].'</span>
					        <strong>'.$txt['comunidades_guests'].'</strong>
				        </li>
						    <li class="favs-count">
					         <i class="iconos_ favs fright" style="margin:0"></i>
					         <span data-val="'.$context['tema']['favoritos'].'">'.$context['tema']['favoritos'].'</span>
					         <strong>'.$txt['comunidades_favorites'].'</strong>
				        </li>
					   </ul>
	        </div>
       </div>
       
       ';
		   if(!empty($modSettings['publicidad_one'])){
		   echo'
		   <div class="publicidad 710x75 fleft">
		      '.$modSettings['publicidad_one'].'
		   </div>';}
		   echo'
       
       
		</div>
		<div id="all-comments">
		<h3 class="fleft answer-count"><span data-val="'.$context['tema']['respuestas'].'">'.$context['tema']['respuestas'].'</span> '.$txt['comunidades_comentarios'].'</h3>
		</div>
		<br>
		<br>';
    // comentarios
    $allow_comment = $context['user']['is_logged'] && empty($context['tema']['cerrado']);
    
    if(!$allow_comment)
       if(allowedTo('moderate_forum') || $ID_MEMBER == $context['tema']['id_admin'])
           $allow_comment = true;
      
    if(!empty($context['tema']['respuestas']) && $context['show_paginator']){
       echo'
       <div class="inset-bar wrap-paginator clearfix">
          '.$context['paginacion'].'
          <div class="clear"></div>
       </div>';}	
    
   echo'
    <div id="comentarios" class="body_answers fleft">';
   		   foreach($context['respuestas']['list'] as $answers){
       echo'
       <div class="relative" id="comment-'.$answers['id2'].'">
          <div class="UI-comment clearfix'.($answers['autor'] == $context['tema']['id_admin'] ? ' author' : ($ID_MEMBER == $answers['autor'] ? ' own' : '') ).'">
             <div class="author-data">
                <div class="author-avatar box-shadow-soft">
                   <div class="img avatar_thumbnail s48">
                       <img src="'.$answers['avatar'].'" class="avatar" onerror="$.Comunidades.error_logo(this)" style="'.$context['user']['avatar']['coords'][48]['style'].'">
                   </div>
                </div>
                <div class="nick">
                   <a class="nick" href="'.$scripturl.'?action=profile&u='.$answers['autor'].'" text-quote="'.$answers['username'].'">
                      '.$answers['username'].'
                   </a>
		               <input name="suspension_'.$answers['autor'].'" type="hidden" value="">
		               <input name="edicion_'.$answers['autor'].'" type="hidden" value="">
                </div>
             </div>    
             <div class="comment-data rounded-3 box-shadow-soft">
                <div class="context">
                   <i class="arrow-dialog"></i>
                   <div class="comment-content msg answer_'.$answers['id2'].'" text-quote="'.$answers['comentario']['source'].'">
                      '.$answers['comentario']['bbc'].'
                   </div>
                </div>
                <div class="footer fleft">
                   <i class="iconos_ calendar" style="margin-right:5px;"></i>'.$answers['hace'];
		                  if($context['user']['is_logged']){
		                  echo' 
                   '.($context['tema']['id_admin'] == $ID_MEMBER || allowedTo('moderate_forum') ? ($context['tema']['id_admin'] != $answers['autor'] ? '<i class="cr iconos_ baned fright suspender_'.$answers['autor'].'" style="margin:0 2px;" title="'.$txt['comunidades_blocked_user'].'" id="se" onclick="$.Comunidades.suspender_show('.$answers['autor'].','.$context['comunidad']['id'].',1, this);"></i>':'') :'').'
                   '.($ID_MEMBER == $answers['autor'] || $context['tema']['id_admin'] == $ID_MEMBER || allowedTo('moderate_forum') ? '<i class="cr iconos_ delete_ fright" style="margin:0 2px;" title="'.$txt['comunidades_delete_comment'].'" id="se"></i>' :'').'
                   '.($context['user']['is_admin'] || allowedTo('moderate_forum') ? '<i class="cr iconos_ edite_ fright" style="margin:-1px 2px 0 2px;" title="'.$txt['comunidades_edite_comment'].'" id="se" onclick="$.Comunidades.edit_answer('.$answers['autor'].','.$answers['id2'].');"></i>' :'').'
                   <i class="cr iconos_ quote fright" style="margin:0 2px;" title="'.$txt['comunidades_quote_comment'].'" id="se" onclick="$.Comunidades.citar_answer('.$answers['id2'].');"></i>';}
		               echo'
                </div>
             </div>
          </div>
       </div>';}
  echo'
    </div>';
       	
                // alertas
		if(empty($context['tema']['respuestas']) && $context['miembro']['is_member'] && $context['user']['is_logged']){
		echo'
		<div class="fleft notice infofix no-answers">'.$txt['comunidades_empty_comments'].'</div>
		';}
		else if(!empty($context['tema']['cerrado']) && $context['user']['is_logged']){
		echo'
		<div class="fleft notice infofix">'.$txt['comunidades_error_can_not_permissions'].'</div>
		';}
		else if(empty($context['miembro']['is_member']) && $context['user']['is_logged']){
		echo'
		<div class="fleft notice infofix">'.$txt['comunidades_error_can_not_answer'].'</div>
		';}
		else if($context['user']['is_guest']){
		echo'
		<div class="fleft info infofix">'.$txt['comunidades_error_can_not_answer_guests'].'</div>
		';}

  if(!empty($context['tema']['respuestas']) && $context['show_paginator']){
  echo'
    <div class="inset-bar wrap-paginator clearfix">
       '.$context['paginacion'].'
       <div class="clear"></div>
    </div>';}

  // nueva respuesta

  if($allow_comment && $context['miembro']['is_member'] && $context['user']['is_logged']){
    echo'
    <div class="new-comment clearfix fleft" style="margin-bottom:10px;">
       <div class="mask-load with-icon"></div>
       <div class="author-data fleft">
          <div class="author-avatar box-shadow-soft">
             <div class="img avatar_thumbnail s48">
                <img class="avatar" src="'.$context['user']['avatar']['src'].'" style="'.$context['user']['avatar']['coords'][48]['style'].'">
             </div>
          </div>
       </div>
       <div class="wrap-comment fleft">
          <i class="arrow-dialog"></i>
          <textarea name="comment" class="answer comment autogrow fleft" style="overflow: hidden; resize: none;" rows="1"></textarea>
       </div>
       <div class="clear"></div>
       <div class="right">
          <input type="button" class="sp-button" value="Comentar" onclick="$.Comunidades.new_answer()">
       </div>
    </div>';}
   echo'
 </div>
  </div>
</div>
		
		
		
		
		
		
</div>

</div>

';
/* Javascript */
?>
<script type="text/javascript">
var last_page = <?= $context['is_last_page'] ? 'true' : 'false' ?>;
</script>

<script id="gotoLastPageTmpl" type="text/x-jquery-tmpl">
      <div class="fleft info infofix hide" style="margin:10px auto!important;">{{html templ}} <a href="<?=$context['last_page_href']?>">${txt_gotolast}</a></div>
</script>
<script id="newAnswerTmpl" type="text/x-jquery-tmpl">
       <div class="relative" id="comment-${id_comment}" style="display:none">
          <div class="UI-comment clearfix ${type_comment}">
             <div class="author-data">
                <div class="author-avatar box-shadow-soft">
                   <div class="img avatar_thumbnail s48">
                       <img src="${avatar}" class="avatar" onerror="$.Comunidades.error_logo(this)" style="${avatar_coords}">
                   </div>
                </div>
                <div class="nick">
                   <a class="nick" href="<?=$scripturl?>?action=profile&u=${id_member}" text-quote="${nick}">
                      ${nick}
                   </a>
		               <input name="suspension_${id_member}" type="hidden" value="">
		               <input name="edicion_${id_member}" type="hidden" value="">
                </div>
                </div>    
             <div class="comment-data rounded-3 box-shadow-soft">
                <div class="context">
                   <i class="arrow-dialog"></i>
                   <div class="comment-content msg answer_${id_comment}" text-quote="${comment2}">
                      {{html comment}}
                   </div>
                </div>
                <div class="footer fleft">
                   <i class="iconos_ calendar" style="margin-right:5px;"></i>${time}		                  
                   <?php
                   if($context['user']['is_logged']){
                   echo'
                   '.(allowedTo('moderate_forum') ? '<i class="cr iconos_ baned fright" style="margin:0 2px;" title="'.$txt['comunidades_blocked_user'].'" id="se"></i>' :'').'
                   '.(allowedTo('moderate_forum') ? '<i class="cr iconos_ delete_ fright" style="margin:0 2px;" title="'.$txt['comunidades_delete_comment'].'" id="se"></i>' :'').'';
                   if($context['user']['is_admin'] || allowedTo('moderate_forum')){
                   echo'
                   <i class="cr iconos_ edite_ fright" style="margin:-1px 2px 0 2px;" title="'.$txt['comunidades_edite_comment'].'" id="se"';?> onclick="$.Comunidades.edit_answer(${id_member},${id_comment});"<?php echo'></i>';}
                   echo'
                   <i class="cr iconos_ quote fright" style="margin:0 2px;" title="'.$txt['comunidades_quote_comment'].'" id="se" onclick="$.Comunidades.citar_answer(\'';?>${id_comment}<?php echo'\');"></i>';
                   }
                   ?>
                </div>
             </div>
          </div>
       </div>
</script>
<?php
echo'
<script>
var id_admin = "'.$context['comunidad']['idmember'].'";
var id_auhor = "'.$context['tema']['id_admin'].'";
var id_comunidad = "'.$context['comunidad']['id'].'";
$.Comunidades.tipsy();
$(document).ready(function(){
$(\'.inset-bar\').addClass(\'left\').attr({\'style\':\'width:690px\'});
});

</script>
';
}

// MIEMBROS DE LA COMUNIDAD
function template_miembros(){
	global $context, $settings, $options, $txt, $scripturl, $modSettings, $db_prefix, $modSettings, $ID_MEMBER;

	global $context, $settings, $txt, $modSettings, $scripturl, $tipo, $eliminados, $comunidades, $options, $db_prefix, $puedopostear;
	global $pagAnterior, $pagActual, $pagTotal, $pagSiguiente, $modSettings;
	
echo'	
  <style type="text/css">	
		body{background-position: 0 116px!important;background-image: url('.$context['comunidad']['background'].');}
		#main .globalcontent{padding:0 15px!important;}
	</style>
	
<div class="bg_comunidad">

<!-- BOX LEFT -->
<div class="fleft box-left-comunidad">

    <!-- BREADCRUMP -->
    
    <ul class="fleft breadcrump clearfix">
		    <li class="first"><a href="'.$scripturl.'?action=comunidades" title="'.$txt['comunidades'].'">'.$txt['comunidades'].'</a></li>
		    <li><a href="'.$scripturl.'?action=comunidades;categoria='.$context['comunidad']['id_categoria'].'" title="'.$context['comunidad']['bname'].'">'.$context['comunidad']['bname'].'</a></li>
		    <li><a href="'.$scripturl.'?action=comunidades;sa=comunidad;idco='.$context['comunidad']['id'].'">'.$context['comunidad']['titulo'].'</a></li>		
		    <li>'.$txt['comunidades_members'].'</li>		
		    <li class="last"></li>
	  </ul>
	   
	  <!-- BOX SEARCH MEMBERS -->
	   
	  <div class="big-group-info fleft" id="com-long-desc">
       <div class="fleft">
          <input type="text" class="text-search left" style="margin:0 10px 0 0"> 
          <a role="button" class="sp-button green left" onclick="return $(\'form[name=search-com]\').submit()">Buscar</a>
			 </div>
	     
	     <div class="fright">
		      <ul class="list-menu-seach">
		         <a href="'.$scripturl.'?action=comunidades;sa=miembros;idco='.$context['comunidad']['id'].';tipo=all">
		            <li '.(empty($_GET['tipo']) || $_GET['tipo'] == 'all' ?'class="active"':'').'>
		               '.$txt['comunidades_members'].'
		            </li>
		         </a>
		         <a href="'.$scripturl.'?action=comunidades;sa=miembros;idco='.$context['comunidad']['id'].';tipo=ban">
		            <li '.($_GET['tipo'] == 'ban' ?'class="active"':'').'>
		               Suspendidos
		            </li>
		         </a>
		         <a href="'.$scripturl.'?action=comunidades;sa=miembros;idco='.$context['comunidad']['id'].';tipo=history">
		            <li '.($_GET['tipo'] == 'history' ?'class="active"':'').'>
		               '.$txt['comunidades_history'].'
		            </li>
		         </a>
		         '.(!empty($context['comunidad']['soyadmin']) || !empty($mb['admin'])?'
		         <a href="'.$scripturl.'?action=comunidades;sa=miembros;idco='.$context['comunidad']['id'].';tipo=solicitudes">
		            <li '.($_GET['tipo'] == 'solicitudes' ?'class="active"':'').'>
		               '.$txt['comunidades_solicitudes'].'
		            </li>
		         </a>
		         ':'').'
		      </ul>
		   </div>
	     
		</div>
		
		<!-- BOX MEMBERS -->';
		
		foreach($context['miembros']['all'] as $mb){
		echo'
		<div class="content_search_members fleft">
		   <div class="fleft">
		      <img src="'.$mb['avatar'].'" onerror="$.Comunidades.error_logo(this)">
		   </div>
		   <div class="fleft" style="margin-left:10px">
		      <a href="'.$scripturl.'?action=profile;u='.$mb['idmember'].'">'.$mb['nombre'].'</a>
		      <br>
		      '.$txt['comunidades_the_range_'].': <b>'.querango($mb['id_rango']).'</b>
		      <br>';
		      if(empty($context['miembro']['posteador']) && empty($context['miembro']['visitante'])){
		      if($context['comunidad']['idmember'] != $mb['idmember']){
		      echo'
		      <div class="fleft">
		         '.$txt['comunidades_opciones'].': 
		         <a id="sw" title="'.$txt['comunidades_suspend_from_this_community'].'" onclick="$.Comunidades.suspender_show('.$mb['idmember'].','.$context['comunidad']['id'].',1);" class="suspender">'.$txt['comunidades_suspend'].'</a>
		         '.(!empty($context['comunidad']['soyadmin']) || !empty($mb['admin'])?' | <a id="sw" href="" title="'.$txt['comunidades_delete_from_this_community'].'">'.$txt['comunidades_delete'].'</a>':'').'
		         '.(!empty($context['comunidad']['soyadmin'])?' | <a id="sw" href="" title="'.$txt['comunidades_change_rank_this_user'].'">'.$txt['comunidades_change_rank'].'</a>':'').'
		      </div>
		      <br>';}}
		      echo'
		      <a href="">'.$txt['comunidades_send_pm'].'</a>
		      <input name="suspension_'.$mb['idmember'].'" type="hidden" value="">
		   </div>
		</div>
		';}

		if($_GET['tipo'] == 'ban' or $_GET['tipo'] == 'history' or $_GET['tipo'] == 'solicitudes'){
		
		if(!empty($context['miembro']['admin']) || !empty($context['miembro']['moderador']) && !empty($context['miembro']['bloqueado'])){
		
		if(!empty($context['miembros']['ban']) && $_GET['tipo'] == 'ban'){
	     foreach($context['miembros']['ban'] as $mb){
		   echo'
		   <div class="content_search_members fleft">
		      <div class="fleft">
		         <img src="'.$mb['avatar'].'" onerror="$.Comunidades.error_logo(this)">
		      </div>
		      <div class="fleft" style="margin-left:10px">
		         <a href="'.$scripturl.'?action=profile;u='.$mb['idmember'].'">'.$mb['nombre'].'</a>
		         <br>
		         '.$txt['comunidades_the_range_'].': <b>'.querango($mb['id_rango']).'</b>
		         <br>
		         '.$txt['comunidades_razon'].': <font style="color:red;">'.$mb['razon'].'</font>
		         <br>';
		         if(empty($context['miembro']['posteador']) && empty($context['miembro']['visitante'])){
		         if($context['comunidad']['idmember'] != $mb['idmember']){
		         echo'
		         <div class="fleft">
		            '.$txt['comunidades_opciones'].': 
		            <a id="sw" title="'.(empty($mb['bloqueado'])?$txt['comunidades_suspend_from_this_community']:$txt['comunidades_suspend2']).'" onclick="$.Comunidades.suspender'.(empty($mb['bloqueado'])?'_show':'').'('.$mb['idmember'].','.$context['comunidad']['id'].','.(empty($mb['bloqueado'])?1:2).');" class="suspender">'.(empty($mb['bloqueado'])?$txt['comunidades_suspend']:$txt['comunidades_suspend2']).'</a>
		            '.(!empty($context['comunidad']['soyadmin']) || !empty($mb['admin'])?'
		          | <a id="sw" href="" title="'.$txt['comunidades_delete_from_this_community'].'">'.$txt['comunidades_delete'].'</a>':'').'
		            '.(!empty($context['comunidad']['soyadmin'])?'
		          | <a id="sw" href="" title="'.$txt['comunidades_change_rank_this_user'].'">'.$txt['comunidades_change_rank'].'</a>':'').'
		         </div>
		         <br>';}}
		         echo'
		         <a href="">'.$txt['comunidades_send_pm'].'</a>
		         <input name="suspension_'.$mb['idmember'].'" type="hidden" value="">
		      </div>
		   </div>
		   ';}
		}
		else if(empty($context['miembros']['ban']) && $_GET['tipo'] == 'ban'){
		   echo'<div class="fleft error infofix">'.$txt['comunidades_no_user_bloqued'].'</div>';
		}
		
		   foreach($context['miembros']['history'] as $mb){
		   echo'
		   <div class="content_search_members fleft">
		      <div class="fleft">
		         <img src="'.$mb['avatar'].'" onerror="$.Comunidades.error_logo(this)">
		      </div>
		      <div class="fleft" style="margin-left:10px">
		         <a href="'.$scripturl.'?action=profile;u='.$mb['idmember'].'">'.$mb['nombre'].'</a>
		         <br>
		         '.$txt['comunidades_the_range_'].': <b>'.querango($mb['id_rango']).'</b>
		         <br>';
		         if(empty($context['miembro']['posteador']) && empty($context['miembro']['visitante'])){
		         if($context['comunidad']['idmember'] != $mb['idmember']){
		         echo'
		         <div class="fleft">
		            '.$txt['comunidades_opciones'].': 
		            <a id="sw" title="'.$txt['comunidades_suspend_from_this_community'].'" onclick="$.Comunidades.suspender_show('.$mb['idmember'].','.$context['comunidad']['id'].',1);" class="suspender">'.$txt['comunidades_suspend'].'</a>
		            '.(!empty($context['comunidad']['soyadmin']) || !empty($mb['admin'])?' | <a id="sw" href="" title="'.$txt['comunidades_delete_from_this_community'].'">'.$txt['comunidades_delete'].'</a>':'').'
		            '.(!empty($context['comunidad']['soyadmin'])?' | <a id="sw" href="" title="'.$txt['comunidades_change_rank_this_user'].'">'.$txt['comunidades_change_rank'].'</a>':'').'
		         </div>
		         <br>';}}
		         echo'
		         <a href="">'.$txt['comunidades_send_pm'].'</a>
		         <input name="suspension_'.$mb['idmember'].'" type="hidden" value="">
		      </div>
		   </div>
		   ';}
		
		if(!empty($context['comunidad']['soyadmin']) && !empty($context['miembros']['solicitudes']) && $_GET['tipo'] == 'solicitudes'){
		
		   foreach($context['miembros']['solicitudes'] as $mb){
		   echo'
		   <div class="content_search_members fleft">
		      <div class="fleft">
		         <img src="'.$mb['avatar'].'" onerror="$.Comunidades.error_logo(this)">
		      </div>
		      <div class="fleft" style="margin-left:10px">
		         <a href="'.$scripturl.'?action=profile;u='.$mb['idmember'].'">'.$mb['nombre'].'</a>
		         <br>
		         '.$txt['comunidades_the_range_'].': <b>'.querango($mb['id_rango']).'</b>
		         <br>';
		         if(empty($context['miembro']['posteador']) && empty($context['miembro']['visitante'])){
		         if($context['comunidad']['idmember'] != $mb['idmember']){
		         echo'
		         <div class="fleft">
		            '.$txt['comunidades_opciones'].': 
		            <a id="sw" title="'.(!empty($mb['bloqueado'])?$txt['comunidades_suspend_from_this_community']:$txt['comunidades_suspend2']).'" onclick="$.Comunidades.suspender'.(!empty($mb['bloqueado'])?'_show':'').'('.$mb['idmember'].','.$context['comunidad']['id'].','.(!empty($mb['bloqueado'])?1:2).');" class="suspender">'.(!empty($mb['bloqueado'])?$txt['comunidades_suspend']:$txt['comunidades_suspend2']).'</a>
		            '.(!empty($context['comunidad']['soyadmin']) || !empty($mb['admin'])?'
		          | <a id="sw" href="" title="'.$txt['comunidades_delete_from_this_community'].'">'.$txt['comunidades_delete'].'</a>':'').'
		            '.(!empty($context['comunidad']['soyadmin'])?'
		          | <a id="sw" href="" title="'.$txt['comunidades_acept_member'].'">'.$txt['comunidades_acept_member'].'</a>':'').'
		         </div>
		         <br>';}}
		         echo'
		         <a href="">'.$txt['comunidades_send_pm'].'</a>
		      </div>
		   </div>
		   ';}
		}
		else if(!empty($context['comunidad']['soyadmin']) && empty($context['miembros']['solicitudes']) && $_GET['tipo'] == 'solicitudes'){
		   echo'<div class="fleft error infofix">'.$txt['comunidades_no_user_solicitud'].'</div>';
		}
		else if(empty($context['comunidad']['soyadmin']) && empty($context['miembros']['solicitudes']) && $_GET['tipo'] == 'solicitudes'){
		   echo'<div class="fleft error infofix">'.$txt['comunidades_only_admin_solicitudes'].'</div>';
		}
		
		}
		else{
		   echo'<div class="fleft error infofix">'.$txt['comunidades_no_access'].'</div>';
		}
		}
echo'
</div>
<!-- END BOX LEFT -->

<!-- BOX RIGHT -->

<div class="fleft box-right-comunidad">';
	 
	 if($context['comunidad']['miembros']){
   echo'
   <!-- �LTIMOS MIEMBROS -->
	 <div class="title clearfix">
		  <h2>'.$txt['comunidades_last_members'].'</h2>
	 </div>
	 <div class="list">
	    <ul class="avatar-list-32 clearfix">';
			   foreach($context['miembros']['todos'] as $miembros){
		echo'<li data-uid="'.$miembros['id'].'">
			      <a href="'.$scripturl.'?acttion=profile;u='.$miembros['idmember'].'">
               <img  class="avatar-32" src="'.$miembros['avatar'].'" title="'.$miembros['nombre'].'" onerror="$.Comunidades.error_logo(this)">
			      </a>
			   </li>';}
 echo'</ul>
      <hr>
 
      <div class="read-more clearfix" style="margin:-15px 0 0 0">
         <span class="show-more fright">
		        <a href="'.$scripturl.'?action=comunidades;sa=miembros;idco='.$context['comunidad']['id'].'">'.$txt['comunidades_see-more'].' '.$txt['comunidades_raquo'].'</a>
		     </span>
      </div>';
		  echo'
	 </div>';}
	 echo'
<script>
var id_admin = "'.$context['comunidad']['idmember'].'";
</script>

</div>

<!-- END BOX RIGHT -->

</div>';	

}


function template_protocolo(){
	global $context, $settings, $txt, $modSettings, $scripturl, $tipo, $eliminados, $cantnot, $options;
	    global $id, $pagarray, $modSettings, $db_prefix;

echo'
<br>
<center>
   <h3>'.$txt['comunidades_protocolo'].'</h3>
</center>
<hr>

<div class="fleft ctn_title_prot">
   <div class="fleft border-left"></div>
   <div class="fleft title_prot">'.$txt['comunidades_protocolo_intro'].'</div>
   <div class="fleft border-right"></div>
</div>
<br>
'.$txt['comunidades_protocolo_intro_desc'].' <b>'.$context['forum_name'].'</b> '.$txt['comunidades_protocolo_intro_desc2'].'
<br>

<div class="fleft ctn_title_prot">
   <div class="fleft border-left2"></div>
   <div class="fleft title_prot2">'.$txt['comunidades_protocolo_thems'].'</div>
   <div class="fleft border-right2"></div>
</div>

<ul style="margin-left:20px;">
   <li>
      <b>'.$txt['comunidades_protocolo_thems_desc'].'</b>
   </li>
   <li>
      <ul style="list-style-type:circle;margin-left:20px;">';
         for($i=1;$i<18;$i++){
         echo'
         <li>
            '.$txt['comunidades_protocolo_thems_desc_one_'.$i].' '.($i==17 ? '<b>'.$context['forum_name'].'</b>':'').' '.$txt['comunidades_protocolo_thems_desc_one_'.$i.'_2'].'
         </li>';}
         echo'
      </ul>
   </li>
   <li><br></li>
   <li>
      <b>'.$txt['comunidades_protocolo_thems_desc2'].'</b>
   </li>
   <li>
      <ul style="list-style-type:circle;margin-left:20px;">';
         for($i=1;$i<6;$i++){
         echo'
         <li>
            '.$txt['comunidades_protocolo_thems_desc_two_'.$i].' '.($i==5 ? '<b>'.$context['forum_name'].'</b>':'').' '.$txt['comunidades_protocolo_thems_desc_two_'.$i.'_2'].'
         </li>';}
         echo'
      </ul>
   </li>
   <li><br></li>
   <li>
      <b>'.$txt['comunidades_protocolo_thems_desc3'].'</b>
   </li>
   <li>
      <ul style="list-style-type:circle;margin-left:20px;">';
         for($i=1;$i<7;$i++){
         echo'
         <li>
            '.$txt['comunidades_protocolo_thems_desc_three_'.$i].'
         </li>';}
         echo'
      </ul>
   </li>
</ul>
<br>
<hr>

<center>'.$txt['comunidades_protocolo_thems_desc4'].'<b>'.$context['forum_name'].' </b></center>';

}

// MIS COMUNIDADES
function template_miscomunidades(){
	global $context, $settings, $txt, $scripturl, $db_prefix, $modSettings, $ID_MEMBER;
	
echo'	
  <style type="text/css">
		body{background-position: 0 116px!important;background-image: url('.$context['comunidad']['background'].');}
		#main .globalcontent{padding:0 15px!important;}
	</style>
	
<div class="bg_comunidad">
<!-- BOX LEFT -->
<div class="fleft box-left-comunidad">
	   
	  <!-- BOX Filtro -->
	   
	  <div class="big-group-info fleft ui-corner-all" style="padding:4px;width:703px;">
       <div class="fleft">
          <div class="result_shows">'.$txt['comunidades_shows'].' <b>'.$context['count::comunidades'].'</b> '.$txt['comunidades_results_of'].' <b>'.$context['user']['count::comunidades'].'</b></div>
			 </div>
			 
	     <div class="fright" style="width:311px">
	        <div class="result_shows fleft">'.$txt['comunidades_order_by'].'</div>
		      <ul class="list-menu-seach">
		         <a href="'.$scripturl.'?action=comunidades;sa=miscomunidades;tipo=name">
		            <li '.(empty($_GET['tipo']) || $_GET['tipo'] == 'name' ?'class="active"':'').'>
		               Nombre
		            </li>
		         </a>
		         <a href="'.$scripturl.'?action=comunidades;sa=miscomunidades;tipo=range">
		            <li '.($_GET['tipo'] == 'range' ?'class="active"':'').'>
		               Rango
		            </li>
		         </a>
		         <a href="'.$scripturl.'?action=comunidades;sa=miscomunidades;tipo=members">
		            <li '.($_GET['tipo'] == 'members' ?'class="active"':'').'>
		               Miembros
		            </li>
		         </a>
		         <a href="'.$scripturl.'?action=comunidades;sa=miscomunidades;tipo=thems">
		            <li '.($_GET['tipo'] == 'thems' ?'class="active"':'').'>
		               Temas
		            </li>
		         </a>
		      </ul>
		   </div>
	     
		</div>
		
		<!-- BOX MisComunidades -->';
                 if(empty($context['comunidades']['my'])){
				echo'<div class="content_search_members fleft">
                                <div class="content">
					<div class="align-c">
						<div class="error">No tienes comunidades para mostrar.</div>
					</div>
                                     </div></div>   ';}

		foreach($context['comunidades']['my'] as $cm){
		echo'

		<div class="content_search_members fleft">
		   <div class="fleft avatarBox">
			    <a href="'.$scripturl.'?action=comunidades;sa=comunidad;idco='.$cm['id'].'">
			       <img src="'.$cm['portada'].'" alt="animecity" width="75" height="75" onerror="com.error_logo(this)" />
			    </a>
			 </div>
			 <div class="fleft infoBox">
				   <h4><a href="'.$scripturl.'?action=comunidades;sa=comunidad;idco='.$cm['id'].'">'.$cm['titulo'].'</a></h4>
				   <ul>
					    <li>Categor&iacute;a: <strong>'.$cm['categoria'].'</strong></li>
					    <li>
					    '. _substr($cm['descripcion'], 0, 75, 70, true).'
					    </li>
					    <li>Miembros: <strong>'.$cm['miembros'].'</strong> - Temas: <strong>'.$cm['temas'].'</strong></li>
					    <li>Mi rango: <strong>'.querango($cm['id_rango']).'</strong></li>
				   </ul>
			 </div>
		</div>
                ';}


			     if(!empty($context['total_pages'])){
      echo'
      <strong>'.$txt['comunidades_pages'].': </strong>'.$context['total_pages'];
      echo'
      <div class="inset-bar wrap-paginator clearfix">' .$context['paginacion'] . '</div>';
    }
echo'</div> ';

echo'
<!-- END BOX LEFT -->

<!-- BOX RIGHT -->

<div class="fleft box-right-comunidad">';


   echo'
   <!-- �LTIMOS MIEMBROS -->
	 <div class="title clearfix">
		  <h2>Publicidad</h2>
	 </div>

	 <div class="list">
	    Publi everywhere
			  </div>';
	 echo'


</div>

<!-- END BOX RIGHT -->

</div>';

}

//DIRECTORIO DE COMUNIDADES
function template_directorio(){

global $context, $settings, $options, $txt, $scripturl, $modSettings, $context, $db_prefix;
echo'

 		<div class="bg_comunidad">
			<!-- BOX LEFT -->
				<div class="fleft box-left-comunidad">
                                     <!-- BUSCADOR COMUNIDADES -->
						<div class="search-c">
							<div class="big-group-info fleft ui-corner-all" style="padding:4px;width:703px;">
								<form id="search-form" method="GET" action="#">
								<input class="text-search left" type="text" autocomplete="off" name="q" size="41" maxlength="2048" placeholder="Buscar en comunidades" title="Search" style="margin-right:10px">
								<a class="sp-button green left" style="margin-top:6px;" onclick="#" role="button">Buscar</a>
								</form>
							</div>
						</div>
                         <!-- NAVEGACION -->
			<div class="breadcrump clearfix" style="padding:0">
				<ul>
					<li class="first">
						<a href="#" title="Comunidades">Comunidades</a>
			       		</li>
					<li>
						<a href="'.$scripturl.'?action=comunidades;sa=dir" title="Comunidades">Directorio</a>
					</li>
					<li> Todas </li>
					<li class="last"> </li>
				</ul>
			</div>';
$id = $_GET['id'];
if($cat=='')
{

foreach($context['categoria'] as $comunidad){

$id_categoria = $comunidad['ID_BOARD'];
$id_subcat = $comunidad['ID_BOARD2'];
$id_comu = $comunidad['ID_COMUNIDAD'];
$categoria= $comunidad['name'];

$request = mysql_query("SELECT COUNT(ID_COMUNIDAD) AS cantidad FROM {$db_prefix}comunidades WHERE ID_BOARD = '".$id_categoria."'");
$comu = mysql_fetch_assoc($request);

 echo'
    <!-- DIRECTORIO -->
		<div class="clearfix dir-box">
			<i class="iconos_ cat_'.$id_categoria.'" style="margin-right: 10px; margin-top: 8px;"></i>
			<a class="nombre"href="'.$scriptur.'?action=comunidades;sa=dir;cat=#">',$comunidad['name'],'</a>
			<p> ',$comu['cantidad'],' </p>
					<a href="#">General y Otros Ej.#1</a>
					,
					<a href="#">Humor Ej.#2</a>
					,
					<a href="#">Vida nocturna Ej.#3</a>
		</div>';}

   }

   /*CREAR TEMPLATE O LO QUE SEA PARA LAS SUBCATEGORIAS
DE LAS COMUNIDADES TIPO T!

ACA UN LINK DE SUBCATEGORIA --> http://www.taringa.net/comunidades/dir/Internacional/diversion-esparcimiento

ACA OTRO LINK DE LAS COMUNIDADES POR CATEGORIA --> http://www.taringa.net/comunidades/dir/Internacional/diversion-esparcimiento/vida-noctura


*/

echo'
</div>

<!-- END BOX LEFT -->

<!-- BOX RIGHT -->

<div class="fleft box-right-comunidad">';


   echo'
   <!-- FILTRADO POR PAISES -->
	 <div class="title clearfix">
		  <div class="title clearfix">
			<h2>'.$txt['comunidades_by_country'].'</h2>
		  </div>

	 </div>

         <ul id="comunidades-dir" class="categoriaList" style="height: 170px; overflow: hidden;">
		<li class="first-child">
			<a href="/comunidades/dir/Internacional/">Todos los pa�ses</a>
		</li>
		<li>
			<a href="/comunidades/dir/Argentina/">Argentina</a>
			<span class="count">11418</span>
		</li>
		<li>
			<a href="/comunidades/dir/Bolivia/">Bolivia</a>
			<span class="count">4526</span>
		</li>
 	</ul>

      <hr>
      		 <div class="read-more clearfix" style="margin:-15px 0 0 0">
         		<span class="show-more fright">
		        	<a href="'.$scripturl.'?action=comunidades;sa=#">'.$txt['comunidades_see-more'].' '.$txt['comunidades_raquo'].'</a>
		     	</span>
      		 </div>';
		  echo'
	 </div>';
	 echo'


</div>

<!-- END BOX RIGHT -->


 </div>
  ';


}
?>
