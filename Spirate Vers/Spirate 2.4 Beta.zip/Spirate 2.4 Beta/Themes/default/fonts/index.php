<?php
$iterations = 0;
$dirname = dirname(__FILE__);

while(!file_exists($dirname . '/Settings.php')){

    $dirname = dirname($dirname);

    if($iterations > 25) // are you serius?
        exit;

    $iterations++;
}

require($dirname . '/Settings.php');
header('Location: ' . $boardurl);

?>