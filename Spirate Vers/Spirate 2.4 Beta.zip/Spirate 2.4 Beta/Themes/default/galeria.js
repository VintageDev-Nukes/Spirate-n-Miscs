global = {};
global.onetime = [];
global.lang = [];
global.cache = {};




var galeria = {
             /* Funciones Ajax de Galeria */

   imgAlbRight : function(){
  
            var img = document.album.noalbum;
            var id = img.value;
            var text = $('#img'+id).html();

            if(text!=null) {

           $('#img'+id).remove();
           $('#sialbum').html($('#sialbum').html()+'<option id="img'+id+'" value="'+id+'">'+text+'</option>');}
                             },

   imgAlbLeft : function(){

            var id = document.album.sialbum.value;
            var text = $('#img'+id).html();

            if(text!=null){

           $('#img'+id).remove();
           $('#noalbum').html($('#noalbum').html()+'<option id="img'+id+'" value="'+id+'">'+text+'</option>');}
  
            

           
                             },

   createThumb : function(url_img,id){

           $('#lalala').html('<span style="text-decoration: blink">Espere...</span>'); 
  
    $.ajax({
            type : 'POST',
            data : 'url_img=' + url_img + '&id=' + id,
            url : global.data.scripturl + '?action=thumb',
            
            success : function(data){

               $('#lalala').html(data);
            },
            error : function(){
                //Menos
            },
            complete : function(){
                //mmmm
            }
        });

           
                             },

   imgVacio : function(img){
  
          img.src= global.data.images_url +"/galeria/vacio.jpg";
                             },

   /* Comentar Imagen */
    new_comment : function(retry){

        if(!global.cache['new_comment_gal'])
            global.cache['new_comment_gal'] = {
                retry : false,
                wait : false,
                last_error : '',
                ready : false
            };
        
        if(!retry)
            data = {comment : encodeURIComponent($('textarea.comment').val()), ID_IMG : global.data.ID_IMG};
        else
            data = global.cache['new_comment_gal']['retry'];

        if(!global.cache['new_comment_gal']['retry'])
            global.cache['new_comment_gal']['retry'] = data;

        if(global.cache['new_comment_gal']['wait'])
            if(global.cache['new_comment_gal']['wait'] > 0)
                return sp_dialog.alert($txt['error'], global.cache['new_comment_gal']['last_error']);

        if(global.cache['new_comment_gal']['ready'])
            return false;
        else
            global.cache['new_comment_gal']['ready'] = true;

        var maskload = $('.new-comment .mask-load').fadeIn();
        $.ajax({
            type : 'POST',
            data : 'comentario=' + data.comment + '&imagen=' + data.ID_IMG,
            url : global.data.scripturl + '?action=galeria&sa=comentar',
            dataType: 'json',
            cache: false,
            async: true,
            success : function(data){



                if(data.status == 'error'){
                           
                    if(data.type == 'timeout'){ 
                        global.cache['new_comment_gal']['wait'] = data.timeout;
                        galeria.checkTimeout();
                    } // suponiendo que el post se cerro en ese instante.
                    else if(data.type == 'locked' && $('.new-comment').length > 0)
                        $('.new-comment').slideUp(function(){

                            $(this).remove();
                        });
                        
                        global.cache['new_comment_gal']['last_error'] = data.message;
                        return sp_dialog.alert($txt['error'], data.message);
                }
                 
                $('textarea.comment').val('').focus().blur();
                
                if($('.no-comments').length > 0)
                    $('.no-comments').fadeOut();
                
                        var template = $("#newCommentTmpl").tmpl(data).appendTo("#comentarios");
                        $(template).slideDown('slow');

                        var scrollheight = 40;
                        if($(template).find('.UI-comment').length > 0)
                            scrollheight = $(template).find('.UI-comment')[0].offsetHeight;

                        $.scrollTo('+=' + scrollheight + 'px', 800);
            },
            error : function(){
                errors.retry('galeria.new_comment(true)');
            },
            complete : function(){
                global.cache['new_comment_gal']['ready'] = false;
                $(maskload).fadeOut();
            }
        });

    },

    checkTimeout : function(){

        if(global.cache['new_comment_gal']['wait'] <= 0)
            return false;
        
        global.cache['new_comment_gal']['wait']--;

        setTimeout(function(){
            galeria.checkTimeout();
        }, 1000);

    },

   /* Puntuar Imagen, Me Gusta */
   megusta : function(){
       $("button.sp-button.green.right").addClass("nodisabled");

       $('button.sp-button.red.right').attr("disabled", "true");        
       $('button.sp-button.green.right.nodisabled').attr("disabled", "true");   

       $('.sp-button.green.right').css('background','#8FF1AC');
       $('.sp-button.green.right').css('color','#4B865D');
       $('.sp-button.green.right').css('text-shadow','1px 1px 0px #B8F3C9');
       $('.icongal.mau').css('background-position','5px -18px');

       var cp = parseInt($('#puntosgal').html());

      $.ajax({
            type : 'POST',
            data: 'imagen='+ global.data.ID_IMG +'&con=masuno',
            url: global.data.scripturl + '?action=galeria&sa=puntuar',
            dataType: 'json',
            cache: false,
            async: true,
            success : function(data){

                if(data.status == 'error')
                return sp_dialog.alert($txt['error'], data.message);
                else if(data.status == 'fin') 
                $('#puntosgal').html(cp+1);

                
            },
            error : function(){
                errors.retry('galeria.megusta(true)');
            },
           
        }); 

   },

   /* Puntuar Imagen, No Me Gusta */
   nomegusta : function(){


       $("button.sp-button.red.right").addClass("nodisabled");

       $('button.sp-button.red.right.nodisabled').attr("disabled", "true");        
       $('button.sp-button.green.right').attr("disabled", "true");   

       $('.sp-button.red.right').css('background','#E88E9D');
       $('.icongal.meu').css('background-position','-15px -18px');

       var cp = parseInt($('#puntosgal').html());

      $.ajax({
            type : 'POST',
            data: 'imagen='+ global.data.ID_IMG +'&con=menosuno',
            url: global.data.scripturl + '?action=galeria&sa=puntuar',
            dataType: 'json',
            cache: false,
            async: true,
            success : function(data){

                if(data.status == 'error')
                return sp_dialog.alert($txt['error'], data.message);
                else if(data.status == 'fin') 
                $('#puntosgal').html(cp-1);

                
            },
            error : function(){
                errors.retry('galeria.megusta(true)');
            },
           
        }); 

   },
   
   borrarAlbum: function(idAlbum){
   
    var causa ='<input type="text" name="causa" value="" />';
	var img ='<input type="checkbox" name="imagenes" />';
    var enviar ='<br/><center><input class="sp-button red" type="submit" value="Borrar" /><center>';
    var body='<form onSubmit="return galeria.verificarCausaAlbum(this);" action="'+global.data.scripturl +'?action=galeria;sa=borrarAlbum;id='+idAlbum+'" method="POST">Causa: '+causa+'<br/>Borrar tambien las Im&aacute;genes? '+img+' '+enviar+'</form>';
   
     dialogbox.show();
	 dialogbox.centerbox();
	 dialogbox.html({
            'title' : 'Borrar Album',
            'body'  : body
        });
   
   },
   
   verificarCausaAlbum: function(f){
   
      if(f.causa.value==''){
	  
      alert('Debes Ingresar una Causa.');
      return false;
	  }
	  
	  if(f.imagenes.checked)
	   f.imagenes.value = true;
	  else
       f.imagenes.value = false;
	   
	  return true;
   }

};
