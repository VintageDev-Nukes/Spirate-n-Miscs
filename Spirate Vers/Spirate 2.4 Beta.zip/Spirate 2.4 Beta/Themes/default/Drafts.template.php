<?php
// Spirate Script - Version 2.4
header("Content-Type: text/html;charset=utf-8");

function template_main(){
	global $context, $txt, $modSettings, $db_prefix, $modSettings;
 
	
}

?>