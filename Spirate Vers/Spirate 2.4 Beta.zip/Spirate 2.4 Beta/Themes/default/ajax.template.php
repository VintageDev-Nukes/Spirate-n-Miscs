<?php

function template_notifications(){
	global $context;

	// todo en un <ul>
	echo '<ul class="list-notifications">';
                        // sin notificaciones? :( forever alone
			if(empty($context['notifications']))
				echo '<li><div class="error margin-10 notify align-c">No tienes notificaciones</div></li>';

                        // seteamos los avatars
			$avatars = array();
                        // imprimimos las notificaciones
			foreach($context['notifications'] as $k => $data){
                            foreach($data as $n){
                            # la notificacion fue hecha por varios usuarios, obtenemos el avatar de los principales.
                            if($n['notifiers']){
                                $count = count($n['notifiers']);
                            // dividimos los avatars por cada uno
                            $i = 0;
                            foreach($n['notifiers'] as $member){
                            $i++;
                                switch($count){
                                    case 2: // 2 usuarios
                                        $avatars[$n['id']][] = '<span class="split"><img src="'.$member['avatar'].'" width="48" height="48"></span>';
                                    break;
                                    case 3: // 3 usuarios
                                        $setClass = array(1 => 'three', 2 => 'top', 3 => 'bottom');
                                        $avatars[$n['id']][] = '<span class="split '.$setClass[$i].'"><img src="'.$member['avatar'].'" width="48" height="48"></span>';
                                    break;
                                    case 4: // 4 usuarios 
                                        $setClass = array(1 => 'top', 2 => 'top', 3 => 'bottom', 4 => 'bottom');
                                        $avatars[$n['id']][] = '<span class="split four '.$setClass[$i].'"><img src="'.$member['avatar'].'" width="48" height="48"></span>';
                                    break;
                                }
                            }
                            }else // Solo fue un usuario el que realizo la accion, tomemos su avatar, :it's something:
                                $avatars[$n['id']] = '<img style="'.$n['first_sender']['avatar_coords'][48]['style'].'" src="'.$n['first_sender']['avatar'].'" width="48" height="48">';
                            
                            // un o unos avatars ?
                            $avatars[$n['id']] = is_array($avatars[$n['id']]) ? implode('', $avatars[$n['id']]) : $avatars[$n['id']];

                            # Cuantos mas?
                            $Lastsenders = (int)$n['params']['times']-4;
                            $bubble_lastSenders = '';
							
                            if($Lastsenders > 0)
                                $bubble_lastSenders = '<div style="display: block; float: left; top: -12px; left: -4px!important; right:auto!important" class="notify-globe red"><a><span>'.$Lastsenders.'+</span></a></div>';

                            // imprimimos la notificacion
                            echo '<li', !$n['is_read'] ? ' class="recent"' : '' ,'><div class="notify clearfix">
                            <div class="avatar split relative">'.$n['params']['times'].' '. $avatars[$n['id']] .'</div>
                            <div class="history">
                            <div class="action">' . $n['template']['minimal'] . '</div>
                            <div class="time clearfix"><i class="icon notifyIcon '.$n['type'].'"></i><span>'.$n['date'].'.</span></div>
                            </div>
                            </div></li>';
                            }
                    }
	// fin notificaciones.
	echo '</ul>';

}

?>