<?php 

/***************************************
*      Creado por 002 para SPIRATE     *
*--------------------------------------*
*        Gestor de Bloques v2.0        *
*--------------------------------------*
*             Spirate v2.4             *
****************************************/

function template_main(){
	global $context, $settings, $options, $txt, $scripturl, $modSettings, $context, $db_prefix, $requestbloques, $activado;

echo'<div style="float:left;">

<table width="100%"><tr><td>

<div class="box_title">
	Activar Gestor
</div><!-- /box_title -->
<div class="box_cuerpo">
	<form action="'.$scripturl.'?action=bloques;sa=editar" method="POST">
		<div class="alignC">
			<span class="color_red"><b>Activar Gestor de Bloques</b></span>
			<br />Activado <input type="radio" name="activar" value="1" ',$activado==1 ? 'checked="1"' : '' ,' />&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Desactivado <input type="radio" name="activar" value="0" ',$activado==0 ? 'checked="1"' : '' ,' />
			<br />
			<input class="button" type="submit" value="Editar" />
		</div><!-- /alignC -->
	</form>
</div><!-- /box_cuerpo -->

<br class="space" />

<div class="box_title">
	', $txt['ver_colum'], '
	<div class="box_rss">
		<span class="botondown" onclick="javascript:act()">
			Act
		</span>
	</div><!-- /box_rss -->
</div><!-- /box_title -->
<div class="box_cuerpo" style="min-height:360px;border-bottom:0">';

$columnas=0;
$anchomax=980;

echo'<div id="act">
<div id="solobloques" style="margin-top:5px;margin-bottom:10px;min-height:300px;">';

$request = db_query("SELECT COUNT(ID) AS cantidad FROM {$db_prefix}bloques",__FILE__,__LINE__);
$rrr = mysql_fetch_assoc($request);
mysql_free_result($request);

foreach($context['bloques'] as $bloques){
	$bordes = '';
	$tituloimg = '';
	$contenido = '';
	$columnas = $columnas + 1;
	$anchomax = $anchomax - ($bloques['ancho'] + 4);
	
	if($bloques['custom']==1){
		$tituloimg = 'background: url('.$bloques['tituloimg'].') repeat-x';
		$contenido = 'background:'.$bloques['contcolor'];
		$bordes = 'border: '.$bloques['bordera'].'px '.$bloques['bordert'].' '.$bloques['borderc'];
	}
	
	echo'<div id="f',$columnas,'"></div>';
	
	echo'<div id="',$columnas,'" style="width: ',($bloques['ancho']*717)/(960-(4*$columnas)),'px;float:left; padding-left:',(4*735)/960,'px;">

	<div class="box_title" style="',$tituloimg,'">
		Columna ',$bloques['columna'],'
		<div class="box_rss"></div>
	</div>
	<div class="box_cuerpo alignC" style="',$contenido,'; ',$bordes,'">';
		if($columnas>1){
			echo'
			<span onclick="javascript:mover(',$columnas - 1,',',$bloques['ID'],', ',$columnas,')" style="align:left;margin:2px;cursor:pointer;">
				<img title="Mover a la columna ',$columnas - 1,'" src="', $settings['default_images_url'], '/atras.png" />
			</span>';
		}
		
		if($columnas != $rrr['cantidad']){
			echo'
			<span onclick="javascript:mover(',$columnas + 1,', ',$bloques['ID'],', ',$columnas,')" style="align:right;margin:2px;cursor:pointer;">
				<img title="Mover a la columna ',$columnas + 1,'" src="', $settings['default_images_url'], '/adelante.png" />
			</span>';
		}

		echo'
		<div class="alignC">
			<span class="botondown" onclick="javascript:filas(',$bloques['ID'],',',$columnas,')">Filas</span>
			<br />
			<br />
			<span class="botondown" onclick="javascript:editar(',$bloques['ID'],')">Editar</span>
			<br />
			<br />
			<span class="botondown" onclick="javascript:borrar(',$bloques['ID'],',',$columnas,')">Borrar</span>
		</div><!-- /alignC -->

		<span class="color_green"><strong>ID: ',$bloques['ID'],'</strong></span> | 
		<span class="color_purple"><strong>Ancho: ',$bloques['ancho'],'px</strong></span>
	</div><!-- /box_cuerpo -->
	</div>';
}

echo'</div><!-- /solobloques -->
<table width="100%" style="float:left"><tr><td>
<span style="color:red;float:right;text-align:right;"><table><tr><td>',$txt['ancho_disponible'],'</td> <td><b>';if($anchomax<=0){echo'<span style="text-decoration:blink;">',$anchomax,'px</span>';}else{echo'',$anchomax-6,'px';} echo'</b></td></tr><tr><td>',$txt['numero_columnas'],'</td> <td><b>',$columnas,'</b></td></tr></table></span>
</td></tr></table></div>';

echo'</div></div>
<table width="100%" style="float:left"><tr><td>
<div style="width:750px;margin-top:10px;margin-bottom:5px;"><center><a id="agregar" class="botondown" style="cursor:pointer;margin-top:10px;">Agregar una Columna</a></center></div>

<div id="espera" style="display:none;"><center><img src="', $settings['default_images_url'], '/recarga.gif"></center><br></div>
<div id="agregado" style="display:none;"></div>
</td></tr></table>
</div>
&nbsp;<br><br><br>


<div id="editardiv" style="display:none;float:left"></div>

<div id="agregardiv" style="display:none;">
	<form method="post">
		<table width="410px" style="border: 4px dashed #025AC7;padding:5px;margin-left:50px;background:#FFFFFF">
			<tr>
				<td>',$txt['ancho_columna'],'</td><td>'; 
					if($anchomax<=0){
						echo'
						<div class="relative">
							<input type="int" name="ancho" maxlength="4" />
							<div class="tip_ayuda trouble" style="display:inline;">
								<span>
									<strong>',$txt['ancho_sobrepasado'],'</strong>
								</span>
							</div>
						</div><!-- /relative -->';
					}
					else{
						echo'<input type="int" name="ancho" maxlength="4" />';
					}

					echo'
				</td>
			</tr>
			<tr>
				<td>
					<hr class="divider" /><b>',$txt['custom_desing'],'</b>
				</td>
				<td>
					<div class="relative" onMouseOver="javascript:mostrar_flecha(this)">
						<input type="checkbox" name="custom" value="1" />
						<div class="tip_ayuda warning2">
							<span><strong></strong></span>
						</div>
					</div>
				</td>
			</tr>
			<tr>
				<td>',$txt['img_back'],'</td>
				<td>
					<input type="text" name="tituloimg" />
				</td>
			</tr>
			<tr>
				<td>
					<hr class="divider" />',$txt['content'],'
				</td>
			</tr>
			<tr>
				<td>
					',$txt['content_color'],'
				</td>
				<td>
					<input type="text" name="contcolor" maxlength="7">
				</td>
			</tr>
			<tr>
				<td>
					',$txt['borderw'],'
				</td>
				<td>
					<input type="int" name="bordera" maxlength="1" />
				</td>
			</tr>
			<tr>
				<td>
					',$txt['border_tipe'],'
				</td>
				<td>
					<select name="bordert">
						<option value="none" selected="selected">Ninguno</option>
						<option value="solid">Solido</option>
						<option value="inset">Recuadrado</option>
						<option value="dotted">Punteado</option>
						<option value="dashed">Discontinua</option>
						<option value="outset">Por Fuera</option>
						<option value="groove">Surcado</option>
					</select>
				</td>
			</tr>
			<tr>
				<td>
					',$txt['border_color'],'
				</td>
				<td>
					<input type="text" name="borderc" maxlength="7" />
				</td>
			</tr>
			<tr>
				<td>
					<center>
						<input class="botondown" type="button" onclick="javascript:agregar(',$columnas,',this.form,this.form.ancho.value,this.form.tituloimg.value,this.form.contcolor.value,this.form.bordera.value,this.form.bordert.value,this.form.borderc.value,this.form.custom.value);" style="cursor:pointer" value="Agregar" tabindex="2" />
					<center>
				</td>
			</tr>
		</table>
	</form>
<br />

</div><!-- /agregardiv -->
</td></tr></table>
</div><!-- /floatL -->';


//scripts
echo'
<script type="text/javascript">
$(\'#agregar\').click(function (){
	$(\'#agregardiv\').slideDown(\'slow\');
});

function mover(donde,idmover,cual){
	var filabloque = 1;
	
	$(\'#espera\').slideDown(\'slow\');
	
	$.ajax({
		type: \'POST\',
		url: url_sp + \'/Sources/Bloques-Mover.php\',
		data: \'donde=\'+ donde +\'&cual=\'+ cual +\'&idmover=\'+ idmover +\'&filabloque=\'+ filabloque,
		success: function(h){
			$(\'#espera\').slideUp(\'slow\');
			$(\'#agregado\').html(h);
			$(\'#agregado\').slideDown({duration: 2000});
			setTimeout(\'cerrarag()\', 2000);
			setTimeout(\'act()\', 1);
		}
	});
}

function moverf(donde,idmover,cual){
	var filabloque = 2;
	
	$(\'#espera\').slideDown(\'slow\');
	
	$.ajax({
		type: \'POST\',
		url: url_sp + \'/Sources/Bloques-Mover.php\',
		data: \'donde=\'+ donde +\'&cual=\'+ cual +\'&idmover=\'+ idmover +\'&filabloque=\'+ filabloque,
		success: function(h){
			$(\'#espera\').slideUp(\'slow\');
			$(\'#agregado\').html(h);
			$(\'#agregado\').slideDown({duration: 2000});
			setTimeout(\'cerrarag()\', 2000);
			setTimeout(\'act()\', 1);
		}
	});
}

function cerrarag(){
	$(\'#agregado\').slideUp({duration: 2000});
}

function act(){
	$(\'#act\').fadeOut(\'slow\');
	$.ajax({
		type: \'POST\',
		url: url_sp + \'/Sources/Bloques-Act.php\',
		success: function(h){
			$(\'#act\').html(h);
			$(\'#act\').fadeIn(\'slow\');
		}
	});
}

function agregar(columnas,f,ancho,tituloimg,contcolor,bordera,bordert,borderc,custom){
	var customon = 0;

	if(ancho == \'\'){
		alert(\'Debes fijar el ancho de los Bloques de la columna.\');
		return false;
	}

	if(f.custom.checked){
		customon = 1;
		if(contcolor != \'\'){
			if(contcolor.length!=7){
				alert(\'El color del contenido debe ser un Codigo Valido, ejemplo #FFFFFF.\');
				return false;
			}
		}
		if(borderc != \'\'){
			if(borderc.length!=7){
				alert(\'El color del borde debe ser un Codigo Valido, ejemplo #FFFFFF.\');
				return false;
			}
		}
		if(bordera == \'\'){
			alert(\'Debes ingresar el ancho del borde..\');
			return false;
		}
		if(tituloimg == \'\'){
			alert(\'El dise&#241;o customizado requiere una imagen de fondo para el tutilo.\');
			return false;
		}
	}

	$(\'#espera\').slideDown(\'slow\');
	$(\'#agregardiv\').slideUp(\'slow\');
	$.ajax({
		type: \'POST\',
		url: url_sp + \'/Sources/Bloques-AgregarC.php\',
		data: \'ancho=\'+ ancho +\'&tituloimg=\'+ tituloimg + \'&contcolor=\'+ contcolor + \'&bordera=\'+ bordera + \'&bordert=\'+ bordert + \'&borderc=\'+ borderc +\'&customon=\' + customon+  \'&columnas=\' + columnas,
		success: function(h){
			$(\'#espera\').slideUp(\'slow\');
			$(\'#agregado\').html(h);
			$(\'#agregado\').slideDown({duration: 2000});
			setTimeout(\'cerrarag()\', 2000);
			setTimeout(\'act()\', 1);
		}
	});
}

function mostrar_flecha(div){
	var a;
	$(div).click(function(){
		if(a==false){
			a=true;
			$(\'.tip_ayuda.warning2\').slideUp(\'slow\');
		}
		else{
			$(div).children(\'.tip_ayuda\').children().children().html(\'Rellena todos los cubiculos de abajo.\');
			$(div).children(\'.tip_ayuda\').addClass(\'correct\');
			$(div).children(\'.tip_ayuda\').show();
			a=false;
		}
	});
}

function editar(que){
	$(\'#espera\').slideDown(\'slow\');
	
	var edit = 1;
	
	$.ajax({
		type: \'POST\',
		url: url_sp + \'/Sources/Bloques-EditarC.php\',
		data: \'que=\'+ que +\'&edit=\'+ edit,
		success: function(h){
			$(\'#espera\').slideUp(\'slow\');
			$(\'#editardiv\').html(h);
			$(\'#editardiv\').slideDown({duration: 2000});
		}
	});
}

function guardar(f,ancho,tituloimg,contcolor,bordera,bordert,borderc,custom,id){
	var edit = 2;
	var customon = 0;

	if(ancho == \'\'){
		alert(\'Debes fijar el ancho de los Bloques de la columna.\');
		return false;
	}
	if(f.custom.checked){
		customon = 1;
		if(contcolor != \'\'){
			if(contcolor.length!=7){
				alert(\'El color del contenido debe ser un Codigo Valido, ejemplo #FFFFFF.\');
				return false;
			}
		}
		if(borderc != \'\'){
			if(borderc.length!=7){
				alert(\'El color del borde debe ser un Codigo Valido, ejemplo #FFFFFF.\');
				return false;
			}
		}

		if(bordera == \'\'){
			alert(\'Debes ingresar el ancho del borde..\');
			return false;
		}
		if(tituloimg == \'\'){
			alert(\'El dise&#241;o customizado requiere una imagen de fondo para el tutilo.\');
			return false;
		}
	}

	$(\'#espera\').slideDown(\'slow\');
	$(\'#editardiv\').slideUp(\'slow\');
	$.ajax({
		type: \'POST\',
		url: url_sp + \'/Sources/Bloques-EditarC.php\',
		data: \'ancho=\'+ ancho +\'&tituloimg=\'+ tituloimg + \'&contcolor=\'+ contcolor + \'&bordera=\'+ bordera + \'&bordert=\'+ bordert + \'&borderc=\'+ borderc +\'&customon=\' + customon +\'&id=\' + id +\'&edit=\' + edit,
		success: function(h){
			$(\'#espera\').slideUp(\'slow\');
			$(\'#agregado\').html(h);
			$(\'#agregado\').slideDown({duration: 2000});
			setTimeout(\'cerrarag()\', 2000);
			setTimeout(\'act()\', 1);
		}
	});
}

function borrar(id,columna){
	var borrarque = 1;
	
	if (confirm(\'Esta seguro de querer borrar esta columna junto con todos sus Bloques?\')){
		$(\'#espera\').slideDown(\'slow\');
		
		$.ajax({
			type: \'POST\',
			url: url_sp + \'/Sources/Bloques-Borrar.php\',
			data: \'id=\'+ id +\'&columna=\'+ columna +\'&borrarque=\'+ borrarque,
			success: function(h){
				$(\'#espera\').slideUp(\'slow\');
				$(\'#agregado\').html(h);
				$(\'#agregado\').slideDown({duration: 2000});
				setTimeout(\'cerrarag()\', 2000);
				setTimeout(\'act()\', 1);
			}
		});
	}
}

function borrarf(fila,bloque,id_columna){
	var borrarque = 2;
	
	if (confirm(\'Esta seguro de querer borrar esta fila?\')){
		$(\'#espera\').slideDown(\'slow\');
		
		$.ajax({
			type: \'POST\',
			url: url_sp + \'/Sources/Bloques-Borrar.php\',
			data: \'fila=\'+ fila +\'&bloque=\'+ bloque +\'&borrarque=\'+ borrarque +\'&id_columna=\'+ id_columna,
			success: function(h){
				$(\'#espera\').slideUp(\'slow\');
				$(\'#agregado\').html(h);
				$(\'#agregado\').slideDown({duration: 2000});
				setTimeout(\'cerrarag()\', 2000);
				setTimeout(\'act()\', 1);
			}
		});
	}
}

function filas(id_columna,columna){
	var fila = 1;
	
	$(\'#\'+columna).slideUp(\'slow\');
	$(\'#espera\').slideDown(\'slow\');
	
	$.ajax({
		type: \'POST\',
		url: url_sp + \'/Sources/Bloques-Filas.php\',
		data: \'id_columna=\'+ id_columna +\'&columna=\'+ columna +\'&fila=\'+ fila,
		success: function(h){
			$(\'#espera\').slideUp(\'slow\');
			$(\'#\'+columna).html(h);
			$(\'#\'+columna).slideDown({duration: 2000});
		}
	});
}

function agregarfilas(id){
	var fila = 2;
	
	$(\'#espera\').slideDown(\'slow\');
	
	$.ajax({
		type: \'POST\',
		url: url_sp + \'/Sources/Bloques-Filas.php\',
		data: \'id=\'+ id +\'&fila=\'+ fila,
		success: function(h){
			$(\'#espera\').slideUp(\'slow\');
			$(\'#editardiv\').html(h);
			$(\'#editardiv\').slideDown({duration: 2000});
		}
	});
}

function agregarf(titulo,contenido,conttipe,on,rss,bd,id){
	for(i=0; i <document.forma.conttipe.length; i++){
		if(document.forma.conttipe[i].checked){
			conttipe = document.forma.conttipe[i].value;
		}
	}

	for(i=0; i <document.forma.on.length; i++){
		if(document.forma.on[i].checked){
			on = document.forma.on[i].value;
		}
	}

	if(titulo == \'\'){
		alert(\'Debes agregar un titulo.\');
		return false;
	}
	if(contenido == \'\'){
		alert(\'Debes agregar un contenido.\');
		return false;
	}

	$(\'#espera\').slideDown(\'slow\');
	$(\'#editardiv\').slideUp(\'slow\');
	$.ajax({
		type: \'POST\',
		url: url_sp + \'/Sources/Bloques-AgregarF.php\',
		data: \'titulo=\'+ encodeURIComponent(titulo) + \'&contenido=\'+ encodeURIComponent(contenido) + \'&conttipe=\'+ conttipe + \'&on=\'+ on + \'&rss=\'+ rss +  \'&bd=\' + encodeURIComponent(bd) +\'&id=\' + id,
		success: function(h){
			$(\'#espera\').slideUp(\'slow\');
			$(\'#agregado\').html(h);
			$(\'#agregado\').slideDown({duration: 1000});
			setTimeout(\'cerrarag()\', 3000);
			setTimeout(\'act()\', 4000);
		}
	});
}

function editarf(id_columna,filase){
	var fila = 3;
	
	$(\'#fr\'+filase).slideUp(\'slow\');
	$(\'#espera\').slideDown(\'slow\');
	
	$.ajax({
		type: \'POST\',
		url: url_sp + \'/Sources/Bloques-Filas.php\',
		data: \'id_columna=\'+ id_columna +\'&filase=\'+ filase +\'&fila=\'+ fila,
		success: function(h){
			$(\'#espera\').slideUp(\'slow\');
			$(\'#editardiv\').html(h);
			$(\'#editardiv\').slideDown({duration: 2000});
		}
	});
}

function editarf2(ID_BLOQUE,titulo,contenido,conttipe,on,rss,bd){
	var fila = 4;
	
	for(i=0; i <document.forma.conttipe.length; i++){
		if(document.forma.conttipe[i].checked){
			conttipe = document.forma.conttipe[i].value;
		}
	}
	
	for(i=0; i <document.forma.on.length; i++){
		if(document.forma.on[i].checked){
			on = document.forma.on[i].value;
		}
	}
	
	if(titulo == \'\'){
		alert(\'Debes agregar un titulo.\');
		return false;
	}
	if(contenido == \'\'){
		alert(\'Debes agregar un contenido.\');
		return false;
	}
	
	$(\'#espera\').slideDown(\'slow\');
	$(\'#editardiv\').slideUp(\'slow\');
	$.ajax({
		type: \'POST\',
		url: url_sp + \'/Sources/Bloques-Filas.php\',
		data: \'titulo=\'+ encodeURIComponent(titulo) + \'&contenido=\'+ encodeURIComponent(contenido) + \'&conttipe=\'+ conttipe + \'&on=\'+ on + \'&rss=\'+ rss +  \'&bd=\' + encodeURIComponent(bd)  +\'&fila=\' + fila +\'&ID_BLOQUE=\' + ID_BLOQUE,
		success: function(h){
			$(\'#espera\').slideUp(\'slow\');
			$(\'#agregado\').html(h);
			$(\'#agregado\').slideDown({duration: 1000});
			setTimeout(\'cerrarag()\', 3000);
			setTimeout(\'act()\', 4000);
		}
	});
}
</script>';

}

function template_editar(){
	global $txt, $scripturl, $db_prefix;
	
	$activar = $_POST['activar'];
	
	echo'
	<div class="alignC">';
		if($activar!=''){
			$result1 = db_query("UPDATE {$db_prefix}settings
			SET value = '$activar'
			WHERE variable = 'gestorbloques' 
			LIMIT 1", __FILE__, __LINE__);

			if($result1){
				echo'<span class="color_green"><strong>editado Correctamente</strong></span>';
			}
			else{
				echo'<span class="color_red"><strong>algo salio mal</strong></span>';
			}
		}
		else{
			echo'<span class="color_red"><strong>No seleccionaste nada</strong></span>';
		}
		
		echo'
		<br />
		<a href="'.$scripturl.'?action=bloques">
			<input class="button" type="button" value="Volver" />
		</a>
	</div><!-- /alignC -->';
}

?>