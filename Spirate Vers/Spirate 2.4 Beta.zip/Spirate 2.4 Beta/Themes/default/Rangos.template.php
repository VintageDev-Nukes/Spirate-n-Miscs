<?php

function template_puntospr()
{
  global $txt, $context, $scripturl, $db_prefix, $settings, $modSettings, $user_info;

echo'<div class="box_title">', $txt['puntospr'] ,'</div>
     <div class="box_cuerpo" >
     <form action="/?action=puntospr" method="POST">
     <center><table widht="50%">
     <tr>
     <td>&nbsp</td>
     <td><b>',$txt['puntospr_range'],'</b></td>
     <td><b>',$txt['puntospr_points'],'</b></td>
     </tr>'; 

     foreach($context['puntospr'] as $ppr)
     {

      $ppr['stars']=explode('#', $ppr['stars']);
echo'<tr>
     <td><img src="',$settings['theme_url'],'/images/',$ppr['stars'][1],'"></td>
     <td>',$ppr['groupName'],'</td>
     <td><input type="int" name="p',$ppr['ID_GROUP'],'" value="',$ppr['puntos'],'"></td>
     </tr>';
     }

echo'</table><input class="button" type="submit" name="edit" value="Editar"></center></form></div>';

}

?>