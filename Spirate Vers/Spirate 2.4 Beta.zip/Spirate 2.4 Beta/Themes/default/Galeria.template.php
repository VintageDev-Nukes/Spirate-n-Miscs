<?php
 
if (!defined('SPIRATE'))
die('Hacking attempt...');

function template_reindex(){

 global $context,$settings, $Paginacion, $scripturl, $modSettings;

echo '<div class="left clearfix tituloGal">';
echo '<h3 class="blue" style="margin-left: 10px;margin-bottom:10px;margin-top:7px">Galeria de Im&aacute;genes</h3>';
echo '<div class="box-selection">
        <div class="context">
            <ul>
                <li ',($_GET['filtro'] == 'ultimasImagenes' OR empty($_GET['filtro'])) ? 'class="selected first-child"' : '','><a style="font-size:14px" href="',$scripturl,'?action=galeria;filtro=ultimasImagenes">&Uacute;ltimas Im&aacute;genes</a><i class="arrow"></i></li>
                <li ',($_GET['filtro'] == 'puntos') ? 'class="selected first-child"' : '','><a style="font-size:14px" href="',$scripturl,'?action=galeria;filtro=puntos">Con mas Puntos</a><i class="arrow"></i></li>
                <li ',($_GET['filtro'] == 'comentarios') ? 'class="selected first-child"' : '','><a style="font-size:14px" href="',$scripturl,'?action=galeria;filtro=comentarios">Con mas Comentarios</a><i class="arrow"></i></li>
            </ul>
        </div>
     </div>';

/* Publicidad */
	 if($modSettings['act_publi']){
echo '<h3 class="blue" style="margin-left: 10px">Publicidad</h3>';
echo '<div style="margin-left: 9px;">
      ',$modSettings['publi'],'
      </div>';}

echo '</div>';

echo'<div class="left clearfix UltImg">
      <div class="box" style="">
       <div class="box_title">&Uacute;ltimas Im&aacute;genes</div>                             
       <div class="box_cuerpo">           
        <div class="image_gal">';

		if($context['imglist'])
        foreach($context['imglist'] as $img){

    echo'<ul>
          <li class="img"><img src="',$img['url'],'"></li>
          <li>
           <a href="/?action=galeria;imagen=',$img['IDI'],'" class="titgal">',$img['titulo'],'</a>
           <span class="infogal">Creado por: <a href="/?action=profile;user=',$img['nick'],'">',$img['nick'],'</a> hace: ',howlong($img['fecha']),'</span>
          </li>
          ', $img['puntos']>0 ? '<span class="gpoint"><span class="icongal mu">&nbsp;</span> '.$img['puntos'].'</span>' : '' ,'
          ', $img['puntos']<0 ? '<span class="gpointM"><span class="icongal mu">&nbsp;</span> '.str_replace("-","",$img['puntos']).'</span>' : '' ,'
         </ul>';

                                              }
		else
		 echo'<div class="npa">No se han agregado im&aacute;genes.</div>';
		 
        echo'</div>
        
       ',$Paginacion['paginacion'],'
              
       </div>
      </div>
     </div>';

echo'<div class="left clearfix rightGal">
      <div class="box">
       <div class="box_title">&Uacute;ltimos Comentarios</div>                             
       <div class="box_cuerpo">           
        <ul id="last_comments" class="list smallfont">';
        
		if($context['lastcmt'])
         foreach($context['lastcmt'] as $cmt)
         echo'<li><span class="subinfo"><a href="'.$scripturl.'?action=profile;user=',$cmt['nick'],'">',$cmt['nick'],'</a></span> <a href="'.$scriptur.'?action=galeria;imagen=',$cmt['IDI'],'" title="',$cmt['titulo'],'">',$cmt['titulo'],'</a></li>';
        else
		 echo'<div class="npa">No se han agregado comentarios.</div>';
		 
        echo'</ul>              
       </div>
      </div>';

echo'<div class="arrow-box green" style="width:263px;float:left;margin-left:0px;">
      <div class="title"><span><i></i></span><strong>Imagenes de la Semana</strong></div>
			<div class="count-list data list">';
			if($context['topten'])
       foreach($context['topten'] as $top)
	echo'<div class="list-element topten clearfix"><span class="list-number"></span> <img src="'.$settings['images_url'].'/post/icono_109.gif" style="float: left; margin-top: 2px;"> <a  href="',$scripturl,'?action=galeria;imagen=',$top['IDI'],'">',$top['titulo'],'</a> <span class="points">',$top['puntos'],'</span></div>';
            else
			echo'<div class="npa">Nada por aqu&iacute;.</div>';
			
			echo '</div>
		</div>';

echo'</div>';


}


function template_agregar(){

global $context, $txt, $scripturl, $id, $img;

$EN = (int) $_GET['en'];

/* Remove Padding from .globalcontent */
echo '<style type="text/css">

#main .globalcontent{
    padding:0 !important;
}
#scroll-pane {
    display: inline;
    float: left;
    height: 300px;
    margin-bottom: 25px;
    overflow: hidden;
    position: relative;
    width: 240px;
}
#form-category{
position: relative;
}
#scroll-content {position:absolute;top:0;left:0}
.scroll-content-item {background-color:#fcfcfc;color:#003366;width:100px;height:100px;float:left;margin:10px;font-size:3em;line-height:96px;text-align:center;border:1px solid gray;display:inline;}
#slider-wrap{
    float: left;
    margin-left: 7px;
    width: 10px;
}
#slider-vertical{position:relative;height:100%;}

.ui-slider-handle{
    background-color: #CCCCCC;
    border-radius: 15px;
    -moz-border-radius: 15px;
    -webkit-border-radius: 15px;
    display: block;
    height: 10px;
    margin: 0 auto;
    position: absolute;
    width: 10px;
}
.wrap-categories{
margin: 20px 0 0 20px
}

#contimg{width:252px;height:251px;border:1px solid #cccccc;marging:0;padding:0;padding-top:1px}
#ponimg{
width:250px!important;
height:250px!important;
border:1px solid #FFFFFF;
line-height:250px!important;
padding:auto!important;
display:inline!important;}

</style>';


echo'<div class="genericContentAddPost clearfix">

     <form action="',$scripturl,'?action=galeria;sa=agregar2" method="post" accept-charset="', $context['character_set'], '" name="imagenes" id="imagenes" enctype="multipart/form-data">
     <input type="hidden" name="id_img" value="',$img['IDI'],'">
     <input type="hidden" name="oldalbum" value="',$img['album'],'">
     <input type="hidden" name="own" value="',$img['ID_MEMBER'],'">';

echo '<div class="new-post-content left clearfix">
       <div class="box-border-striped">
        <div class="stripes"></div>
        <div class="content">
       <div class="header"><h3>Titulo</h3></div>
       <div class="html-content">
<span class="description">Ingresa el titulo de tu im&aacute;gen. Debe tener entre 5 y 35 caracteres.</span>
<input type="text" name="titulo" class="input-add-post box-shadow-soft"', $img['titulo'] == '' ? '' : ' value="' . $img['titulo'] . '"', ' tabindex="1" size="60" maxlength="54" />
</div>

<div class="header"><h3>Url de la Im&aacute;gen</h3></div>
<div class="html-content form-add-post">
<span class="description">Ingresa el la url de la im&aacute;gen. verifica que la url exista.</span>
<input id="urlimg" type="text" name="url_img" class="input-add-post box-shadow-soft"', $img['url'] == '' ? '' : ' value="' . $img['url'] . '"' ,' tabindex="1" size="60" />


<div class="header"><h3>Descripcion de la Im&aacute;gen</h3></div>
<div class="html-content form-add-post">
<span class="description">Ingresa una breve descripcion de la im&aacute;gen, los BBC no estan permitidos</span>
<textarea class="add-post-textarea box-shadow-soft" name="descripcion">', $img['descripcion'], '</textarea>
</div>
</div>
</div></div>';

echo'<div class="box-border-striped green">
        <div class="stripes"></div>
        <div class="content">

        <div class="header"><h3>Terminaste?</h3></div>
        <div class="html-content clearfix">
        <span class="description">Puedes darle tipos de privacidad a tus Im&aacute;genes para que no todos los usuarios la puedan ver y comentar.</span><hr>
        <div class="left"><ul id="filter-category">';


	
	if (strstr($_SERVER["HTTP_USER_AGENT"], "MSIE"))
	echo'
	<li><input type="radio" tabindex="6" name="privacy" value="0"  ', $img['privacy']==0 ? 'checked' :  '' ,' /> <span>Publico</span></li>
	<li><input type="radio" tabindex="6" name="privacy" value="1"  ', $img['privacy']==1 ? 'checked' : '' ,' /> <span>Privado</span></li>
	<li><input type="radio" tabindex="6" name="privacy" value="2"  ', $img['privacy']==2 ? 'checked' : '' ,' /> <span>Solo Amigos</span></li>
	';
	else
	echo'<li><input type="radio" tabindex="6" name="privacy" id="publico" value="0" class="ui-radio" ', $img['privacy']==0 ? 'checked' :  '' ,' /><label class="ui-radio" for="publico">&nbsp;</label> <span>Publico</span></li>
	     <li><input type="radio" tabindex="6" name="privacy" id="privado" value="1" class="ui-radio" ', $img['privacy']==1 ? 'checked' : '' ,' /><label class="ui-radio" for="privado">&nbsp;</label> <span>Privado</span></li>
	     <li><input type="radio" tabindex="6" name="privacy" id="amigo" value="2" class="ui-radio" ', $img['privacy']==2 ? 'checked' : '' ,' /><label class="ui-radio" for="amigo">&nbsp;</label> <span>Solo Amigos</span></li>';	

        echo '</ul></div>
        <div class="right"><input type="submit" onclick="javascript:verificar(this.form.titulo.value,this.form.url_img.value,this.form.descripcion.value); return false" class="sp-button bluesky" value="', $img['editar'] ? 'Editar' : 'Agregar' ,'" /></div>
        </div>
        </div>
        </div></div>';

echo'<div class="r-add-post-options right clearfix"><div class="protcl-txt">

          <center style="vertical-align:middle"><div id="contimg"><div id="ponimg"></div></div></center>

         <div class="hr"></div>
        <div class="box-border-striped" >
        <div class="content" style="border:none">
        <div class="header"><h3 class="title">Album</h3></div>
        <div class="html-content form-add-post">
        <span class="description">A&ntilde;ade esta imagen a un album</span>
        <select style="width:250px;" name="album" class="input-add-post box-shadow-soft">
         <option value="0" ',$alb['IDA']==$img['album'] ? 'selected' : '' ,' >Ninguno</option>';
         foreach($context['albums'] as $alb)
         echo'<option value="',$alb['IDA'],'" ',$alb['IDA']==$img['album'] ? 'selected' : ( !empty($EN) ? ($EN==$alb['IDA'] ? 'selected' : '') : '') ,' >',$alb['nombre'],'</option>';
   echo'</select>
        </div></div></div></div>';

echo'</div></div></form>';

echo'<div id="lalala"></div>';

echo'<script type="text/javascript">

function verificar(titulo,url,des){


		if(titulo == \'\'){
			alert(\'No has ingresado un Titulo.\');
			return false;
		}
		if(url == \'\'){
			alert(\'No has ingresado una URL.\');
			return false;
		}
                if(desc.length>300){
			alert(\'La descripcion es muy larga.\');
			return false;
		}

}


$(\'#urlimg\').keyup(function() {

  var url = document.imagenes.url_img.value;
  
  var url2 = new Image();
  url2.src = url;
  var wh = \'\';

   if(url2.width>250 || url2.height>250)
   {
      wh = \'width="250px" height="250px"\';
   }  


  $(\'#ponimg\').html(\'<img class="middle" onerror="javascript:ponerror();" src="\'+url2.src+\'" \'+wh+\'>\');  

});


function ponerror(){

 $(\'#ponimg\').html(\'<span style="color:red;font-weight:bold;">La imagen no pudo cargarse.</span>\');  

}

     </script>';

}

function template_agregado(){

 global $context, $scripturl, $url_img, $id, $dueno, $boarddir,$settings, $modSettings;

echo'<div id="errorBox">
<div class="minimal-box">
	<div class="title">
		<h3 class="color-dark-blue">'.$context['titulo'].'</div>
	<div class="content">
       <div class="align-c">
            <div class="info">'.$context['contenido'].'</div><br />
           <div>
                <a class="sp-button green" type="submit" title="Ir a la Galeria" href="'.$scripturl.'/?action=galeria">Ir a la Galeria</a>';

	if(!$context['volver'])			 
   if($context['album'])
    echo'<a class="sp-button blue" type="submit" title="',$txt['go_to_back'],'" href="'.$scripturl.'/?action=galeria;sa=album;id=', $_POST['ida'] ,'">Ir al Album</a>';
   elseif(!empty($context['id'])){
    echo'<a class="sp-button blue" type="submit" title="',$txt['go_to_back'],'" href="'.$scripturl.'/?action=galeria;imagen=',$context['id'],'">Ver la Im&aacute;gen</a>';
}
 
        echo'</div>
       </div>
	            
        <br />
        </center>
	</div>
</div>
</div>';

 //Verificamos si esta activado el uso de Thumbnails
 if($modSettings['thumbnail']){
  if(!empty($url_img) && !empty($id)){
  //Creamos un Thumbnail
  echo'<script>galeria.createThumb("',$url_img,'",',$context['id'],');</script>';
   }
   else{
    //Borramos el Thumbnail
    if(!$context['album'] && !empty($dueno) && !empty($id)){
    unlink($boarddir."/Themes/default/images/galeria/thumbnails/thumb_user".$dueno."-".$id.".jpg");
    
    }
   }
  }

}

function template_display(){
 
 global $context, $txt, $img, $scripturl, $settings, $owner, $nextImg, $prevImg;
 

 echo'<style type="text/css">
      #post-body{ width:600px;text-align:center;padding:10px;}
      .box-border-striped.blue .header h4{color:#4b8bcd;font-size:16px}
      .fecha{border-top:1px dashed #cccccc;width:320px;text-align:right;margin-top:5px;}
      .editar{width:620px;text-align:right;}

    .ui-effects-transfer{
        background: #FFF;
        opacity: 0.5;
        border: 1px dashed #555;
        z-index: 999;
    }
    .preview-thumb a.cross{
        background: url("'.$settings['images_url'].'/cross_gray.png") no-repeat;
        display: none;
        width: 24px;
        height: 24px;
        margin: 12px;
        position: absolute;
        right: 0;
        top: 0;
    }
    .preview-thumb .inner{
        background: #FFF;
        box-shadow: 0 0 7px #CCC;
        display: none;
        border: 1px solid #CCC;
        padding: 6px;
    }
    .preview-thumb .inner img{
        max-width: 950px;
    }
    </style>';
?>

<script>
$(document).ready(function(){

$('a.thumb').click(function(){

       

       $('.preview-thumb').hide().remove();

       var img = new Image();
           img.src = $(this).attr('img-src');

      if(img.width > 950){
          var p = img.width - 950-200;
          img.width = 950;
          img.height = img.height - p;
      }

       var data = {
           height : img.height,
           width : img.width > 950 ? 950 : img.width
       }

       data.top = 100;
       data.left = $(document).width()/2 - data.width/2;
       data.template = $('<div class="preview-thumb"><a class="cross"></a><div class="inner" style="display:none"></div></div>');

       $(data.template).find('.inner').html('<img src="' + img.src + '">');

       $(data.template).css({
           'z-index' : '99',
           'position' : 'absolute',
           'left' : data.left,
           'min-height' : data.height,
           'min-width' : data.width,
           'top' : data.top
       });

       $('body').prepend(data.template);

       var resizeFunc = function(){
           $(data.template).css({
                    'top' : 100,
                    'left' : $(document).width()/2 - $(data.template)[0].offsetWidth/2
               });
       }

       $(this).effect('transfer', { to: $('.inner').parent() }, 500, function(){

           $(data.template).find('.inner').fadeIn('fast', function(){

                if(img.width==950)
                    resizeFunc();

                $(data.template).find('a.cross').stop().show().bind('click', function(){
                    $(data.template).fadeOut(function(){
                        $(this).remove();
                    });
                });
           });

           if(typeof $.scrollTo !== 'undefied')
                $.scrollTo('.preview-thumb', 1000, {offset:-40});
       });
	   
    });
});
</script>
<?php	
	
 
       $link = $scripturl .'?action=galeria;imagen='. $img['IDI'];

 echo'<div class="left cleafix" style="width:619px;border-right:1px dashed #cccccc;">';

 echo'<div class="top-info-post clearfix">';
 
      if(!empty($prevImg))
      echo'<a class="tt-element arrows-post left" title="Imagen Anterior" href="',$scripturl,'?action=galeria&imagen='.$prevImg.'"></a>';
	  if(!empty($nextImg))
	  echo'<a class="tt-element arrows-post right" title="Imagen Siguiente" href="',$scripturl.'?action=galeria&imagen='.$nextImg.'"></a>';

 echo' <div style="text-align:center"><h1 class="title">'.$img['titulo'].'</h1></div> </div>'; 
 
 echo '<div id="post-body"><a title="Agrandar Imagen" id="Agrandar" img-src="'.$img['url'].'" class="tt-element thumb"><img id="imagen" src="'.$img['url'].'" border="0" /></a>
     
	   </div>

      <div class="post-options" style="width:600px">
      <div class="sheets">
      <div class="data clearfix" style="padding: 7px 7px 15px;">
      <div class="title clearfix"><div class="left"><span>Opciones</span></div><div class="right" style="padding-right:10px"><strong>Agregar a:</strong>
        &nbsp;
        <a href="http://www.facebook.com/share.php?u='.$link.'" rel="nofollow" target="_blank" title="',$txt['add_facebook'],'"><img src="',$settings['images_url'],'/icons/facebook.png"></a>
        &nbsp;<a href="http://technorati.com/faves/?add='.$link.'" rel="nofollow" target="_blank" title="',$txt['add_technorati'],'"><img src="',$settings['images_url'],'/icons/technorati.png" style="cursor: pointer;display: inline;"></a>
        &nbsp;<a href="http://del.icio.us/post?url='.$link.'" rel="nofollow" target="_blank" title="',$txt['add_delicio'],'"><img src="',$settings['images_url'],'/icons/delicious.png" style="cursor: pointer;display: inline;"></a>
        &nbsp;<a href="http://digg.com/submit?phase=2&url='.$link.'" rel="nofollow" target="_blank" title="',$txt['add_digg'],'"><img src="',$settings['images_url'],'/icons/digg.png" style="cursor: pointer;display: inline;"></a>
        &nbsp;<a href="http://twitter.com/home?status=Les%20recomiendo%20este%20post:%20'.$link.'" rel="nofollow" target="_blank" title="',$txt['add_twitter'],'"><img src="',$settings['images_url'],'/icons/twitter.png"></a>

      </div></div>
      
      <div class="left" style="width:285px;margin-left: -100px;">';

      echo'<div id="pcont">
           <button class="sp-button red right" style="width: 50px;padding:3px;" onclick="galeria.nomegusta();"><span class="icongal meu">&nbsp;</span></button>
           <button class="sp-button green right" style="width: 110px;padding:3px;" onclick="galeria.megusta();"><span class="icongal mau">&nbsp;</span> Me gusta</button></div>';
      
      echo'</div><div class="right clearfix" style="margin-top:15px;">
      <ul class="data-post">
      <li class="clearfix"><span class="ballon rounded"><strong>'.$img['comentarios'].'</strong><i></i></span><img src="'.$settings['images_url'].'/balloons-box.png" style="margin:0 1px -3px 0"> Comentarios</li>
      <li class="clearfix"><span class="ballon rounded"><strong id="puntosgal">'.$img['puntos'].'</strong><i></i></span><img src="'.$settings['images_url'].'/point.png" style="margin:0 1px -3px 0"> Me gusta</li>
      </ul>
      </div>
      <div class="clear"></div>
      <hr>
      <button class="sp-button" onclick="denuncias.nueva(',$img['IDI'],', 3)"><img src="'.$settings['images_url'].'/flag.png" style="margin-bottom:-2px"> Denunciar</button>'; 
      	  
      if($owner || allowedTo('manage_bans')){
          echo '<fieldset class="descr" style="padding-bottom:0">';
          echo '<legend>Administrar/Moderar</legend>';
          echo '<strong style="display:block">Causa de eliminaci&oacute;n: </strong>
                <form action="', $scripturl,'?action=galeria;sa=borrar" method="post" accept-charset="', $context['character_set'], '" name="causa" id="causa">
                <input type="text" name="causa" style="padding:5px;"> <input type="submit" class="sp-button red" value="Eliminar"> <a href="', $scripturl,'?action=galeria;sa=agregar;id=',$img['IDI'],'"><input type="button" class="sp-button green" value="Editar"></a>
                <input type="hidden" name="id_img" value="',$img['IDI'],'">
                </form>';
          echo '</fieldset>';
      }
      echo '</div>
      <div class="sheets-bottom"><strong></strong><span></span></div>
      </div>
      </div>';

     /****Comentarios****/

 echo'<div class="padding-15" id="all-comments">
      <div class="clearfix"><h3 class="left">'. (int) $img['comentarios'] .' comentarios</h3></div>';
      
      $i = 0;
      echo '<div id="comentarios">';
      foreach($context['comentarios'] as $comment){

          echo '<div class="relative">
              <div class="UI-comment clearfix'.($comment['ID_MEMBER'] == $img['ID_MEMBER'] ? ' author' : ($ID_MEMBER == $comment['ID_MEMBER'] ? ' own' : '') ).'">
                    <div class="author-data">
                        <div class="author-avatar box-shadow-soft"><div class="img"><img src="'.$comment['avatar'].'" class="avatar"></div></div>
                        <div class="nick"><a class="nick" href="'.$scripturl.'?action=profile&u='.$comment['ID_MEMBER'].'">'.$comment['nick'].'</a></div>
                    </div>
                    
                    <div class="comment-data rounded-3 box-shadow-soft" style="width:460px;">
                        <div class="context">
                        <i class="arrow-dialog"></i>
                            <div class="msg">'.$comment['comentario'].'</div>
                        </div>
                        <div class="footer"><img src="'.$settings['images_url'].'/calendar.gif" style="margin: 0 3px -2px 0"> '.$comment['fecha'].'</div>
                   </div>
                </div>
                </div>';

      }
      echo '</div></div>';

      
      if($context['user']['is_guest'])
          echo '<div class="info" style="width:95%;">Para poder comentar debes estar <a rel="registro">registrado</a>. Ya tienes usuario? <a href="'.$scripturl.'?action=login">Logueate!</a></div>';
      else if (empty($context['comentarios']))
          echo '<div class="info no-comments" style="width:95%;">Este post no tiene comentarios. Deseas ser el primero en comentar?</div>';

if(!$context['user']['is_guest'])
      echo '<div class="new-comment clearfix comment-gal">
                <div class="mask-load with-icon"></div>
                <div class="author-data">
                        <div class="author-avatar box-shadow-soft"><div class="img"><img class="avatar" src="'.$context['user']['avatar']['src'].'"></div></div>
                </div>
                <div class="wrap-comment">
                <i class="arrow-dialog"></i>
                <textarea id="gal_markitup" name="comment" class="comment autogrow" style="overflow: hidden; resize: none;" rows="1"></textarea>
                </div>
                <div class="clear"></div>
                <div class="right"><input type="button" class="sp-button" value="Comentar" onclick="galeria.new_comment()"></div>
            </div>';

/* Nuevo Comentario */
?>

<script id="newCommentTmpl" type="text/x-jquery-tmpl">
      <div class="relative" id="comment-${id_comment}" style="display:none">
              <div class="UI-comment clearfix${type_comment}">
                    <div class="author-data">
                        <div class="author-avatar box-shadow-soft"><div class="img"><img src="${avatar}" class="avatar"></div></div>
                        <div class="nick"><a class="nick" href="<?=$scripturl?>?action=profile&u=${id_member}">${nick}</a></div>
                    </div>
                    <div class="comment-data rounded-3 box-shadow-soft" style="width:460px;">
                        <div class="context">
                        <i class="arrow-dialog"></i>
                            <div class="msg">{{html comment}}</div>
                        </div>
                        <div class="footer"><img src="<?=$settings['images_url']?>/calendar.gif" style="margin: 0 3px -2px 0">${time}</div>
                   </div>
                </div>
                </div>
</script>

<?php
/* Fin Nuevo Comentario */

 echo'</div>';

 echo'<div class="left cleafix" style="margin-left:10px;width:340px">

       <h3 class="blue" style="margin-left: 10px">Im&aacute;gen por: </h3>

      <div class="user-profile-post clearfix">
       <div class="left">
        <div class="box-inset white shadow clearfix left">
         <div class="avatar clearfix ">
          <div class="shadow-top-line"></div>
           <img class="user-avatar" src="'.$img['avatar'].'" style="width:100px">
         </div>
        </div>
         <div class="clear"></div>
         <div class="a-nick"><a href="', $scripturl . '?action=profile&u=' . $img['ID_MEMBER'], '" title="Ver Perfil">', $img['nick'], '</a><br /></div>
        
       </div>

       <div class="left">
        <div class="user-info">
                                     <ul class="info-user-post">
                                     <li class="data"><img src="'.$settings['images_url'].'/documents.png" style="margin:0 5px -3px 0"> <strong>', $img['posts'], '</strong> posts</li>
                                     <li class="data puntos"><img src="'.$settings['images_url'].'/point.png" style="margin:0 5px -2px 0"> <strong>', $img['money'], '</strong> puntos</li>
                                     <li class="data comentarios"><img src="'.$settings['images_url'].'/balloons-box.png" style="margin:0 5px -3px 0"> <strong>'.$img['comments'].'</strong> comentarios</li>
                                     <li class="data photos">
									 <a title="Ver Galeria de '.$img['nick']. '" href="'. $scripturl . '?action=galeria;sa=album;user='.$img['ID_MEMBER'].'">
									 <img src="'.$settings['images_url'].'/icons/image.png" style="margin:0 5px -3px 0"> <strong>'.$img['photos'].'</strong> fotos</a></li>
                                     </ul>
       </div>
      </div>

      </div>

       <div class="box-border-striped blue">
        <div class="stripes"></div>
        <div class="content">
         <span style="margin:0;" class="iconpri vacy',$img['privacy'],'" title="Privacidad: ',$img['privacy'] == 0 ? 'p&uacute;blico' : ($img['privacy'] == 1 ? 'privado' : 's&oacute;lo amigos') ,'">&nbsp;</span>
        <div class="header"><h4 class="galtitcut">',$img['titulo'],'</h4></div>
         <div class="html-content clearfix">
          <span class="description">',$img['descripcion'],'
          <div class="fecha">Creado: ',howlong($img['fecha']),'</div><br/>
          ', $img['album']!=0 ? 
           '<img style="vertical-align:middle" src="'.$settings['images_url'].'/galeria/album.png" width="16px" height="16px"> 
            Publicada en el album: <a href="'.$scripturl.'?action=galeria;sa=album;id='.$img['album'].'">'.$img['nombre'].'</a>' : '' ,'<br />
             
          </span>
         
         </div>
        </div>
       </div>

      <div class="box-border-striped green codesin">
        <div class="stripes"></div>
        <div class="content">
         <div class="html-content clearfix"><table cellspacing="0" class="codesa"><tr>
          <td>BBC</td> 
          <td><input onClick="this.select()" type="text" class="input-add-post box-shadow-soft" style="width:260px" value="[img]',$img['url'],'[/img]" /></td>
          </tr><tr>
          <td>HTML</td> 
          <td><input onClick="this.select()" type="text" class="input-add-post box-shadow-soft" style="width:260px" value="', htmlentities('<img src="'.$img['url'].'" />') ,'" /></td>
          </tr><tr>
          <td>URL</td> 
          <td><input onClick="this.select()" type="text" class="input-add-post box-shadow-soft" style="width:260px" value="'.$img['url'].'"/</td></tr></table>
         </div>
        </div>
       </div>

      </div>';

}


function template_crearalbum(){

global $context, $txt, $scripturl, $id, $img,$settings, $alb;

/* Remove Padding from .globalcontent */
echo '<style type="text/css">

#main .globalcontent{
    padding:0 !important;
}
#scroll-pane {
    display: inline;
    float: left;
    height: 300px;
    margin-bottom: 25px;
    overflow: hidden;
    position: relative;
    width: 240px;
}
#form-category{
position: relative;
}
#scroll-content {position:absolute;top:0;left:0}
.scroll-content-item {background-color:#fcfcfc;color:#003366;width:100px;height:100px;float:left;margin:10px;font-size:3em;line-height:96px;text-align:center;border:1px solid gray;display:inline;}
#slider-wrap{
    float: left;
    margin-left: 7px;
    width: 10px;
}
#slider-vertical{position:relative;height:100%;}

.ui-slider-handle{
    background-color: #CCCCCC;
    border-radius: 15px;
    -moz-border-radius: 15px;
    -webkit-border-radius: 15px;
    display: block;
    height: 10px;
    margin: 0 auto;
    position: absolute;
    width: 10px;
}
.wrap-categories{
margin: 20px 0 0 20px
}

#contimg{width:252px;height:251px;border:1px solid #cccccc;marging:0;padding:0;padding-top:1px}
#ponimg{
width:250px!important;
height:250px!important;
border:1px solid #FFFFFF;
line-height:250px!important;
padding:auto!important;
display:inline!important;}
.imgselect{width:200px;}
.oppass{width:30px;margin:10px;vertical-align:middle}
#noalbum,#sialbum{height:150px}
#noalbum .titulo,#sialbum .titulo{font-size:13px;text-align:right;color:#8F8F8F;background:#E6E6E6}
option:focus.titulo{border:1px solid red}
</style>';


echo'<div class="genericContentAddPost clearfix">

     <form action="',$scripturl,'?action=galeria;sa=crearalbum2" method="POST" accept-charset="', $context['character_set'], '" name="album" id="albumform" enctype="multipart/form-data">
     <input type="hidden" name="ida" value="',$alb['IDA'],'">
     <input type="hidden" name="newimg">';

echo '<div class="new-post-content left clearfix">
       <div class="box-border-striped">
        <div class="stripes"></div>
        <div class="content">
       <div class="header"><h3>Nombre</h3></div>
       <div class="html-content">
<span class="description">Ingresa un Nombre para tu Album. Debe tener entre 5 y 35 caracteres.</span>
<input type="text" name="nombre" class="input-add-post box-shadow-soft"', $alb['nombre'] == '' ? '' : ' value="' . $alb['nombre'] . '"', ' tabindex="1" size="60" maxlength="54" />
</div>

<div class="header"><h3>Agregar Im&aacute;genes al Album</h3></div>
<div class="html-content form-add-post">
<span class="description">Ya puedes comenzar a a&ntilde;adir im&aacute;ngenes a tu nuevo Album, esta opcion es opcional.</span>

 <center>
 <select name="noalbum" id="noalbum" size="10" class="imgselect">
 <option class="titulo" value="-1" disabled>Im&aacute;genes sin Album</option>';
 
 if($context['imgensinalbum'])
 foreach($context['imgensinalbum'] as $sin)
 echo'<option id="img',$sin['IDI'],'" value="',$sin['IDI'],'">',$sin['titulo'],'</option>';

echo'</select>
 <span class="oppass">
  <span class="icongal atras" onclick="galeria.imgAlbLeft();">&nbsp;</span>&nbsp;
  <span class="icongal adelante" onclick="galeria.imgAlbRight();">&nbsp;</span>
 </span>
 <select name="sialbum" id="sialbum" size="10" class="imgselect">
 <option class="titulo" value="-1" disabled>Nuevo Album</option>';

 if($context['imgenalbum'])
 foreach($context['imgenalbum'] as $con)
 echo'<option id="img',$con['IDI'],'" value="',$con['IDI'],'">',$con['titulo'],'</option>';

echo'</select>
 </center>
</div>
</div></div>';

echo'<div class="box-border-striped green">
        <div class="stripes"></div>
        <div class="content">

        <div class="header"><h3>Terminaste?</h3></div>
        <div class="html-content clearfix">
        <span class="description">Puedes darle tipos de privacidad a tu Album para que no todos los usuarios la puedan ver.</span><hr>
        <div class="left"><ul id="filter-category">';

	if (strstr($_SERVER["HTTP_USER_AGENT"], "MSIE"))
	echo'
	<li><input type="radio" tabindex="6" name="privacy" value="0"  ', $img['privacy']==0 ? 'checked' :  '' ,' /> <span>Publico</span></li>
	<li><input type="radio" tabindex="6" name="privacy" value="1"  ', $img['privacy']==1 ? 'checked' : '' ,' /> <span>Privado</span></li>
	<li><input type="radio" tabindex="6" name="privacy" value="2"  ', $img['privacy']==2 ? 'checked' : '' ,' /> <span>Solo Amigos</span></li>
	';
	else
	echo'<li><input type="radio" tabindex="6" name="privacy" id="publico" value="0" class="ui-radio" ', $img['privacy']==0 ? 'checked' :  '' ,' /><label class="ui-radio" for="publico">&nbsp;</label> <span>Publico</span></li>
	     <li><input type="radio" tabindex="6" name="privacy" id="privado" value="1" class="ui-radio" ', $img['privacy']==1 ? 'checked' : '' ,' /><label class="ui-radio" for="privado">&nbsp;</label> <span>Privado</span></li>
	     <li><input type="radio" tabindex="6" name="privacy" id="amigo" value="2" class="ui-radio" ', $img['privacy']==2 ? 'checked' : '' ,' /><label class="ui-radio" for="amigo">&nbsp;</label> <span>Solo Amigos</span></li>';	

	
        echo '</ul></div>
        <div class="right"><input type="submit" onclick="javascript:verificar(this.form.nombre.value); return false" class="sp-button bluesky" value="', $alb['editar'] ? 'Editar' : 'Crear' ,'" /></div>
        </div>
        </div>
        </div></div>';

echo'<div class="r-add-post-options right clearfix">

        <h3 class="title">Consejos al crear un Album</h3>
        <div class="protcl-txt">
        <h3 class="title">El Nombre</h3>
        <ul>
        <li><i class="bad"></i> No debe estar en MAYUSCULAS o parcialmente en mayusculas.</li>
        <li><i class="good"></i> Debe ser descriptivo.</li>
        <li><i class="bad"></i> No debe ser EXAGERADO!!!</li>
        </ul>
        </div>
        <div class="protcl-txt">
        <h3 class="title">La Privacidad</h3>
        <ul>
        <li><i class="bad"></i> Podran entrar a tu album solo los que tu elijas.</li>
        <li><i class="bad"></i> Las Im&aacute;genes no dependen de la privacidad del Album.</li>
        </ul>
        </div>

     </div>';

echo'</div></div></form>';


echo'<script type="text/javascript">

function verificar(titulo){


		if(titulo == \'\'){
			alert(\'No has ingresado un Titulo.\');
			return false;
		}


 var opt = "";

 for(var i = 0; i<document.album.sialbum.length;i++)
 {
   if(document.album.sialbum.options[i].value>0){
   if(i+1!=document.album.sialbum.length)
   opt += document.album.sialbum.options[i].value+",";
   else
   opt += document.album.sialbum.options[i].value;

   }
 }


 document.album.newimg.value = opt;
 document.album.submit();

}

     </script>';

}

function template_album(){

global $context, $Album, $db_prefix, $ID_MEMBER, $Member, $pagetitle, $owner;
global $txt, $scripturl, $settings, $fecha_album;

 echo'<style name="Galeria">
      #post-body{ width:600px;text-align:center;padding:10px;}
      .box-border-striped.blue .header h4{color:#4b8bcd;font-size:16px}
      .fecha{border-top:1px dashed #cccccc;width:320px;text-align:right;margin-top:5px;}
      .editar{width:620px;text-align:right;}

      </style>';

 
 echo'<div class="left cleafix" style="width:619px;border-right:1px dashed #cccccc;">';
 
 //Creamos un contenido diferente para un album y otro para todos los albums
 if($Album!=0)
 {
   /* Contenido para un Album en especial */ 

 // El album no tiene Imagenes :o
 if(!$context['images']){
 echo'<div class="info" style="width:95%;height:20px;"><div style="float:left">Este Album no tiene Im&aacute;genes.</div>';
      
      echo'<div style="float:right;">';
      if($owner || allowedTo('manage_bans'))  
      echo'', $owner ? '<a href="'.$scripturl.'?action=galeria;sa=agregar;en='.$Album.'">Agregar Im&aacute;gen</a> - ' : '' ,'<a href="'.$scripturl.'?action=galeria;sa=crearalbum;id='.$Album.'">Administrar</a>  -  <a href="javascript(0);" onClick="galeria.borrarAlbum('.$Album.'); return false;">Borrar</a>';

 echo'</div></div>';
	  
	  
  }
  else{

  //Hay imagenes, entonces las listamos 

  echo'<div class="gal_bar_info">Im&aacute;genes del Album ',$pagetitle,'';
        if($owner || allowedTo('manage_bans'))  
        echo'<div class="right">', $owner ? '<a href="'.$scripturl.'?action=galeria;sa=agregar;en='.$Album.'">Agregar Im&aacute;gen</a> - ' : '' ,'<a href="',$scripturl,'?action=galeria;sa=crearalbum;id=',$Album,'">Administrar</a> -  <a href="javascript(0);" onClick="galeria.borrarAlbum('.$Album.'); return false;">Borrar</a></div>';
  echo'</div>';
  
  echo'<script>
  var body = \'hola\';
  
  </script>';

  echo'<div class="album">';
  $c = 0;

  //Listamos las imagenes del album
  foreach($context['images'] as $img)
  {
    $c++;

     if($c==1)
     echo'<ul>';

echo'<li>
       <a href="',$scripturl,'?action=galeria;imagen=',$img['IDI'],'"><div class="cont_image">
        <div class="imgparse">
         <img onerror="javascript:galeria.imgVacio(this);" src="',$img['url'],'" />
        </div>
       </div>
	   <span class="iconpri vacy',$img['privacy'],'" title="Privacidad de la Im&aacute;gen: ',$img['privacy'] == 0 ? 'P&uacute;blico' : ($img['privacy'] == 1 ? 'Privado' : 'S&oacute;lo amigos') ,'">&nbsp;</span></a> 
     </li>';

    if($c==4){
    echo'</ul>';
    $c=0;}
      
  }

  echo'',$c!=4 ? '</ul>' : '' ,'</div>';
  
  if($context['total_pages']>0){
  echo'<div style="float:left;width:100%;">';
  echo '<strong>P&aacute;ginas:</strong> ' . $context['total_pages'].'<br/>';
  echo '<div class="inset-bar wrap-paginator clearfix">' .$context['paginacion'] . '</div></div>';}

  }

 }
 else{

    /* Contenido de Todos Mis Albums */

  /* Lista de Albums */
  if($context['albums']){

  echo'<div class="gal_bar_info">Albums de ',$Member['nick'];
        if($owner) 
         echo'<div class="right"><a href="',$scripturl,'?action=galeria;sa=crearalbum">Crear Album</a></div>';
  echo'</div>';

  echo'<div class="album">';
  $c = 0;
 
  foreach($context['albums'] as $alb)
  {
    $c++;

     if($c==1)
     echo'<ul>';

echo'<li>
     <a href="',$scripturl,'?action=galeria;sa=album;id=',$alb['IDA'],'">   
      <div class="cont_image vacy',$alb['privacy'],'">
       <div class="cont_image">    
        <div class="imgparse">
         <img onerror="javascript:galeria.imgVacio(this);" 
          src="',empty($context['img_'.$alb['IDA']]['url']) ? $settings['images_url'].'/galeria/vacio.jpg' : $context['img_'.$alb['IDA']]['url'] ,'" />
        </div>
       </div>  
      </div>
      <span class="iconpri vacy',$alb['privacy'],'" title="Privacidad del Album: ',$alb['privacy'] == 0 ? 'P&uacute;blico' : ($alb['privacy'] == 1 ? 'Privado' : 'S&oacute;lo amigos') ,'">&nbsp;</span>
     </a>
      <a href="',$scripturl,'?action=galeria;sa=album;id=',$alb['IDA'],'">',$alb['nombre'],'</a><br />
      <span class="descrip">fotos: ',$alb['cantimg'],'</span>
     
     </li>';

    if($c==4){
    echo'</ul>';
    $c=0;}
      
  }

  echo'',$c!=4 ? '</ul>' : '' ,'</div>';
  }

  /* Lista de Imagenes */
  if($context['imglist']){

  echo'<div class="gal_bar_info">Im&aacute;genes de ',$Member['nick'];
        if($owner) 
         echo'<div class="right"><a href="',$scripturl,'?action=galeria;sa=agregar">Agregar Im&aacute;gen</a></div>';
  echo'</div>';

  echo'<div class="album">';
  $c = 0;

  //Listamos las imagenes que no tienen album
  foreach($context['imglist'] as $img)
  {
    $c++;

     if($c==1)
     echo'<ul>';

echo'<li>
       <a href="',$scripturl,'?action=galeria;imagen=',$img['IDI'],'"><div class="cont_image">
        <div class="imgparse">
         <img onerror="javascript:galeria.imgVacio(this);" src="',$img['url'],'" />
        </div>
       </div>
	   <span class="iconpri vacy',$img['privacy'],'" title="Privacidad de la Im&aacute;gen: ',$img['privacy'] == 0 ? 'P&uacute;blico' : ($img['privacy'] == 1 ? 'Privado' : 'S&oacute;lo amigos') ,'">&nbsp;</span></a> 
     </li>';

    if($c==4){
    echo'</ul>';
    $c=0;}
      
  }

  echo'',$c!=4 ? '</ul>' : '' ,'</div>';
  
  if($context['total_pages']>0){
  echo'<div style="float:left;width:100%;">';
  echo '<strong>P&aacute;ginas:</strong> ' . $context['total_pages'];
  echo '<div class="inset-bar wrap-paginator clearfix">' .$context['paginacion'] . '</div></div>';}

  }
  
  if(!$context['albums'] && !$context['imglist'])
  echo'<div class="info" style="width:95%;"><center>No se encontraron Im&aacute;genes.
      ', $owner ? '<a href="'.$scripturl.'?action=galeria;sa=agregar;en='.$Album.'">Agregar Im&aacute;gen</a>' : '' ,'
      </center></div>';
 }


 echo'</div>';

 /* Info Usuario */ 
 echo'<div class="left cleafix" style="margin-left:10px;width:340px">

      <div class="user-profile-post clearfix">
       <div class="left">
        <div class="box-inset white shadow clearfix left">
         <div class="avatar clearfix ">
          <div class="shadow-top-line"></div>
           <img class="user-avatar" src="'.$Member['avatar'].'" style="width:100px">
         </div>
        </div>
         <div class="clear"></div>
         <div class="a-nick"><a href="', $scripturl . '?action=profile&u=' . $Member['ID_MEMBER'], '" title="Ver Perfil">', $Member['nick'], '</a><br /></div>
        
       </div>

       <div class="left">
        <div class="user-info">
                                     <ul class="info-user-post">
                                     <li class="data"><img src="'.$settings['images_url'].'/documents.png" style="margin:0 5px -3px 0"> <strong>', $Member['posts'], '</strong> posts</li>
                                     <li class="data puntos"><img src="'.$settings['images_url'].'/point.png" style="margin:0 5px -2px 0"> <strong>', $Member['money'], '</strong> puntos</li>
                                     <li class="data comentarios"><img src="'.$settings['images_url'].'/balloons-box.png" style="margin:0 5px -3px 0"> <strong>'.$Member['comments'].'</strong> comentarios</li>
                                     <li class="data photos"><img src="'.$settings['images_url'].'/icons/image.png" style="margin:0 5px -3px 0"> <strong>'.$Member['photos'].'</strong> fotos</li>
                                     </ul>
       </div>
      </div>

      </div>';

   if($context['album'])
   echo'<div class="box-border-striped blue">
        <div class="stripes"></div>
        <div class="content">
         <span style="margin:0;" class="iconpri vacy',$context['album']['privacy'],'" title="Privacidad: ',$context['album']['privacy'] == 0 ? 'p&uacute;blico' : ($context['album']['privacy'] == 1 ? 'privado' : 's&oacute;lo amigos') ,'">&nbsp;</span>
        <div class="header"><h4>',$pagetitle,'</h4></div>
         <div class="html-content clearfix">
          <span class="description">
           <div class="fecha">Creado: ',howlong($fecha_album),'</div><br/>
          </span>
         </div>
        </div>
       </div>';


   echo'</div>';

}

function template_agregado2(){



}

function template_prueba(){

global $context, $sourcedir, $settings, $boarddir;

 
echo'<div id="lalala"></div>';
  echo'<script>
galeria.createThumb("http://3.bp.blogspot.com/-urCNQxOJJiE/TlFqWd9G1GI/AAAAAAAABro/5DPHrVFeqCQ/s1600/space-art-wallpaper-715255%255B1%255D.jpeg",48);</script>';

/*
 echo'<form action="/Sources/Thumbnail.php" method="POST">
      <input type="text" value="asdasd" name="img_url">
      <input type="text" value="1" name="id">
      <input type="submit" value="enviar">    
 
      </form>';
*/


}





?>