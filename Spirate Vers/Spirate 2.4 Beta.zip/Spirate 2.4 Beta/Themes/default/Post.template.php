<?php
/* Spirate 2.4 */
function template_main(){
	global $context, $settings, $options, $txt, $scripturl, $modSettings;

/* Remove Padding from .globalcontent */
echo '<style type="text/css">

#main .globalcontent{
    padding:0 !important;
}
</style>';
echo '<script src="'.$settings['theme_url'].'/slimScroll.min.js" type="text/javascript"></script>';
echo '<script src="'.$settings['theme_url'].'/post.js?upd=0.2" type="text/javascript"></script>';
echo '<div class="genericContentAddPost clearfix">';

echo'
<form action="',$scripturl,'?action=' . $context['destination'] . ';start=0" method="post" accept-charset="', $context['character_set'], '" name="postmodify" id="postmodify" enctype="multipart/form-data">
<input type="hidden" name="topic" value="' . $context['current_topic'] . '" />';

        theme_postbox($context['message']);

echo'<input type="hidden" name="additional_options" value="', $context['show_additional_options'] ? 1 : 0, '" />
<input type="hidden" name="sc" value="', $context['session_id'], '" />
<input type="hidden" name="seqnum" value="', $context['form_sequence_number'], '" />


                    
</div>
</form>';

}

function template_postbox(&$message){
	global $context, $settings, $options, $txt, $modSettings, $db_prefix, $scripturl;

$t = isset($_GET['topic']) ? (int) $_GET['topic'] : '';
if($t){
	$inputs = mysql_query("SELECT p.ID_BOARD,p.hiddenOption,t.isSticky,t.locked
	FROM ({$db_prefix}messages AS p, {$db_prefix}topics AS t)
	WHERE p.ID_TOPIC = '$t'
	AND p.ID_TOPIC = t.ID_TOPIC");
	while($grup = mysql_fetch_assoc($inputs)){
		$context['ID_BOARD'] = $grup['ID_BOARD'];
		$context['hiddenOption'] = $grup['hiddenOption'];
		$context['isSticky'] = $grup['isSticky'];
		$context['locked'] = $grup['locked'];
	}
	mysql_free_result($inputs);
}


echo'<div class="new-post-content left clearfix">';

if(!empty($context['post_error']))
    echo '<div class="error">' . implode('<br>', $context['post_error']['messages']) . '</div>';

echo'<div id="preview"></div>';

echo '<div id="edicion"><div class="box-border-striped">
<div class="stripes"></div>
<div class="content">
<div class="header"><h3>';
		if ((!$context['is_new_post'])){
			echo $context['submit_label'];
		}
		else {
			echo $txt[70];
		}
		echo'</h3></div>
<div class="html-content">
<span class="description">Ingresa el titulo de tu post. Debe tener entre 5 y 35 caracteres.</span>
<input type="text" name="subject" class="input-add-post box-shadow-soft"', $context['subject'] == '' ? '' : ' value="' . $context['subject'] . '"', ' tabindex="1" size="60" maxlength="54" />
</div>

<div class="header"><h3>', $txt['post_message'],'</h3></div>
<div class="html-content form-add-post">
<span class="description">Ingresa el contenido de tu post. recuerda ingresar mas de 60 caracteres.</span>
<textarea id="markItUp" class="add-post-textarea box-shadow-soft" name="', $context['post_box_name'], '">', $message, '</textarea>';

	if(!empty($context['smileys']['postform'])){
		foreach($context['smileys']['postform'] as $smiley_row){
			foreach ($smiley_row['smileys'] as $smiley)
				echo '<a  style="padding-right:4px;" href="javascript:void(0);" onclick="replaceText(\' ', $smiley['code'], '\', document.forms.', $context['post_form'], '.', $context['post_box_name'], '); return false;"><img src="', $settings['smileys_url'], '/', $smiley['filename'], '" align="bottom" alt="', $smiley['description'], '" title="', $smiley['description'], '" /></a>';
		}
	}
	if(!empty($context['smileys']['popup'])){
		echo'<script type="text/javascript">function openpopup(){var winpops=window.open("',$boardurl,'emoticones.php","","width=255px,height=500px,scrollbars");}</script>
		<a href="#" onclick="openpopup(); return false;">[', $txt['more_smileys'], ']</a>';
	}

echo'</div>
</div>
</div>

<div class="box-border-striped orange">
        <div class="stripes"></div>
        <div class="content">

        <div class="header"><h3>Fuentes de informacion</h3></div>
        <div class="html-content">
        <span class="description">Si el contenido del post es de otra pagina, ingresa el o las fuentes ( EJ: <a class="ej-fuente">http://wikipedia.com</a> ). <br/>Recuerda separarlas con coma.</span>
        <div class="input-plus box-shadow-soft"><input type="text" name="link" value="' . $context['link'] . '"></div>
		<div style="margin:5px;"><input type="checkbox" name="miautoria"> La informaci&oacute;n del post es de mi autor&iacute;a, no utilic&eacute; contenido de terceros.</div>
        </div>
        </div>
        </div>

        <div class="box-border-striped green">
        <div class="stripes"></div>
        <div class="content">

        <div class="header"><h3>Terminaste?</h3></div>
        <div class="html-content clearfix">
        <span class="description">'.$txt['remember_view_protocol'].'</span><hr>';
        // razon de edicion, solo para post post ya creados :/
		if(!$context['is_new_post']){
			echo'<span>Raz&oacute;n de la edici&oacute;n: </span><input type="text" name="causa" maxlength="50" size="27" /><hr>';
		}        
        echo'<div class="left">';

		
        // sticky
	if($context['can_sticky']){
		if($context['sticky']){
			echo'<label for="check_sticky"><input type="checkbox" tabindex="6" name="sticky" id="check_sticky" value="0" class="check" />', $txt['delete_sticky'],'</label>';
		}
		else {
			echo'<label for="check_sticky"><input type="checkbox" tabindex="6" name="sticky" id="check_sticky" value="1" class="check" />', $txt['add_sticky'],'</label>';
		}
		
		echo'<br />';
		
	}

	
	// permitir comentarios
	if($context['can_lock']){
		if($context['locked']){
			echo'<label for="check_lock"><input type="checkbox" name="lock" tabindex="8" id="check_lock" value="0" class="check" />', $txt['allow_comments'],'</label>';
		}
		else {
			echo'<label for="check_lock"><input tabindex="8" type="checkbox" name="lock" id="check_lock" value="1" class="check" />', $txt['not_allow_comments'],'</label>';
		}
		
		echo'<br />';
	}
	
	// post privado
	if ($context['hiddenOption']){
		echo'<label for="hiddenOption"><input class="check" type="checkbox" tabindex="9" name="hiddenOption" id="hiddenOption" value="0">', $txt['quit_only_users'],'</label>';
	}
	else {
		echo'<label for="hiddenOption"><input class="check" type="checkbox" tabindex="9" name="hiddenOption" id="hiddenOption" value="1">', $txt['only_users'],'</label>';
	}

       echo'</div><div class="right">';
        if($context['is_new_post']){
        echo'<input type="button" class="preview sp-button bluesky" value="Postear" /> <input type="button" onclick="vprevia(this.form.subject.value, this.form.message.value, this.form);" class="sp-button green" value="Previsualizar" />';}
        else{
        echo'<input type="button" class="preview sp-button bluesky" value="Postear" /> <input class="sp-button green" onclick="vprevia(this.form.subject.value, this.form.message.value, this.form, this.form.causa.value);" style="font-size: 15px;" value="Previsualizar" title="', $txt['preview'],'" type="button" />';	
        }
        echo'</div>
        </div>
        </div>
        </div>
        <input type="text" name="categoria" id="category-from-box" class="hideObj"', !empty($context['ID_BOARD']) ? ' value="' . $context['ID_BOARD'] . '"' : '' ,'>

</div></div>';

echo'<div class="r-add-post-options left clearfix">
<h3 class="title">Consejos al crear un post</h3>
        <div class="protcl-txt">
        <h3 class="title">El titulo</h3>
        <ul>
        <li><i class="bad"></i> No debe estar en MAYUSCULAS o parcialmente en mayusculas.</li>
        <li><i class="good"></i> Debe ser descriptivo.</li>
        <li><i class="bad"></i> No debe ser EXAGERADO!!!</li>
        </ul>
        </div>
        <div class="protcl-txt">
        <h3 class="title">El post no debe tener</h3>
        <ul>
        <li><i class="bad"></i> Informaci&oacute;n personal o de terceros.</li>
        <li><i class="bad"></i> Fotos de personas menores de edad.</li>
        <li><i class="bad"></i> Muertos, sangre, v&oacute;mitos, etc.</li>
        <li><i class="bad"></i> Con contenido racista y/o peyorativo.</li>
        <li><i class="bad"></i> Poca calidad (una imagen, texto pobre).</li>
        <li><i class="bad"></i> Haciendo preguntas o cr&iacute;ticas.</li>
        <li><i class="bad"></i> Con intenci&oacute;n de armar pol&eacute;mica.</li>
        <li><i class="bad"></i> Apolog&iacute;a de delito.</li>
        <li><i class="bad"></i> Software spyware, malware, virus o troyanos.</li>
        </ul>
        </div>

        <div class="hr"></div>
        <h3 class="title">'.$txt['post_category'],'</h3>
        <div class="wrap-categories clearfix">
        <div class="box-categories rounded" style="margin-top:30px height:300px;">
        <ul id="form-category" class="slimScroll ">
        <li></li>
        <li',$context['is_new_post'] ? ' class="selected"' : '' ,'><a val="0" style="padding:0">Selecciona la categoria</a></li>
        ';
	foreach($context['boards'] as $board){
		echo'<li', ( $context['ID_BOARD'] == $board['id'] ) ? ' class="push selected"' : '' ,'><a style="background:url('.$settings['images_url'].'/post/icono_', $board['id'], '.gif) no-repeat top left" val="', $board['id'], '">', $board['name'], '</a></li>';
	}
	echo'<li></li></ul></div></div>';




/*/Opciones/**
echo'
<div style="background: #E7FFE2; border:1px solid #9BFF84; padding:5px;">
	',$txt['options'],'
	<br />
	<br />';
	
	// sticky
	if($context['can_sticky']){
		if($context['sticky']){
			echo'<label for="check_sticky"><input type="checkbox" tabindex="6" name="sticky" id="check_sticky" value="0" class="check" />', $txt['delete_sticky'],'</label>';
		}
		else {
			echo'<label for="check_sticky"><input type="checkbox" tabindex="6" name="sticky" id="check_sticky" value="1" class="check" />', $txt['add_sticky'],'</label>';
		}
	}
	
	echo'<br />';
	
	// permitir comentarios
	if($context['can_lock']){
		if($context['locked']){
			echo'<label for="check_lock"><input type="checkbox" name="lock" tabindex="8" id="check_lock" value="0" class="check" />', $txt['allow_comments'],'</label>';
		}
		else {
			echo'<label for="check_lock"><input tabindex="8" type="checkbox" name="lock" id="check_lock" value="1" class="check" />', $txt['not_allow_comments'],'</label>';
		}
	}
	
	echo'<br />';
	
	// post privado
	if ($context['hiddenOption']){
		echo'<label for="hiddenOption"><input class="check" type="checkbox" tabindex="9" name="hiddenOption" id="hiddenOption" value="0">', $txt['quit_only_users'],'</label>';
	}
	else {
		echo'<label for="hiddenOption"><input class="check" type="checkbox" tabindex="9" name="hiddenOption" id="hiddenOption" value="1">', $txt['only_users'],'</label>';
	}
	
	// razon de edicion, solo para post post ya creados :/
	if(!$context['is_new_post']){
		echo'
		<div style="background: #FFE2E2; border:1px solid #FF8484; padding:5px;width:205px">
			Causa de la edici&oacute;n:</font> <input type="text" name="causa" maxlength="50" size="27" />
		</div>

		<div class="alignC">
			<br /><input onclick="vprevia(this.form.subject.value, this.form.message.value, this.form, this.form.causa.value);" class="button" style="font-size: 15px;" value="Previsualizar" title="', $txt['preview'],'" type="button" />
		</div>
		';
	}
	else {
		echo'
		<div class="alignC">
			<input onclick="vprevia(this.form.subject.value, this.form.message.value, this.form);" class="button" style="font-size: 15px;" value="Previsualizar" title="', $txt['preview'],'" type="button" />
		</div>';
	}
echo'</div><!-- /box de opciones -->';*/
echo'</div>';

echo'<br />';

?>
<script type="text/javascript">
    $('input.preview').click(function(){
        if ($('#markItUp').get(0).view == 'html')
            $('#markItUp').val($.html2bbcode($($('#markItUp').get(0).editor.contentWindow.document.body).html()));
        
        $('#postmodify')[0].submit();
    });
</script>
<?php

//Javascript previsualizar
echo '
<script type="text/javascript">
    function

	function oblig(subject,message,f,causa){
		if(message.length>63206){
			preview.error(\'', $txt['post_way_too_large'],'\');
			return false;
		}
		if(f.categorias.options.selectedIndex==-1 || f.categorias.options[f.categorias.options.selectedIndex].value==-1){
			preview.error(\'', $txt['category_missing'],'\');
			return false;
		}
		if(message == \'\'){
			preview.error(\'', $txt['empty_post'],'\');
			return false;
		}
		if(subject == \'\'){
			preview.error(\'', $txt['empty_title'],'\');
			return false;
		}
        if(message.length<30){
			preview.error(\'', $txt['post_way_too_short'],'\');
			return false;
		}
		if(subject.length<10){
			preview.error(\'', $txt['post_subject_too_short'],'\');
			return false;
		}
		if(f.link.value == \'\' && !f.miautoria.checked){
				preview.error(\'Debes Agregar al menos una fuente de informacion.\');
				return false;
			}
	}
</script>
';

echo'
<script>
function scrollUp(){
		var cs = (document.documentElement && document.documentElement.scrollTop)? document.documentElement : document.body;
		var step = Math.ceil(cs.scrollTop / 10);
		scrollBy(0, (step-(step*2)));
		if(cs.scrollTop>0)
			setTimeout(\'scrollUp()\', 40);
	}
</script>
';

if ((!$context['is_new_post'])){
	echo'
	<script>
	function vprevia(subject,message,f, causa) {
		
            if(causa == \'\'){
				preview.error(\'Debes Ingresar la Causa de la Edicion\');
				return false;
			}
		        if(message.length>63206){
				preview.error(\'', $txt['post_way_too_large'],'\');
				return false;
			}
			
			if(message == \'\'){
				preview.error(\'', $txt['empty_post'],'\');
				return false;
			}

			if(subject == \'\'){
				preview.error(\'', $txt['empty_title'],'\');
				return false;
			}
                        if(message.length<30){
				preview.error(\'', $txt['post_way_too_short'],'\');
				return false;
			}
			if(subject.length<10){
				preview.error(\'', $txt['post_subject_too_short'],'\');
				return false;
			}
			if(f.link.value == \'\' && !f.miautoria.checked){
				preview.error(\'Debes Agregar al menos una fuente de informacion.\');
				return false;
			}

			scrollUp();
        	preview.mostrar(message); 


    }</script>';}
    else
	echo'<script>
		function vprevia(subject,message,f) {

		if(message.length>63206){
				preview.error(\'', $txt['post_way_too_large'],'\');
				return false;
			}
			
			if(message == \'\'){
				preview.error(\'', $txt['empty_post'],'\');
				return false;
			}

			if(subject == \'\'){
				preview.error(\'', $txt['empty_title'],'\');
				return false;
			}
                        if(message.length<30){
				preview.error(\'', $txt['post_way_too_short'],'\');
				return false;
			}
			if(subject.length<10){
				preview.error(\'', $txt['post_subject_too_short'],'\');
				return false;
			}
			if(f.link.value == \'\' && !f.miautoria.checked){
				preview.error(\'Debes Agregar al menos una fuente de informacion.\');
				return false;
			}

			scrollUp();
      		preview.mostrar(message);
            


    }</script>';


}

function template_spellcheck(){}
function template_quotefast(){}
function template_announce(){}
function template_announcement_send(){}
function template_quickreply_box(){}
?>