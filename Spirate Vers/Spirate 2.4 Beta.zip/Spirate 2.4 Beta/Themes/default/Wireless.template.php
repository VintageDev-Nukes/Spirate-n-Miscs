<?php
function template_wap_above(){global $scripturl; Header("Location: $scripturl");}
function template_wap_boardindex(){global $scripturl; Header("Location: $scripturl");}
function template_wap_messageindex(){global $scripturl; Header("Location: $scripturl");}
function template_wap_display(){global $scripturl; Header("Location: $scripturl");}
function template_wap_login(){global $scripturl; Header("Location: $scripturl");}
function template_wap_recent(){global $scripturl; Header("Location: $scripturl");}
function template_wap_error(){global $scripturl; Header("Location: $scripturl");}
function template_wap_below(){global $scripturl; Header("Location: $scripturl");}
function template_imode_above(){global $scripturl; Header("Location: $scripturl");}
function template_imode_boardindex(){global $scripturl; Header("Location: $scripturl");}
function template_imode_messageindex(){global $scripturl; Header("Location: $scripturl");}
function template_imode_display(){global $scripturl; Header("Location: $scripturl");}
function template_imode_post(){global $scripturl; Header("Location: $scripturl");}
function template_imode_login(){global $scripturl; Header("Location: $scripturl");}
function template_imode_pm(){global $scripturl; Header("Location: $scripturl");}
function template_imode_recent(){global $scripturl; Header("Location: $scripturl");}
function template_imode_error(){global $scripturl; Header("Location: $scripturl");}
function template_imode_below(){global $scripturl; Header("Location: $scripturl");}
function template_wap2_above(){global $scripturl; Header("Location: $scripturl");}
function template_wap2_boardindex(){global $scripturl; Header("Location: $scripturl");}
function template_wap2_messageindex(){global $scripturl; Header("Location: $scripturl");}
function template_wap2_login(){global $scripturl; Header("Location: $scripturl");}
function template_wap2_post(){global $scripturl; Header("Location: $scripturl");}
function template_wap2_pm(){global $scripturl; Header("Location: $scripturl");}
function template_wap2_error(){global $scripturl; Header("Location: $scripturl");}
function template_wap2_below(){global $scripturl; Header("Location: $scripturl");}
?>