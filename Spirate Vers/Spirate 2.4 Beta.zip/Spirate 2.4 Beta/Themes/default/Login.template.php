<?php

// Spirate Script - Version 2.4

function template_login()

{

	global $context, $settings, $options, $scripturl, $modSettings, $txt;

echo'



<script language="JavaScript" type="text/javascript" src="', $settings['default_theme_url'], '/sha1.js"></script>



<div id="errorBox">
<div class="minimal-box">
<form action="', $scripturl, '?action=login2" method="post" accept-charset="', $context['character_set'], '" name="frmLogin" id="frmLogin" ', empty($context['disable_login_hashing']) ? ' onsubmit="hashLoginPassword(this, \'' . $context['session_id'] . '\');"' : '', '>
<div class="title"><h3 class="color-dark-red">', $txt[34], '</h3></div>

<div class="content clearfix">
<div class="left">';
echo'<strong>', $txt[35], ':</strong><br>
<div><input type="text" name="user" class="text" size="20" value="', $context['default_username'], '" /></div>
<div><b class="size11">', $txt[36], ':</b></div>
<div><input type="password" name="passwrd" class="text" value="', $context['default_password'], '" size="20" /></div>';
echo '<input type="hidden" name="hash_passwrd" value="" />
<input class="sp-button bluesky" type="submit" value="', $txt[34], '"/>
</div>

<div class="right" style="width:220px; color: #555">
<div>Para acceder a esta &aacute;rea debes loguearte.</div><br>';

if (isset($context['login_error']))
echo '<div class="error">', $context['login_error'], '</div>';

if (isset($context['login_show_undelete']))
    echo '<div class="info"><input type="checkbox" name="undelete" class="check" /> ', $txt['undelete_account'], '</div>';

echo '</div>
<div class="clear"></div>
<div class="align-r">
    <a href="', $scripturl, '?action=reminder">', $txt[315], '</a>
</div>
</div>
</div>
</div><!-- /errorBox -->

</form>

<script language="JavaScript" type="text/javascript">

document.forms.frmLogin.', isset($context['default_username']) && $context['default_username'] != '' ? 'passwrd' : 'user', '.focus();

</script>';



echo'<!-- Small Pirate - Social Community Script -->';

}



// Tell a guest to get lost or login!

function template_kick_guest(){

	template_login();

}



// This is for maintenance mode.

function template_maintenance()

{

	global $context, $settings, $options, $scripturl, $txt, $modSettings;



	// Display the administrator's message at the top.

	echo '

<form action="', $scripturl, '?action=login2" method="post" accept-charset="', $context['character_set'], '">

	<table border="0" width="86%" cellspacing="0" cellpadding="3" class="tborder" align="center">

		<tr class="titlebg">

			<td colspan="2">', $context['title'], '</td>

		</tr><tr>

			<td class="windowbg" width="44" align="center" style="padding: 1ex;">

				<img src="', $settings['images_url'], '/construction.gif" width="40" height="40" alt="', $txt['maintenance3'], '" />

			</td>

			<td class="windowbg">', $context['description'], '</td>

		</tr><tr class="titlebg">

			<td colspan="2">', $txt[114], '</td>

		</tr><tr>';



	// And now all the same basic login stuff from before.

	echo '

			<td colspan="2" class="windowbg">

				<table border="0" width="90%" align="center">

					<tr>

						<td><b>', $txt[35], ':</b></td>

						<td><input class="barradelogear2" id="barradelogear1" type="text" name="user" size="15" /></td>

						<td><b>', $txt[36], ':</b></td>

						<td><input class="barradepass2" id="barradepass1" type="password" name="passwrd" size="10" /> &nbsp;</td>

					</tr><tr>

						<td><b>', $txt[508], ':</b></td>

						<td><input type="checkbox" name="cookieneverexp" class="check" /></td>

					</tr><tr>

						<td align="center" colspan="4"><input class="login" type="submit" value="', $txt[34], '" style="margin-top: 1ex; margin-bottom: 1ex;" /></td>

					</tr>

				</table>

			</td>

		</tr>

	</table>

</form>';

}



// This is for the security stuff - makes administrators login every so often.

function template_admin_login()

{

	global $context, $settings, $options, $scripturl, $txt;



	// Since this should redirect to whatever they were doing, send all the get data.

	echo '

<script language="JavaScript" type="text/javascript" src="', $settings['default_theme_url'], '/sha1.js"></script>



<form action="', $scripturl, $context['get_data'], '" method="post" accept-charset="', $context['character_set'], '" name="frmLogin" id="frmLogin" onsubmit="hashAdminPassword(this, \'', $context['user']['username'], '\', \'', $context['session_id'], '\');">

	<div id="errorBox">
            <div class="minimal-box">

		<div class="title"><h3 class="color-dark-red">', $txt[34], '</h3></div>

		<div class="content clearfix">
                <div class="left">
			<strong>', $txt[36], ': &nbsp;</strong> <input class="barradepass2" id="barradepass1" type="password" name="admin_pass" size="24" /><br />
                        ';



			// Make sure to output all the old post data.

			echo $context['post_data'], '
                        <input type="hidden" name="admin_hash_pass" value="" />
                </div>
                <div class="right" style="width:180px; color: #555">
                <div>Para acceder a esta &aacute;rea debes loguearte.</div>
                <div class="align-r"><input class="sp-button bluesky" type="submit" value="', $txt[34], '" style="margin-top: 2ex;" /></div>
                </div>

		</div>
                </div>
	</div>

</form>';



	// Focus on the password box.

	echo '

<script language="JavaScript" type="text/javascript"><!-- // --><![CDATA[

	document.forms.frmLogin.admin_pass.focus();

// ]]></script>';

}



// Activate your account manually?

function template_retry_activate()

{

	global $context, $settings, $options, $txt, $scripturl;



	// Just ask them for their code so they can try it again...

	echo '

		<br />

		<form action="', $scripturl, '?action=activate;u=', $context['member_id'], '" method="post" accept-charset="', $context['character_set'], '">

			<table border="0" width="600" cellpadding="4" cellspacing="0" class="tborder" align="center">

				<tr class="titlebg">

					<td colspan="2">', $context['page_title'], '</td>';



	// You didn't even have an ID?

	if (empty($context['member_id']))

		echo '

				</tr><tr class="windowbg">

					<td align="right" width="40%">', $txt['invalid_activation_username'], ':</td>

					<td><input type="text" name="user" size="30" /></td>';



	echo '

				</tr><tr class="windowbg">

					<td align="right" width="40%">', $txt['invalid_activation_retry'], ':</td>

					<td><input type="text" name="code" size="30" /></td>

				</tr><tr class="windowbg">

					<td colspan="2" align="center" style="padding: 1ex;"><input class="login" type="submit" value="', $txt['invalid_activation_submit'], '" /></td>

				</tr>

			</table>

		</form>';

}



// Activate your account manually?

function template_resend()

{

	global $context, $settings, $options, $txt, $scripturl;



	// Just ask them for their code so they can try it again...

	echo '

		<br />

		<form action="', $scripturl, '?action=activate;sa=resend" method="post" accept-charset="', $context['character_set'], '">

			<table border="0" width="600" cellpadding="4" cellspacing="0" class="tborder" align="center">

				<tr class="titlebg">

					<td colspan="2">', $context['page_title'], '</td>

				</tr><tr class="windowbg">

					<td align="right" width="40%">', $txt['invalid_activation_username'], ':</td>

					<td><input class="barradelogear2" id="barradelogear1" type="text" name="user" size="40" value="', $context['default_username'], '" /></td>

				</tr><tr class="windowbg">

					<td colspan="2" style="padding-top: 3ex; padding-left: 3ex;">', $txt['invalid_activation_new'], '</td>

				</tr><tr class="windowbg">

					<td align="right" width="40%">', $txt['invalid_activation_new_email'], ':</td>

					<td><input type="text" name="new_email" size="40" /></td>

				</tr><tr class="windowbg">

					<td align="right" width="40%">', $txt['invalid_activation_password'], ':</td>

					<td><input class="barradepass2" id="barradepass1" type="password" name="passwd" size="30" /></td>

				</tr><tr class="windowbg">';



	if ($context['can_activate'])

		echo '

					<td colspan="2" style="padding-top: 3ex; padding-left: 3ex;">', $txt['invalid_activation_known'], '</td>

				</tr><tr class="windowbg">

					<td align="right" width="40%">', $txt['invalid_activation_retry'], ':</td>

					<td><input type="text" name="code" size="30" /></td>

				</tr><tr class="windowbg">';



	echo '

					<td colspan="2" align="center" style="padding: 1ex;"><input class="login" type="submit" value="', $txt['invalid_activation_resend'], '" /></td>

				</tr>

			</table>

		</form>';

}



?>