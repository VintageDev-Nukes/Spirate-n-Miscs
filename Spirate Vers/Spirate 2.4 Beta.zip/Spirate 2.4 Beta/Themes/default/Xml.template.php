<?php
function template_quotefast(){}
function template_modifyfast(){}
function template_modifydone(){}
function template_modifytopicdone(){}
function template_post(){}
function template_stats(){}
function template_split(){}
function template_button_strip(){}
function template_menu(){}
function theme_linktree(){}
function template_generic_xml(){}
?>