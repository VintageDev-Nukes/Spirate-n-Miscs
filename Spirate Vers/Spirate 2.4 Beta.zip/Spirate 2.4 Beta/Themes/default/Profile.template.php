<?php
// Spirate Script - Version 2.4


function template_OP_perfil(){

global $context, $settings, $options, $scripturl, $modSettings, $txt, $Opcion;

 global $context, $settings, $options, $scripturl, $modSettings, $txt, $db_prefix;
  

echo'<form action="', $scripturl, '?action=profile2" method="post" accept-charset="UTF-8" name="creator" id="creator" enctype="multipart/form-data">';

     echo'<div class="op_item">
         <span class="titulo">', $txt[563], '</span>
       <span class="cont">
        <input class="padding5 stream-content with-placeholder rounded" type="text" name="bday2" size="2" maxlength="2" value="', $context['member']['birth_date']['day'], '" />
      <input class="padding5 stream-content with-placeholder rounded" type="text" name="bday1" size="2" maxlength="2" value="', $context['member']['birth_date']['month'], '" />
      <input class="padding5 stream-content with-placeholder rounded" type="text" name="bday3" size="4" maxlength="4" value="', $context['member']['birth_date']['year'], '" />
       </span>
      </div>';
      
     echo'<div class="op_item">
         <span class="titulo">',$txt['country'],'</span>
       <span class="cont">
       <select name="usertitle" id="usertitle">
						<option value="' . $context['member']['title'] . '">',nombre_pais($context['member']['title']),'</option>';
						foreach($context['paises'] as $p)
							echo'<option value="',$p['ID_PAIS'],'" ', ($context['member']['title'] == $p['ID_PAIS'] ? ' selected="selected"' : ''), '>',$p['nombre'],'</option>';
					echo'
					</select>
       </span>
      </div>';
/*      
   echo'<div class="op_item">
         <span class="titulo">', $txt[227], '</span>
       <span class="cont">
        <input class="padding5 stream-content with-placeholder rounded" type="text" name="location" size="44" value="', $context['member']['location'], '" />
       </span>
      </div>';  
  */
     echo'<div class="op_item">
         <span class="titulo">', $txt[231], '</span>
       <span class="cont">
        <select name="gender" size="1">
            <option value="1"', ($context['member']['gender']['name'] == 'm' ? ' selected="selected"' : ''), '>', $txt[238], '</option>
            <option value="2" ', ($context['member']['gender']['name'] == 'f' ? ' selected="selected"' : ''), '>', $txt[239], '</option>
        </select>
       </span>
      </div>';
      
   echo'<div class="op_item">
         <span class="titulo">', $txt[228], '<div class="smalltext">',$txt['under_avatar'],'</div></span>
       <span class="cont">
        <input class="padding5 stream-content with-placeholder rounded" type="text" name="personalText" size=44" maxlength="70" value="', $context['member']['blurb'], '" />
       </span>
      </div>';  
    /*
     echo'<div class="op_item">
         <span class="titulo">', $txt['MSN'], '<div class="smalltext">', $txt['smf237'], '</div></span>
       <span class="cont">
        <input class="padding5 stream-content with-placeholder rounded" type="text" name="MSN" value="', $context['member']['msn']['name'], '" size="44" />
       </span>
      </div>';

     echo'<div class="op_item">
         <span class="titulo">Pagina Web</span>
       <span class="cont">
        <input class="padding5 stream-content with-placeholder rounded" type="text" name="websiteTitle" size="44" value="', $context['member']['website']['title'], '" />
       </span>
      </div>';*/
  
     echo'<div class="op_item">
         <span class="titulo">Mostrarme Online?</span>
       <span class="cont">
        Si <input type="radio" name="showOnline" value="1" ', ($context['member']['show_online'] == '1' ? ' checked="checked"' : ''), '>
      &nbsp;&nbsp;&nbsp;No <input type="radio" name="showOnline" value="0" ', ($context['member']['show_online'] == '0' ? ' checked="checked"' : ''), '>
       </span>
      </div>';
      
      template_profile_save();


  if (!empty($context['member']['avatar']['allow_server_stored']))
    echo '
      <script language="JavaScript" type="text/javascript"><!-- // --><![CDATA[
        var files = ["' . implode('", "', $context['avatar_list']) . '"];
        var avatar = document.getElementById("avatar");
        var cat = document.getElementById("cat");
        var selavatar = "' . $context['avatar_selected'] . '";
        var avatardir = "' . $modSettings['avatar_url'] . '/";
        var size = avatar.alt.substr(3, 2) + " " + avatar.alt.substr(0, 2) + String.fromCharCode(117, 98, 116);
        var file = document.getElementById("file");

        if (avatar.src.indexOf("blank.gif") > -1)
          changeSel(selavatar);
        else
          previewExternalAvatar(avatar.src)

        function changeSel(selected)
        {
          if (cat.selectedIndex == -1)
            return;

          if (cat.options[cat.selectedIndex].value.indexOf("/") > 0)
          {
            var i;
            var count = 0;

            file.style.display = "inline";
            file.disabled = false;

            for (i = file.length; i >= 0; i = i - 1)
              file.options[i] = null;

            for (i = 0; i < files.length; i++)
              if (files[i].indexOf(cat.options[cat.selectedIndex].value) == 0)
              {
                var filename = files[i].substr(files[i].indexOf("/") + 1);
                var showFilename = filename.substr(0, filename.lastIndexOf("."));
                showFilename = showFilename.replace(/[_]/g, " ");

                file.options[count] = new Option(showFilename, files[i]);

                if (filename == selected)
                {
                  if (file.options.defaultSelected)
                    file.options[count].defaultSelected = true;
                  else
                    file.options[count].selected = true;
                }

                count++;
              }

            if (file.selectedIndex == -1 && file.options[0])
              file.options[0].selected = true;

            showAvatar();
          }
          else
          {
            file.style.display = "none";
            file.disabled = true;
            document.getElementById("avatar").src = avatardir + cat.options[cat.selectedIndex].value;
            document.getElementById("avatar").style.width = "";
            document.getElementById("avatar").style.height = "";
          }
        }

        function showAvatar()
        {
          if (file.selectedIndex == -1)
            return;

          document.getElementById("avatar").src = avatardir + file.options[file.selectedIndex].value;
          document.getElementById("avatar").alt = file.options[file.selectedIndex].text;
          document.getElementById("avatar").alt += file.options[file.selectedIndex].text == size ? "!" : "";
          document.getElementById("avatar").style.width = "";
          document.getElementById("avatar").style.height = "";
        }

        function previewExternalAvatar(src)
        {
          if (!document.getElementById("avatar"))
            return;

          var maxHeight = ', !empty($modSettings['avatar_max_height_external']) ? $modSettings['avatar_max_height_external'] : 0, ';
          var maxWidth = ', !empty($modSettings['avatar_max_width_external']) ? $modSettings['avatar_max_width_external'] : 0, ';
          var tempImage = new Image();

          tempImage.src = src;
          if (maxWidth != 0 && tempImage.width > maxWidth)
          {
            document.getElementById("avatar").style.height = parseInt((maxWidth * tempImage.height) / tempImage.width) + "px";
            document.getElementById("avatar").style.width = maxWidth + "px";
          }
          else if (maxHeight != 0 && tempImage.height > maxHeight)
          {
            document.getElementById("avatar").style.width = parseInt((maxHeight * tempImage.width) / tempImage.height) + "px";
            document.getElementById("avatar").style.height = maxHeight + "px";
          }
          document.getElementById("avatar").src = src;
        }
      // ]]></script>';
echo'</form>';

}

function template_OP_cuenta(){

global $context, $settings, $options, $scripturl, $modSettings, $txt, $Opcion;

 echo'<form action="', $scripturl, '?action=profile2" method="post" accept-charset="UTF-8" name="creator" id="creator" enctype="multipart/form-data">';
 
 if($context['allow_edit_account'])
  {
      echo'<div class="op_item">
          <span class="titulo">Nombre<div class="smalltext">Nombre y/o Apellido que se mostrara en el Perfil</div></span>
        <span class="cont"><input class="padding5 stream-content with-placeholder rounded" type="text" name="nombre" size="44" value="', $context['member']['nombre'], '" /></span></div>';
      
      echo'<div class="op_item">';
    if($context['user']['is_admin'] && !empty($context['allow_edit_username']))
     echo'', $txt['username_warning'], ' ', $txt[35], '</br>
        <input class="padding5 stream-content with-placeholder rounded" type="text" name="memberName" size="30" value="', $context['member']['username'], '" />';
    else
       echo '', $context['user']['is_admin'] ? '<span class="titulo">'.$txt['user_name'].'</span><span class="cont">'. $context['member']['username']. ' <a href="'.$scripturl.'?action=profile;u=' . $context['member']['id'] . ';sa=cuenta;changeusername" style="font-style: italic;">' . $txt['username_change'] . '</a></span>' : '', '';

    echo'</div>';
    
  }
  
  
 if($context['allow_edit_membergroups'])
  {
    echo'<div class="op_item">
          <span class="titulo">', $txt['primary_membergroup'], '</span>
        <span class="cont"><select name="ID_GROUP">';
    foreach($context['member_groups'] as $member_group)
      echo '<option value="', $member_group['id'], '"', $member_group['is_primary'] ? ' selected="selected"' : '', '>
           ', $member_group['name'], '
          </option>';
    echo '</select></span></div>
    <div class="op_item">
     <span class="titulo">', $txt['additional_membergroups'], '</span>
     <span class="cont"><div id="additionalGroupsList"><input type="hidden" name="additionalGroups[]" value="0" />';
  
    foreach ($context['member_groups'] as $member_group)
      if ($member_group['can_be_additional'])
        echo '<label for="additionalGroups-', $member_group['id'], '"><input type="checkbox" name="additionalGroups[]" value="', $member_group['id'], '" id="additionalGroups-', $member_group['id'], '"', $member_group['is_additional'] ? ' checked="checked"' : '', ' class="check" /> ', $member_group['name'], '</label>';
    
    echo'</div><a href="javascript:void(0);" onclick="document.getElementById(\'additionalGroupsList\').style.display = \'block\'; document.getElementById(\'additionalGroupsLink\').style.display = \'none\'; return false;" id="additionalGroupsLink" style="display: none;">', $txt['additional_membergroups_show'], '</a>
        <script language="JavaScript" type="text/javascript"><!-- // --><![CDATA[
         document.getElementById("additionalGroupsList").style.display = "none";
         document.getElementById("additionalGroupsLink").style.display = "";
        // ]]></script>
        </span></div>';
  }

 if($context['allow_edit_account'])
  {
  
    echo'<div class="op_item">
          <span class="titulo">', $txt[69], '<div class="smalltext">', $txt[679], '</div></span>
        <span class="cont"><input class="padding5 stream-content with-placeholder rounded" type="text" name="emailAddress" size="44" value="', $context['member']['email'], '" /></span></div>';
                        
    
    echo '<div class="op_item">
           <span class="titulo">', $txt['pswd1'], '<div class="smalltext">', $txt['secret_desc'], '</div></span>
         <span class="cont"><input class="padding5 stream-content with-placeholder rounded" type="text" name="secretQuestion" size="44" value="', $context['member']['secret_question'], '" /></span>
        </div>
        <div class="op_item">     
         <span class="titulo">', $txt['pswd2'], ':<div class="smalltext">', $txt['secret_desc2'], '</div></span>
         <span class="cont"><input class="padding5 stream-content with-placeholder rounded" type="text" name="secretAnswer" size="44" /><span class="smalltext" style="margin-left: 4ex;"></span>
        </div>';
  }
  
  template_profile_save();
  
 echo'</form>';

}

function template_OP_privacidad(){

global $context, $settings, $options, $scripturl, $modSettings, $txt, $Opcion, $Privacy, $user_id;

 echo'<form action="', $scripturl, '?action=profile&sa=cuenta&op=privacidad&u='.$context['member']['id'].'" method="post" accept-charset="UTF-8" name="creator" id="creator" enctype="multipart/form-data">';
 
 /* Esto hay que hacerlo con variables del smf_privacy
 if($context['allow_edit_account'])
  {
    if ($context['allow_hide_email'])
    {
     echo'<div class="op_item">
           <span class="titulo">', $txt[721], '<div class="smalltext">',$txt['no_email_public'],'</div></span>
         <span class="cont"><input type="hidden" name="hideEmail" value="0" /><input type="checkbox" name="hideEmail"', $context['member']['hide_email'] ? ' checked="checked"' : '', ' value="1" class="check" />
         </span>
        </div>';
      }
    
    }*/

  echo'<div class="op_item">
         <span class="op_headings"><img src="'.$settings['images_url'].'/pglobe.png""> Privacidad del stream</span>
      </div><div class="op_pcont">';
  foreach($Privacy['stream'] as $pry)
  {
   echo'<div class="op_item">
         <span class="titulo">',$txt[$pry['name']],'</span>
       <span class="cont">
        <input type="checkbox" name="'.$pry['name'].'" ',$pry['value'] ? 'checked' : '' ,'/>
       </span>
      </div>';
  }
echo'</div><div class="op_item">
         <span class="op_headings"><img src="'.$settings['images_url'].'/ui-stream-eye-icon.png""> Privacidad del perfil al p&uacute;blico</span>
      </div><div class="op_pcont">';
  foreach($Privacy['profile'] as $pry)
  {
   echo'<div class="op_item">
         <span class="titulo">',$txt[$pry['name']],'</span>
       <span class="cont">
        <input type="checkbox" name="'.$pry['name'].'" ',$pry['value'] ? 'checked' : '' ,'/>
       </span>
      </div>';
  }
echo'</div><div class="op_item">
         <span class="op_headings"><img src="'.$settings['images_url'].'/msn.png""> Privacidad del perfil a tus seguidores</span>
      </div><div class="op_pcont">';

   foreach($Privacy['followers'] as $pry)
  {
   echo'<div class="op_item">
         <span class="titulo">',$txt[$pry['name']],'</span>
       <span class="cont">
        <input type="checkbox" name="'.$pry['name'].'" ',$pry['value'] ? 'checked' : '' ,'/>
       </span>
      </div>';
  }
  
  echo'</div><div class="configBloqs" style="float:right;"><input class="sp-button bluesky"  type="submit" value="',$txt['save_changes'],'" /></div>
        <input type="hidden" name="save" value="1" />
       </form>';
  
  /*echo'<div class="op_item">
         <span class="titulo"></span>
       <span class="cont">
       
       </span>
      </div>';*/

}



function template_OP_avatar(){

global $context, $settings, $options, $scripturl, $modSettings, $txt, $Opcion;

     echo'<form action="', $scripturl, '?action=profile2" method="post" accept-charset="UTF-8" name="creator" id="creator" enctype="multipart/form-data">';
  
   echo'<div class="op_item">
         <span class="titulo">', $txt[475], '</span>
       <span class="cont">
        <input class="padding5 stream-content with-placeholder rounded" type="text" name="avatar" size="44" value="', $context['member']['avatar'], '"  onchange="if (typeof(previewExternalAvatar) != \'undefined\') load_new_avatar();" />
       </span>
      </div>';
  

     echo'<div class="op_item">
         <span class="titulo">', $txt[229], '</span>
       <span class="cont">
        <div style="width: auto;">
        <img name="avatar" style="margin: 10px;padding:10px;max-width:100px;max-height:100px;" id="avatar" src="', $context['member']['avatar'], '" alt="Do Nothing" />
        <b', (isset($context['modify_error']['bad_avatar']) ? ' style="color: red;"' : ''), '><label for="avatar_choice_server_stored"></label></b>
        </div>
       </span>
      </div>';
              
    template_profile_save();
      
  echo'<script>
function load_new_avatar()
{
  var f=document.forms.per;

  if(f.avatar.value.substring(0, 7)!="http://")
  {
    f.avatar.focus();
    alert("',$txt['alert_http'],'");
    return;
  }

  window.newAvatar = new Image();
  window.newAvatar.src = f.avatar.value;
  newAvatar.loadBeginTime = (new Date()).getTime();
  newAvatar.onerror = show_error;
  newAvatar.onload = show_new_avatar;
  avatar_check_timeout();
}

function avatar_check_timeout()
{
  if(((new Date()).getTime()-newAvatar.loadBeginTime)>15)
  {
    alert("',$txt['alert_avatar'],'");
    document.forms.per.avatar.focus();
  }
}

function show_error()
{
  alert("',$txt['alert_dir_image'],'");
  document.forms.per.avatar.focus();
}

function show_new_avatar()
{
  document.getElementById("miAvatar").src = newAvatar.src;
}
</script>'; 
  
  echo '</form>';

}

function profile_head($nav){

  global $context, $settings, $options, $scripturl, $modSettings, $txt, $db_prefix, $ID_MEMBER;
    echo '<style type="text/css">
    #main .globalcontent{
        padding:0;
    }
    .ui-effects-transfer{
        background: #FFF;
        opacity: 0.5;
        border: 1px dashed #555;
        z-index: 999;
    }
    .preview-thumb a.cross{
        background: url("'.$settings['images_url'].'/cross_gray.png") no-repeat;
        display: none;
        width: 24px;
        height: 24px;
        margin: 12px;
        position: absolute;
        right: 0;
        top: 0;
    }
    .preview-thumb .inner{
        background: #FFF;
        box-shadow: 0 0 7px #CCC;
        display: none;
        border: 1px solid #CCC;
        padding: 6px;
    }
    .preview-thumb .inner img{
        max-width: 950px;
    }
    </style>';
?>
<script type="text/javascript" src="<?=$settings['theme_url']?>/jquery.Jcrop.min.js"></script>
<script type="text/javascript">
var coordsthumbnail = '';
var sizeImgToThumb;

$(document).ready(function(){
sizeImgToThumb = [$('#jcrop_target').width(), $('#jcrop_target').height()]; // W x H

$('#run_jcrop').click(function(){
var jcropCall = $.Jcrop('#jcrop_target', {
                        onChange: showPreview,
                        onSelect: showPreview,
                        aspectRatio: 1,
                        minSize : [48, 48]
                });
var coords = [sizeImgToThumb[0]/2-24, sizeImgToThumb[1]/2+24, sizeImgToThumb[0]/2-24, sizeImgToThumb[1]/2-24];
jcropCall.animateTo([ coords[0], coords[1], coords[2], coords[3] ]);
});

function showPreview(coords){

    
  var rx = 48 / coords.w;
  var ry = 48 / coords.h;

        var rx2 = 120 / coords.w,
            ry2 = 120 / coords.h;
        
        
        coordsthumbnail = implode(', ', coords)
        
  $('#thumbnail_target').css({
    width: Math.round(rx * sizeImgToThumb[0]) + 'px',
    height: Math.round(ry * sizeImgToThumb[1]) + 'px',
    marginLeft: '-' + Math.round(rx * coords.x) + 'px',
    marginTop: '-' + Math.round(ry * coords.y) + 'px'
  });

        $('#thumbnail_target2').css({
    width: Math.round(rx2 * sizeImgToThumb[0]) + 'px',
    height: Math.round(ry2 * sizeImgToThumb[1]) + 'px',
    marginLeft: '-' + Math.round(rx2 * coords.x) + 'px',
    marginTop: '-' + Math.round(ry2 * coords.y) + 'px'
  });


        $('#_x').val(coords.x);
        $('#_y').val(coords.y);
        $('#_w').val(coords.w);
        $('#_h').val(coords.h);
        $('#_tw').val(sizeImgToThumb[0]);
        $('#_th').val(sizeImgToThumb[1]);

};

$('a.thumb').click(function(){

       $('.preview-thumb').hide().remove();

       var img = new Image();
           img.src = $(this).attr('img-src');

      if(img.width > 950){
          var p = img.width - 950-200;
          img.width = 950;
          img.height = img.height - p;
      }

       var data = {
           height : img.height,
           width : img.width > 950 ? 950 : img.width
       }

       data.top = $(document).height()/2 - data.height/2;
       data.left = $(document).width()/2 - data.width/2;
       data.template = $('<div class="preview-thumb"><a class="cross"></a><div class="inner" style="display:none"></div></div>');

       $(data.template).find('.inner').html('<img src="' + img.src + '">');

       $(data.template).css({
           'z-index' : '99',
           'position' : 'absolute',
           'left' : data.left,
           'min-height' : data.height,
           'min-width' : data.width,
           'top' : data.top
       });

       $('body').prepend(data.template);

       var resizeFunc = function(){
           $(data.template).css({
                    'top' : $(document).height()/2 - $(data.template).find('.inner img')[0].offsetHeight/2,
                    'left' : $(document).width()/2 - $(data.template)[0].offsetWidth/2
               });
       }

       $(this).effect('transfer', { to: $('.inner').parent() }, 500, function(){

           $(data.template).find('.inner').fadeIn('fast', function(){

                if(img.width==950)
                    resizeFunc();

                $(data.template).find('a.cross').stop().show().bind('click', function(){
                    $(data.template).fadeOut(function(){
                        $(this).remove();
                    });
                });
           });

           if(typeof $.scrollTo !== 'undefied')
                $.scrollTo('.preview-thumb', 1000, {offset:-40});
       });
    });
});

</script>
<?php
 $idu = $context['member']['id'];

if($context['user']['is_logged'])
    $allow_edit = allowedTo('moderate_forum') || $context['user']['is_owner'];

    else
    $allow_edit = false; 

 define('TOOLTIP', '<div class="nano-tooltips clearfix left" style="position: absolute; top: -19px; left: 4px;"><span class="izq"></span><span class="text">Denunciaste al usuario</span><span class="der"></span></div>');

$allow_mod = allowedTo('moderate_forum');

echo '<div class="info-profile clearfix">';

     if($context['user']['is_logged'] && !$context['user']['is_owner']){
    echo '<div class="absolute" style="left:160px; bottom:0px"><div class="data-profile inset rounded">';
    
    if( $context['member']['is_followed'] )
      echo '<input class="sp-button red no-shadow" type="button" onclick="unfollow_u(this, '.$context['member']['id'].', \'profile\')" value="Dejar de seguir">';
    else
    echo '<input class="sp-button green no-shadow" type="button" onclick="follow_u(this, '.$context['member']['id'].', \'profile\')" value="Seguir usuario">';
    

    echo '
    </div></div>';
    }
echo '
    <div class="left">
    <div class="wrap-avatar rounded">
        <div class="avatar_thumbnail">
            <img class="avatar rounded" src="'.$context['member']['avatar']['src'].'" style="'.$context['member']['avatar']['coords'][120]['style'].'">
        </div>
    </div>

    </div>
    <div class="left" style="width:270px;"><span class="profile-nick">'.ucwords($context['member']['name']).' <img src="'.$settings['images_url'].'/' . $context['member']['online']['image_href'] . '.png" style="margin-bottom:-3px"></span>
    <div class="personal-message"><div style="width:240px;overflow:auto;" id="personal-message">'.($context['info']['estado'] ? $context['info']['estado'] : '...').'</div><span class="arrow"></span></div>
    <div style="margin-top:4px;margin-left:4px;">'.($allow_edit ? '<a style="color:#58ACFA;" href="javascript:profile.changestatus('.$idu.');">Editar Estado</a>' : '').'</div>
    </div>
    <div class="left resume-profile clearfix">';

    if(empty($context['info']['trabajo']))
      $context['info']['trabajo'] = "No especificado";
    if(empty($context['info']['estudios']))
      $context['info']['estudios'] = "No especificado";
    if(empty($context['info']['situacion']))
      $context['info']['situacion'] = "No especificado";

	if($context['member']['gender']['name'] == 'Femenino'){
		$icon = 'female';
	}
	else{
	$icon = 'male';
	}
    $resume = array(
        'age' => array('value' => $context['member']['age'], 'img' => ''.$settings['images_url'].'/Balloons_.png', 'txt' => sprintf('Tiene <strong>%d</strong> años', $context['member']['age'])),
        'gender' => array('value' => true, 'img' => ''.$settings['images_url'].'/_'.$icon.'_.png', 'txt' =>  $context['member']['gender']['name']),
        'work' => array('value' => true, 'img' => ''.$settings['images_url'].'/companies_.png', 'txt' => sprintf('Trabaja en <strong>%s</strong>', recortar_texto($context['info']['trabajo'], 20))),
        'studies' => array('value' => true, 'img' => ''.$settings['images_url'].'/school_.png', 'txt' => sprintf(' Estudio en <strong>%s</strong>', recortar_texto($context['info']['estudios'], 20))),
        'location' => array('value' => true, 'img' => ''.$settings['images_url'].'/home_.png', 'txt' => sprintf('Vive en <strong>%s</strong>', $context['member']['country']['name'])),
        'relationship' => array('value' => true, 'img' => ''.$settings['images_url'].'/Love_.png', 'txt' => sprintf('Actualmente está <strong>%s</strong>', recortar_texto($context['info']['situacion'], 20))),
    );


    echo'<ul>';
    foreach($resume as $k => $info)
        if($info['value'])
            echo '<li><span class="resume-item"><i class="icon" style="display: inline-block; float:none; margin:0 5px 0 0; width: 16px; background:url('.$info['img'] . ') left 4px no-repeat"></i><span class="resume-item">' . $info['txt'] . '</span></span></li>';
     echo'</ul>';   
    if($context['info']['web']){echo '<div style="margin-top:10px"><img style="margin:0 0px -4px 0" src="'.$settings['images_url'].'/link_.png"> <a>'.$context['info']['web'].'</a></div>';}
    echo'</div>
    <div class="right" style="margin:5px 0 0 20px; width:200px;">
    <div class="pright" style="width:100%;"><strong style="font-size:16px;">'.(!empty($context['member']['group']) ? $context['member']['group'] : $context['member']['post_group']).'</strong></div>
    <div class="pright" style="width:100%;"><span>'.$context['member']['total']['comments'].'</span>&nbsp;<strong>Comentarios</strong></div>
    <div class="pright" style="width:100%;"><span>'.$context['profile']['posts'].'</span>&nbsp;<strong>Posts</strong></div>
    <div class="pright" style="width:100%;"><span>'.$context['member']['money'].'</span>&nbsp;<strong>Puntos</strong></div>
    <div class="pright" style="width:100%;"><span>'.$context['profile']['fotos'].'</span>&nbsp;<strong>Fotos</strong></div>

    </div>

    </div>';

    echo'
      <div class="profile-content-tabs clearfix">
      '; define('FLAGED', '<div class="nano-tooltips black clearfix left" style="position: absolute; top: -22px; left: 4px;"><span class="izq"></span><span class="text">Denunciaste al usuario</span><span class="der"></span></div>');
          
        if(!$context['user']['is_owner'] && $context['user']['is_logged']){
          if($context['info']['flagged']){
            echo'<div title="Denunciaste al usuario" id="flageduser" class="flageduser"></div>';
          }  
          else{
                
                echo'<div title="Denunciar al usuario" id="flaguser" onclick="denuncias.nueva('.$context['member']['id'].', 2);" class="flaguser"></div>';
                echo'<div title="Denunciaste al usuario" style="display:none" id="flageduser" class="flageduser"></div><div style="display:none" id="msgden">'.FLAGED.'</div>';
          } 
        }     
      
      
      echo'<div class="left contenido">';

     
      //Cargamos la privacidad del usuario
        $Privacy['profile'] = array(
             'fotos' => getPrivacyUser($idu,array("profile" => "show_fotos"))
          );  


      foreach($nav as $navigation){

      //Mostramos las fotos, solo si el usuario lo quiere
      if($navigation['name']=="Fotos"){
        if($Privacy['profile']['fotos'] || $context['user']['is_owner']){
        echo '<a href="'.$navigation['href'].'" class="tabProfile '.$navigation['selected'].'">'.$navigation['name'].'</a>';
        }
      }
      else
      echo '<a href="'.$navigation['href'].'" class="tabProfile '.$navigation['selected'].'">'.$navigation['name'].'</a>';
      }
      echo'</div>';
      if($allow_mod){
        echo '<div class="right contenido"><a href="'.$scripturl.'?action=profile&sa=cuenta&u='.$context['member']['id'].'" class="tabProfile mod">Gestionar Cuenta</a></div>';
      }

echo'</div>';

echo '<div class="globalcontent2 clearfix">';
/*
echo '<div class="right">
        <img src="http://maps.google.com/maps/api/staticmap?center='.$context['member']['country']['name'].'&zoom=5&size=200x200&sensor=true">
      </div>';
*/


    
}

function template_act(){

   global $context, $settings, $options, $scripturl, $modSettings, $txt, $db_prefix, $ID_MEMBER;



   $idu = $context['member']['id'];

  $head_menu = array(
      'Informacion' => array(
            'name' => 'Informacion',
            'href' => ''.$scripturl.'?action=profile;u='.$idu.'',
            'selected' => ''
            ),
      'Actividad' => array(
            'name' => 'Actividad',
            'href' => ''.$scripturl.'?action=profile;sa=act;u='.$idu.'',
            'selected' => 'selected'
            ),
      'Ultimos Posts' => array(
            'name' => 'Ultimos Posts',
            'href' => ''.$scripturl.'?action=profile;sa=post;u='.$idu.'',
            'selected' => ''
            ),
      'Fotos' => array(
            'name' => 'Fotos',
            'href' => ''.$scripturl.'?action=profile;sa=fotos;u='.$idu.'',
            'selected' => ''
            ),
      );

  echo profile_head($head_menu);
  // add script tag to header 
  echo'<script type="text/javascript" src="' . $settings['theme_url'] . '/jquery.overscroll.min.js?update"></script>
  <script type="text/javascript" src="' . $settings['theme_url'] . '/stream.js?version='.( $_SERVER['HTTP_HOST'] == 'localhost' ? '?upd=' . time() : '0.1' ).'"></script>';
if(!$context['user']['is_logged']){
fatal_error("Debes estar logueado para ver la actividad de este usuario.");
}
    //Cargamos la privacidad del usuario
  $Privacy['profile'] = array(
       'fotos' => getPrivacyUser($idu,array("profile" => "show_fotos"))
    );  

  
  echo '
  <div class="container-stories sheets borderight" >
            <div class="profhead">'.$txt['last_activities'].'</div>
    <ul class="stream-stories"', $context['user']['is_guest'] ? ' style="border-top:none"' : '' ,'>';
    
    
    if(empty($context['stream']['stories']))
    {
      echo '<li class="story clearfix"><div class="error margin-5">no se encontro ninguna historia.</div></li>';
    }
    else
      foreach( $context['stream']['stories'] as $key_time => $story )
      {
      
        printActionByType( $story, $story['story']['type'], $key_time );
      
      }
    
    echo '
    </ul><div class="sheets-bottom"></div>
  </div>';
  
  echo '</div>';

  stream_temp();

}

function stream_temp(){

  /* TEMPLATES AUXILIARES JAVASCRIPT ( $.tmpl ) */
    echo '
  <script id="story_tmpl_sub" type="text/x-jquery-tmpl">
    <li class="clearfix" id="cc_${id}">
      <a class="author-com">
        <img src="'.$context['user']['avatar']['src'].'" width="150" height="150">
      </a>
        <div class="inner-comment">
          <span class="author"><a href="'.$scripturl . '?action=profile&u='.$context['user']['id'].'">'.$context['user']['name'].'</a> coment&oacute;:</span>
            <span class="msg">${comentario}</span>
            <span class="time time-upd">Hace instantes - <span style="cursor:pointer;" id="${id}" class="deleteSub">Borrar</span></span>
        </div>
    </li>
  </script>
  
  <script id="story_tmpl_likes" type="text/x-jquery-tmpl">
    <li><a title="${membername}" href="'.$scripturl . '?action=profile&u=${iduser}"><img src="${avatar}"></a></li>

  </script>
  
  <script id="story_tmpl_sub_all" type="text/x-jquery-tmpl">
    <li class="clearfix" id="cc_${id}" style="background:rgba(0,0,0,0.03);">
      <a class="author-com">
        <img src="${avatar}" width="150" height="150">
      </a>
        <div class="inner-comment">
          <span class="author"><a href="'.$scripturl . '?action=profile&u=${iduser}">${name}</a> coment&oacute;:</span>
            <span class="msg">${comment}</span>
            <span class="time time-upd">${fecha} 
            {{if delete_item}}
            - <span style="cursor:pointer;" id="${id}" class="deleteSub">Borrar</span>
          {{/if}}
          </span>
        </div>
    </li>
  </script>
  
  <script id="story_tmpl_own" type="text/x-jquery-tmpl">
  <li class="story recentStoryElement clearfix">
      <div class="avatar">
        <a href="?clickStory" class="avatar-thumb"><img style="${avatar_coords}" src="${avatar_src}"></a>
      </div>
      <div class="story-context">
        
        <span class="story-user-info"><a class="nick" href="${member_href}">${member_name}</a> ${story_action} <a class="time-story" title="${story_date}">${story_time}</a>:</span>
        <div class="story-content">
          <span class="msg word-wrap"><div>{{html message}}</div></span>
          {{if attach_on}}
            <div class="streamAttachContext clearfix {{if attach_thumbnail}}thumbnailVisible{{/if}} ${story_type} rounded">
            </div>
          {{/if}}
        </div>
        
        <div class="outter-footer-story">
          <i class="arrow-footer"></i>
          <div class="footer-story rounded box-shadow-soft clearfix">
            <a class="outter-icon-story rounded-left"><i class="story-icon ${story_type}"></i></a>
            <ul class="stats">
              <li class="comments"><a class="clearfix">0</a></li>
              <li class="likes disabled"><a class="clearfix">0</a></li>
              <li class="re-streams disabled rounded-right"><a class="clearfix">0</a></li>
            </ul>
          </div>
        </div>
        
      </div>
    </li>
  </script>
  
    <script id="attachment_tmpl_link" type="text/x-jquery-tmpl">    
    <div class="attachThumbnail">
      <div class="thumbnails_list"><img src="${thumbnail}"></div>
      <div class="thumbnail-options">
        <span class="count"></span>
        <div class="paginate_thumbnails clearfix"></div>
        <span class="disable_thumbnail"><input type="checkbox" name="disable_thumbnail" /> Sin miniatura</span>
      </div>
    </div>
    <div class="attachText">
      <h3>${title}</h3>
      <div><a>${url}</a></div>
      <div><span>${description}</span></div>      
    </div>
    <!-- <i style="background: url(http://www.google.com/s2/favicons?domain=${domain})" class="favicon"></i> -->
    </script>
  
    <script id="attachment_tmpl_video" type="text/x-jquery-tmpl">
        <div class="thumbnail clearfix">
      <img src="${thumbnail}" width="180">
      <a class="play-icon"></a>
    </div>
    <div class="attachText clearfix">
      <a>${title}</a>
      <span>${description}</span>
    </div>
    </script>
  
  <script id="attachment_tmpl_swf" type="text/x-jquery-tmpl">
    <embed width="${width}" height="${height}" wmode="transparent" autoplay="false" allownetworking="internal" allowscriptaccess="never" allowfullscreen="true" type="application/x-shockwave-flash" quality="high" src="${src}" class="swf-untrusted">
  </script>
  
    <script id="attachment_tmpl_image" type="text/x-jquery-tmpl">
       <div class="thumbWrap"><img class="disabled-select" src="${src}" style="${style}"></div>    
    </script>';
}


function printActionByType($data, $type, $key_time){
  global $context, $txt, $ID_MEMBER;
 	$context['following_list'] = array(
		array('id' => 1, 'name' => 'jonathan', 'avatar' => 'http://localhost/cms/spirate2_4/Themes/default/images/avatar-4.png', 'type' => 'user'),
		array('id' => 2, 'name' => 'shake', 'avatar' => 'http://localhost/cms/spirate2_4/Themes/default/images/avatar-4.png', 'type' => 'user'),
		array('id' => 3, 'name' => 'rancitis', 'avatar' => 'http://localhost/cms/spirate2_4/Themes/default/images/avatar-4.png', 'type' => 'user'),
		array('id' => 4, 'name' => 'kawapanga', 'avatar' => 'http://localhost/cms/spirate2_4/Themes/default/images/avatar-4.png', 'type' => 'user'),
		array('id' => 5, 'name' => 'fivezone', 'avatar' => 'http://localhost/cms/spirate2_4/Themes/default/images/avatar-4.png', 'type' => 'user'),
		array('id' => 6, 'name' => 'uciel', 'avatar' => 'http://localhost/cms/spirate2_4/Themes/default/images/avatar-4.png', 'type' => 'user'),
		array('id' => 7, 'name' => '002', 'avatar' => 'http://localhost/cms/spirate2_4/Themes/default/images/avatar-4.png', 'type' => 'user'),
		array('id' => 8, 'name' => 'jesus', 'avatar' => 'http://localhost/cms/spirate2_4/Themes/default/images/avatar-4.png', 'type' => 'user'),
		array('id' => 9, 'name' => 'rancio', 'avatar' => 'http://localhost/cms/spirate2_4/Themes/default/images/avatar-4.png', 'type' => 'user'),
		array('id' => 10, 'name' => 'ran', 'avatar' => 'http://localhost/cms/spirate2_4/Themes/default/images/avatar-4.png', 'type' => 'user'),
		array('id' => 10, 'name' => 'ran', 'avatar' => 'http://localhost/cms/spirate2_4/Themes/default/images/avatar-4.png', 'type' => 'user'),
		array('id' => 10, 'name' => 'ran', 'avatar' => 'http://localhost/cms/spirate2_4/Themes/default/images/avatar-4.png', 'type' => 'user'),
		array('id' => 10, 'name' => 'ran', 'avatar' => 'http://localhost/cms/spirate2_4/Themes/default/images/avatar-4.png', 'type' => 'user'),
		array('id' => 10, 'name' => 'ran', 'avatar' => 'http://localhost/cms/spirate2_4/Themes/default/images/avatar-4.png', 'type' => 'user'),
		array('id' => 10, 'name' => 'ran', 'avatar' => 'http://localhost/cms/spirate2_4/Themes/default/images/avatar-4.png', 'type' => 'user'),
		array('id' => 10, 'name' => 'ran', 'avatar' => 'http://localhost/cms/spirate2_4/Themes/default/images/avatar-4.png', 'type' => 'user'),
		array('id' => 10, 'name' => 'ran', 'avatar' => 'http://localhost/cms/spirate2_4/Themes/default/images/avatar-4.png', 'type' => 'user'),
	);
	
	echo '
	<script type="text/javascript">
		global.stream = {
			follow_list : ' . (isset($context['following_list']) ? preg_replace('~(\}\,)~', "$1\n\t\t\t\t\t", json_encode($context['following_list'])) : '{}') .',
			privacy : ' .( $context['stream']['user']['privacy'] ?  $context['stream']['user']['privacy'] : 0 ). '
		}
	</script>';
	
  switch( $type )
  {
    case 'error':
      echo '
      <li class="story error clearfix', $data['story']['class'] ? ' ' . $data['story']['class'] : '' ,'">
        ' . $data['story']['body'] . '
      </li>';
      
      
    break;
    case 'status':
    case 'video':
    case 'video/swf':
    case 'image':
    case 'link':
    if($data['member']['id'] == $ID_MEMBER){
    $footer_stats = array(
      'comments' => array(
        'count' => $data['story']['stats']['comments'],
        'no_show' => $data['story']['stats']['disabled']['comment'] === 'hide',
        'disabled' => false
      ),
      'likes' => array(
        'count' => $data['story']['stats']['likes'],
        'no_show' => $data['story']['stats']['disabled']['like'] === 'hide',
        'disabled' => $data['story']['stats']['disabled']['like'] ? true : false
      ),
      're-streams' => array(
        'count' => $data['story']['stats']['re_streams'],
        'no_show' => $data['story']['stats']['disabled']['re_stream'] === 'hide',
        'disabled' => $data['story']['stats']['disabled']['re_stream'] ? true : false
      )
    );
    
      
    echo '
    <li class="story clearfix', $data['story']['is_shared'] && !empty($data['story']['body']) ? ' re-stream' : '' ,'" story_id="' . ( $data['story']['is_shared'] ? $data['object']['stream']['id'] : $data['story']['id'] ) . '" id="storyi_'.$data['story']['id'].'">
      <div class="avatar">
        <a href="?clickStory" class="avatar-thumb"><img style="' . $data['member']['avatar']['coords'] . '" src="' . $data['member']['avatar']['src'] . '"></a>
      ';
      
      if( $data['story']['is_shared'] && !$data['is_agrouped'] )
        echo '<div class="re-stream"><a href="" class="avatar-thumb s-32"><img style="'. $data['object']['member']['avatar']['coords'] . '" src="' . $data['object']['member']['avatar']['src'] . '"></a></div>';
      
      echo '
      </div>
      <div class="story-context">
      
        <span class="story-user-info">';
        
        echo'<a class="nick" href="' . $data['member']['href'] . '">' . $data['member']['name'] . '</a> ' . $data['story']['action'] . ' <a class="time-story" title="'.$data['story']['time']['date'].'">' . $data['story']['time']['text'] . '</a>:';

        
        echo'</span>

        <div class="story-content">
          <span class="msg word-wrap"><div>' . $data['story']['body'] . '</div></span>';
          if( $data['attach'] && $type != 'status' )
          {
            
            echo '
            <div class="streamAttachContext clearfix ' .( $data['attach']['thumbnail'] ? 'thumbnailVisible ' : '' ) . ( $data['attach']['params']['type'] ? $data['attach']['params']['type'] : $type) .' rounded">
            
              <!-- attach_story:'.$data['story']['id'].' -->
              ';
              switch( $type ){
                
                case 'image':
                
                  $set_min_height = ' style="';
                  
                  if ( $data['attach']['params']['minHeight'] )
                    $set_min_height .= 'min-height: 350';
                  else
                    $set_min_height .= 'height: ' . $data['attach']['params']['height'];
                  
                  $set_min_height .= 'px;"';
                  
                  echo '<a' . $set_min_height . '><img style="'.$data['attach']['align'].'" src="'.$data['attach']['src'].'"></a>';
                  
                break;
                
                case 'link':
                
                if( $data['attach']['thumbnail'] )
                  echo '
                  <div class="thumbnail clearfix">
                    <img src="' . $data['attach']['thumbnail'] . '">
                  </div>';
                  
                  echo '
                  <div class="attachText clearfix">
                    <h3>' . $data['attach']['params']['title'] . '</h3>
                    <a>' . $data['attach']['params']['url'] . '</a>
                    <span>' . $data['attach']['params']['description'] . '</span>                   
                  </div>
                  <i class="favicon" style="background: url(' . $data['attach']['favicon'] . ')"></i>';
                
                break;
                
                case 'video':
                
                if( $data['attach']['thumbnail'] )
                  echo '
                  <div class="thumbnail clearfix">
                    <img src="' . $data['attach']['thumbnail'] . '" width="180">
                    <a class="play-icon"></a>
                  </div>';
                  
                  echo '
                  <div class="attachText clearfix">
                    <a href="' . $data['attach']['url'] . '">' . $data['attach']['params']['title'] . '</a>
                    <span>' . $data['attach']['params']['description'] . '</span>
                  </div>';
                
                break;
                
                case 'video/swf':
                  
                  $scaled = getScaledCoords(372, 0, $data['attach']['params']['width'], $data['attach']['params']['height']);
                  
                  echo '
                  <div class="swf-content" style="width: ' . $scaled[0] . 'px; height: ' . $scaled[1] .'px">
                    <div class="hide hide-swf"><embed width="' . $scaled[0] . '" height="' . $scaled[1] .'" wmode="transparent" autoplay="false" allownetworking="internal" allowscriptaccess="never" allowfullscreen="true" type="application/x-shockwave-flash" quality="high" src="' . $data['attach']['url'] . '" class="swf-untrusted"></div>
                    <a class="play-icon"></a>
                  </div>';
                  
                break;
              
              }
              echo '
            
            </div>';
            
          }
          echo '
        </div>
        
        <div class="outter-footer-story rounded-left">
          <i class="arrow-footer"></i>
          <div class="footer-story rounded box-shadow-soft clearfix">
            <a class="outter-icon-story  rounded-left"><i class="story-icon ' .( $data['story']['type'] == 'video/swf' ? 'video' : $data['story']['type'] ). '"></i></a>
            <ul class="stats">';
            $last_button = end(array_keys($footer_stats));
            
            foreach( $footer_stats as $key => $button )
            {
              if( $button['no_show'] )
                continue;
              if(empty($data['story']['is_shared'])){
              echo '
                <li class="' . $key . ( $button['disabled'] ? ' disabled' : '') . ($last_button == $key ? ' rounded-right' : '') . ($button['count'] > 0 ? ' filled' : '') . '"><a class="clearfix" id="comments_'.$data['story']['id'].'">' . $button['count'] . '</a></li>';            
            }
            }
              echo '
            </ul>';
        if(empty($data['story']['is_shared'])){
        
          if(!empty($data['story']['stats']['likes'])){
            echo'
            <div class="likes_content" id="likes_'.$data['story']['id'].'">
              ',getLikes($data['story']['id']),'
            </div>';
          }
          
            if($context['user']['is_logged']){
              if($_COOKIE['text_'.$data['story']['id'].''] == 0 or $_COOKIE['text_'.$data['story']['id'].''] == ''){
            }
              
              else{
                echo'
                <script type="text/javascript">
                    stream_actions.maketext('.$data['story']['id'].','.$_COOKIE['text_'.$data['story']['id'].''].');
                  </script>
                
                ';
              }
            }
          
          if($context['user']['is_logged'] or $data['story']['stats']['comments'] >= 1) 
          {echo'<div class="activity-users-actions">
                        
              
            <div class="comments clearfix">
              <i class="header-arrow"></i>';
            if($data['story']['stats']['comments'] > 5){ 
              $restanPorVer = $data['story']['stats']['comments'] -5;
              echo'<span class="see-all" id="linkAll_'.$data['story']['id'].'" ><a onclick="stream_actions.seeAll(\''.$data['story']['id'].'\');">Ver los otros '.$restanPorVer.' comentarios</a></span>';}
            else{
            echo'<style>ul.comms{margin-top:0!important;} ul.comms li:first-child{border-top:none!important;margin-top:-3px;}</style>';
            }
            
            echo'<ul class="comms" id="comms_'.$data['story']['id'].'">';
              
              getsubsComments($data['story']['id']);    
              
            if(($mostrar = checkPriv($data['story']['id'])) == 1){
              echo'
              
                <li class="clearfix" id="addbox_'.$data['story']['id'].'">
                  <a class="author-com"><img src="'.$context['user']['avatar']['src'].'"></a>
                    <div class="inner-comment">
                      <form  method="post" name="subcomment">
                      <textarea id="sub_'.$data['story']['id'].'"onkeydown="stream_actions.comment(\''.$data['story']['id'].'\',event)" class="comment-form" tabindex="700" placeholder="Escribe un comentario..."></textarea>
                      </form>
                    </div>
                  </li>
              ';}
                  
                echo' 
                </ul>
              </div>
            </div>';}}
          echo' 
          </div>
        </div>
        
      </div>
    </li>';
      }
    break;
    case 'follow':
    $from_user = preg_match("/\bte\b/i", $data['story']['action']);
    if($from_user){
      echo '
    <li class="story short-activity clearfix">      
      <div class="story-context">
      
        <span class="story-user-info activity_action ' . $type . '"><i class="icon notifyIcon follow"></i> ' . $data['story']['action'] . ' ( <a class="time-story" title="' . $data['story']['time']['date'] . '">' . $data['story']['time']['text'] . '</a> ).</span>
        
        
      </div>
    </li>';
    }
    break;
    case 'multi-follow':
    $from_user = preg_match("/\bte\b/i", $data['story']['action']);
    if($from_user){
    $data['story']['action'] = preg_replace("/\bte\b/i","lo", $data['story']['action']);
      echo '
    <li class="story short-activity clearfix">      
      <div class="story-context">
      
        <span class="story-user-info activity_action ' . $type . '"><i class="icon notifyIcon follow"></i>' . $data['story']['action'] . '</span>
        <div class="avatars-stack">';
        
        $fade = false;
        
        if( count($data['members']) > 6 )
        {
        
          $fade = 1.00;
          $less_fade = $fade/(count($data['members'])+1);
        
        }
        
        foreach( $data['members'] as $member )
        {
          
          echo '
          <a href="'.$member['href'].'" class="avatar-thumb inline" title="'.$member['name'].'"><img src="' . $member['avatar']['src'] . '" style="' . $member['avatar']['coords'] . '"', $fade ? ' opacity="' . $fade . '"' : '' ,'></a>';
          
          if( $fade )         
            $fade = $fade - $less_fade;
        
        }

        echo '</div>
        
      </div>
    </li>';
    } 
    
    break;
    case 'signup':
      //...
    break;
    case 'avatar':
      //...
    break;
    case 'shared-story':
    
      echo 'hola';
    
    break;
  
  
  }
}

function template_post(){

       global $context, $settings, $options, $scripturl, $modSettings, $txt, $db_prefix, $ID_MEMBER;


   $idu = $context['member']['id'];

  $head_menu = array(
      'Informacion' => array(
            'name' => 'Informacion',
            'href' => ''.$scripturl.'?action=profile;u='.$idu.'',
            'selected' => ''
            ),
      'Actividad' => array(
            'name' => 'Actividad',
            'href' => ''.$scripturl.'?action=profile;sa=act;u='.$idu.'',
            'selected' => ''
            ),
      'Ultimos Posts' => array(
            'name' => 'Ultimos Posts',
            'href' => ''.$scripturl.'?action=profile;sa=post;u='.$idu.'',
            'selected' => 'selected'
            ),
        'Fotos' => array(
            'name' => 'Fotos',
            'href' => ''.$scripturl.'?action=profile;sa=fotos;u='.$idu.'',
            'selected' => ''
            ),
      );

  echo profile_head($head_menu);


    //Cargamos la privacidad del usuario
  $Privacy['profile'] = array(
       'fotos' => getPrivacyUser($idu,array("profile" => "show_fotos"))
    );  
 echo'<div class="clearfix fuente-title"><div class="left"><span>&Uacute;ltimos posts del usuario</span></div><div class="left dotccc">&nbsp;</div></div>';
echo'
<div class="tinybox">
    <div class="html clearfix">';

          if (!empty($context['posts'])){
            echo'<ul class="list-profile-summary min">';
        foreach ($context['posts'] as $post){
              echo'<li>';
                  if ($context['user']['is_guest']){
                      if (!$post['can_view_post']){
                        echo'<img title="',$txt['private_post'],'" src="', $settings['images_url']  ,'/icons/icono-post-privado.gif">';
                      }
                  }
              echo'<a style="background:url('.$settings['images_url'].'/post/icono_'.$post['board']['id'].'.gif) no-repeat; padding: 2px 1px 2px 25px" href="', $scripturl . '?topic=', $post['topic'], '">', $post['subject'], '</a><span></span></li>';
          }
          echo'</ul>';
        }

        else{
          echo'<div class="info">El usuario no tiene posts</div><span></span>';   
        }

       echo'
    </div>
</div></div>';

}

function template_fotos(){

   global $context, $settings, $options, $scripturl, $modSettings, $txt, $db_prefix, $ID_MEMBER;

      $idu = $context['member']['id'];


  $head_menu = array(
      'Informacion' => array(
            'name' => 'Informacion',
            'href' => ''.$scripturl.'?action=profile;u='.$idu.'',
            'selected' => ''
            ),
      'Actividad' => array(
            'name' => 'Actividad',
            'href' => ''.$scripturl.'?action=profile;sa=act;u='.$idu.'',
            'selected' => ''
            ),
      'Ultimos Posts' => array(
            'name' => 'Ultimos Posts',
            'href' => ''.$scripturl.'?action=profile;sa=post;u='.$idu.'',
            'selected' => ''
            ),
      'Fotos' => array(
            'name' => 'Fotos',
            'href' => ''.$scripturl.'?action=profile;sa=fotos;u='.$idu.'',
            'selected' => 'selected'
            ),
      );

  echo profile_head($head_menu);


$allow_mod = allowedTo('moderate_forum');

$Privacy_follower = $context['member']['is_followed']  && $imagen['privacy']=="2";

    //Cargamos la privacidad del usuario
  $Privacy['profile'] = array(
       'fotos' => getPrivacyUser($idu,array("profile" => "show_fotos"))
    );  

  if(!$context['user']['is_logged']){
  fatal_error("Debes estar logueado para ver la actividad de este usuario.");
  }
  if(!$Privacy['profile']['fotos'] && !$context['user']['is_owner']){

      fatal_error("No tienes los permisos suficientes para ver las fotos del usuario.");

  }

  if(empty($context['img'])){

  echo'<div class="info">El usuario no tiene fotos.</div>'; 
  }
  else {                  
    echo'<div class="clearfix fuente-title"><div class="left"><span>&Uacute;ltimas fotos del usuario</span></div><div class="left dotccc">&nbsp;</div></div><br>';

  echo'<div style="width:100%;margin-left:25px;">';

    foreach($context['img'] as $imagen){

          
       if($context['member']['is_followed'] && $imagen['privacy']=="2" || $imagen['privacy']=="0" || $allow_mod || $context['user']['is_owner'])
          echo'<div style="float:left;padding:5px;"><a img-src="'.$imagen['url'].'" style="background:url(http://localhost/designs/sp_24/photos/1.png) center center; width:140px;height:140px;text-align:center;" class="thumb shape-img rounded left"><div class="mask-load with-icon rounded"></div><img style="max-height:130px; max-width:130px;" src="'.$imagen['url'].'" title="'.$imagen['titulo'].'"><div class="IEFIX_box-shadow clearfix"></div></a></div>';
      }

    echo'</div>';
}

}

function template_summary(){
    global $context, $settings, $options, $scripturl, $modSettings, $txt, $db_prefix, $ID_MEMBER, $Privacy;

    if($context['user']['is_logged'])
    $allow_edit = allowedTo('moderate_forum') || $context['user']['is_owner'];

    else
    $allow_edit = false; 

    $idu = $context['member']['id'];
    
     $head_menu = array(
      'Informacion' => array(
            'name' => 'Informacion',
            'href' => ''.$scripturl.'?action=profile;u='.$idu.'',
            'selected' => 'selected'
            ),
      'Actividad' => array(
            'name' => 'Actividad',
            'href' => ''.$scripturl.'?action=profile;sa=act;u='.$idu.'',
            'selected' => ''
            ),
      'Ultimos Posts' => array(
            'name' => 'Ultimos Posts',
            'href' => ''.$scripturl.'?action=profile;sa=post;u='.$idu.'',
            'selected' => ''
            ),
      'Fotos' => array(
            'name' => 'Fotos',
            'href' => ''.$scripturl.'?action=profile;sa=fotos;u='.$idu.'',
            'selected' => ''
            ));

    

  echo profile_head($head_menu);

  
    
    //Cargamos la privacidad del usuario
  $Privacy['profile'] = array(
       'email' => getPrivacyUser($idu,array("profile" => "show_mail")),
       'info' => getPrivacyUser($idu,array("profile" => "show_info")),
       'followers' => getPrivacyUser($idu,array("profile" => "show_followers")),
       'following' => getPrivacyUser($idu,array("profile" => "show_following")),
       'fotos' => getPrivacyUser($idu,array("profile" => "show_fotos"))
    );
  $Privacy['followers'] = array(
       'email' => getPrivacyUser($idu,array("followers" => "show_mail")),
       'info' => getPrivacyUser($idu,array("followers" => "show_info")),
       'followers' => getPrivacyUser($idu,array("followers" => "show_followers")),
       'following' => getPrivacyUser($idu,array("followers" => "show_following")),
       'fotos' => getPrivacyUser($idu,array("followers" => "show_fotos"))
    );    


echo '<div class="left relative" style="width:650px">';

$context['member']['registered'] = time($context['member']['registered']);
echo'
<div class="minimal-box">
    <div class="title clearfix"><h3 class="left blue">Informacion b&aacute;sica</h3></div>
    <div class="content clearfix">
    <div class="left" style="width: 420px">
        <ul class="list-profile-summary min">
            <li><label><img src="'.$settings['images_url'].'/user.png" style="margin:0 6px -1px 0">Nombre</label><span>'.$context['member']['name'].'</span></li>
            <li><label><img src="'.$settings['images_url'].'/ballons.png" style="margin:0 6px -2px 0">Edad</label><span>'.$context['member']['age'].' años '.$Privacy['profile_hide_mail'].'</span></li>
            <li><label><img src="'.$settings['images_url'].'/location.png" style="margin:0 10px -2px 0">Vive en</label><span>'.$context['member']['country']['name'].'</span></li>';
            if(!$context['member']['is_followed'] && $Privacy['profile']['email'] || $context['member']['is_followed'] && $Privacy['followers']['email']){echo'<li><label><img src="'.$settings['images_url'].'/post-card.png" style="margin:0 6px 0px 0">Email</label><span>'.$context['member']['email'].'</span></li>';}
            echo'<li><label><img src="'.$settings['images_url'].'/calendar.gif" style="margin:0 6px -2px 0">Se registro el</label><span>'.date('d/m/Y', $context['member']['registered']).'</span></li>';
            if($context['info']['web']){echo'<li><label><img src="'.$settings['images_url'].'/link.png" style="margin:0 6px -2px 0">P&aacute;gina web</label><span><a>'.$context['info']['web'].'</a></span></li>';}
            echo'<li><label><img src="'.$settings['images_url'].'/rank-podium.png" style="margin:0 6px 0 0">Rango</label><span>'.(!empty($context['member']['group']) ? $context['member']['group'] : $context['member']['post_group']).'</span></li>';
           if (!$context['user']['is_owner'] && $context['can_send_pm']) 
            echo'<li><label><img src="'.$settings['images_url'].'/comment-stream.gif" style="margin:0 6px 0 0">Comunicarse</label><span><a href="', $scripturl, '?action=pm;sa=send;u=', $context['member']['id'], '">Enviar Mensaje Privado</a></span></li>';
        echo'</ul>
    </div>
    <div class="right"><img src="http://maps.google.com/maps/api/staticmap?center='.$context['member']['country']['name'].'&zoom=3&size=190x190&sensor=true"></div>
    </div>
</div>';


if(!$context['member']['is_followed'] && $Privacy['profile']['info'] || $context['member']['is_followed'] && $Privacy['followers']['info'] || $context['user']['is_owner']){

echo'<div class="minimal-box">
    <div class="title clearfix"><h3 class="left color-orange">Acerca de '.$context['member']['name'].'</h3>'; if($allow_edit){echo'<a onclick="profile.editbox(1, '.$idu.');" class="right ui-selector" id="ib1">Editar</a>';}
    echo'</div><div class="content biography" id="i1">'.($context['info']['biografia'] ? '"'.$context['info']['biografia'].'"' : 'El usuario no tiene biografia.').'</div>
    <div class="editbox" id="ie1"><textarea id="in1">'.$context['info']['biografia'].'</textarea></div>
</div>
 <div class="info" id="info" style="display:none">Haz doble click en la informaci&oacute;n que quieras editar.</div>
<div class="minimal-box">
    <div class="title clearfix"><h3 class="left">Intereses</h3><a href="#info" onclick="info_help();" class="right ui-selector">¿Como lo cambio?</a></div>';
echo'
    <div class="content">
    <ul class="list-profile-summary">
    <li '.($allow_edit ? 'ondblclick="profile.editbox(2, '.$idu.');"' : '').'><label>Busca</label> <span id="i2">'.$context['info']['busca'].'</span><div class="editbox" id="ie2"><textarea id="in2">'.$context['info']['busca'].'</textarea><a onclick="profile.editbox(2, '.$idu.');" class="right ui-selector">Guardar</a></div></li>
    <li '.($allow_edit ? 'ondblclick="profile.editbox(3, '.$idu.');"' : '').'><label>Hobbies</label> <span id="i3">'.$context['info']['hobbies'].'</span><div class="editbox" id="ie3"><textarea id="in3">'.$context['info']['hobbies'].'</textarea><a onclick="profile.editbox(3, '.$idu.');" class="right ui-selector">Guardar</a></div></li>
    </ul>
    </div>
</div>

<div class="minimal-box">
    <div class="title clearfix"><h3 class="left">Formacion y empleo</h3><a href="#info" onclick="info_help();" class="right ui-selector">¿Como lo cambio?</a></div>
    <div class="content">
    <ul class="list-profile-summary">
    <li '.($allow_edit ? 'ondblclick="profile.editbox(4, '.$idu.');"' : '').'><label>Idiomas</label> <span id="i4">'.$context['info']['idiomas'].'</span><div class="editbox" id="ie4"><textarea id="in4">'.$context['info']['idiomas'].'</textarea><a onclick="profile.editbox(4, '.$idu.');" class="right ui-selector">Guardar</a></div></li>
    <li '.($allow_edit ? 'ondblclick="profile.editbox(5, '.$idu.');"' : '').'><label>Estudio en</label> <span id="i5">'.$context['info']['estudios'].'</span><div class="editbox" id="ie5"><textarea id="in5">'.$context['info']['estudios'].'</textarea><a onclick="profile.editbox(5, '.$idu.');" class="right ui-selector">Guardar</a></div></li>
    <li '.($allow_edit ? 'ondblclick="profile.editbox(6, '.$idu.');"' : '').'><label>Trabajos</label> <span id="i6">'.$context['info']['trabajo'].'</span><div class="editbox" id="ie6"><textarea id="in6">'.$context['info']['trabajo'].'</textarea><a onclick="profile.editbox(6, '.$idu.');" class="right ui-selector">Guardar</a></div></li>
    <li '.($allow_edit ? 'ondblclick="profile.editbox(7, '.$idu.');"' : '').'><label>Habilidades Profesionales</label> <span id="i7">'.$context['info']['habilidades'].'</span><div class="editbox" id="ie7"><textarea id="in7">'.$context['info']['habilidades'].'</textarea><a onclick="profile.editbox(7, '.$idu.');" class="right ui-selector">Guardar</a></div></li>
    <li '.($allow_edit ? 'ondblclick="profile.editbox(8, '.$idu.');"' : '').'><label>Intereses Personales</label> <span id="i8">'.$context['info']['intereses'].'</span><div class="editbox" id="ie8"><textarea id="in8">'.$context['info']['intereses'].'</textarea><a onclick="profile.editbox(8, '.$idu.');" class="right ui-selector">Guardar</a></div></li>
    </ul>
    </div>
</div>

<div class="minimal-box">
    <div class="title clearfix"><h3 class="left">Vida personal</h3> <a href="#info" onclick="info_help();" class="right ui-selector">¿Como lo cambio?</a></div>
    <div class="content">
    <ul class="list-profile-summary">
    <li '.($allow_edit ? 'ondblclick="profile.editbox(9, '.$idu.');"' : '').'><label>Situaci&oacute;n sentimental</label> <span id="i9">'.$context['info']['situacion'].'</span><div class="editbox" id="ie9"><textarea id="in9">'.$context['info']['situacion'].'</textarea><a onclick="profile.editbox(9, '.$idu.');" class="right ui-selector">Guardar</a></div></li>
    <li '.($allow_edit ? 'ondblclick="profile.editbox(10, '.$idu.');"' : '').'><label>Vive con</label> <span id="i10">'.$context['info']['vivecon'].'</span><div class="editbox" id="ie10"><textarea id="in10">'.$context['info']['vivecon'].'</textarea><a onclick="profile.editbox(10, '.$idu.');" class="right ui-selector">Guardar</a></div></li>
    </ul>
    </div>
</div>';
}
else{

  echo'<div class="info">El usuario no comparte su informacion personal.</div>';
}

echo '</div>';

echo '<div class="right" style="width:300px; margin-top:12px">';

//Usuarios a los que sigue
if(!$context['member']['is_followed'] && $Privacy['profile']['following'] || $context['member']['is_followed'] && $Privacy['followers']['following'] || $context['user']['is_owner']){

echo'<div class="tinybox">
<div class="title"><span>Siguiendo</span><span style="float:right;color:#848484;margin-right:10px;">'.$context['follows'].'</span></div>
<div class="html clearfix">';

if(empty($context['following'])){

  echo'<div class="error">Actualmente no sigue a nadie.</div>'; 
}
else foreach($context['following'] as $following){

echo'<a href="'.$scripturl.'?action=profile;u='.$following['id'].'" class="shape-img rounded left" style="margin: 0 10px 10px 0"><img class="rounded-2" width="40" src="'.$following['avatar'].'" title="'.$following['nombre'].'"></a>';
}
echo'
</div>
</div>';

}

//Usuarios que lo siguen
if(!$context['member']['is_followed'] && $Privacy['profile']['followers'] || $context['member']['is_followed'] && $Privacy['followers']['followers'] || $context['user']['is_owner']){
echo'<div class="tinybox">
<div class="title"><span>Seguidores</span><span style="float:right;color:#848484;margin-right:10px;">'.$context['info']['followers'].'</span></div>
<div class="html clearfix">';
if(empty($context['follower'])){

  echo'<div class="error">Actualmente, no tiene Seguidores.</div>'; 
}
else foreach($context['follower'] as $follower){

echo'<a href="'.$scripturl.'?action=profile;u='.$follower['id'].'" class="shape-img rounded left" style="margin: 0 10px 10px 0"><img class="rounded-2" width="40" src="'.$follower['avatar'].'" title="'.$follower['nombre'].'"></a>';
}
echo'
</div>
</div>';
}

$allow_mod = allowedTo('moderate_forum');


if(!$context['member']['is_followed'] && $Privacy['profile']['fotos'] || $context['member']['is_followed'] && $Privacy['followers']['fotos'] || $context['user']['is_owner']){

echo'<div class="tinybox">
<div class="title"><span>&Uacute;ltimas fotos</span></div>
<div class="html clearfix" id="last-images-profile">
<div class="clearfix" style="width:280px; margin:0 auto">';
if(empty($context['img'])){

  echo'<div class="error">No ha publicado imagenes.</div>'; 
}
else foreach($context['img'] as $imagen){

  if($context['member']['is_followed'] && $imagen['privacy']=="2" || $imagen['privacy']=="0" || $allow_mod || $context['user']['is_owner'])
        echo'<a img-src="'.$imagen['url'].'" style="background:url(http://localhost/designs/sp_24/photos/1.png) center center" class="thumb shape-img rounded left"><div class="mask-load with-icon rounded"></div><img style="max-height:70px; max-width:80px;" src="'.$imagen['url'].'" title="'.$imagen['titulo'].'"><div class="IEFIX_box-shadow clearfix"></div></a>';
 }

echo'</div>
</div>
</div>';

}
echo'<div class="minimal-box">
<div class="title"><h3>'.$txt['advertising'].'</h3></div>
    <div class="content">
    ',get_advertise(3),'
  </div>
</div>

</div>';

echo '<div class="clear"></div>
'.str_repeat('<br />', 10).'
</div>
<script type="text/javascript">
var feed_time = 1;
</script>';




}


function template_editBuddies(){
	global $context, $settings, $options, $scripturl, $modSettings, $txt;

	echo'
	<div class="box_title">
		', $txt['editBuddies'], '
		<div class="box_rss">
			<img src="', $settings['images_url'], '/icons/profile_sm.gif" alt="" align="top" />
		</div>
	</div>
	<div class="box_cuerpo">
		<table width="90%">
			<tr class="catbg3">
				<td width="20%">', $txt[68], '</td>
				<td>', $txt['online8'], '</td>
				<td>', $txt[69], '</td>
				<td align="center">', $txt[513], '</td>
				<td align="center">', $txt[603], '</td>
				<td align="center">', $txt[604], '</td>
				<td align="center">', $txt['MSN'], '</td>
				<td></td>
			</tr>';

	//Sin amigos :)
	if (empty($context['buddies']))
		echo'<tr class="windowbg">
				<td colspan="8" align="center"><b>', $txt['no_buddies'], '</b></td>
			</tr>';

	// Muestro los Amigos
	$alternate = false;
    foreach ($context['buddies'] as $buddy){
		echo'<tr class="', $alternate ? 'windowbg' : 'windowbg2', '">
				<td>', $buddy['link'], '</td>
				<td align="center"><a href="', $buddy['online']['href'], '"><img src="', $buddy['online']['image_href'], '" alt="', $buddy['online']['label'], '" title="', $buddy['online']['label'], '" /></a></td>
				<td align="center">', ($buddy['hide_email'] ? '' : '<a href="mailto:' . $buddy['email'] . '"><img src="' . $settings['images_url'] . '/email_sm.gif" alt="' . $txt[69] . '" title="' . $txt[69] . ' ' . $buddy['name'] . '" /></a>'), '</td>
				<td align="center">', $buddy['icq']['link'], '</td>
				<td align="center">', $buddy['aim']['link'], '</td>
				<td align="center">', $buddy['yim']['link'], '</td>
				<td align="center">', $buddy['msn']['link'], '</td>
				<td align="center"><a href="', $scripturl, '?action=profile;u=', $context['member']['id'], ';sa=editBuddies;remove=', $buddy['id'], '"><img src="', $settings['images_url'], '/icons/delete.gif" alt="', $txt['buddy_remove'], '" title="', $txt['buddy_remove'], '" /></a></td>
			</tr>';

		$alternate = !$alternate;
	}

	echo '</table>
	</div><!-- /box_cuerpo -->';
	
	// Add a new buddy?
	echo '
	<br />
	<form action="', $scripturl, '?action=profile;u=', $context['member']['id'], ';sa=editBuddies" method="post" accept-charset="', $context['character_set'], '">
		<table width="65%" cellpadding="4" cellspacing="0" class="tborder" align="center">
			<tr class="titlebg">
				<td colspan="2">', $txt['buddy_add'], '</td>
			</tr>
			<tr class="windowbg">
				<td width="45%">
					<b>', $txt['who_member'], ':</b>
				</td>
				<td width="55%">
					<input type="text" name="new_buddy" id="new_buddy" size="25" />
					<a href="', $scripturl, '?action=findmember;input=new_buddy;quote=1;sesc=', $context['session_id'], '" onclick="return reqWin(this.href, 350, 400);"><img src="', $settings['images_url'], '/icons/assist.gif" alt="', $txt['find_members'], '" align="top" /></a>
				</td>
			</tr>
			<tr class="windowbg">
				<td colspan="2" align="right">
					<input type="submit" value="', $txt['buddy_add_button'], '" />
				</td>
			</tr>
		</table>
	</form>';

}

// This template shows an admin information on a users IP addresses used and errors attributed to them.
function template_trackUser(){
	global $context, $settings, $options, $scripturl, $txt;

    echo '
		<table cellpadding="0" cellspacing="0" border="0" class="bordercolor" align="center" width="90%"><tr><td>
			<table border="0" cellspacing="1" cellpadding="4" align="left" width="100%">
				<tr class="titlebg">
					<td colspan="2">
						<b>', $txt['view_ips_by'], ' ', $context['member']['name'], '</b>
					</td>
				</tr>';

	echo '
				<tr>
					<td class="windowbg2" align="left" width="200">', $txt['most_recent_ip'], ':</td>
					<td class="windowbg2" align="left">
						<a href="', $scripturl, '?action=trackip;searchip=', $context['last_ip'], ';">', $context['last_ip'], '</a>
					</td>
				</tr>';

	// Lists of IP addresses used in messages / error messages.
	echo '
				<tr>
					<td class="windowbg2" align="left">', $txt['ips_in_messages'], ':</td>
					<td class="windowbg2" align="left">
						', (count($context['ips']) > 0 ? implode(', ', $context['ips']) : '(' . $txt['none'] . ')'), '
					</td>
				</tr><tr>
					<td class="windowbg2" align="left">', $txt['ips_in_errors'], ':</td>
					<td class="windowbg2" align="left">
						', (count($context['error_ips']) > 0 ? implode(', ', $context['error_ips']) : '(' . $txt['none'] . ')'), '
					</td>
				</tr>';

	// List any members that have used the same IP addresses as the current member.
	echo '
				<tr>
					<td class="windowbg2" align="left">', $txt['members_in_range'], ':</td>
					<td class="windowbg2" align="left">
						', (count($context['members_in_range']) > 0 ? implode(', ', $context['members_in_range']) : '(' . $txt['none'] . ')'), '
					</td>
				</tr>
			</table>
		</td></tr></table>
		<br />';

	// The second table lists all the error messages the user has caused/received.
	echo '
		<table cellpadding="0" cellspacing="0" border="0" class="bordercolor" align="center" width="90%"><tr><td>
			<table border="0" cellspacing="1" cellpadding="4" align="center" width="100%">
				<tr class="titlebg">
					<td colspan="4">
						', $txt['errors_by'], ' ', $context['member']['name'], '
					</td>
				</tr><tr class="windowbg">
					<td class="smalltext" colspan="4" style="padding: 2ex;">
						', $txt['errors_desc'], '
					</td>
				</tr><tr class="titlebg">
					<td colspan="4">
						', $txt[139], ': ', $context['page_index'], '
					</td>
				</tr><tr class="catbg3">
					<td>', $txt['ip_address'], '</td>
					<td>', $txt[72], '</td>
					<td>', $txt[317], '</td>
				</tr>';

	if (empty($context['error_messages']))
		echo '
				<tr><td class="windowbg2" colspan="4"><i>', $txt['no_errors_from_user'], '</i></td></tr>';
	else
		foreach ($context['error_messages'] as $error)
			echo '
				<tr>
					<td class="windowbg2">
						<a href="', $scripturl, '?action=trackip;searchip=', $error['ip'], ';">', $error['ip'], '</a>
					</td>
					<td class="windowbg2">
						', $error['message'], '<br />
						<a href="', $error['url'], '">', $error['url'], '</a>
					</td>
					<td class="windowbg2">', $error['time'], '</td>
				</tr>';
	echo '
			</table>
		</td></tr></table>';
}

function template_trackIP()
{
	global $context, $settings, $options, $scripturl, $txt;

	echo '
		<form action="', $scripturl, '?action=trackip" method="post" accept-charset="', $context['character_set'], '">';

	echo '
			<table cellpadding="0" cellspacing="0" border="0" class="bordercolor" align="center" width="90%"><tr><td>
				<table border="0" cellspacing="1" cellpadding="4" align="center" width="100%">
					<tr class="titlebg">
						<td>', $txt['trackIP'], '</td>
					</tr><tr>
						<td class="windowbg2">
							', $txt['enter_ip'], ':&nbsp;&nbsp;<input type="text" name="searchip" value="', $context['ip'], '" size="20" />&nbsp;&nbsp;<input class="login" type="submit" value="', $txt['trackIP'], '" />
						</td>
					</tr>
				</table>
			</td></tr></table>
		</form>
		<br />';

	if ($context['single_ip'])
	{
		echo '
		<table cellpadding="0" cellspacing="0" border="0" class="bordercolor" align="center" width="90%"><tr><td>
			<table border="0" cellspacing="1" cellpadding="4" align="center" width="100%">
				<tr class="titlebg">
					<td colspan="2">
						', $txt['whois_title'], ' ', $context['ip'], '
					</td>
				</tr><tr>
					<td class="windowbg2">';
		foreach ($context['whois_servers'] as $server)
			echo '
						<a href="', $server['url'], '" target="_blank"', isset($context['auto_whois_server']) && $context['auto_whois_server']['name'] == $server['name'] ? ' style="font-weight: bold;"' : '', '>', $server['name'], '</a><br />';
		echo '
					</td>
				</tr>
			</table>
		</td></tr></table>
		<br />';
	}

	echo '
		<table cellpadding="0" cellspacing="0" border="0" class="bordercolor" align="center" width="90%"><tr><td>
			<table border="0" cellspacing="1" cellpadding="4" align="center" width="100%">
				<tr class="titlebg">
					<td colspan="2">
						', $txt['members_from_ip'], ' ', $context['ip'], '
					</td>
				</tr><tr class="catbg3">
					<td>', $txt['ip_address'], '</td>
					<td>', $txt['display_name'], '</td>
				</tr>';
	if (empty($context['ips']))
		echo '
				<tr><td class="windowbg2" colspan="2"><i>', $txt['no_members_from_ip'], '</i></td></tr>';
	else
		foreach ($context['ips'] as $ip => $memberlist)
			echo '
				<tr>
					<td class="windowbg2"><a href="', $scripturl, '?action=trackip;searchip=', $ip, ';">', $ip, '</a></td>
					<td class="windowbg2">', implode(', ', $memberlist), '</td>
				</tr>';
	echo '
			</table>
		</td></tr></table>
		<br />';

	echo '
		<table cellpadding="0" cellspacing="0" border="0" class="bordercolor" align="center" width="90%"><tr><td>
			<table border="0" cellspacing="1" cellpadding="4" align="center" width="100%">
				<tr class="titlebg">
					<td colspan="4">
						', $txt['messages_from_ip'], ' ', $context['ip'], '
					</td>
				</tr><tr class="windowbg">
					<td class="smalltext" colspan="4" style="padding: 2ex;">
						', $txt['messages_from_ip_desc'], '
					</td>
				</tr><tr class="titlebg">
					<td colspan="4">
						<b>', $txt[139], ':</b> ', $context['message_page_index'], '
					</td>
				</tr><tr class="catbg3">
					<td>', $txt['ip_address'], '</td>
					<td>', $txt['rtm8'], '</td>
					<td>', $txt[319], '</td>
					<td>', $txt[317], '</td>
				</tr>';

	if (empty($context['messages']))
		echo '
				<tr><td class="windowbg2" colspan="4"><i>', $txt['no_messages_from_ip'], '</i></td></tr>';
	else
		foreach ($context['messages'] as $message)
			echo '
				<tr>
					<td class="windowbg2">
						<a href="', $scripturl, '?action=trackip;searchip=', $message['ip'], '">', $message['ip'], '</a>
					</td>
					<td class="windowbg2">
						', $message['member']['link'], '
					</td>
					<td class="windowbg2">
						<a href="', $scripturl, '?topic=', $message['topic'], '">
							', $message['subject'], '
						</a>
					</td>
					<td class="windowbg2">', $message['time'], '</td>
				</tr>';
	echo '
			</table>
		</td></tr></table>
		<br />';

	echo '
		<table cellpadding="0" cellspacing="0" border="0" class="bordercolor" align="center" width="90%"><tr><td>
			<table border="0" cellspacing="1" cellpadding="4" align="center" width="100%">
				<tr class="titlebg">
					<td colspan="4">
						', $txt['errors_from_ip'], ' ', $context['ip'], '
					</td>
				</tr><tr class="windowbg">
					<td class="smalltext" colspan="4" style="padding: 2ex;">
						', $txt['errors_from_ip_desc'], '
					</td>
				</tr><tr class="titlebg">
					<td colspan="4">
						', $txt[139], ': ', $context['error_page_index'], '
					</td>
				</tr><tr class="catbg3">
					<td>', $txt['ip_address'], '</td>
					<td>', $txt['display_name'], '</td>
					<td>', $txt[72], '</td>
					<td>', $txt[317], '</td>
				</tr>';
	if (empty($context['error_messages']))
		echo '
				<tr><td class="windowbg2" colspan="4"><i>', $txt['no_errors_from_ip'], '</i></td></tr>';
	else
		foreach ($context['error_messages'] as $error)
			echo '
				<tr>
					<td class="windowbg2">
						<a href="', $scripturl, '?action=trackip;searchip=', $error['ip'], '">', $error['ip'], '</a>
					</td>
					<td class="windowbg2">
						', $error['member']['link'], '
					</td>
					<td class="windowbg2">
						', $error['message'], '<br />
						<a href="', $error['url'], '">', $error['url'], '</a>
					</td>
					<td class="windowbg2">', $error['error_time'], '</td>
				</tr>';
	echo '
			</table>
		</td></tr></table>';
}

function template_menu_editor(){
	global $txt, $settings, $context, $scripturl;
	echo'
	<div id="cuentaL">
		<div class="box_title">
			',$txt['my_options'],'
		</div><!-- /box_title -->
		<div class="box_cuerpo">
			<div align="left" style="margin-bottom:4px;">
				<span style="margin-bottom:5px;">
					<img src="', $settings['images_url']  ,'/icons/edit.png" align="absmiddle"> <a href="'.amigables('?action=profile&sa=perfil'),'">',$txt['edit_my_profile'],'</a>
				</span>
			</div>
			<div align="left" style="margin-bottom:4px;">
				<span style="margin-bottom:5px;">
					<img src="', $settings['images_url']  ,'/icons/icono-editar-cuenta.gif" align="absmiddle"> <a href="'.amigables('?action=profile&sa=cuenta'),'">',$txt['edit_my_account'],'</a>
				</span>
			</div>
			
			<hr class="divider" />
			
			<img src="', $settings['images_url']  ,'/user.png" alt="" /> <b>',$txt['edit_appearance'],':</b><br/>
			<div align="left">
				<b class="size12">
					<ul style="margin:0px;padding-left:15px;">
						<li style="margin:0px;padding-left:0px;"><a href="'.amigables('?action=profile&sa=apariencia'),'">',$txt['appearance'],'</a></li>
						<li style="margin:0px;padding-left:0px;"><a href="'.amigables('?action=profile&sa=interes'),'">',$txt['interests_and_preferences'],'</a></li>
					</ul>
				</b>
			</div>
			<hr class="divider" />
			
			<div align="left" style="margin-bottom:4px;">
				<img src="', $settings['images_url']  ,'/icons/icono-foto.gif" align="absmiddle"> <a href="', $scripturl, '?action=imagenes;sa=agregar">',$txt['add_image'],'</a>
			</div>
			<div align="left" style="margin-bottom:4px;">
				<img src="', $settings['images_url']  ,'/icons/icon-avatar.png" align="absmiddle"> <a href="'.amigables('?action=profile&sa=avatar'),'">',$txt['modify_avatar'],'</a>
			</div>
			<div align="left" style="margin-bottom:4px;">
				<img src="', $settings['images_url']  ,'/mcontento.gif" align="absmiddle"> <a href="'.amigables('?action=profile&sa=estado'),'">',$txt['change_state'],'</a>
			</div>
		</div><!-- /box_cuerpo -->
	</div><!-- /cuentaL -->';
}

function template_cuenta(){
  global $context, $settings, $options, $scripturl, $modSettings, $txt, $Opcion;

  
  echo '
   <div class="col-left-stream">
        <div class="context topad">';
    
    echo '
    <div class="title" style="margin-left:10px;"><strong class="color-orange size-15">Mis opciones</strong></div>
    <div class="nav">
        <ul>';    
    
        foreach($context['navigation'] as $tab){
        if(empty($tab))
      echo'<li>&nbsp;</li>';
      else
            echo '<li', $tab['act'] ? ' class="selected"' : '' ,'><a href="'.$tab['href'].'">'.$tab['text'].'</a></li>';
      
      }
      
        echo '</ul>
    </div>';
        
    echo '</div>';

    echo '</div>';
  
  echo'<div class="main-stream equal-height topad" style="width:600px"><div class="context">',$Opcion(),'</div></div>';
    
}

function template_apariencia()
{global $context, $settings, $options, $scripturl, $modSettings, $txt;

	echo '
		<script language="JavaScript" type="text/javascript"><!-- // --><![CDATA[
			function checkProfileSubmit()
			{';
	if ($context['user']['is_owner'] && $context['require_password'])
		echo '
				// Did you forget to type your password?
				if (document.forms.creator.oldpasswrd.value == "")
				{
					alert();
					return false;
				}';

	if ($context['allow_edit_membergroups'] && $context['user']['is_owner'] && $context['member']['group'] == 1)
		echo '
				if (typeof(document.forms.creator.ID_GROUP) != "undefined" && document.forms.creator.ID_GROUP.value != "1")
					return confirm("', $txt['deadmin_confirm'], '");';

	echo '
				return true;
			}
		// ]]></script>';

template_menu_editor();

echo '
<form action="', $scripturl, '?action=profile2" method="post" accept-charset="UTF-8" name="creator" id="creator" enctype="multipart/form-data">

<div id="cuentaR">
<div class="box_title"><center>',$txt['appearancex'],'</center></div>
<div class="box_cuerpo">
	
		
		
	
			<div class="configBloqs">
				<b>',$txt['staturex'],': </b>
				<input type="text" name="default_options[altura]" size="5" value="', @$context['member']['options']['altura'] ,'" />',$txt['cm'],'&nbsp;<span class="smalltext">(',$txt['insert_stature'],')</span>
			
		</div>
		
		
			
	
		
			<div class="configBloqs">
				<b>',$txt['weight'],': </b>
				<input type="text" name="default_options[peso]" size="5" value="', @$context['member']['options']['peso'] ,'" />',$txt['kg'],'&nbsp;		<span class="smalltext">(',$txt['insert_weight'],')</span>	
		</div>
		
			
		
		
			<div class="configBloqs">
				<b>',$txt['physical'],': </b>
				<input type="text" name="default_options[fisico]" size="40" value="', @$context['member']['options']['fisico'] ,'" />&nbsp;<span class="smalltext">(',$txt['state_physical'],')</span>
                </div>
		
			
		
		
			<div class="configBloqs">
				<b>',$txt['hair'],': </b>
				<input type="text" name="default_options[cabello]" size="40" value="', @$context['member']['options']['cabello'] ,'" />&nbsp;<span class="smalltext">(',$txt['color_h'],')</span>
              </div>
		
			
		
		
			<div class="configBloqs">
				<b>',$txt['eyes'],': </b>
				<input type="text" name="default_options[ojos]" size="40" value="', @$context['member']['options']['ojos'] ,'" />&nbsp;<span class="smalltext">(',$txt['color_e'],')</span>
			</div>
		
			
	
		
			<div class="configBloqs">
				<b>',$txt['color_skin'],': </b>
				<input type="text" name="default_options[colorpiel]" size="40" value="', @$context['member']['options']['colorpiel'] ,'" />&nbsp;<span class="smalltext">(',$txt['color_s'],')</span>
					</div>';		
		
			
	
			template_profile_save();
	echo'
	</table>
</div>
</div><!-- /cuentaR -->
</form>';
}

function template_interes(){
	global $context, $settings, $options, $scripturl, $modSettings, $txt;

	echo '
		<script language="JavaScript" type="text/javascript"><!-- // --><![CDATA[
			function checkProfileSubmit()
			{';
	if ($context['user']['is_owner'] && $context['require_password'])
		echo '
				// Did you forget to type your password?
				if (document.forms.creator.oldpasswrd.value == "")
				{
					alert();
					return false;
				}';

	if ($context['allow_edit_membergroups'] && $context['user']['is_owner'] && $context['member']['group'] == 1)
		echo '
				if (typeof(document.forms.creator.ID_GROUP) != "undefined" && document.forms.creator.ID_GROUP.value != "1")
					return confirm("', $txt['deadmin_confirm'], '");';

	echo '
				return true;
			}
		// ]]></script>';

template_menu_editor();

echo '
<form action="', $scripturl, '?action=profile2" method="post" accept-charset="UTF-8" name="creator" id="creator" enctype="multipart/form-data">
<div id="cuentaR">
<div class="box_title">',$txt['interests'],'</div>
<div class="box_cuerpo">
		   
		    <div class="configBloqs">
				<b>',$txt['i_like'],': </b>
				<input type="text" name="default_options[gustar]" size="50" value="', @$context['member']['options']['gustar'] ,'" />&nbsp;<span class="smalltext">(',$txt['i_like_insert'],')</span>
		    </div>
			
			<div class="configBloqs">
				<b>',$txt['favorite_band'],': </b>
				<input type="text" name="default_options[banda]" size="50" value="', @$context['member']['options']['banda'] ,'" />&nbsp;<spanclass="smalltext">(',$txt['favorite_band_insert'],')</span>
		 </div>
		 
		
	
			<div class="configBloqs">
				<b>',$txt['hobbie'],': </b>
				<input type="text" name="default_options[hobbie]" size="50" value="', @$context['member']['options']['hobbie'] ,'" />&nbsp;<span class="smalltext">(',$txt['hobbie_insert'],')</span>
			
		</div>
		
			
	
		
			<div class="configBloqs">
				<b>',$txt['sport'],': </b>
				<input type="text" name="default_options[deporte]" size="50" value="', @$context['member']['options']['deporte'] ,'" />&nbsp;	<span class="smalltext">(',$txt['sport_insert'],')</span>
		</div>
		
			
		
			<div class="configBloqs">
				<b>',$txt['eq'],': </b>
				<input type="text" name="default_options[equipo]" size="50" value="', @$context['member']['options']['equipo'] ,'" />&nbsp;<span class="smalltext">(',$txt['eq_insert'],')</span>
		</div>
		
			
		
		
			<div class="configBloqs">
				<b>',$txt['favorite_food'],': </b>
               <input type="text" name="default_options[comida]" size="50" value="', @$context['member']['options']['comida'] ,'" />&nbsp;<span class="smalltext">(',$txt['favorite_food_insert'],')</span>
			
		</div>
		
		
		
			<div class="configBloqs">
			<b>',$txt['book'],': </b>
             <input type="text" name="default_options[libro]" size="50" value="', @$context['member']['options']['libro'] ,'" />&nbsp;<span class="smalltext">(',$txt['book_insert'],')</span>
			</div>
		
			
			<div class="configBloqs">
			<b>',$txt['favorite_place'],': </b>
            <input type="text" name="default_options[lugar]" size="50" value="', @$context['member']['options']['lugar'] ,'" />&nbsp;<span class="smalltext">(',$txt['favorite_place_insert'],')</span>
		    </div>
		
	
			
		
		
			<div class="configBloqs">
				<b>',$txt['favorite_movie'],': </b>
				<input type="text" name="default_options[pelicula]" size="50" value="', @$context['member']['options']['pelicula'] ,'" />&nbsp;<span class="smalltext">(',$txt['favorite_movie_insert'],')</span>
		</div>';
		
			
	
		template_profile_save();
		echo '											
	</table>
</div>
</div><!-- /cuentaR -->
</form>';
}
// template_perfil() -> editar perfil
function template_perfil(){
	global $context, $settings, $options, $scripturl, $modSettings, $txt, $db_prefix;
	
template_menu_editor();
echo'
<form action="', $scripturl, '?action=profile2" method="post" accept-charset="UTF-8" name="creator" id="creator" enctype="multipart/form-data">
<div id="cuentaR">
	<div class="box_title">
		',$txt['edit_my_profile'],'
	</div><!-- /box_title -->
	<div class="box_cuerpo">
		<table>
			<tr>
				<td width="40%">
					<b class="size11">', $txt[563], ':</b>
					<div class="smalltext">
						&#40;', $txt[565], '&#47;', $txt[564], '&#47;', $txt[566], '&#41;
					</div>
				</td>
				<td class="smalltext">
					<input type="text" name="bday2" size="2" maxlength="2" value="', $context['member']['birth_date']['day'], '" />
					<input type="text" name="bday1" size="2" maxlength="2" value="', $context['member']['birth_date']['month'], '" />
					<input type="text" name="bday3" size="4" maxlength="4" value="', $context['member']['birth_date']['year'], '" />
				</td>
			</tr>
			<tr>
				<td width="40%">
					<b>',$txt['country'],' </b>
				</td>
				<td>
					<select name="usertitle" id="usertitle">
						<option value="' . $context['member']['title'] . '">',nombre_pais($context['member']['title']),'</option>';
						foreach($context['paises'] as $p)
							echo'<option value="',$p['ID_PAIS'],'" ', ($context['member']['title'] == $p['ID_PAIS'] ? ' selected="selected"' : ''), '>',$p['nombre'],'</option>';
					echo'
					</select>
				</td>
			</tr>
			<tr>
				<td width="40%">
					<b>', $txt[227], ': </b>
				</td>
				<td>
					<input type="text" name="location" size="50" value="', $context['member']['location'], '" />
				</td>
			</tr>
			<tr>
				<td width="40%">
					<b>', $txt[231], ': </b>
				</td>
				<td>
					<select name="gender" size="1">
						<option value="1"', ($context['member']['gender']['name'] == 'm' ? ' selected="selected"' : ''), '>', $txt[238], '</option>
						<option value="2" ', ($context['member']['gender']['name'] == 'f' ? ' selected="selected"' : ''), '>', $txt[239], '</option>
					</select>
				</td>
			</tr>
			<tr>
				<td width="20%">
					<b>', $txt[228], ':</b><div class="smalltext">',$txt['under_avatar'],'</div>
				</td>
				<td>
					<input type="text" name="personalText" size="50" maxlength="70" value="', $context['member']['blurb'], '" />
				</td>
			</tr>
			<tr>
				<td width="20%">
					<b class="size11">', $txt['MSN'], ': </b><div class="smalltext">', $txt['smf237'], '</div>
				</td>
				<td>
					<input type="text" name="MSN" value="', $context['member']['msn']['name'], '" size="50" />
				</td>
			</tr>
			<tr>
				<td width="40%">
					<b>Pagina Web: </b>
				</td>
				<td>
					<input type="text" name="websiteTitle" size="50" value="', $context['member']['website']['title'], '" />
				</td>
			</tr>
			<tr>
				<td width="40%">
					<b>Mostrarme Online?: </b>
				</td>
				<td>
					Si <input type="radio" name="showOnline" value="1" ', ($context['member']['show_online'] == '1' ? ' checked="checked"' : ''), '>
					&nbsp;&nbsp;&nbsp;No <input type="radio" name="showOnline" value="0" ', ($context['member']['show_online'] == '0' ? ' checked="checked"' : ''), '>
				</td>
			</tr>';
	/*
	//firma
		if ($context['signature_enabled'])
		{
		echo '<tr><td width="20%"><b class="size11">', $txt[85], ':</b><div class="smalltext">(aparecera debajo tu post)</div></td><td>
										<textarea class="editor" onkeyup="calcCharLeft();" name="signature" rows="5" cols="50">', $context['member']['signature'], '</textarea></td></tr><tr><td></td>';}

	$firma = parse_bbc($context['member']['signature']);

	//firma
	echo'<td><div class="act_comments" style="margin-bottom:8px;">
	<div class="box_title" style="width: 363px;"><div class="box_txt box_363-34" style="margin-top:-5px;"><center>Firma</center></div></div>
	<div class="windowbg" style="width: 353px; padding: 4px;margin-top:-10px;">';
	if (!empty($context['member']['signature']) && empty($options['show_no_signatures']))
	echo'<b class="size11"><center>'.$firma.'</center></b>';
	else
	echo'<span class="size11"><center><img src="', $settings['images_url'], '/no-firma.png" alt="Usuario sin firma" border="0" /></center></span>';

		if ($context['signature_enabled'])
		{
		

		if (!empty($context['max_signature_length']))
			echo '
										<span class="smalltext">', $txt[664], ' <span id="signatureLeft">', $context['max_signature_length'], '</span></span>';

		echo '
										<script language="JavaScript" type="text/javascript"><!-- // --><![CDATA[
											function tick()
											{
												if (typeof(document.forms.creator) != "undefined")
												{
													calcCharLeft();
													setTimeout("tick()", 1000);
												}
												else
													setTimeout("tick()", 800);
											}

											function calcCharLeft()
											{
												var maxLength = ', $context['signature_limits']['max_length'], ';
												var oldSignature = "", currentSignature = document.forms.creator.signature.value;

												if (!document.getElementById("signatureLeft"))
													return;

												if (oldSignature != currentSignature)
												{
													oldSignature = currentSignature;

													if (currentSignature.replace(/\r/, "").length > maxLength)
														document.forms.creator.signature.value = currentSignature.replace(/\r/, "").substring(0, maxLength);
													currentSignature = document.forms.creator.signature.value.replace(/\r/, "");
												}

												setInnerHTML(document.getElementById("signatureLeft"), maxLength - currentSignature.length);
											}

											setTimeout("tick()", 800);
										// ]]></script>
									</td>
								</tr>';
								}
	*/
			template_profile_save();
		echo'
		</table>
	</div><!-- /box_cuerpo -->
</div><!-- /cuentasR -->';

	if (!empty($context['member']['avatar']['allow_server_stored']))
		echo '
			<script language="JavaScript" type="text/javascript"><!-- // --><![CDATA[
				var files = ["' . implode('", "', $context['avatar_list']) . '"];
				var avatar = document.getElementById("avatar");
				var cat = document.getElementById("cat");
				var selavatar = "' . $context['avatar_selected'] . '";
				var avatardir = "' . $modSettings['avatar_url'] . '/";
				var size = avatar.alt.substr(3, 2) + " " + avatar.alt.substr(0, 2) + String.fromCharCode(117, 98, 116);
				var file = document.getElementById("file");

				if (avatar.src.indexOf("blank.gif") > -1)
					changeSel(selavatar);
				else
					previewExternalAvatar(avatar.src)

				function changeSel(selected)
				{
					if (cat.selectedIndex == -1)
						return;

					if (cat.options[cat.selectedIndex].value.indexOf("/") > 0)
					{
						var i;
						var count = 0;

						file.style.display = "inline";
						file.disabled = false;

						for (i = file.length; i >= 0; i = i - 1)
							file.options[i] = null;

						for (i = 0; i < files.length; i++)
							if (files[i].indexOf(cat.options[cat.selectedIndex].value) == 0)
							{
								var filename = files[i].substr(files[i].indexOf("/") + 1);
								var showFilename = filename.substr(0, filename.lastIndexOf("."));
								showFilename = showFilename.replace(/[_]/g, " ");

								file.options[count] = new Option(showFilename, files[i]);

								if (filename == selected)
								{
									if (file.options.defaultSelected)
										file.options[count].defaultSelected = true;
									else
										file.options[count].selected = true;
								}

								count++;
							}

						if (file.selectedIndex == -1 && file.options[0])
							file.options[0].selected = true;

						showAvatar();
					}
					else
					{
						file.style.display = "none";
						file.disabled = true;
						document.getElementById("avatar").src = avatardir + cat.options[cat.selectedIndex].value;
						document.getElementById("avatar").style.width = "";
						document.getElementById("avatar").style.height = "";
					}
				}

				function showAvatar()
				{
					if (file.selectedIndex == -1)
						return;

					document.getElementById("avatar").src = avatardir + file.options[file.selectedIndex].value;
					document.getElementById("avatar").alt = file.options[file.selectedIndex].text;
					document.getElementById("avatar").alt += file.options[file.selectedIndex].text == size ? "!" : "";
					document.getElementById("avatar").style.width = "";
					document.getElementById("avatar").style.height = "";
				}

				function previewExternalAvatar(src)
				{
					if (!document.getElementById("avatar"))
						return;

					var maxHeight = ', !empty($modSettings['avatar_max_height_external']) ? $modSettings['avatar_max_height_external'] : 0, ';
					var maxWidth = ', !empty($modSettings['avatar_max_width_external']) ? $modSettings['avatar_max_width_external'] : 0, ';
					var tempImage = new Image();

					tempImage.src = src;
					if (maxWidth != 0 && tempImage.width > maxWidth)
					{
						document.getElementById("avatar").style.height = parseInt((maxWidth * tempImage.height) / tempImage.width) + "px";
						document.getElementById("avatar").style.width = maxWidth + "px";
					}
					else if (maxHeight != 0 && tempImage.height > maxHeight)
					{
						document.getElementById("avatar").style.width = parseInt((maxHeight * tempImage.width) / tempImage.height) + "px";
						document.getElementById("avatar").style.height = maxHeight + "px";
					}
					document.getElementById("avatar").src = src;
				}
			// ]]></script>';
echo'
</form>';
}

function template_avatar(){
	global $context, $settings, $options, $scripturl, $modSettings, $txt;
	echo'
<script>
function load_new_avatar()
{
	var f=document.forms.per;

	if(f.avatar.value.substring(0, 7)!="http://")
	{
		f.avatar.focus();
		alert("',$txt['alert_http'],'");
		return;
	}

	window.newAvatar = new Image();
	window.newAvatar.src = f.avatar.value;
	newAvatar.loadBeginTime = (new Date()).getTime();
	newAvatar.onerror = show_error;
	newAvatar.onload = show_new_avatar;
	avatar_check_timeout();
}

function avatar_check_timeout()
{
	if(((new Date()).getTime()-newAvatar.loadBeginTime)>15)
	{
		alert("',$txt['alert_avatar'],'");
		document.forms.per.avatar.focus();
	}
}

function show_error()
{
	alert("',$txt['alert_dir_image'],'");
	document.forms.per.avatar.focus();
}

function show_new_avatar()
{
	document.getElementById("miAvatar").src = newAvatar.src;
}
</script>';

template_menu_editor();

echo '
<form action="', $scripturl, '?action=profile2" method="post" accept-charset="UTF-8" name="creator" id="creator" enctype="multipart/form-data">

<div id="cuentaR">
<div class="box_title">',$txt['modify_avatar'],'</div>
<div class="box_cuerpo">
';
	
	
	// This is the avatar selection table that is only displayed if avatars are enabled!
	if (!empty($context['member']['avatar']['allow_server_stored']) || !empty($context['member']['avatar']['allow_upload']) || !empty($context['member']['avatar']['allow_external']))
	{
		// If users are allowed to choose avatars stored on the server show selection boxes to choice them from.
		if (!empty($context['member']['avatar']['allow_server_stored']))
		{
			echo '
						<div class="configBloqs">
										<input type="radio" name="avatar_choice" id="avatar_choice_server_stored" value="server_stored"', ($context['member']['avatar']['choice'] == 'server_stored' ? ' checked="checked"' : ''), ' class="check" />
									
											<b', (isset($context['modify_error']['bad_avatar']) ? ' style="color: red;"' : ''), '><label for="avatar_choice_server_stored">', $txt[229], ':</label></b>
											<div style="width: auto;"><center><img name="avatar" style="margin: 10px;padding:10px;" id="avatar" src="', !empty($context['member']['avatar']['allow_external']) && $context['member']['avatar']['choice'] == 'external' ? $context['member']['avatar']['external'] : $modSettings['avatar_url'] . '/blank.gif', '" alt="Do Nothing" /></center></div>
						
									
									
									';
			// This lists all the file catergories.
			foreach ($context['avatars'] as $avatar)
				echo '                     <option value="', $avatar['filename'] . ($avatar['is_dir'] ? '/' : ''), '"', ($avatar['checked'] ? ' selected="selected"' : ''), '>', $avatar['name'], '</option>';
			echo '
											<select name="file" id="file" size="10" style="display: none;" onchange="showAvatar()" onfocus="selectRadioByName(document.forms.creator.avatar_choice, \'server_stored\');" disabled="disabled"><option></option></select></div>
								';
		}

		// If the user can link to an off server avatar, show them a box to input the address.
		if (!empty($context['member']['avatar']['allow_external']))
		{
			echo '
							<div class="configBloqs">
										<input type="radio" name="avatar_choice" id="avatar_choice_external" value="external"', ($context['member']['avatar']['choice'] == 'external' ? ' checked="checked"' : ''), ' class="check" />
										', $txt[475], ':
									<input type="text" name="userpicpersonal" size="45" value="', $context['member']['avatar']['external'], '" onfocus="selectRadioByName(document.forms.creator.avatar_choice, \'external\');" onchange="if (typeof(previewExternalAvatar) != \'undefined\') previewExternalAvatar(this.value);" /></div>
							';
		}


	}							
		template_profile_save();
	echo '

</div>
</div><!-- /cuentasR -->';
			/* If the user is allowed to choose avatars stored on the server, the below javascript is used to update the
		file listing of avatars as the user changes catergory. It also updates the preview image as they choose
		different files on the select box. */
	if (!empty($context['member']['avatar']['allow_server_stored']))
		echo '
			<script language="JavaScript" type="text/javascript"><!-- // --><![CDATA[
				var files = ["' . implode('", "', $context['avatar_list']) . '"];
				var avatar = document.getElementById("avatar");
				var cat = document.getElementById("cat");
				var selavatar = "' . $context['avatar_selected'] . '";
				var avatardir = "' . $modSettings['avatar_url'] . '/";
				var size = avatar.alt.substr(3, 2) + " " + avatar.alt.substr(0, 2) + String.fromCharCode(117, 98, 116);
				var file = document.getElementById("file");

				if (avatar.src.indexOf("blank.gif") > -1)
					changeSel(selavatar);
				else
					previewExternalAvatar(avatar.src)

				function changeSel(selected)
				{
					if (cat.selectedIndex == -1)
						return;

					if (cat.options[cat.selectedIndex].value.indexOf("/") > 0)
					{
						var i;
						var count = 0;

						file.style.display = "inline";
						file.disabled = false;

						for (i = file.length; i >= 0; i = i - 1)
							file.options[i] = null;

						for (i = 0; i < files.length; i++)
							if (files[i].indexOf(cat.options[cat.selectedIndex].value) == 0)
							{
								var filename = files[i].substr(files[i].indexOf("/") + 1);
								var showFilename = filename.substr(0, filename.lastIndexOf("."));
								showFilename = showFilename.replace(/[_]/g, " ");

								file.options[count] = new Option(showFilename, files[i]);

								if (filename == selected)
								{
									if (file.options.defaultSelected)
										file.options[count].defaultSelected = true;
									else
										file.options[count].selected = true;
								}

								count++;
							}

						if (file.selectedIndex == -1 && file.options[0])
							file.options[0].selected = true;

						showAvatar();
					}
					else
					{
						file.style.display = "none";
						file.disabled = true;
						document.getElementById("avatar").src = avatardir + cat.options[cat.selectedIndex].value;
						document.getElementById("avatar").style.width = "";
						document.getElementById("avatar").style.height = "";
					}
				}

				function showAvatar()
				{
					if (file.selectedIndex == -1)
						return;

					document.getElementById("avatar").src = avatardir + file.options[file.selectedIndex].value;
					document.getElementById("avatar").alt = file.options[file.selectedIndex].text;
					document.getElementById("avatar").alt += file.options[file.selectedIndex].text == size ? "!" : "";
					document.getElementById("avatar").style.width = "";
					document.getElementById("avatar").style.height = "";
				}

				function previewExternalAvatar(src)
				{
					if (!document.getElementById("avatar"))
						return;

					var maxHeight = ', !empty($modSettings['avatar_max_height_external']) ? $modSettings['avatar_max_height_external'] : 0, ';
					var maxWidth = ', !empty($modSettings['avatar_max_width_external']) ? $modSettings['avatar_max_width_external'] : 0, ';
					var tempImage = new Image();

					tempImage.src = src;
					if (maxWidth != 0 && tempImage.width > maxWidth)
					{
						document.getElementById("avatar").style.height = parseInt((maxWidth * tempImage.height) / tempImage.width) + "px";
						document.getElementById("avatar").style.width = maxWidth + "px";
					}
					else if (maxHeight != 0 && tempImage.height > maxHeight)
					{
						document.getElementById("avatar").style.width = parseInt((maxHeight * tempImage.width) / tempImage.height) + "px";
						document.getElementById("avatar").style.height = maxHeight + "px";
					}
					document.getElementById("avatar").src = src;
				}
			// ]]></script>';
	echo '
		</form>';
}


function template_buddies(){

	global $context, $settings, $txt, $scripturl;

	echo '

	<div class="box_title">&nbsp;<img src="', $settings['images_url'], '/icons/profile_sm.gif" alt="" align="top" />&nbsp;
				<a href="', $scripturl ,'?action=profile;u=', $context['member']['id'] ,'">', $context['member']['name'] ,'</a> - ',$txt['friends'],'</div>
		<div class="box_cuerpo"><center>
		<table width="85%">
		<tr>
			<td style="padding-bottom: 2ex;">
				<table width="100%">';

	if (isset ($context['member']['buddies_data'])) {

		$i = 1;

		foreach ($context['member']['buddies_data'] as $buddy_id => $data) {

			if ($i == 1)

				echo '

					<tr>';

			echo '

						<td align="center">
							', $data['avatar_image'],'<br />
							<a href="', $scripturl , '?action=profile;u=', $data['ID_MEMBER'] , '">' , empty($context['member']['nombre']) ? $data['realName'] :  $context['member']['nombre'], '</a><br />

							<i>', $settings['use_image_buttons'] ? '<img src="' . $settings['images_url'] . '/buddy_' . ($data['is_online'] ? 'useron' : 'useroff') . '.gif' . '" alt="' . $txt[$data['is_online'] ? 'online2' : 'online3'] . '" align="middle" />' : $txt[$data['is_online'] ? 'online2' : 'online3'], $settings['use_image_buttons'] ? '<span class="smalltext"> ' . $txt[$data['is_online'] ? 'online2' : 'online3'] . '</span>' : '', '</i>
						</td>';
			if ($i == 3)
				echo '
					</tr>';
			
			$i++;
			if ($i == 4) $i = 1;
		}
	} else
		echo '			<tr><td>',$txt['no_friends'],'</td></tr>';
	echo '
				</table>
			</td>
		</tr>
	</table></center></div>';
}

function template_estado(){
        global $context, $settings, $options, $scripturl, $modSettings, $txt, $message;

	echo '
		<script language="JavaScript" type="text/javascript"><!-- // --><![CDATA[
			function checkProfileSubmit()
			{';
	if ($context['user']['is_owner'] && $context['require_password'])
		echo '
				// Did you forget to type your password?
				if (document.forms.creator.oldpasswrd.value == "")
				{
					alert();
					return false;
				}';

	if ($context['allow_edit_membergroups'] && $context['user']['is_owner'] && $context['member']['group'] == 1)
		echo '
				if (typeof(document.forms.creator.ID_GROUP) != "undefined" && document.forms.creator.ID_GROUP.value != "1")
					return confirm("', $txt['deadmin_confirm'], '");';

	echo '
				return true;
			}
		// ]]></script>';

template_menu_editor();

echo '
<form action="', $scripturl, '?action=profile2" method="post" accept-charset="UTF-8" name="creator" id="creator" enctype="multipart/form-data">

<div id="cuentaR">
<div class="box_title">',$txt['change_state'],'</div>
<div class="box_cuerpo">
	<table>
		<tr>
			<td width="20%"></td>
			<td>
				<b>',$txt['select_state'],': </b>
			</td>
			<td>
				<select name="default_options[bear_tab]" size="8">
					<option value="bar">',$txt['no_state'],'</option>
					<option value="mcontento">',$txt['very_happy_state'],'</option>
					<option value="contento">',$txt['happy_state'],'</option>
					<option value="sueno"> ',$txt['dream_state'],'</option>
					<option value="descansar">',$txt['resting_state'],'</option>
					<option value="triste">',$txt['sad_state'],'</option>
					<option value="enferm"> ',$txt['enf_state'],'</option>
					<option value="emusic"> ',$txt['music_state'],'</option>
				</select>
			</td>
			<td>
				<b> ',$txt['state_'],':</b>
				<option', @$context['member']['options']['bear_tab'] == 'bar' ? ' selected="selected"' : '', '>
				', !empty($context['member']['options']['bear_tab']) ? '
				<img alt="" title="' . $context['member']['options']['bear_tab'] . '" src="' . $settings['default_images_url'] . '/estado/' . $context['member']['options']['bear_tab'] . '.png"/>' : 
				'<img src="' . $settings['default_images_url'] . '/estado/na.png"/>', '
			</td>
		</tr>';
			template_profile_save();
	echo '											
	</table>
</div>
</div><!-- /cuentaR -->
</form>';
}

function template_deleteAccount(){
	global $context, $settings, $options, $scripturl, $txt;

	echo '
		<form action="', $scripturl, '?action=profile2" method="post" accept-charset="', $context['character_set'], '" name="creator" id="creator">
			<table border="0" width="85%" cellspacing="1" cellpadding="4" align="center" class="bordercolor">
				<tr class="titlebg">
					<td height="26">
						&nbsp;<img src="', $settings['images_url'], '/icons/profile_sm.gif" alt="" align="top" />&nbsp;
						', $txt['deleteAccount'], '
					</td>
				</tr>';
	if (!$context['user']['is_owner'])
	echo '
					<tr class="windowbg">
						<td class="smalltext" colspan="2" style="padding-top: 2ex; padding-bottom: 2ex;">
							', $txt['deleteAccount_desc'], '
						</td>
					</tr>';
	echo '
				<tr>
					<td class="windowbg2">
						<table width="100%" cellspacing="0" cellpadding="3"><tr>
							<td align="center" colspan="2">';
	if ($context['needs_approval'])
		echo '
								<div style="color: red; border: 2px dashed red; padding: 4px;">', $txt['deleteAccount_approval'], '</div><br />
							</td>
						</tr><tr>
							<td align="center" colspan="2">';

	// If the user is deleting their own account warn them first - and require a password!
	if ($context['user']['is_owner'])
	{
		echo '
								<span style="color: red;">', $txt['own_profile_confirm'], '</span><br /><br />
							</td>
						</tr><tr>
							<td class="windowbg2" align="', !$context['right_to_left'] ? 'right' : 'left', '">
								<b', (isset($context['modify_error']['bad_password']) || isset($context['modify_error']['no_password']) ? ' style="color: red;"' : ''), '>', $txt['smf241'], ': </b>
							</td>
							<td class="windowbg2" align="', !$context['right_to_left'] ? 'left' : 'right', '">
								<input type="password" name="oldpasswrd" size="20" />&nbsp;&nbsp;&nbsp;&nbsp;
								<input class="login" type="submit" value="', $txt[163], '" />
								<input type="hidden" name="sc" value="', $context['session_id'], '" />
								<input type="hidden" name="userID" value="', $context['member']['id'], '" />
								<input type="hidden" name="sa" value="', $context['menu_item_selected'], '" />
							</td>';
	}

	else
	{
		echo '
								<div style="color: red; margin-bottom: 2ex;">', $txt['deleteAccount_warning'], '</div>
							</td>
						</tr>';

		if ($context['can_delete_posts'])
			echo '
						<tr>
							<td colspan="2" align="center">
								', $txt['deleteAccount_posts'], ': <select name="remove_type">
									<option value="none">', $txt['deleteAccount_none'], '</option>
									<option value="posts">', $txt['deleteAccount_all_posts'], '</option>
									<option value="topics">', $txt['deleteAccount_topics'], '</option>
								</select>
							</td>
						</tr>';

		echo '
						<tr>
							<td colspan="2" align="center">
								<label for="deleteAccount"><input type="checkbox" name="deleteAccount" id="deleteAccount" value="1" class="check" onclick="if (this.checked) return confirm(\'', $txt['deleteAccount_confirm'], '\');" /> ', $txt['deleteAccount_member'], '.</label>
							</td>
						</tr>
						<tr>
							<td colspan="2" class="windowbg2" align="center" style="padding-top: 2ex;">
								<input class="login" type="submit" value="', $txt['smf138'], '" />
								<input type="hidden" name="sc" value="', $context['session_id'], '" />
								<input type="hidden" name="userID" value="', $context['member']['id'], '" />
								<input type="hidden" name="sa" value="', $context['menu_item_selected'], '" />
							</td>';
	}
	echo '
						</tr></table>
					</td>
				</tr>
			</table>
		</form>';
}
function template_profile_save(){
	global $context, $settings, $options, $txt;

	if ($context['user']['is_owner'] && $context['require_password'])
		echo '<b class="size11"', isset($context['modify_error']['bad_password']) || isset($context['modify_error']['no_password']) ? ' style="color: red;"' : '', '></b>
			<div class="smalltext">', $txt['smf244'], '</div>
			<input type="password" name="oldpasswrd" size="20" style="margin-right: 4ex;" />';

	echo'<div class="smalltext">', $txt['smf244'], '</div>
		
			<div class="configBloqs" style="float:right;"><input class="sp-button bluesky"  type="submit" value="',$txt['save_changes'],'" /></div>
			<input type="hidden" name="sc" value="', $context['session_id'], '" />
			<input type="hidden" name="userID" value="', $context['member']['id'], '" />
			<input type="hidden" name="sa" value="', $context['menu_item_selected'], '" />
			<input type="hidden" name="op" value="', $context['opcion'], '" />';
}

function template_profile_save2(){
	global $context, $txt;
	
	if($context['user']['is_owner'] && $context['require_password']){
		echo'
		<b class="size11"', isset($context['modify_error']['bad_password']) || isset($context['modify_error']['no_password']) ? ' style="color: red;"' : '', '>',$txt['pw_'],': </b>
		<div class="smalltext">
			', $txt['smf244'], '
		</div>
		<input type="password" name="oldpasswrd" size="20" style="margin-right: 4ex;" />';
	}
	else{
		echo '
		
		<input class="login" type="submit" value="Amigo" />
		<input type="hidden" name="default_options[Amigo]" size="20" value="', $context['member']['name'] ,'" /> 
		<input type="hidden" name="default_options[Amigoid]" size="5" value="', $context['member']['id'] ,'" />
		<input type="hidden" name="sc" value="', $context['session_id'], '" />
		<input type="hidden" name="userID" value="', $context['member']['id'], '" />';
	}
}

function template_error_message(){
	global $context, $txt;
	
	echo '
	<div class="windowbg" style="margin: 1ex; padding: 1ex 2ex; border: 1px dashed red; color: red;">
		<span style="text-decoration: underline;">', $txt['profile_errors_occurred'], ':</span>
			<ul>';
			foreach($context['post_errors'] as $error)
				echo '
				<li>', $txt['profile_error_' . $error], '.</li>';
			echo '
			</ul>
		</div>';
}

function restado($valor){
	$valor = str_replace("mcontento", "Muy Contento", $valor);
	$valor = str_replace("contento", "Contento", $valor);
	$valor = str_replace("sueno", "Con Sue&ntilde;o", $valor);
	$valor = str_replace("descansar", "Descansando", $valor);
	$valor = str_replace("triste", "Triste", $valor);
	$valor = str_replace("enferm", "Enfermo", $valor);
	$valor = str_replace("emusic", "Escuchando Musica", $valor);
	return $valor;
}

// op_muro() -> muro
function op_muro($memID){
	global $context, $settings, $scripturl, $txt, $db_prefix,$boardurl;
	
if(allowedTo('pcomments_view')){
	echo'
	<div class="murodecoment" style="margin-left:20px;width:100%;float:left;">
		<div id="coment_load" class="displayN">
			<img src="', $settings['images_url']  ,'/loading.gif" />
		</div>
	</div><!-- /murodecoment -->
	
	<div id="coment_previa"></div>
	
	<form method="POST" name="cprofile" id="cprofile" action="'.$scripturl.'?action=comment&sa=add2">
		<table id="coment_muro" width="100%" style="float:left;">
			<tr>
				<td>';
					$u = $context['member']['id'];
					$dbresult = db_query("SELECT avatar 
					FROM {$db_prefix}members 
					WHERE ID_MEMBER = ".$context['user']['id'], __FILE__, __LINE__);
					$row = mysql_fetch_assoc($dbresult);
					mysql_free_result($dbresult);
					$avatar = $row['avatar'];
				echo'
				</td>
			</tr>
			<tr>
				<td>
					<div class="alignC">
						<center><textarea placeholder="',$txt['muro_set_coment'],'" class="markItUpEditor" id="markItUp" name="comment" style="height:100px;"></textarea></center>
					</div>';
					$request = db_query("SELECT code, filename, description, smileyRow, hidden
					FROM {$db_prefix}smileys
					WHERE hidden IN (0, 2)
					ORDER BY smileyRow, smileyOrder", __FILE__, __LINE__);
					while ($row = mysql_fetch_assoc($request)){
						$row['code'] = htmlspecialchars($row['code']);
						$row['filename'] = htmlspecialchars($row['filename']);
						$row['description'] = htmlspecialchars($row['description']);
						$context['smileys'][empty($row['hidden']) ? 'postform' : 'popup'][$row['smileyRow']]['smileys'][] = $row;
					}
					mysql_free_result($request);
					echo'
					<div id="smilieclosed" style="display:none;float:left;width:100%;text-align:center;">';
						if(!empty($context['smileys']['postform'])){
							foreach($context['smileys']['postform'] as $smiley_row){
								foreach($smiley_row['smileys'] as $smiley){
									echo'
									<a href="javascript:void(0);" onclick="replaceText(\' ', $smiley['code'], '\', document.forms.cprofile.markItUp); return false;">
										<img src="'.$settings['images_url'].'/Smileys/default/', $smiley['filename'], '" align="bottom" alt="', $smiley['description'], '" title="', $smiley['description'], '" />
									</a> ';
								}
							}
							if(!empty($context['smileys']['popup']))
							echo'
								<script type="text/javascript">
									function openpopup(){
										var winpops=window.open("'.$boardurl.'/Web/otros/emoticones.php","","width=255px,height=500px,scrollbars");
									}
								</script>
								<a href="javascript:openpopup()">
									',$txt['muro_more'],'
								</a>';
						}
					echo'
					</div><!-- /smilieclosed -->
				</td>
			</tr>
			<tr>
				<td colspan="2" height="26" align="center">
					<input type="hidden" name="userid" value="', $u , '" />
					<input type="hidden" name="avatar" value="', $avatar , '" />';
					//Check if comments are autoapproved
					if(allowedTo('pcomments_autocomment') == false)
						echo $txt['pcomments_text_commentwait'] . '<br />';
					if($context['show_spellchecking'])
						echo'<input type="button" value="', $txt['spell_check'], '" onclick="spellCheck(\'cprofile\', \'comment\');" />';

					echo'
					<script type="text/javascript">
						$(\'#markItUp\').click(function(){
							$(\'#smilieclosed\').slideDown(\'slow\');
						});
					</script>
					<input class="button" onclick="javascript:add_cperfil(this.form.avatar.value,this.form.comment.value,this.form.userid.value,1,0);" type="button" value="Comentar" style="cursor:pointer;" name="submit" />
				</td>
			</tr>
		</table>
	</form>';

	$context['start'] = (int) $_REQUEST['start'];

	$dbresult = db_query("SELECT COUNT(*) AS total 
	FROM {$db_prefix}profile_comments 
	WHERE COMMENT_MEMBER_ID = " . $context['member']['id'] . "
	AND approved = 1", __FILE__, __LINE__);
	$row = mysql_fetch_assoc($dbresult);
	mysql_free_result($dbresult);
	$total = $row['total'];

	if($context['user']['is_logged']){
		// Loop though all the comments
		$dbresult = db_query("SELECT p.ID_COMMENT, p.ID_MEMBER, p.comment, p.subject, p.date, m.realName, m.avatar, p.COMMENT_MEMBER_ID
		FROM smf_profile_comments as p
		LEFT JOIN smf_members AS m ON (p.ID_MEMBER = m.ID_MEMBER)
		WHERE  p.COMMENT_MEMBER_ID = " . $context['member']['id'] . " AND p.approved = 1 ORDER BY p.ID_COMMENT DESC  LIMIT $context[start],5", __FILE__, __LINE__);
		$comment_count = db_affected_rows();
		while ($row = mysql_fetch_assoc($dbresult)){
			echo'
			<table style="border-top:1px solid #E9E9E9;margin-top:5px;" width="98%">
				<tr>
					<td align="left" valign="top">	
						<a href="'.$scripturl.'?action=profile;u='.$row['ID_MEMBER'].'">
							<img class="muro_avatar" src="'.$row['avatar'].'" align="top" width="50" height="50" />
						</a>
					</td>
					<td align="left" valign="top" style="width:700px;">';
						$muromember = $row['ID_MEMBER'];
						$dbresult33 = db_query("SELECT realName
						FROM {$db_prefix}members
						WHERE ID_MEMBER = '$muromember'
						LIMIT 1", __FILE__, __LINE__);
						while ($row2 = mysql_fetch_assoc($dbresult33)){
							$nick = $row2['realName'];
						}
						mysql_free_result($dbresult33);
						echo'
						<a style="color:#1B90EB;font-weight:bold;" href="',amigables_profile($row['realName']),'">
							'.$nick.'
						</a>';
						//Botones editar, eliminar
						echo'
						<div style="float:right">&nbsp;';
							if(allowedTo('pcomments_edit_any') || (allowedTo('pcomments_edit_own') && $context['user']['is_owner'])){
								echo'
								<a href="',$scripturl,'/?action=comment;sa=edit;id='.$row['ID_COMMENT'].'">
									<span title="',$txt['muro_coment_edit'],'" class="iconmuro edit">&nbsp;</span>
								</a>';
							}
							if(allowedTo('pcomments_delete_any') || (allowedTo('pcomments_delete_own') && $context['user']['is_owner'])){
								echo '&nbsp;
								<a href="',$scripturl,'/?action=comment;sa=delete;id='.$row['ID_COMMENT'].'">
									<span title="',$txt['muro_coment_delete'],'" class="iconmuro delete">&nbsp;</span>
								</a>';
							}
						echo'
						</div>
						<br />
						<div class="muro_coment',$row['ID_COMMENT'],'">
							',parse_bbc(parse_video($row['comment'],$row['ID_COMMENT'])),'
						</div>
						<br />
					</td>
				</tr>
				<tr>
					<td>&nbsp;</td>
					<td align="left" valign="top">
						&nbsp; 
						<span class="iconmuro coment">&nbsp;</span> &middot; <span style="color:#767676;">',howlong($row['date']),'</span> &middot; <a style="cursor:pointer;" onclick="javascript:opensc(',$row['ID_COMMENT'],');"><span style="color:#2B97CF;">',$txt['muro_coment'],'</span></a>';
						//subcoments    
						$dbresult2 = db_query("SELECT p.ID_SC, p.ID_MEMBER, p.COMMENT, p.ID_PROFILE_COMMENT , p.DATE, m.realName, m.avatar
						FROM smf_profile_subcomments as p
						LEFT JOIN smf_members AS m ON (p.ID_MEMBER = m.ID_MEMBER)
						WHERE  p.ID_PROFILE_COMMENT = " . $row['ID_COMMENT'] . "
						ORDER BY p.DATE ASC", __FILE__, __LINE__);
						$subcoments_cant = db_affected_rows();
						$ban=true;
						while($sc = mysql_fetch_assoc($dbresult2)){
							$style_sc='';
							if($subcoments_cant > 2){
								$subcoments_cant--;
								if($ban){
									echo'
									<br />
									<div class="subcoment_display" id="link',$row['ID_COMMENT'],'">
										<a style="cursor:pointer;" onclick="javascript:mostrar_sc(',$row['ID_COMMENT'],');">
											<span class="iconmuro add">&nbsp;</span>
											Ver los ',$subcoments_cant+1,' comentarios
										</a>
									</div>';
									echo'<div id="ocultar_sc',$row['ID_COMMENT'],'" style="display:none;"></div>';
								}
								$ban=false;
							}
							echo'
								<div id="subcoment_delete',$sc['ID_SC'],'" ></div>
								<div id="coment_load3',$sc['ID_SC'],'" style="display:none;float:left;">
									<img src="', $settings['images_url']  ,'/loading.gif" />
								</div>
								<div id="subcoment',$sc['ID_SC'],'" class="subcoment_display">
									<div onclick="javascript:add_cperfil(0,0,0,3,',$sc['ID_SC'],');" class="delete_sc">x</div>
									<table width="70%">
										<tr>
											<td width="30px" valign="top">
												<img src="',$sc['avatar'],'" width="30px" height="30px;" />
											</td>
											<td valign="top">
												<a style="color:#1B90EB;font-weight:bold;" href="'.$scripturl.'?action=profile;u='.$sc['ID_MEMBER'].'">
													',$sc['realName'],'
												</a>           
												',parse_bbc(parse_video($sc['COMMENT'],$sc['ID_SC'])),'
												<br />
												<span style="color:#767676;">
													',howlong($sc['DATE']),'
												</span>
											</td>
										</tr>
									</table>
								</div><!-- /subcoment',$sc['ID_SC'],' -->';
						}
						//comentar subcomentario
						echo'
						<div id="coment_load2',$row['ID_COMMENT'],'" style="display:none;">
							<img src="', $settings['images_url']  ,'/loading.gif" />
						</div>
						<div id="subcoment_previa',$row['ID_COMMENT'],'"></div>
						<div id="box_sc',$row['ID_COMMENT'],'" style="display:none;background:#EDEFF4;padding:5px;width:95%;border-top:1px solid #E9E9E9;">
							<form action="#" method="POST" name="subcoment">
								<table width="70%">
									<tr>
										<td width="30px">
											<img src="',$avatar,'" width="30px" height="30px;" />
										</td>
										<td>
											<textarea id="muro_textarea" name="subcoment"></textarea>
										</td>
									</tr>
									<tr>
										<td>&nbsp;</td>
										<td>
											<div class="floatR">
												<input type="hidden" name="userid" value="', $u , '" />
												<input type="hidden" name="avatar" value="', $avatar , '" />
												<input class="button" onclick="javascript:add_cperfil(this.form.avatar.value,this.form.subcoment.value,this.form.userid.value,2,',$row['ID_COMMENT'],');" type="button" value="Comentar" />
											</div>
										</td>
									</tr>
								</table>
							</form>
						</div><!-- /box_sc',$row['ID_COMMENT'],' -->
					</td>
				</tr>
			</table>
			<br />';
		}

		if($total > 0){     
			$context['page_index'] = constructPageIndex($scripturl . '?action=profile;op=muro;u=' . $context['member']['id'] , $_REQUEST['start'], $total, 5);
			echo $context['page_index'];
			echo '<br />';
		}

		if($total==0){
			echo'<br /><div class="clearfix"></div><span id="nocoment"><div class="titlep"><b>',$txt['muro_coment_no'],'</b></div></span><br />';
		}
	}
}
else{
	echo'<div class="info_box alignC" style="width:98%"><b>',$txt['muro_priv'],'</b></div>';
}

echo'
<script type="text/javascript">
	function opensc(id){
		$(\'#box_sc\'+id).slideDown(\'slow\');
	}
</script>';
}

// op_caracteristicas() -> caracteristicas
function op_caracteristicas($memID){
	global $context, $settings, $options, $scripturl, $modSettings, $txt, $db_prefix;
	
//imagen del rango
$context['medallagrupo'] = array();
$result = db_query("SELECT groupName, stars
FROM {$db_prefix}membergroups
ORDER BY groupName ASC
", __FILE__, __LINE__);
while ($row = mysql_fetch_assoc($result)){
	$context['medallagrupo'][] = array(
		'stars' => $row['stars'], 
		'groupName' => $row['groupName']
	);
}
foreach($context['medallagrupo'] as $grupo){
	if($context['member']['post_group'] == $grupo['groupName']){
		$starmedalla = $grupo['stars'];
	}
}

$starmedalla = substr($starmedalla, 2);

$noimg = $context['member']['name'] . $txt['no_image_gallery'];
$nopost = $context['member']['name'] . $txt['no_post'];
$iduser = $context['member']['id'];

// aca marca los comentarios de los usuarios
$request = db_query("SELECT id_coment
FROM {$db_prefix}comentarios
WHERE id_user = '$iduser'
", __FILE__, __LINE__);
$context['comentuser'] = mysql_num_rows($request);


//Datos del usuario li!
echo'		<div class="titlep2">',$txt['caract'],' ',$context['member']['name'],'</div>
			
		<div class="box-info" style="width:305px;float:left;margin-top:3px;">	
			<li>
			', $context['member']['group_stars'], ' <b>Rango:</b> <span class="fR">',$context['member']['group'],' - ',$context['member']['post_group'],'</span>
			</li>
			<li>
			<img src="', $settings['images_url']  ,'/puntos.png" /> <b>Puntos:</b> <span class="fR">', $context['member']['money'], '</span>
			</li>
			<li>
			<img src="', $settings['images_url']  ,'/mensajes.gif" /> <a href="',amigables_profile2($context['member']['name'], 'posts'),'"><b>',$txt['posts'],'</b> </a> <span class="fR">', $context['member']['topics'], '</span>
			</li>
			<li>
			<img src="', $settings['images_url']  ,'/stats_board.gif" /> <a href="',amigables_profile2($context['member']['name'], 'comentarios'),'"><b>',$txt['comments'],'</b></a> <span class="fR">',$context['comentuser'], '</span>
			</li>
			<li>
			<img src="', $settings['images_url']  ,'/icons/icono-foto.gif" /> <a href="',amigables_profile2($context['member']['name'], 'galeria'),'"><b>',$txt['imagesx'],'</b></a> <span class="fR">', $context['fotos'], '</span>
			</li>
			<li>
			<img src="', $settings['images_url']  ,'/icons/calendar.gif" /> <b>',$txt['user_time'],'</b> <span class="fR">', $context['member']['registered'], '</span>
			</li>
			<li>
			<img src="', $settings['images_url']  ,'/icons/monitor.png" />&nbsp;<b>', $txt['lastLoggedIn'], ':</b> <span class="fR">', $context['member']['last_login'],'</span>';
			if(!empty($context['activate_message']) || !empty($context['member']['bans'])){
				if(!empty($context['activate_message']))
					echo'<br /><span style="color: red;">', $context['activate_message'], '</span>&nbsp;(<a href="'.$scripturl.'?action=profile2;sa=activateAccount;userID='.$context['member']['id'].';sesc='.$context['session_id'].'" ', ($context['activate_type'] == 4 ? 'onclick="return confirm(\'' . $txt['profileConfirm'] . '\');"' : ''), '>', $context['activate_link_text'], '</a>)';
				if(!empty($context['member']['bans'])){
					echo'<br /><span style="color: red;"><div class="alignC"><img title="', $txt['user_is_banned'], '" alt="', $txt['user_is_banned'], '" src="', $settings['images_url']  ,'/icons/show_sticky.gif" /> ', $txt['user_is_banned'], '</div></span><br />';
				}
			}
		echo'
		</li>
		</div>
		
			<div class="box-info" style="float:left;width:305px;margin-left:5px;margin-top:3px;">	
			</li>
			<li>
			<b><img src="'.$settings['images_url'].'/icons/comosoy.png" /> <span class="fR" style="color:#3778C9;">',$txt['appearance'],':</span></b>
			</li>
			<li>
			<b>',$txt['stature'],':</b><span class="fR">', $context['member']['options']['altura'] ,' ',$txt['cm'],'</span>
			</li>
			<li>
			<b>',$txt['weight'],':</b> <span class="fR">', $context['member']['options']['peso'] ,' ',$txt['kg'],'</span>
			</li>
			<li>
			<b>',$txt['physical'],':</b><span class="fR"> ', $context['member']['options']['fisico'] ,'</span>
			</li>
			<li>
			<b>',$txt['hair'],':</b><span class="fR"> ', @$context['member']['options']['cabello'] ,'</span>
			</li>
			<li>
			<b>',$txt['eyes'],':</b> <span class="fR">', @$context['member']['options']['ojos'] ,'</span>
			</li>
			<li>
			<b>',$txt['color_skin'],':</b> <span class="fR">', @$context['member']['options']['colorpiel'] ,'</span>
			</li>
			<br /><br />
			</div>
			
			
			<div class="box-info" style="width:626px;float:left">	
			<b class="size14"><img src="', $settings['images_url']  ,'/icons/interes.png" /> <span style="color:#3778C9;">',$txt['interests'],':</span></b>
			
			<li>
			<b>',$txt['i_like'],':</b> ', @$context['member']['options']['gustar'] ,'
			</li>
			<li>
			<b>',$txt['favorite_band'],':</b> ', @$context['member']['options']['banda'] ,'
			</li>
			<li>
			<b>',$txt['hobbie'],':</b> ', @$context['member']['options']['hobbie'] ,'
			</li>
			<li>
			<b>',$txt['sport'],':</b> ', @$context['member']['options']['deporte'] ,'
			</li>
			<li>
			<b>',$txt['eq'],':</b> ', @$context['member']['options']['equipo'] ,'
			</li>
			<li>
			<b>',$txt['favorite_food'],':</b> ', @$context['member']['options']['comida'] ,'
			</li>
			<li>
			<b>',$txt['book'],':</b> ', @$context['member']['options']['libro'] ,'
			</li>
			<li>
			<b>',$txt['favorite_place'],':</b> ', @$context['member']['options']['lugar'] ,'
			</li>
			<li>
			<b>',$txt['favorite_movie'],':</b> ', @$context['member']['options']['pelicula'] ,'
			</li>
			
		</div>';
}

// op_posts() -> ultimos posts
function op_posts($memID){
	global $txt, $user_info, $scripturl, $modSettings, $db_prefix;
	global $context, $user_profile, $ID_MEMBER, $sourcedir;
	global $settings, $options;
	
	if (!empty($context['load_average']) && !empty($modSettings['loadavg_show_posts']) && $context['load_average'] >= $modSettings['loadavg_show_posts'])
		fatal_lang_error('loadavg_show_posts_disabled', false);
	if (empty($_REQUEST['viewscount']) || !is_numeric($_REQUEST['viewscount']))
		$_REQUEST['viewscount'] = '10';
	if ($modSettings['totalMessages'] > 100000 && $user_profile[$memID]['posts'] > 100){
		db_query("DROP TABLE IF EXISTS {$db_prefix}topics_posted_in", false, false);
		$have_temp_table = db_query("
			CREATE TEMPORARY TABLE {$db_prefix}topics_posted_in (
				PRIMARY KEY (ID_TOPIC)
			)
			SELECT ID_TOPIC, ID_BOARD
			FROM {$db_prefix}messages
			WHERE ID_MEMBER = $memID
			GROUP BY ID_TOPIC", false, false);
	}

	$request = db_query("SELECT COUNT(m.ID_MSG)
	FROM ({$db_prefix}messages AS m, {$db_prefix}topics AS t, {$db_prefix}boards AS b)
	WHERE m.ID_MEMBER = $memID
	AND t.ID_TOPIC = m.ID_TOPIC
	AND b.ID_BOARD = t.ID_BOARD
	AND t.ID_FIRST_MSG = m.ID_MSG
	AND $user_info[query_see_board]", __FILE__, __LINE__);
	list ($msgCount) = mysql_fetch_row($request);
	mysql_free_result($request);
	$maxIndex = isset($_REQUEST['view']) && $_REQUEST['view'] == 'all' ? $msgCount : 50;
	$context['page_index'] = constructPageIndex(''. $scripturl .'/?action=profile;u=' . $memID . ';sa=post', $_REQUEST['start'], $msgCount, $maxIndex);
	$context['start'] = $_REQUEST['start'];
	$context['current_page'] = $context['start'] / $maxIndex;
	$context['current_member'] = $memID;

	$context['page_title'] = $txt[18];

	$request = db_query("SELECT b.ID_BOARD, b.name AS bname, t.puntos, c.ID_CAT, c.name AS cname, m.ID_TOPIC, m.ID_MSG,
	t.ID_MEMBER_STARTED, t.ID_FIRST_MSG, t.ID_LAST_MSG, m.body, m.smileysEnabled, m.subject, m.posterTime
	FROM (" . (empty($have_temp_table) ? '' : "{$db_prefix}topics_posted_in AS pi, ") . "{$db_prefix}messages AS m, {$db_prefix}topics AS t, {$db_prefix}boards AS b)
		LEFT JOIN {$db_prefix}categories AS c ON (c.ID_CAT = b.ID_CAT)
	WHERE " . (empty($have_temp_table) ? '' : "t.ID_TOPIC = pi.ID_TOPIC
	AND ") . "m.ID_MEMBER = $memID
	AND m.ID_TOPIC = t.ID_TOPIC
	AND t.ID_BOARD = b.ID_BOARD
	AND $user_info[query_see_board]
	AND t.ID_FIRST_MSG = m.ID_MSG
	ORDER BY m.ID_MSG DESC
	LIMIT $_REQUEST[start], $maxIndex", __FILE__, __LINE__);
	$counter = $_REQUEST['start'];
	$context['posts'] = array();
	$board_ids = array('own' => array(), 'any' => array());
	while($row = mysql_fetch_assoc($request)){
		censorText($row['subject']);
		$context['posts'][++$counter] = array(
			'counter' => $counter,
			'board' => array(
			'name' => $row['bname'],
			'id' => $row['ID_BOARD']),
			'topic' => $row['ID_TOPIC'],
			'subject' => $row['subject'],
			'time' => timeformat($row['posterTime']),
			'id' => $row['ID_MSG'],
			'puntos' => $row['puntos']
		);
	}
	mysql_free_result($request);
	
	echo'<div class="titlep2">',$txt['postst'],' ',$context['member']['name'],'</div>
	<div class="box-info" style="width:647px;margin-top:3px;">';
	
	if(!empty($context['posts'])){
	
		foreach ($context['posts'] as $post){
			echo'
				
			<li>
			<img title="'.$post['board']['name'].'" src="'.$settings['images_url'].'/post/icono_'.$post['board']['id'].'.gif" />&nbsp;<a href="'.amigables_post($post['topic']),'" >'.$post['subject'].'</a>
					
			<span class="fR">',$txt['created'],': ', $post['time'],' | ', $post['puntos'],' pts. | <a title="',$txt['send_friend'],'" href="'.$scripturl.'?action=enviar-a-amigo;topic=', $post['id'],'"><img src="', $settings['images_url']  ,'/icons/icono-enviar-mensaje.gif" align="absmiddle" /></a>
					</span></li>
					';
		}
	}
	else{
		echo'
		<br /><br />
		<div class="alignC">
			<b>', $context['member']['name'], '</b> ',$txt['no_postx'],'
		</div>
		<br /><br />';
	}
	echo'</div>';
}

// op_posts() -> ultimos posts bloque
function op_posts2($memID){
	global $txt, $user_info, $scripturl, $modSettings, $db_prefix;
	global $context, $user_profile, $ID_MEMBER, $sourcedir;
	global $settings, $options;
	
	if (!empty($context['load_average']) && !empty($modSettings['loadavg_show_posts']) && $context['load_average'] >= $modSettings['loadavg_show_posts'])
		fatal_lang_error('loadavg_show_posts_disabled', false);
	if (empty($_REQUEST['viewscount']) || !is_numeric($_REQUEST['viewscount']))
		$_REQUEST['viewscount'] = '10';
	if ($modSettings['totalMessages'] > 100000 && $user_profile[$memID]['posts'] > 100){
		db_query("DROP TABLE IF EXISTS {$db_prefix}topics_posted_in", false, false);
		$have_temp_table = db_query("
			CREATE TEMPORARY TABLE {$db_prefix}topics_posted_in (
				PRIMARY KEY (ID_TOPIC)
			)
			SELECT ID_TOPIC, ID_BOARD
			FROM {$db_prefix}messages
			WHERE ID_MEMBER = $memID
			GROUP BY ID_TOPIC", false, false);
	}

	$request = db_query("SELECT COUNT(m.ID_MSG)
	FROM ({$db_prefix}messages AS m, {$db_prefix}topics AS t, {$db_prefix}boards AS b)
	WHERE m.ID_MEMBER = $memID
	AND t.ID_TOPIC = m.ID_TOPIC
	AND b.ID_BOARD = t.ID_BOARD
	AND t.ID_FIRST_MSG = m.ID_MSG
	AND $user_info[query_see_board]", __FILE__, __LINE__);
	list ($msgCount) = mysql_fetch_row($request);
	mysql_free_result($request);
	$maxIndex = isset($_REQUEST['view']) && $_REQUEST['view'] == 'all' ? $msgCount : 50;
	$context['page_index'] = constructPageIndex(''. $scripturl .'/?action=profile;u=' . $memID . ';sa=post', $_REQUEST['start'], $msgCount, $maxIndex);
	$context['start'] = $_REQUEST['start'];
	$context['current_page'] = $context['start'] / $maxIndex;
	$context['current_member'] = $memID;

	$context['page_title'] = $txt[18];

	$request = db_query("SELECT b.ID_BOARD, b.name AS bname, t.puntos, c.ID_CAT, c.name AS cname, m.ID_TOPIC, m.ID_MSG,
	t.ID_MEMBER_STARTED, t.ID_FIRST_MSG, t.ID_LAST_MSG, m.body, m.smileysEnabled, m.subject, m.posterTime
	FROM (" . (empty($have_temp_table) ? '' : "{$db_prefix}topics_posted_in AS pi, ") . "{$db_prefix}messages AS m, {$db_prefix}topics AS t, {$db_prefix}boards AS b)
		LEFT JOIN {$db_prefix}categories AS c ON (c.ID_CAT = b.ID_CAT)
	WHERE " . (empty($have_temp_table) ? '' : "t.ID_TOPIC = pi.ID_TOPIC
	AND ") . "m.ID_MEMBER = $memID
	AND m.ID_TOPIC = t.ID_TOPIC
	AND t.ID_BOARD = b.ID_BOARD
	AND $user_info[query_see_board]
	AND t.ID_FIRST_MSG = m.ID_MSG
	ORDER BY m.ID_MSG DESC
	LIMIT $_REQUEST[start], $maxIndex", __FILE__, __LINE__);
	$counter = $_REQUEST['start'];
	$context['posts'] = array();
	$board_ids = array('own' => array(), 'any' => array());
	while($row = mysql_fetch_assoc($request)){
		censorText($row['subject']);
		$context['posts'][++$counter] = array(
			'counter' => $counter,
			'board' => array(
			'name' => $row['bname'],
			'id' => $row['ID_BOARD']),
			'topic' => $row['ID_TOPIC'],
			'subject' => $row['subject'],
			'time' => timeformat($row['posterTime']),
			'id' => $row['ID_MSG'],
			'puntos' => $row['puntos']
		);
	}
	mysql_free_result($request);
	
	echo'<div class="m10">';
	
	if(!empty($context['posts'])){
	
		foreach ($context['posts'] as $post){
			echo'
				
			<li>
			<img title="'.$post['board']['name'].'" src="'.$settings['images_url'].'/post/icono_'.$post['board']['id'].'.gif" />&nbsp;<a href="'.amigables_post($post['topic']),'" >'.quitarc($post['subject']).'</a>
					
			</li>
					';
		}
	}
	else{
		echo'
		
		<div class="titlep">
			', $context['member']['name'], '</b> ',$txt['no_postx'],'
		</div>
		';
	}
	echo'</div>';
}

// op_comentarios() -> ultimos comentarios
function op_comentarios($memID){
	global $context, $settings, $scripturl, $txt, $db_prefix;

	$context['page_title'] = $txt[18];
	$looped = false;
	while(true){
		$request = db_query("SELECT c.id_post, c.id_coment, c.comentario, c.fecha, m.subject, m.ID_TOPIC, c.id_user, m.ID_BOARD 
		FROM ({$db_prefix}comentarios AS c, {$db_prefix}messages AS m)
		WHERE c.id_post = m.ID_TOPIC AND c.id_user = $memID
		ORDER BY c.id_coment DESC
		LIMIT 50", __FILE__, __LINE__);
		if(mysql_num_rows($request) === $maxIndex || $looped)
			break;
		$looped = true;
		$range_limit = '';
	}
	$counter = $reverse ? $context['start'] + $maxIndex + 1 : $context['start'];
	$board_ids = array('own' => array(), 'any' => array());
	$context['cposts'] = array();
	while ($row = mysql_fetch_assoc($request)){
		censorText($row['subject']);
		censorText($row['body']);
		$context['cposts'][] = array(
			'id_coment' => $row['id_coment'],
			'subject' => $row['subject'],
			'ID_TOPIC' => $row['ID_TOPIC'],
			'posterTime' => $row['fecha'],
			'body' => $row['comentario'],
			'ID_BOARD' => $row['ID_BOARD']
		);
	}
	mysql_free_result($request);
	echo'<div class="titlep2">',$txt['comentst'],' de ',$context['member']['name'],'</div>
	<div class="box-info" style="width:647px;margin-top:3px;">';
	if(!empty($context['cposts'])){
		foreach($context['cposts'] as $cpost){
			echo'<li>
			
						<img title="" src="', $settings['images_url']  ,'/post/icono_'.$cpost['ID_BOARD'].'.gif" />
					
							<a href="'.amigables_post($cpost['ID_TOPIC']),'" title="'.$cpost['subject'].'">
								'.$cpost['subject'].'
							</a>
						
						<a href="'.amigables_post($cpost['ID_TOPIC']),'#cmt_', $cpost['id_coment'], '" title="'.$cpost['body'].'">
							'.$cpost['body'].'
						</a></li>
					';
		}
		if($context['page_index']){
			echo'
			<div class="box_icono" style="width: 100%">
				<div class="alignC">
					', $context['page_index'], '
				</div>
			</div>';
		}
	}
	else{
		echo'
		<br /><br />
		<div class="alignC">
			<b>', $context['member']['name'], '</b> ',$txt['no_comments'],'
		</div>
		<br /><br />';
	}
	echo'</div>';
}


// op_ref() -> referidos
function op_ref($memID){
	global $context, $settings, $txt;
	
	echo'<div class="titlep2">',$txt['referst'],' ',$context['member']['name'],'</div>
	<div class="box-info" style="width:647px;margin-top:3px;">';
	echo'
	<li>
	<img src="', $settings['images_url']  ,'/icons/ref_cant.png" />&nbsp;', $txt['referrals_referrals'], '</b> ', $context['member']['referrals_no'],'<br />
				';
								// referidos de mi cuenta
								if (!empty($context['member']['referred_members'])){
									foreach($context['member']['referred_members'] as $referred)
										echo $referred,'<hr />';
								}
							
				//fue referido por?
				if(!empty($context['member']['referred_by']))
					echo'<div class="info_box">&nbsp;<img src="', $settings['images_url']  ,'/icons/ref_por.png" />&nbsp;<b>', $txt['referrals_referred_by'], '</b> ', $context['member']['referred_by_link'], ' ', howlong($context['member']['referred_on']), '</div>';
			echo'
			</li></div>';    
}

// op_galeria() -> ultimas imagenes
function op_galeria($memID){
	global $context, $settings, $scripturl, $txt;
	
	$noimg = $context['member']['name'] . $txt['no_image_gallery'];
	
	echo'<div class="titlep2">',$txt['imagest'],' ',$context['member']['name'],'</div>
	
	<div class="box-info" style="width:647px;margin-top:3px;">';
	
	if ($context['img']){
		foreach($context['img'] as $img){
			echo'<a style="margin-left:2px;" href="', $scripturl, '?action=imagenes;sa=ver;id=' . $img['id'] . '" class="tooltip" title="' . $img['commenttotal'] . ' ',$txt['commentsx'],'"><img src="' . $img['filename'] . '" width="115" height="100" /></a>';
		}
		echo'<hr /><div align="center">&nbsp;<img src="', $settings['images_url']  ,'/icons/images.png" />&nbsp;<a href="', $scripturl, '?action=imagenes&usuario=', $context['member']['name'], '">',$txt['go_to_gallery'],'</a>';
	}
	else {
		echo'<br /><div class="alignC"><img title="',$noimg,'"  alt="',$noimg,'" border="0" src="', $settings['images_url']  ,'/icons/show_sticky.gif" /> ',$noimg,'</div>';
	}
	echo'</div>';
}	


// op_galeria() -> ultimas imagenes bloque
function op_galeria2($memID){
	global $context, $settings, $scripturl, $txt;
	
	$noimg = $context['member']['name'] . $txt['no_image_gallery'];
	
		
	if ($context['img']){
		foreach($context['img'] as $img){
			echo'<a style="margin-left:2px;" href="', $scripturl, '?action=imagenes;sa=ver;id=' . $img['id'] . '" class="tooltip" title="' . $img['commenttotal'] . ' ',$txt['commentsx'],'"><img src="' . $img['filename'] . '" width="115" height="100" /></a>';
		}
		echo'<hr /><div align="center">&nbsp;<img src="', $settings['images_url']  ,'/icons/images.png" />&nbsp;<a href="', $scripturl, '?action=imagenes&usuario=', $context['member']['name'], '">',$txt['go_to_gallery'],'</a></div>';
	}
	else {
		echo'<div class="titlep" style="margin-top:-2px;">',$noimg,'</div>';
	}

}		


// op_comentarios2() -> ultimos comentarios bloque
function op_comentarios2($memID){
	global $context, $settings, $scripturl, $txt, $db_prefix;

	$context['page_title'] = $txt[18];
	$looped = false;
	while(true){
		$request = db_query("SELECT c.id_post, c.id_coment, c.comentario, c.fecha, m.subject, m.ID_TOPIC, c.id_user, m.ID_BOARD 
		FROM ({$db_prefix}comentarios AS c, {$db_prefix}messages AS m)
		WHERE c.id_post = m.ID_TOPIC AND c.id_user = $memID
		ORDER BY c.id_coment DESC
		LIMIT 50", __FILE__, __LINE__);
		if(mysql_num_rows($request) === $maxIndex || $looped)
			break;
		$looped = true;
		$range_limit = '';
	}
	$counter = $reverse ? $context['start'] + $maxIndex + 1 : $context['start'];
	$board_ids = array('own' => array(), 'any' => array());
	$context['cposts'] = array();
	while ($row = mysql_fetch_assoc($request)){
		censorText($row['subject']);
		censorText($row['body']);
		$context['cposts'][] = array(
			'id_coment' => $row['id_coment'],
			'subject' => $row['subject'],
			'ID_TOPIC' => $row['ID_TOPIC'],
			'posterTime' => $row['fecha'],
			'body' => $row['comentario'],
			'ID_BOARD' => $row['ID_BOARD']
		);
	}
	mysql_free_result($request);
	
	echo'<div class="m10">';
	if(!empty($context['cposts'])){
		foreach($context['cposts'] as $cpost){
			echo'<li>
			
						<img title="" src="', $settings['images_url']  ,'/post/icono_'.$cpost['ID_BOARD'].'.gif" />
					
							<a href="'.amigables_post($cpost['ID_TOPIC']),'" title="'.$cpost['subject'].'">
								'.quitarc($cpost['subject']).'
							</a>
						</li>
					';
		}
		if($context['page_index']){
			echo'
			
				<div class="titlep">
					', $context['page_index'], '
			
			</div>';
		}
	}
	else{
		echo'
		
			<div class="titlep" style="margin-top:-2px;">
			<b>', $context['member']['name'], '</b> ',$txt['no_comments'],'
		</div>
		';
	}
	echo'</div>';
}		

function recortar_texto($texto, $limite=100){  
    $texto = trim($texto);
    $texto = strip_tags($texto);
    $tamano = strlen($texto);
    $resultado = '';
    if($tamano <= $limite){
        return $texto;
    }else{
        $texto = substr($texto, 0, $limite);
        $palabras = explode(' ', $texto);
        $resultado = implode(' ', $palabras);
        $resultado .= '...';
    }  
    return $resultado;
}

// funciones obsoletas
function template_showPermissions(){}
function template_statPanel(){}
function template_profile_above(){}
function template_profile_below(){}
function template_theme(){}
function template_notification(){}
function template_pmprefs(){}

?>